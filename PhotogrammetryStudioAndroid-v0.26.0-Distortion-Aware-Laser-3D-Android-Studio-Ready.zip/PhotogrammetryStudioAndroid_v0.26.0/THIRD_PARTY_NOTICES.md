# Third-Party Notices

## OpenCV
v0.3 uses OpenCV through the Android Maven artifact `org.opencv:opencv:4.14.0` for local image feature detection and matching.

OpenCV is distributed under the Apache License 2.0. See the OpenCV project and packaged dependency license for full terms.
