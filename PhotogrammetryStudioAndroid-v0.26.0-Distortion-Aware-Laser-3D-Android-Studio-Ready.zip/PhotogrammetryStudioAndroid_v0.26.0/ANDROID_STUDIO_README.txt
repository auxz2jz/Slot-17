3D Scan Studio - Android Studio package
Version: 0.26.0 (versionCode 38)

OPEN/BUILD
1. Extract the ZIP completely.
2. In Android Studio choose Open and select the PhotogrammetryStudioAndroid_v0.23.0 folder.
3. Let Gradle sync.
4. Build/Run the debug app on the Android device.

v0.23 PURPOSE
- Preserves the v0.22 persistent laser-analysis run history and existing photogrammetry Stages 1-10.
- Adds an exact-scale 12x18 laser calibration preset printed from 4 US Letter sheets per LEFT/RIGHT panel.
- Tiled LEFT and RIGHT PDFs are 4 pages each (A1, A2, B1, B2) with crop/registration marks outside the calibration artwork.
- The finished tiled panel reproduces the existing 12x18 / 35 mm marker geometry; it is a print-format change, not a calibration-geometry change.
- Existing Letter, Legal, Ledger and single-sheet 12x18 laser presets remain available.
- Photo calibration remains unchanged: 9x6 inner corners, exact 25.0 mm squares, 250x175 mm checker pattern. The Letter photo target remains one sheet and can be mounted flat on poster board.
- Tiled/poster-board assembly instructions are exportable in both calibration areas.
- CALIBRATION_PRINT_PACK/ includes all existing targets plus the new tiled pair, instructions and combined budget calibration set.

PRINTING
- Print at 100% / Actual Size.
- Do NOT Fit to Page, shrink, enlarge, crop automatically, or scale.
- For tiled laser panels, trim exactly on crop marks and butt the pieces together on a flat rigid board.
- Vertical tiled seam: 4.25 in from left. Horizontal seam: 9.75 in from top.
- Finished LEFT and RIGHT panels must each measure exactly 12 x 18 in (304.8 x 457.2 mm).
- Mount LEFT + RIGHT at an exact 90-degree inside corner.
- Matte paper/cardstock on poster board or foam board is preferred; avoid glossy lamination.

IMPORTANT
- v0.23 does not change laser extraction math. Marker decoding, laser-plane recovery and metric 3D triangulation remain later milestones.
- Existing saved preset IDs remain backward-compatible.
- v0.23 is a CANDIDATE until Android Studio/device testing passes.

TESTING
Use the in-app Test This Version guide for v0.26.0 and export the version test report when complete.
