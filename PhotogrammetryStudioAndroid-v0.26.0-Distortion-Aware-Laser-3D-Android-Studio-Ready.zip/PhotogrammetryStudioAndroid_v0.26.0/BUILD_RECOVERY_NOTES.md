# v0.8.1 recovery / tooling note

The interrupted v0.8.1 session stalled while checking Kotlin/Gradle tooling, not while editing the app logic.

Observed in the recovery environment:

- Java 21 is installed.
- `kotlinc` is available, but it is a standalone Kotlin 1.9 compiler and is not a substitute for the Android Gradle build.
- No system `gradle` executable is installed.
- The project intentionally does not contain `gradle/wrapper/gradle-wrapper.jar`.
- `gradlew` therefore bootstraps that JAR from `raw.githubusercontent.com` on first use.
- The recovery environment cannot resolve `raw.githubusercontent.com` (`curl: (6) Could not resolve host`).

That network/bootstrap combination explains why an automated "check Gradle tooling" step can sit waiting or retrying instead of reaching compilation.

For v0.8.1 the wrapper bootstrap scripts now use short network timeouts so this failure is fast and visible instead of appearing hung. Android Studio on a normal connected development PC remains the real compile/sync check for this package.


## v0.8.2 note

No additional long tooling probe is used. Local wrapper checks should fail within the existing short bootstrap timeout when raw.githubusercontent.com is unavailable. Android Studio remains the authoritative compile test.
