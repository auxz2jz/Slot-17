# 3D Scan Studio Android — v0.8.2

Android Studio-ready Kotlin + Jetpack Compose prototype for the self-contained 3D Scan Studio project.

## v0.7 dense-stereo milestone

This build adds the first genuinely dense photogrammetry geometry stage while preserving every earlier tested stage.

The **Build dense stereo pair (v0.7)** action appears after a saved bundle-refinement result is marked ready for dense reconstruction. v0.7 deliberately uses the already verified best photo pair first rather than attempting full multi-view dense fusion in one jump.

Pipeline added in v0.7:

1. Load the best verified sparse photo pair.
2. Re-detect ORB features and re-verify epipolar geometry with RANSAC.
3. Recover the relative camera pose.
4. Rectify the two camera views.
5. Compute a dense disparity map using OpenCV StereoSGBM.
6. Reproject valid disparity pixels into 3D.
7. Reject extreme depth outliers and cap exported points for practical mobile storage.
8. Save, preview, and export the first dense-pair point cloud.

## Current reconstruction pipeline

1. CameraX capture / photo import.
2. OpenCV ORB feature detection and adjacent matching.
3. Essential-matrix + RANSAC geometric verification.
4. Two-view sparse triangulation.
5. Largest-connected-component multi-view pose chaining.
6. Shared 3+ view feature tracks.
7. Limited bundle refinement of camera translations and shared 3D points.
8. **Dense stereo from one verified photo pair.**

Scale remains arbitrary. v0.7 assumes zero lens distortion for its first dense test. Multi-pair dense fusion, full rotation/intrinsic bundle adjustment, camera calibration, meshing, texturing, laser scanning, structured-light depth, and hybrid fusion remain later stages.

## Testing

Follow the built-in **Test This Version** guide. The exported v0.7 test report includes the dense-pair metrics automatically. Export the dense report and dense PLY as well when possible.


## v0.8.0 dense-quality correction

v0.7 proved that on-device StereoSGBM can produce a dense pair cloud, but the first test cloud looked stretched/cone-like. The v0.8.0 correction stays on the same dense-reconstruction path and addresses two concrete causes:

- The SGBM disparity search window is now estimated from the rectified, verified pose inliers instead of using a generic fixed range.
- Sparse two-view geometry is used as a broad depth/radius guide to reject far background structure when enough guided samples survive.
- The point-cloud preview uses a robust 95% radius so a handful of extreme outliers do not determine the entire preview zoom.

This remains a one-pair dense milestone. Multi-pair dense fusion remains the next major stage after this corrected pair is validated.


### v0.8.0 milestone
Adds verified multi-pair dense fusion in one shared camera frame. The app evaluates selected connected stereo pairs, skips unstable pair clouds, merges accepted dense geometry, and exports a fused PLY plus detailed pair diagnostics.


## v0.8.1 capture + orientation maintenance

This build keeps the v0.8 dense-fusion milestone and adds the capture workflow requested during testing:

- Single capture.
- Rapid Hold capture.
- Rapid Start/Stop capture with optional 3-second delay.
- 5/sec, 2/sec, 1/sec, 2-second, and 5-second target intervals.
- EXIF orientation normalization before all OpenCV reconstruction stages.
- EXIF orientation audit in the exported version-test report.
- Multi-pair fusion can now run even when the first dense seed pair has fewer than 1,000 points; pair acceptance remains the fusion engine's job.

Rapid still capture remains full-resolution CameraX ImageCapture and is hardware-limited. The app serializes captures so a requested rate that is faster than the phone can save simply runs at the fastest sustainable rate.


## v0.8.2 capture/viewer stabilization

v0.8.2 follows successful v0.8.1 dense-fusion runs on both test3 and test4 and fixes the three usability/capture issues found by the v0.8.1 test guide.

- fixes Hold Rapid stopping after its first photo by keeping the press gesture alive while the Rapid state changes;
- records measured Rapid performance (target interval, photos saved, elapsed time, actual photos/sec, average full-resolution save latency, stop reason);
- preserves the current app screen and test-guide state across Android configuration changes so rotating the phone no longer throws the user back to the project list;
- preserves selected camera capture style/interval/countdown across rotation;
- upgrades every point-cloud preview to full 3-axis inspection: yaw, pitch, roll, pinch zoom, touch gestures, sliders, and Front/Back/Left/Right/Top/Bottom presets;
- allows optional tester notes on successful Works steps as well as Problem steps;
- exports Rapid diagnostics in the version-test report.

This is a stabilization build before the next major surface/mesh reconstruction milestone.

## v0.8.3

v0.8.3 improves large-project dense reconstruction and point-cloud inspection. Dense stereo now prefers a pair inside the refined largest connected camera component, records persistent stage diagnostics, and the point-cloud viewer opens full-screen with 3-axis touch controls, fixed orthogonal-view buttons, pinch zoom, and optional fine-control sliders.

## v0.8.4 fusion-candidate maintenance

v0.8.3 successfully recovered the 175-photo test4 dense stage and produced a fused cloud ready for surface reconstruction. v0.8.4 keeps that reconstruction math and fixes a smaller multi-pair fusion selection issue found in the exported pair diagnostics.

Before choosing the distributed dense pairs, fusion now verifies that each candidate has both source images, both refined camera centers, and a completed shared-world pose. Candidates that cannot be transformed into the shared frame are filtered before selection rather than being chosen and later reported with the ambiguous `Missing refined pose or image file.` reason.

The v0.8.4 in-app test guide specifically retests test4 fusion selection, verifies test3 remains healthy, and checks the new precise diagnostics. Surface/triangle mesh reconstruction remains the next major geometry milestone after this maintenance build passes regression testing.


## v0.9.0 — Stage 7 surface mesh

v0.8.4 device testing passed and improved test4 from 14,191 fused points to 40,922 fused points while test3 remained 41,017 points. v0.9.0 begins the next geometry milestone:

- stable Stage 1–7 reconstruction labels replace old release-number card names as primary UI labels,
- Stage 7 converts the saved Stage 6 fused dense cloud into an experimental local-neighbor triangle mesh,
- robust extreme-point trimming prevents isolated fused outliers from controlling mesh scale,
- voxel reduction keeps the on-device vertex count mobile-friendly,
- adaptive local-neighbor edge/shape checks reject long or degenerate triangle candidates,
- full-screen wireframe mesh preview supports yaw/pitch/roll, zoom, and six orthogonal views,
- mesh results persist with the project and export as report, OBJ, and triangle PLY.

This first mesh is deliberately a validation milestone, not final watertight/production meshing. Later work can improve normal estimation, topology, hole filling, smoothing, calibrated scale, and texture projection.


## v0.9.1 — Stage 7 topology cleanup

v0.9.0 successfully proved on-device triangle generation, persistence, preview, OBJ export, and triangle PLY export. v0.9.1 cleans the topology before later surface-quality work.

The Stage 7 mesher now uses ordered local neighbor fans, enforces a two-face maximum per undirected edge, removes tiny disconnected fragments, compacts unused vertices, and reports topology statistics. Kotlin validation on the real test4/test3 fused clouds produced zero non-manifold edges in both cases.

See `PROJECT_CHECKPOINT.md` for the exact device-test sequence.


## v0.9.2 — reconstruction reset/state consistency

v0.9.1 passed device testing and produced topology-clean Stage 7 meshes with zero non-manifold edges on both test4 and test3.

A device retest exposed a UI-state bug: rerunning Stage 1 correctly deleted saved downstream results, but the already-loaded Stage 7 card could remain visible until Stage 6 explicitly cleared it from memory.

v0.9.2 is a maintenance build that does not change reconstruction or mesh mathematics. It:
- centralizes downstream stage invalidation,
- immediately clears later in-memory cards when an earlier stage is rebuilt,
- clears the matching persisted results at the same time,
- adds **Reset reconstruction stages** with confirmation,
- keeps all project photos/settings during reset,
- clears only generated Stage 1–7 reconstruction results,
- adds a v0.9.2-specific in-app test guide.

After v0.9.2 state handling passes, continue with Stage 7 boundary/hole cleanup and surface-normal/smoothing work.

## v0.10.0 — isolated background jobs + Stage 7 surface quality

v0.9.2 passed its reset/state test, but switching from a project that was actively matching into another project exposed one remaining live-state issue: project files were isolated correctly, while the shared ViewModel progress display could make the second project look active.

v0.10.0 makes heavy reconstruction jobs project-owned. A background job keeps using/saving only its owner project's data, does not publish progress into another selected project, and cannot switch the user back when it finishes. One heavy reconstruction job is allowed at a time for now.

The same build also advances Stage 7. The topology-clean mesh now receives conservative boundary-preserving smoothing, per-vertex normals, OBJ/PLY normal export, and boundary classification into closed loops versus open/branched groups. Hole filling is intentionally deferred until these diagnostics are validated on-device.

See `PROJECT_CHECKPOINT.md` and `V0.10.0_BUILD_NOTES.md` for the exact test sequence and locally validated mesh numbers.


## v0.11.0 — combined diagnostics + conservative hole fill

v0.10.0 passed its project-isolation and surface-quality guide. v0.11.0 reduces repetitive test uploads by adding **Export combined project diagnostics**, a single text export containing Quick Check plus every available Stage 1–7 diagnostic section for the project.

Stage 7 also advances from boundary classification to conservative filling of small/simple closed loops. Open or branched borders are not auto-filled. Local validation fills test4's small four-edge closed loop while deliberately skipping test3's less suitable six-edge loop; both remain at zero non-manifold edges.

See `PROJECT_CHECKPOINT.md` for the exact v0.11.0 device test.

## v0.12.0 — Stage 8 photo color projection

v0.11.0 passed device testing with 7 Works / 0 Problems / 0 Untested. The combined-diagnostics workflow is now the default: one project text export contains Quick Check plus all available detailed stage reports.

v0.12.0 adds the first Stage 8 photo-color milestone. It does not alter Stage 7 topology. Instead it rebuilds the connected camera orientation chain, combines it with Stage 4 refined camera centers, projects Stage 7 mesh vertices into the original EXIF-normalized source photos, and blends up to three strong front-facing photo samples per vertex.

Stage 8 provides:
- project-owned background execution;
- camera-pose recovery and per-camera contribution diagnostics;
- colored-vertex coverage statistics;
- in-app colored mesh preview;
- persistent Stage 8 report/color data;
- vertex-colored PLY export with normals + RGB + faces;
- vertex-colored OBJ export using the common `v x y z r g b` extension;
- automatic Stage 8 inclusion in Combined Project Diagnostics.

This is deliberately a vertex-color validation milestone, not yet a full UV texture atlas. The next texture step after device validation is triangle-level visibility/occlusion work followed by UV/texture-atlas generation.


## v0.13.0 — visibility-refined color + Stage 9 texture source assignment

v0.12.0 passed 8 Works / 0 Problems / 0 Untested. It proved that original scan photographs can be projected back onto the Stage 7 mesh, but test4 recovered only 72/100 connected camera world poses and vertex-color coverage remained partial.

v0.13.0 strengthens Stage 8 with short-gap pose bridging and a coarse depth/visibility rejection pass, then adds **Stage 9 — Texture Source Assignment**. Stage 9 chooses a visibility-approved source photo for each usable mesh triangle and stores normalized source-image coordinates for the triangle corners. This is the measurable preparation step immediately before a UV atlas.

Combined Project Diagnostics now covers Quick Check + Stages 1–9. Stage 8/9 remain appearance metadata and do not alter Stage 7 geometry.

Intended Android Studio package:
`PhotogrammetryStudioAndroid-v0.13.0-Stage9-Texture-Source-Assignment-Android-Studio-Ready.zip`

## v0.14.0 — Stage 10 UV texture atlas

v0.13.0 passed 8 Works / 0 Problems / 0 Untested. Test4 reached 29.3% triangle-source coverage after recovering all 100 connected camera poses; test3 reached 18.19% while retaining all 41 camera poses.

v0.14.0 converts those real Stage 9 assignments into the first conventional textured-model export. Each assigned triangle gets a padded photo-derived atlas patch and UV coordinates. Unassigned faces remain gray rather than receiving fabricated image data.

Stage 10 exports a single ZIP containing `textured_model.obj`, `texture_atlas.mtl`, and `texture_atlas.png`, plus optional individual atlas PNG/report exports. Combined Project Diagnostics now covers Stages 1–10.


## v0.15.0 — UV islands + in-app textured preview

v0.14.0 proved conventional OBJ/MTL/PNG texture export. v0.15.0 replaces the one-triangle-per-tile atlas with connected same-photo UV islands, adds atlas occupancy diagnostics, and adds a rotatable in-app textured model preview using the actual saved UVs.

The exported desktop package remains `textured_model.obj` + `texture_atlas.mtl` + `texture_atlas.png`. Keep all three files together when opening the OBJ in MeshLab or Blender.


## v0.16.0 — texture coverage recovery + exposure normalization

v0.15.0 passed all eight device-test steps. test4 retained 3,768 textured faces (29.26%) while proving connected same-photo UV islands and the in-app textured preview. v0.16.0 keeps that geometry/UV-island foundation and targets the two largest remaining appearance limitations.

Stage 9 now keeps strict three-vertex visibility assignments as first choice, then may recover a previously unassigned face only when all three corners still have clean positive-depth/in-image/front-facing projections and at least two of the three pass the coarse visibility test. Stage 10 estimates relative source-photo brightness and applies a conservative clamped luminance gain before copying photo regions into the atlas.

No Stage 7 geometry changes are made. The device test compares Stage 9 coverage against the v0.15 baselines (test4 29.26%, test3 18.19%) and checks that the textured preview remains correctly aligned.



## v0.17.0 — neighbor-consistent texture recovery

v0.16 improved texture coverage slightly without introducing mapping failures. v0.17 keeps the strict and conservative v0.16 assignment paths, then uses mesh-edge continuity for still-unassigned faces: at least two already-textured edge neighbors must agree on the same source photo before that photo is considered for the missing face.

The capture guidance card is also more specific about user technique because overlap, lens consistency, multiple height rings, sharpness and even lighting materially affect reconstruction quality.

## v0.18.0 — guided camera calibration

After v0.17 texture-source recovery plateaued, the next accuracy milestone is measured camera calibration instead of increasingly loose source-assignment heuristics.

v0.18 adds a Camera Calibration screen, a printable Letter-size 9×6-inner-corner checkerboard with 25 mm squares, import of 15–25 calibration views, OpenCV intrinsic/distortion solving, RMS quality reporting, persistent lens profiles, and calibrated focal/principal-point use in compatible reconstruction camera matrices.

Reflective scanner dots and coded fiducial tape are useful future scan-assistance modes, but they are intentionally kept separate from camera calibration: calibration measures lens geometry; markers improve tracking/pose or provide scale references.

## v0.19.0 — Laser Line Lab foundation

Camera calibration remains available but is not required for the new 2D laser-line extraction lab. Laser Scan and Hybrid Scan projects can now import a matched laser-OFF / laser-ON frame pair, select red/green/blue laser color, tune a signal threshold, extract a sub-pixel stripe center per image row, preview the detected line, and export a diagnostic report/overlay.

This is intentionally not yet a 3D laser scanner. Metric triangulation will follow camera calibration, laser-plane calibration, and turntable/movement calibration. See `LASER_LINE_RESEARCH.md` for the open-source reference projects and licensing notes.

## v0.20.0 — selectable calibration target sizes

v0.20 adds persistent physical-target presets for both calibration workflows. Photo calibration can use either **US Letter 8.5×11** or **12×18** while preserving the same 9×6-inner-corner / 25 mm-square calibration geometry. The selected preset is saved into new camera-calibration profiles for traceability.

The Laser Line Lab can select **US Letter** or **12×18** DAVID-style calibration backgrounds and export the corresponding LEFT/RIGHT PDFs. These laser targets are preparatory physical references; v0.20 does not yet decode the ArUco background into a laser plane or perform 3D laser triangulation.

All printable PDFs plus a print-shop instructions sheet are bundled in the app assets and in `CALIBRATION_PRINT_PACK/` for easy access from the Android Studio project.


## v0.21.0 — standard copy-size calibration targets

The calibration preset system now supports the three common US copy sizes: **Letter 8.5×11**, **Legal 8.5×14**, and **Ledger/Tabloid 11×17**. The existing **12×18** preset remains available as an optional poster format for backward compatibility.

All photo calibration presets use the same physical 9×6-inner-corner checkerboard with exact 25.0 mm squares (250×175 mm pattern). The app now displays the selected page dimensions in inches and millimeters and records those dimensions in calibration/test diagnostics.

Laser calibration-background presets now include LEFT/RIGHT pairs for Letter, Legal, Ledger and 12×18. Each laser preset records its physical panel dimensions and marker size. The current laser engine remains the v0.19 OFF/ON 2D stripe extractor; marker decoding, laser-plane recovery and 3D triangulation are still later milestones.


## v0.22 — Persistent laser threshold-run history

Every Laser Line Lab Analyze press now appends a bounded per-project diagnostic run instead of erasing the threshold experiment. Recent runs are visible in-app and the full history exports as cross-platform `laser_analysis_history.jsonl`. The laser extraction algorithm itself is unchanged. Slot-8 now has shared Android/Windows coordination docs; Windows implementation is not started yet.


## v0.23 - Tiled Letter laser calibration panels

v0.23 keeps all v0.22 laser-history behavior and adds a budget print path for the existing 12x18 laser calibration geometry. A new **12x18 tiled (4 Letter sheets)** preset exports LEFT and RIGHT as four-page Letter PDFs (A1/A2/B1/B2). The finished panel remains 12x18 in with the same 35 mm marker geometry as the single-sheet poster preset.

The tiled seams are placed through clear areas (4.25 in from the left and 9.75 in from the top) rather than through the large coded markers. Crop/registration marks are outside the calibration field. Software reassembly was verified pixel-identical to the original v0.22 12x18 assets at 120 dpi.

Photo/camera calibration is intentionally unchanged: the Letter checkerboard remains one sheet with 9x6 inner corners, 25.0 mm squares, and a 250x175 mm pattern. It can be mounted flat on poster board without enlargement. Existing Letter, Legal, Ledger and single-sheet 12x18 presets remain available.

## v0.24.0 — pin-align four-Letter calibration

v0.24 replaces the v0.23 trim-only tiled workflow with a user-alignment workflow designed around ordinary **US Letter 8.5x11 paper**. Matching crosshairs live on sacrificial tabs outside the finished target. The pages may be overlapped, pinned through matching crosshair center dots, straight-cut through both layers, then butted edge-to-edge so no paper overlap covers the active calibration artwork.

Laser LEFT/RIGHT panels preserve the original 12x18 in / 35 mm-marker geometry. Camera calibration gains an optional genuinely larger four-sheet target: 9x6 inner corners with 38.1 mm (1.5 in) squares, producing a 15x10.5 in checkerboard on a 16x11.5 in finished board. The existing 25 mm targets remain available.

Current Android candidate: **v0.24.0 / versionCode 36**, pending Android Studio/device verification.

## v0.26.0 — distortion-aware reconstruction + laser single-frame 3D

v0.26 is the first build that consistently uses the saved camera distortion model in downstream geometry rather than saving k1/k2/p1/p2/k3 only for later work.

Photogrammetry changes:
- Stage 1 ORB descriptors intentionally remain on the original source pixels so the source photographs are never destructively resampled.
- Stages 2–4 undistort matched/track coordinates before epipolar geometry, pose recovery, triangulation and bundle observations.
- Stages 5–6 use the measured distortion coefficients during stereo undistort/rectify instead of a zero-distortion matrix.
- Stage 6 evaluates up to 12 quality/distribution-balanced connected stereo pairs (previously 6) and raises the fused-point cap to 80,000.
- Stages 8–9 project reconstructed geometry back into the original source raster using the calibrated Brown-Conrady distortion model, so Stage 10 inherits distortion-aware UV/source assignments.
- Bundle track budget rises from 1,200 to 1,600 strongest tracks while preserving the existing memory-conscious limited-bundle design.

Laser changes:
- Laser extraction now tests both row-wise and column-wise weighted-centroid sampling and automatically chooses the stronger orientation. This is critical for the current nearly-horizontal hand-swept laser line.
- The new laser-plane stage detects the known DICT_4X4_50 markers on both LEFT and RIGHT calibration sheets.
- Each physical sheet pose is solved as one rigid multi-marker panel using the known printed marker spacing and active camera calibration.
- The app reports the measured angle between the two physical panels so the 90-degree setup can be checked rather than assumed.
- Laser stripe pixels on the known backdrop planes generate metric 3D calibration points; those points fit the instantaneous hand-swept laser plane.
- The current frame is then triangulated into a millimeter-scale PLY. A calibration-only frame may contain no non-backdrop/object points; multi-frame hand-sweep accumulation is intentionally the next laser milestone.

Current status: CANDIDATE until Android Studio/device testing passes.
