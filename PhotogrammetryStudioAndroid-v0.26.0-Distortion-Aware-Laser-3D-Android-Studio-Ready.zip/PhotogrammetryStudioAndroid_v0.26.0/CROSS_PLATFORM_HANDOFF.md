# 3D Scan Studio — Cross-Platform Handoff

3D Scan Studio is one product with separate Android and future Windows implementations.

## Ownership

- Android implementation: owned by the Android development workflow.
- Windows implementation: **NOT STARTED**; future Windows agent owns Windows source/build/test/diagnostic files.
- Shared product behavior and interchange schemas: maintained in Slot-8 `shared/`.

Do not reorganize Android source merely to make it look like Windows source. Share product intent, algorithms, test vectors, and file formats where practical; keep platform implementation details separate.

## Laser analysis history v1

Canonical interchange file: `laser_analysis_history.jsonl`

Each line is one UTF-8 JSON object representing one Analyze attempt. Required stable concepts include schemaVersion, runId, timestampEpochMs, timestampUtc, laserColor, threshold, success, and durationMs. Failure records may also include a full errorStackTrace. Successful rows may carry laser extraction metrics; failed rows carry error details. Readers must ignore unknown fields.

The detailed latest laser report/preview is separate from this history.

See Slot-8 `shared/DATA_FORMATS_AND_INTERFACES.md` for the durable schema contract.


## Tiled calibration print format

v0.23 adds a platform-neutral print option: the existing 12x18 laser calibration geometry may be distributed as four US Letter pages per LEFT/RIGHT panel as long as exact physical scale and marker layout are preserved. This is a print/export representation, not a different laser-calibration geometry. Future Windows implementation should expose equivalent physical-target semantics if calibration printing is implemented.
