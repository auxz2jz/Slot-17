# Android Feature Roadmap — v0.8.2

Status legend: DONE / PARTIAL / TODO.

## Foundation
- DONE — Kotlin + Jetpack Compose project.
- DONE — Local projects and Photo / Laser / Hybrid modes.
- DONE — CameraX capture and multi-photo import.
- DONE — Scrollable project page and photo strip.
- DONE — Version-specific in-app Test This Version guide.

## Photogrammetry
- DONE — Quick photo-set checks.
- DONE — v0.3: real on-device ORB feature detection with OpenCV.
- DONE — v0.3: adjacent-photo descriptor matching and overlap quality report.
- PARTIAL — Match-quality readiness check for the next SfM stage.
- TODO — Camera intrinsic calibration/focal model.
- TODO — Geometric match filtering with essential/fundamental matrix + RANSAC.
- TODO — Relative camera-pose estimation.
- TODO — Multi-view structure-from-motion.
- TODO — Sparse 3D point cloud viewer.
- TODO — Dense reconstruction.
- TODO — Mesh + texture + export.

## Laser / Hybrid / Depth
- PARTIAL — Project types and storage foundation.
- TODO — Camera calibration and laser triangulation.
- TODO — ESP32/Arduino motion-controller integration.
- TODO — Turntable and laser-carriage control.
- TODO — Structured-light/depth camera integration.
- TODO — Hybrid alignment/fusion.

## Permanent testing rule
Every future test build must include an in-app guide that explains what changed, exactly what to test, expected results, and Works/Problem controls.


## v0.3.1
- DONE — Persist feature-match reports with each project.
- DONE — Clear stale match reports when the photo set changes.
- DONE — Scrollable View All adjacent-pair results.
- DONE — Export complete feature-match results to .txt.
- DONE — Delete projects with confirmation.
- DONE — Per-test Problem explanation field.
- DONE — Export version test results and explanations to .txt.


## v0.4.0 — first sparse 3D reconstruction

- DONE — Essential-matrix geometric verification with RANSAC.
- DONE — Relative two-camera pose recovery.
- DONE — Best adjacent pair selection based on recovered-pose inliers.
- DONE — Sparse 3D point triangulation.
- DONE — Persistent sparse reconstruction report.
- DONE — Rotatable sparse point-cloud preview.
- DONE — Sparse reconstruction text export.
- DONE — ASCII PLY point-cloud export.
- DONE — Photo changes invalidate stale feature and sparse reports.
- TODO — Multi-view pose chaining.
- TODO — Track features across more than two images.
- TODO — Bundle adjustment.
- TODO — Camera calibration profiles / refined intrinsics.
- TODO — Dense point cloud.
- TODO — Mesh and texture.


## v0.5 multi-view milestone

- DONE — Sequential adjacent-camera pose chaining across the photo sequence.
- DONE — Merge triangulated points from connected adjacent pairs into one sparse cloud.
- DONE — Persist multi-view report and cloud.
- DONE — Export multi-view report and ASCII PLY.
- DONE — View camera-path pair details.
- DONE — v0.5-specific test guide.
- TODO — True multi-image feature tracks across non-adjacent views.
- TODO — Bundle adjustment to jointly optimize camera poses and 3D points.
- TODO — Loop-closure/drift correction.
- TODO — Dense reconstruction after optimized sparse geometry.


- v0.5.1: multi-view no longer aborts at the first weak adjacent link; it evaluates all pairs and reconstructs the largest connected camera segment.


## v0.6.0 - shared-track bundle refinement

- DONE — Build shared ORB feature tracks observed in at least 3 connected views.
- DONE — Re-triangulate multi-view shared tracks in the connected camera component.
- DONE — Limited bundle refinement of camera translations + 3D points with fixed rotations/intrinsics.
- DONE — Robust Huber weighting and post-refinement high-error track filtering.
- DONE — Before/after RMS reprojection-error reporting.
- DONE — Persist/export refinement report and refined sparse PLY.
- DONE — v0.6-specific in-app test guide.
- TODO — Full bundle adjustment including camera rotations and optional intrinsics.
- TODO — Graph/loop-closure constraints and recovery of disconnected camera components.
- TODO — Dense reconstruction after bundle refinement is validated.


## v0.6.1 testing/reporting maintenance
- DONE — Test guide accessible from project list, project screen, and camera screen.
- DONE — Plain-language RMS improvement display.
- DONE — Automatic diagnostic snapshot embedded in exported version test reports.
- DONE — Stable report fingerprints + project IDs in exported reports and PLY headers.
- DONE — Device/build metadata in test report.

## v0.7.0 — first dense stereo pair
- DONE — Re-verify the known-good sparse photo pair before dense processing.
- DONE — Stereo rectification with recovered relative pose.
- DONE — OpenCV StereoSGBM disparity computation on downscaled working images.
- DONE — Reproject valid disparity into a dense 3D point cloud.
- DONE — Depth outlier filtering and deterministic point-count cap for mobile export.
- DONE — Persistent dense-pair report and point cloud.
- DONE — Dense cloud preview, text report export, and fingerprinted PLY export.
- DONE — Dense metrics included in the automatic version-test diagnostic snapshot.
- DONE — v0.7-specific in-app test guide.
- TODO — Fuse dense clouds from multiple verified photo pairs.
- TODO — Full rotation/intrinsic bundle adjustment and calibrated lens distortion.
- TODO — Dense-cloud cleanup / normal estimation.
- TODO — Surface mesh generation and texture projection.


## v0.7.1 — adaptive dense disparity correction

- TODO/TESTING — Re-run the verified dense pair using an adaptive disparity window derived from rectified pose inliers.
- TODO/TESTING — Confirm observed disparity median lies inside the SGBM search interval.
- TODO/TESTING — Apply sparse-depth/radius guidance when enough dense samples overlap the verified sparse object band.
- DONE — Point-cloud preview zoom now uses a robust 95% extent instead of the single farthest point.
- DONE — v0.7.1 test guide exports diagnostics before any photo-change invalidation step.
- NEXT — Multi-pair dense fusion after this corrected single-pair result passes.

## v0.8.0 — Multi-pair dense fusion
- v0.7.1 device test passed 10/10.
- Adds a separate multi-pair dense fusion stage after the corrected single-pair dense result.
- Rebuilds connected camera orientations, uses v0.6 refined camera centers, densifies a distributed subset of connected stereo pairs, transforms accepted pair points into one shared world frame, rejects unstable/too-sparse pair clouds, globally trims/voxel-downsamples the result, and persists/exports a fused PLY/report.
- The v0.8 guide checks fused/ skipped pair diagnostics, fused point count, cloud preview, persistence, and report/PLY export.
- Surface/mesh reconstruction remains the next milestone after fusion quality is validated.


## v0.8.1 — Rapid capture, orientation normalization, and fusion gate fix

- DONE — Camera capture modes: Single, Rapid Hold, and Rapid Start/Stop.
- DONE — Rapid target intervals: 5/sec, 2/sec, 1/sec, every 2 sec, every 5 sec.
- DONE — Optional 3-second countdown for tap-once Rapid Start/Stop, useful for mounted/rotating rigs.
- DONE — Rapid still capture is serialized and hardware-limited; requested rates never queue uncontrolled overlapping full-resolution captures.
- DONE — Project refresh/analyze runs once after a Rapid sequence rather than once per saved frame.
- DONE — Shared EXIF-aware bitmap loader normalizes orientation/mirroring before OpenCV feature, sparse, multi-view, bundle, dense-stereo, and dense-fusion stages.
- DONE — Project thumbnails use the same EXIF-normalized loader.
- DONE — Version test report includes an EXIF orientation audit for every photo in the selected project.
- DONE — Photo-set resolution consistency ignores portrait/landscape width-height swapping.
- DONE — Multi-pair dense fusion is no longer hidden/blocked solely because the first dense seed pair is below the old 1,000-point readiness threshold; a non-empty seed is enough to let fusion evaluate connected pairs.
- TEST — Verify Rapid Hold and Rapid Start/Stop on the Galaxy S22 Ultra.
- TEST — Verify mixed portrait/landscape captures match correctly after EXIF normalization.
- TEST — Re-run test3 multi-pair dense fusion; its 713-point seed pair should no longer hide/disable fusion.
- NEXT — Validate multi-pair dense fusion quality before surface/mesh reconstruction.

## v0.8.0 device-test result carried into v0.8.1

- test3 contained 95 photos with 93/94 adjacent pairs usable/strong.
- Sparse stage found 1,291 points on the best pair.
- Largest multi-view component connected 41/95 cameras and produced 19,400 combined sparse points.
- Bundle refinement used 41 cameras, 1,200 selected tracks, 4,582 observations, retained 931 points, and improved RMS from 8.6746 px to 2.2359 px.
- Corrected dense seed produced 713 points and was marked readyForDenseFusion=false by the old single-pair threshold.
- Because the v0.8 UI/ViewModel required readyForDenseFusion=true, multi-pair fusion never got a chance to evaluate the other connected pairs. v0.8.1 fixes that gate rather than changing the fusion engine itself.


## v0.8.2 — Rapid reliability + 3-axis cloud inspection

### DONE in this package
- v0.8.1 reconstruction result review: test3 fused 6 pair clouds into 40,836 points; test4 fused 6 pair clouds into 59,801 points. Multi-pair dense fusion is considered functionally validated for this milestone.
- Fixed Hold Rapid gesture cancellation that could stop the sequence after one photo.
- Added measured Rapid diagnostics and version-report export of the last 12 Rapid runs.
- Fast target rates are now explicitly targets; the UI/report records the actual sustained full-resolution rate instead of treating a hardware-limited rate as a failure.
- Preserved navigation/test-guide/capture settings across portrait/landscape configuration changes.
- Replaced the one-axis point-cloud viewer with yaw/pitch/roll + zoom gestures, sliders, reset, and six orthogonal preset views.
- Added optional notes for successful test steps, not only failed steps.
- Added a dedicated v0.8.2 in-app validation guide.

### NEXT after device validation
- First surface/mesh reconstruction from the validated fused dense cloud.

- 2026-09-22 — v0.8.2 device test: 8 Works / 1 Problem. Rapid Hold now works. Galaxy S22 Ultra full-resolution Rapid throughput measured about 1.5–1.7 photos/sec at the 5/sec target, while 1/sec hit target accurately. Mixed EXIF orientations normalized successfully. The 3-axis viewer worked but controls were crowded. test3 rebuilt all stages successfully; test4 (175 photos) completed feature matching, sparse, 100-camera multi-view, and bundle refinement but pressing corrected dense stereo did not produce a saved dense report.
- 2026-09-22 — v0.8.3 prepared as large-project dense recovery + viewer usability. Root-cause analysis found test4's global best sparse pair (cameras 54→55) lies outside the largest refined multi-view component (cameras 57→156). v0.8.3 keeps the successful sparse pair when it belongs to the refined component; otherwise it chooses the strongest connected adjacent pair for dense stereo. Persistent dense-stage progress/failure diagnostics are now exported in the version report. The point-cloud viewer is now full-screen with fixed preset buttons and optional sliders so the cloud remains visible.

## v0.8.4 — fusion candidate preflight robustness

- 2026-09-22 — v0.8.3 device test passed 6 Works / 0 Problems / 0 Untested.
- test3 remained healthy: 95 photos, 41 connected cameras, 30,000-point dense seed, 6/6 selected dense pairs fused, 41,017 fused points, ready for surface reconstruction.
- test4 recovered the former v0.8.2 blocker: 175 photos, 100-camera refined component, bundle RMS 12.3533 -> 2.2892 px, connected-component dense seed produced 30,000 points, fusion produced 14,191 points, ready for surface reconstruction.
- FOUND — test4 fusion selected two later pairs whose own relative pose existed but whose first camera had no completed shared-world pose after an earlier break in the separately rebuilt rotation chain. They were reported with the overly broad `Missing refined pose or image file.` message.
- DONE — v0.8.4 now preflights dense-fusion candidates before distributed selection.
- DONE — Candidate eligibility now requires both image files, both refined camera centers, and a recovered world pose for the first camera in addition to the existing connected/pose-inlier checks.
- DONE — Pairs that cannot be transformed into the shared world frame are filtered before the six distributed pairs are selected, so usable candidates can replace them.
- DONE — Defensive selected-pair failures now report the exact missing prerequisite: camera index, first/second image, refined camera center, or recovered world pose.
- DONE — Dense-fusion reports record how many candidates were removed by v0.8.4 preflight and report the remaining eligible candidate count.
- DONE — v0.8.4-specific in-app test guide covers test4 preflight behavior, test4 fusion readiness, test3 regression, and precise diagnostics.
- NEXT — After v0.8.4 regression testing, begin surface/triangle mesh reconstruction.


## v0.8.4 device-test result

- PASSED — 6 Works / 0 Problems / 0 Untested.
- test3: 40 eligible candidates, 6/6 selected pairs fused, 41,017 fused points, ready for surface reconstruction.
- test4: v0.8.4 preflight filtered 27 unusable connected candidates before selection; 4/6 selected pairs fused; 40,922 fused points; ready for surface reconstruction.
- CONFIRMED — preflight candidate filtering fixed the v0.8.3 missing-world-pose selection issue without regressing test3.

## v0.9.0 — Stage 7 experimental surface mesh

- DONE — Version bump to 0.9.0 / versionCode 19.
- DONE — Reconstruction UI uses stable Stage 1 through Stage 7 names rather than historical release numbers as primary card titles.
- DONE — Primary action buttons explicitly identify the next stage.
- DONE — Version-test instructions quote exact visible card/button labels.
- DONE — Stage 7 builds a local-neighbor triangle mesh from the Stage 6 fused dense cloud.
- DONE — Robust 1%/99% coordinate bounds with padding trim isolated extreme points before mesh-scale selection.
- DONE — Adaptive voxel reduction targets a mobile-friendly mesh vertex count.
- DONE — Spatial-hash local-neighbor lookup avoids an all-pairs O(n²) search.
- DONE — Edge-length, aspect-ratio, and non-degenerate-area checks reject unstable triangle candidates.
- DONE — First mesh is capped at 30,000 triangles for on-device safety.
- DONE — Mesh persists with the project.
- DONE — Full-screen wireframe mesh viewer with yaw/pitch/roll, zoom, reset, and six orthogonal views.
- DONE — Export Stage 7 report, OBJ, and face-containing ASCII PLY.
- DONE — v0.9.0 in-app test guide covers exact stage labels, test4 mesh, viewer, exports, persistence, test3 regression, and report export.
- LOCAL VALIDATION — mesher tested against uploaded v0.8.4 fused clouds: test4 -> 5,795 mesh vertices / 30,000 triangle cap; test3 -> 2,840 mesh vertices / 28,555 triangles.
- TEST — Android Studio compile/install and device validation.
- NEXT — improve surface quality/topology after the first Stage 7 device result; then normals/smoothing/hole filling and texture projection.

## External USB camera roadmap clarification

- TODO — Add a camera-source selector (Phone camera / USB UVC / future network camera).
- TODO — Enumerate and request permission for Android USB UVC cameras.
- TODO — Capture still images from a supported UVC camera directly into the current scan project; do not require extracting frames from video.
- TODO — Expose manual focus/exposure/resolution controls when the UVC device supports them.
- NOTE — The phone camera remains the default until external-camera support is implemented; a high-quality fixed UVC/global-shutter camera may be preferable for a dedicated turntable rig, while a low-resolution webcam is likely worse than the phone for photogrammetry.


## v0.9.1 — Stage 7 topology cleanup

- PASSED — v0.9.0 device guide: 7 Works / 0 Problems / 0 Untested.
- FOUND — v0.9.0 test4 exported 11,137 non-manifold edges and many unused vertices.
- FOUND — v0.9.0 test3 exported 11,600 non-manifold edges.
- DONE — ordered local tangent/fan triangle proposals.
- DONE — maximum two incident faces per undirected edge.
- DONE — tiny disconnected fragment filtering.
- DONE — compact unused vertices and reindex faces.
- DONE — Stage 7 topology statistics in card/report/test export.
- DONE — Ready for export requires zero non-manifold edges.
- KOTLIN VALIDATION — test4: 5,172 vertices / 12,872 faces / 0 non-manifold edges.
- KOTLIN VALIDATION — test3: 2,144 vertices / 4,938 faces / 0 non-manifold edges.
- TEST — Android Studio compile/install and v0.9.1 device guide.
- NEXT — normals/smoothing/component quality and conservative hole strategy before textures.


## v0.9.2 — pipeline reset and stale-card fix

- PASSED — v0.9.1 device guide: 7 Works / 0 Problems / 0 Untested.
- PASSED — test4: 5,172 mesh vertices / 12,872 faces / 0 non-manifold edges.
- PASSED — test3: 2,144 mesh vertices / 4,938 faces / 0 non-manifold edges.
- FOUND — downstream files were invalidated correctly when rebuilding an earlier stage, but Stage 7 could remain visible from stale in-memory state.
- DONE — centralized stage invalidation for both memory and persisted files.
- DONE — rebuilding Stage 1 immediately clears Stages 1–7 before matching starts.
- DONE — rebuilding Stage 2 clears Stages 2–7; Stage 3 clears 3–7; and so on.
- DONE — visible **Reset reconstruction stages** action with confirmation.
- DONE — reset preserves project photos and metadata.
- DONE — reset clears generated Stage 1–7 reports/clouds/meshes only.
- DONE — v0.9.2 version test guide covers cancel, reset, stale-card clearing, persistence, and topology regression.
- TEST — Android Studio/device v0.9.2 guide.
- NEXT — Stage 7 boundary/hole cleanup, normals and smoothing after state-management regression passes.

## v0.10.0 — project isolation + Stage 7 surface quality

- PASSED — v0.9.2 guide: 7 Works / 0 Problems / 0 Untested.
- FOUND — background work remained tied to the correct project on disk, but global live StateFlows could make another selected project display the owner's progress.
- DONE — immutable owner project for every heavy Stage 1–7 job.
- DONE — owner-only live progress/result publishing.
- DONE — background completion never changes selected project.
- DONE — one heavy reconstruction job at a time with explicit project-name busy message.
- RULE — no project-to-project data sharing unless a future explicit merge/compare workflow is added.
- DONE — Stage 7 two-pass boundary-preserving smoothing.
- DONE — Stage 7 per-vertex normal calculation.
- DONE — OBJ normal export (`vn` + normal-referenced faces).
- DONE — PLY normal export (`nx`, `ny`, `nz`).
- DONE — boundary closed-loop/open-or-branched classification.
- DONE — boundary branch-vertex diagnostics.
- LOCAL VALIDATION — test4: 5,172 vertices / 12,872 faces / 0 non-manifold / 5,172 normals.
- LOCAL VALIDATION — test3: 2,144 vertices / 4,938 faces / 0 non-manifold / 2,144 normals.
- TEST — Android Studio/device v0.10.0 guide.
- NEXT — conservative small/simple closed-loop filling, then texture-preparation work.


## v0.11.0 — combined diagnostics + safe closed-loop fill

- PASSED — v0.10.0 guide: 8 Works / 0 Problems / 0 Untested.
- DONE — one **Combined Project Diagnostics** text export per project.
- DONE — combined export includes Quick Check and complete available Stage 1–7 diagnostics.
- DONE — rebuilt/new stage results automatically appear in the next combined export.
- DONE — geometry PLY/OBJ remains separate so the text diagnostic stays readable and upload-friendly.
- DONE — simple closed-boundary loop extraction.
- DONE — conservative loop size/perimeter/radius/planarity checks.
- DONE — conservative centroid-fan shape/edge checks before filling.
- DONE — safe cap adds one center vertex and one triangle per boundary edge.
- DONE — open/branched boundary groups are never auto-filled.
- DONE — Stage 7 reports loops-before / filled / remaining / added vertices / added faces / skipped loops.
- DONE — skipped safe-fill candidates record a human-readable reason.
- VALIDATED — test4 real fused cloud: 1 loop safely filled, 0 non-manifold edges.
- VALIDATED — test3 real fused cloud: unsafe loop intentionally skipped, 0 non-manifold edges.
- TEST — Android Studio/device v0.11.0 guide.
- NEXT — texture-preparation stage: image/camera selection, UV strategy, and first photographic texture projection experiments.

## v0.12.0 — Stage 8 photo color projection

- PASSED — v0.11.0 guide: 7 Works / 0 Problems / 0 Untested.
- PASSED — Combined Project Diagnostics replaces repetitive Stage 1–7 text uploads and remains the normal diagnostic workflow.
- DONE — versionName 0.12.0 / versionCode 24.
- DONE — Stage 8 project-owned photo color projection.
- DONE — rebuild connected camera orientation chain for texturing.
- DONE — reuse Stage 4 refined camera centers and Stage 7 vertices/normals.
- DONE — EXIF-normalized source-photo projection.
- DONE — front-facing, positive-depth, image-bounds and center/distance view scoring.
- DONE — blend up to three strongest photo samples per mesh vertex.
- DONE — persistent Stage 8 report and vertex-color array.
- DONE — per-camera projected/selected contribution diagnostics.
- DONE — colored Stage 8 preview in the existing 3D viewer.
- DONE — colored PLY export with normals, RGB and faces.
- DONE — vertex-colored OBJ export.
- DONE — Combined Project Diagnostics expanded to Stages 1–8.
- TEST — Android Studio/device v0.12.0 guide.
- NEXT — triangle visibility/occlusion refinement, then UV coordinates and a texture atlas.


## v0.13.0 — Stage 8 visibility refinement + Stage 9 texture sources

- PASSED — v0.12.0 guide: 8 Works / 0 Problems / 0 Untested.
- PASSED — test4 Stage 8: 55.67% vertex color, 72/100 recovered connected camera poses, 65 cameras contributing best colors.
- PASSED — test3 Stage 8: 46.60% vertex color, 41/41 recovered camera poses, 35 cameras contributing best colors.
- DONE — versionName 0.13.0 / versionCode 25.
- DONE — short-gap camera orientation bridging up to four connected-camera positions back.
- DONE — recovered adjacent vs bridged pose-link diagnostics.
- DONE — coarse per-camera depth/visibility map from projected Stage 7 vertices.
- DONE — reject substantially occluded vertex-color candidates before sampling.
- DONE — Stage 8 visibility-rejection diagnostics.
- DONE — Stage 9 triangle texture-source assignment.
- DONE — require all 3 face vertices visible/in-bounds in a source camera.
- DONE — reject projected face area below one pixel.
- DONE — per-face best-source-photo scoring.
- DONE — normalized source-photo coordinates for each face corner.
- DONE — Stage 9 assignment persistence and per-camera diagnostics.
- DONE — triangle source-map TSV export.
- DONE — Combined Project Diagnostics expanded through Stage 9.
- TEST — Android Studio/device v0.13.0 guide.
- NEXT — real UV atlas packing/rasterization and UV-mapped model export if Stage 9 coverage is healthy.

## v0.14.0 — Stage 10 UV texture atlas

- PASSED — v0.13.0 guide: 8 Works / 0 Problems / 0 Untested.
- PASSED — test4 Stage 8 recovered 100/100 connected camera poses after gap bridging.
- PASSED — test4 Stage 9 assigned 3,768 / 12,876 triangles (29.3%) using 90 cameras.
- PASSED — test3 Stage 9 assigned 898 / 4,938 triangles (18.19%) using 39 cameras; all 41/41 connected camera poses were available.
- DONE — versionName 0.14.0 / versionCode 26.
- DONE — Stage 10 one-tile-per-assigned-triangle UV atlas rasterization.
- DONE — source photo triangle patches are copied into a padded PNG texture atlas.
- DONE — Stage 9 unassigned faces remain explicitly gray/untextured; no invented photo content.
- DONE — UV-mapped OBJ export with separate textured and untextured materials.
- DONE — MTL export references texture_atlas.png.
- DONE — one-click textured-model ZIP package contains OBJ + MTL + PNG.
- DONE — individual texture atlas PNG export.
- DONE — Stage 10 report persisted per project.
- DONE — Combined Project Diagnostics extended through Stage 10.
- DONE — Stage 10 participates in project isolation and upstream invalidation.
- TEST — Android Studio/device v0.14.0 guide.
- NEXT — validate atlas orientation/seams in real viewers, then improve UV island packing / seam blending and raise Stage 9 assignment coverage.


## v0.15.0 — connected UV islands + textured preview

- PASSED — v0.14.0 guide: 8 Works / 0 Problems / 0 Untested.
- PASSED — test4 Stage 10: 3,768 / 12,876 textured faces (29.26%).
- PASSED — test3 Stage 10: 898 / 4,938 textured faces (18.19%).
- DONE — versionName 0.15.0 / versionCode 27.
- DONE — edge-adjacent same-photo Stage 9 faces form shared UV islands.
- DONE — shared islands preserve relative source-photo coordinates.
- DONE — variable rectangle shelf packing into 2048/4096 atlas.
- DONE — UV island count, largest-island size and atlas occupancy diagnostics.
- DONE — in-app textured mesh preview using Stage 10 atlas UVs.
- DONE — textured preview keeps unassigned faces gray.
- DONE — OBJ/MTL/PNG export remains standard and unchanged in file naming.
- TEST — Android Studio/device v0.15.0 guide.
- NEXT — improve Stage 9 face coverage plus seam/exposure blending between neighboring islands.


## v0.16.0 — coverage recovery + exposure normalization

- PASSED — v0.15.0 guide: 8 Works / 0 Problems / 0 Untested.
- PASSED — test4: 1,503 UV islands, largest 81 faces, 13.60% atlas occupancy, 3,768 textured faces, 29.26% coverage.
- DONE — versionName 0.16.0 / versionCode 28.
- DONE — strict Stage 9 assignments still take priority.
- DONE — conservative fallback can recover an unassigned face only when all three corners project cleanly and at least two pass visibility.
- DONE — fallback keeps front-facing, positive-depth and image-bounds requirements.
- DONE — Stage 9 warning reports fallback assignment count.
- DONE — Stage 10 estimates source-photo luminance and applies clamped 0.82..1.22 exposure gain before atlas copy.
- DONE — connected UV islands and in-app textured preview retained.
- TEST — test4/test3 Stage 9 coverage must not regress from v0.15 baselines.
- TEST — Stage 10 texture placement must remain aligned; brightness stepping should be no worse and ideally reduced.
- NEXT — after device validation, improve source-view confidence/occlusion and seam blending without sacrificing correct placement.


## v0.17.0 — neighbor-consistent texture recovery + capture guidance

- PASSED — v0.16.0 guide: 8 Works / 0 Problems / 0 Untested.
- PASSED — test4 texture coverage: 29.59%; test3: 18.77%.
- DONE — versionName 0.17.0 / versionCode 29.
- DONE — keep strict Stage 9 assignments first.
- DONE — keep v0.16 two-of-three visibility fallback second.
- DONE — add edge-neighbor source-photo continuity recovery only for still-unassigned faces.
- DONE — require at least two already-assigned edge neighbors to agree on the same source photo.
- DONE — require target face positive-depth/in-image/front-facing geometry, projected-area threshold, score threshold, and at least one visible corner.
- DONE — recovered faces do not vote for additional faces.
- DONE — warnings report continuity candidate and accepted-assignment counts.
- DONE — Capture guidance now documents overlap, same lens/zoom, multiple height rings, stable lighting/sharpness, reflections, and temporary texture/markers.
- RETAINED — v0.16 luminance normalization.
- RETAINED — v0.15 connected same-photo UV islands and in-app textured preview.
- TEST — test4 coverage >= 29.59%.
- TEST — test3 coverage >= 18.77%.
- NEXT — if gains remain small, camera calibration/intrinsics and graph-based camera/source recovery take priority over looser occlusion rules.

## v0.18.0 — guided camera calibration

- PASSED — v0.17.0 guide: 8 Works / 0 Problems / 0 Untested.
- PLATEAU — test4 remained 29.59% textured-face coverage; test3 remained 18.77%.
- DONE — Camera Calibration entry from the project list.
- DONE — printable Letter landscape 9×6-inner-corner / 25 mm-square checkerboard target PDF.
- DONE — import calibration image set and preserve it separately from scan projects.
- DONE — OpenCV checkerboard detection + sub-pixel corner refinement.
- DONE — solve fx/fy/cx/cy and k1/k2/p1/p2/k3.
- DONE — RMS reprojection quality threshold and accepted/rejected frame report.
- DONE — persist one active lens/zoom/resolution profile.
- DONE — calibrated focal/principal-point values feed existing camera matrices when dimensions are compatible.
- DONE — calibration snapshot included in version and combined diagnostics.
- TODO — apply saved distortion coefficients to raster/features after v0.18 profile validation.
- ROADMAP — reflective dots as feature assistance for plain objects.
- ROADMAP — coded fiducials/tape as identifiable pose/tracking anchors.
- ROADMAP — known-size scene markers for metric scale.

## v0.19.0 — Laser Line Lab foundation

- DONE — Laser/Hybrid projects can open Laser Line Lab.
- DONE — separate laser-OFF and laser-ON frame import.
- DONE — red/green/blue laser selection and adjustable signal threshold.
- DONE — static-background suppression from OFF/ON color difference.
- DONE — weighted sub-pixel stripe centroid per image row.
- DONE — broad-region rejection, coverage, continuity, signal and stripe-width diagnostics.
- DONE — cyan overlay preview.
- DONE — laser report and preview export.
- DONE — laser data is stored per project and does not affect Photo Scan projects.
- RESEARCH — Horus/Ciclop, FreeLSS, FabScanPi, Sardauscan, and MIT OpenCV sheet-of-light references documented.
- NEXT LASER — laser-plane calibration, then turntable/movement calibration and ray/plane triangulation.
- PAUSED PHOTO ACCURACY — proper printed camera calibration target still pending user test; do not tune Stage 2–7 geometry around the temporary screen calibration.

## v0.20.0 — multiple calibration target presets

- DONE — Photo calibration target selector: US Letter 8.5×11 or 12×18.
- DONE — Both photo presets retain exact 9×6 inner corners / 25.0 mm square geometry.
- DONE — Selected photo target persists across restart.
- DONE — Newly solved camera profile records target preset ID.
- DONE — Older camera profiles remain loadable with backward-compatible default target metadata.
- DONE — Photo calibration screen exports selected target PDF.
- DONE — Laser background selector: US Letter or 12×18.
- DONE — Laser preset persists across restart.
- DONE — Laser Line Lab exports matching LEFT and RIGHT PDFs.
- DONE — Print-shop instructions PDF can be exported from both calibration areas.
- DONE — Corrected calibration PDFs embedded in app and copied into the Android Studio project print pack.
- DONE — v0.20 guided test steps and diagnostics identify selected target presets.
- NOT YET — Laser background marker decoding / per-frame laser-plane solve.
- NOT YET — Laser 3D triangulation.


## v0.21.0 — standard copy-size calibration presets

- DONE — Photo target presets: Letter 8.5×11, Legal 8.5×14, Ledger 11×17, optional Poster 12×18.
- DONE — Exact page dimensions shown in inches and millimeters.
- DONE — Same 250×175 mm / 25 mm-square checker geometry retained for every photo preset.
- DONE — Laser LEFT/RIGHT presets for Letter, Legal, Ledger and 12×18.
- DONE — Laser panel dimensions and marker size shown and included in reports.
- DONE — All matching PDFs bundled and exportable from the app.
- DONE — v0.21 guided test covers persistence, exports, 12×18 compatibility and existing-profile/project regression.
- DEFERRED — laser marker decoding / laser-plane calibration / metric 3D triangulation.


## v0.22.0 — DONE as candidate / pending device verification
- Persistent per-project laser Analyze run history (max 200).
- Threshold/color/result/failure/duration captured per Analyze press.
- Recent history card in Laser Line Lab.
- Cross-platform JSONL history export.
- Human laser report includes recent history.
- v0.22 guided threshold-history regression test.
- Laser extraction math unchanged.


## v0.23.0 - DONE as candidate / pending device verification
- DONE - Added exact-scale 12x18 tiled-on-Letter laser preset.
- DONE - LEFT and RIGHT each export as 4 Letter pages (A1/A2/B1/B2).
- DONE - Finished geometry remains 12x18 / 35 mm markers; existing single-sheet 12x18 preset remains.
- DONE - Crop/registration marks stay outside calibration artwork.
- DONE - Tiled assembly instructions export from Camera Calibration and Laser Line Lab.
- DONE - Existing photo target geometry remains 9x6 inner corners / 25 mm squares / 250x175 mm.
- DONE - v0.23 guided test covers new exports and regression of existing laser presets/history.
- VERIFIED OFF-DEVICE - software reassembly of tiled LEFT/RIGHT matched original 12x18 renders exactly at 120 dpi.
- PENDING - Android Studio compile/install and on-device v0.23 guided test.
- PENDING - physical print measurement/assembly and camera/laser calibration use.

## v0.24.0 — pin-align four-Letter calibration

- DONE — ordinary US Letter paper only for the new tiled assemblies.
- DONE — sacrificial matching crosshairs with center dots for pin registration.
- DONE — straight-cut overlap method leaves no paper overlap covering final calibration artwork.
- DONE — new Large 4-Letter photo target: 9x6 inner corners, 38.1 mm squares, 15x10.5 in checkerboard.
- DONE — existing 25 mm photo targets remain unchanged.
- DONE — laser LEFT/RIGHT pin-align tiled preset preserves original 12x18 / 35 mm marker geometry.
- DONE — v0.24 guided test covers photo preset geometry, four-page exports, pin-align laser exports, instructions, and v0.22 laser-history regression.
- VERIFIED OFF-DEVICE — PDF page sizes/rendering and digital reassembly geometry.
- PASSED — standalone `Models.kt` Kotlin compile.
- PENDING — Android Studio/device compile and v0.24 guided test.
- PENDING — physical pin-align/cut/mount verification and real camera/laser calibration.

## v0.26.0 — calibrated distortion + laser metric single-frame 3D

- DONE — full saved Brown-Conrady coefficients available through shared calibrated geometry helper.
- DONE — Stage 2 essential matrix / pose uses undistorted matched coordinates.
- DONE — Stage 3 multi-view adjacent geometry uses undistorted coordinates.
- DONE — Stage 4 shared-track observations use calibrated undistorted coordinates; strongest-track budget 1200 -> 1600.
- DONE — Stage 5 dense stereo rectifies source rasters with measured camera distortion.
- DONE — Stage 6 dense fusion rectifies with measured distortion and evaluates up to 12 quality/distribution-balanced pairs.
- DONE — Stage 6 fused-point cap 60k -> 80k.
- DONE — Stage 8/9 source-photo projection maps geometry through the saved distortion model into the original raster.
- DONE — Stage 10 continues to consume Stage 9 UV/source assignments; no destructive source-photo rewrite.
- DONE — laser extractor automatically chooses row-wise or column-wise sampling for vertical/horizontal hand-swept stripes.
- DONE — laser analysis history records selected extraction orientation and sample-axis length as optional schema-v1 fields.
- DONE — DICT_4X4_50 marker decode for every existing laser target preset.
- DONE — rigid multi-marker LEFT/RIGHT panel pose solve using known printed marker spacing.
- DONE — measured calibration-panel angle diagnostic.
- DONE — instantaneous laser-plane fit from stripe/backdrop intersections.
- DONE — metric single-frame stripe triangulation and PLY export in millimeters.
- DONE — laser-plane preview/report persistence and export.
- TEST — Android Studio/device v0.26 guide on existing test5 + real Letter laser setup.
- NEXT PHOTOGRAMMETRY — pose-graph/non-adjacent component recovery if connected-camera count still limits test5 after distortion-aware rerun.
- NEXT LASER — multi-frame/video hand-sweep accumulation, per-frame plane recovery and point-cloud fusion.
