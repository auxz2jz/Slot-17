# 3D Scan Studio — Recovery Checkpoint

## Current build

- Version: **v0.9.1**
- Android versionCode: **20**
- Purpose: **Stage 7 topology cleanup after the successful v0.9.0 triangle-mesh proof of concept**
- Canonical repository: `auxz2jz/Slot-8`, branch `main`
- Android Studio/device compile: **pending**

## Last confirmed device results — v0.9.0 PASSED

Guide: **7 Works / 0 Problems / 0 Untested** on Samsung SM-S908U1 / Android 16.

### test4
- source fused points: 40,922
- v0.9.0 mesh vertices: 5,795
- v0.9.0 triangles: 30,000
- readyForExport=true

### test3
- source fused points: 41,017
- v0.9.0 mesh vertices: 2,840
- v0.9.0 triangles: 28,555
- readyForExport=true

Viewer, persistence, report export, OBJ export, PLY export, and Stage 1–7 naming all passed.

## Why v0.9.1 exists

Topology inspection of the uploaded v0.9.0 PLY files found valid face indices and no duplicate faces, but the first all-neighbor-pair strategy intentionally over-generated overlapping local triangles.

Observed v0.9.0 topology:
- test4: 11,137 non-manifold edges and 3,070 vertices unused by any face.
- test3: 11,600 non-manifold edges and 107 unused vertices.

This was acceptable for the first triangle-generation milestone but should be cleaned before normals, smoothing, hole filling, or texture projection.

## v0.9.1 changes

1. Stage 7 now estimates a local tangent frame around each downsampled point.
2. Nearby points are angularly ordered and primarily adjacent fan triangles are proposed.
3. Cleanup enforces at most two faces per undirected edge.
4. Tiny disconnected face fragments are removed while meaningful larger components are retained.
5. Vertices unused by the final face list are removed and face indices are compacted.
6. Stage 7 reports candidate triangles, cleanup-rejected faces, unused vertices removed, boundary edges, non-manifold edges, and retained surface components.
7. Ready-for-export requires at least 100 faces and zero non-manifold edges.
8. Stage 1–7 UI wording remains stable.

## Kotlin validation against the real v0.8.4 fused clouds

The actual v0.9.1 Kotlin mesher was compiled with `kotlinc` and run against the uploaded fused PLY files.

### test4
- source: 40,922 fused points
- final vertices: **5,172**
- final faces: **12,872**
- boundary edges: 7,982
- non-manifold edges: **0**
- retained components: 11
- readyForExport=true

### test3
- source: 41,017 fused points
- final vertices: **2,144**
- final faces: **4,938**
- boundary edges: 3,364
- non-manifold edges: **0**
- retained components: 34
- readyForExport=true

The lower triangle count is intentional: v0.9.1 removes overlapping/non-manifold faces rather than treating them as added detail. Boundary edges remain and a later stage can address holes/watertightness.

## Exact next device test

1. Build/install v0.9.1.
2. Open **test4**.
3. On **Stage 6 — Dense Fusion**, tap **Next: Stage 7 — Build surface mesh**.
4. On **Stage 7 — Surface Mesh**, confirm **Non-manifold edges: 0** and Ready for export=true.
5. Tap **View Stage 7 mesh** and inspect all six preset views plus rotation/zoom.
6. Export the Stage 7 report, OBJ, and triangle PLY.
7. Repeat Stage 7 on **test3**.
8. Confirm test3 also reports **Non-manifold edges: 0**.
9. Leave/reopen one project and confirm Stage 7 topology values persist.
10. Export the v0.9.1 version-test report and upload it with both Stage 7 mesh reports.

## Next after v0.9.1 passes

Evaluate boundary/hole statistics and visual quality. Then choose the next geometry step: normal estimation + smoothing/component cleanup and/or conservative hole filling before texture projection.


## v0.9.2 maintenance build

- versionName: **0.9.2**
- versionCode: **21**
- Scope: reconstruction state invalidation + reset control only.
- Geometry math: unchanged from v0.9.1.
- Trigger: v0.9.1 device retest showed stale Stage 7 UI after Stage 1 invalidated persisted downstream data.
- Fix: centralized memory + disk invalidation at every stage boundary.
- New control: **Reset reconstruction stages** keeps photos/settings and removes generated Stages 1–7 after confirmation.
- Test target: confirm stale cards vanish immediately, reset persists across project reopen, and saved v0.9.1 topology remains compatible.

## v0.10.0 build prepared

- versionName: **0.10.0**
- versionCode: **22**
- Scope: project-scoped background job isolation + Stage 7 normals/smoothing/boundary analysis.
- Stages 1–6 geometry math: unchanged from v0.9.2.
- Stage 7 topology generation: retains v0.9.1 ordered local-fan/non-manifold cleanup, then adds surface-quality analysis.

### Project isolation changes

1. Heavy Stage 1–7 work has an immutable owner project ID/name/stage label.
2. Live progress/results are only published when that owner project is selected.
3. Switching projects during a job no longer makes the second project appear to be processing.
4. A background job finishing cannot force-select its owner project.
5. Reopening the owner project reloads its finished results from that project's repository folder.
6. Only one heavy reconstruction job runs at a time for now; attempts to start another name the project already processing.
7. Cross-project data sharing remains prohibited unless a future explicit merge/compare feature is built.

### Stage 7 v0.10.0 changes

- two boundary-preserving smoothing passes;
- area-weighted per-vertex normals;
- normals stored with the Stage 7 report and exported in OBJ/PLY;
- boundary component classification: closed loops vs open/branched components;
- boundary branch-vertex count;
- no automatic hole filling yet.

### Local Kotlin validation

- test4: 5,172 vertices / 12,872 faces / 0 non-manifold edges / 1 closed loop / 5 open-or-branched boundary groups / 5,172 valid normals.
- test3: 2,144 vertices / 4,938 faces / 0 non-manifold edges / 1 closed loop / 5 open-or-branched boundary groups / 2,144 valid normals.

### Exact next device test

Use the built-in v0.10.0 guide. Most important checks:
- start test4 Stage 1, switch to test3, and verify test3 does not show test4 live progress;
- remain on test3 when test4 finishes;
- reopen test4 and verify its Stage 1 result appears only there;
- rebuild Stage 7 on test4 and export its report/OBJ/PLY;
- verify normals and boundary diagnostics are present and Non-manifold edges remains 0.

Next after v0.10.0 passes: conservative filling of small/simple closed boundary loops, then stronger mesh cleanup/texture preparation.


## v0.10.0 device test — PASSED

- Version guide: **8 Works / 0 Problems / 0 Untested** on Samsung SM-S908U1 / Android 16.
- Cross-project live-state isolation behaved correctly.
- test3 Stage 7 remained topology-clean with 2,144 vertices / 4,938 faces / 0 non-manifold edges and 2,144 valid normals.
- v0.10.0 boundary analysis found 1 simple closed loop plus 5 open/branched boundary groups on the real test clouds.

## v0.11.0 build prepared

- Version: **0.11.0**
- versionCode: **23**
- Main goals: **one combined project diagnostic export** + **first conservative closed-hole fill**.

### Combined Project Diagnostics

A new project card exports one text file containing:
- current project identity/status,
- Quick Check when available,
- full Stage 1 feature-match diagnostics,
- full Stage 2 sparse diagnostics,
- full Stage 3 camera path / pair diagnostics,
- full Stage 4 bundle diagnostics,
- full Stage 5 dense-pair diagnostics,
- full Stage 6 fusion diagnostics,
- full Stage 7 mesh diagnostics.

The combined export is rebuilt from the project's current saved stage state each time it is exported, so a newly created/rebuilt stage automatically appears in the same diagnostic format. Large geometry coordinates are intentionally not embedded; PLY/OBJ remains separate only when geometry inspection is required.

### Stage 7 safe closed-loop filling

v0.11.0 keeps v0.10.0 topology cleanup, smoothing, normals, and boundary classification. It then considers only simple closed boundary loops and fills one only when all conservative checks pass:
- 3–12 boundary vertices,
- local perimeter/radius limits,
- nearly planar loop,
- center spokes no longer than the existing accepted local-edge scale,
- no overly thin/degenerate fan triangle,
- mobile vertex/face safety caps remain respected.

Open/branched boundary groups are never filled automatically in this build.

### Local Kotlin validation on the real Stage 6 fused clouds

- test4: 40,922 source points -> **5,173 vertices / 12,876 faces / 0 non-manifold edges**. Closed loops: 1 before, **1 filled**, 0 remaining. Fill added 1 center vertex and 4 faces. Open/branched groups remain 5.
- test3: 41,017 source points -> **2,144 vertices / 4,938 faces / 0 non-manifold edges**. Closed loops: 1 before, **0 filled**, 1 remaining. The loop was skipped because a centroid fan would create an overly thin/degenerate triangle. Open/branched groups remain 5.

This is intentional conservative behavior, not a failed fill.

### Exact next test

1. Build/install v0.11.0.
2. Export **Combined Project Diagnostics** from test3 and confirm it contains every currently available Stage 1–7 section.
3. Rebuild Stage 7 on test3; confirm 0 non-manifold edges and that the unsafe loop can be skipped with a reason.
4. Rebuild Stage 7 on test4; confirm 0 non-manifold edges and that the safe simple loop is filled if device results match local validation.
5. Export Combined Project Diagnostics again; the new Stage 7 fill statistics should already be included.
6. Export the v0.11.0 version-test report.

After v0.11.0 validation: begin texture-preparation work (camera/image selection and UV/texture projection groundwork) while continuing to treat large open/branched borders conservatively.

## v0.11.0 device result — PASSED

- Version guide: **7 Works / 0 Problems / 0 Untested** on Samsung SM-S908U1 / Android 16.
- test4 Stage 7: 5,173 vertices / 12,876 faces / 0 non-manifold edges; safe closed-loop fill 1/1.
- test3 Stage 7: 2,144 vertices / 4,938 faces / 0 non-manifold edges; unsafe loop intentionally left open.
- Combined Project Diagnostics successfully contains Quick Check plus all saved stage reports and is now the preferred routine upload.

## v0.12.0 build prepared

- Version: **0.12.0**
- Android versionCode: **24**
- Milestone: **Stage 8 — Photo Color Projection**
- Android Studio/device compile: **pending**

### Stage 8 design

- Rebuilds connected camera orientation chain from original photos.
- Uses saved Stage 4 refined camera centers and Stage 7 topology-clean mesh.
- Projects mesh vertices into EXIF-normalized source images.
- Rejects negative-depth/out-of-frame/back-facing candidates.
- Scores views using surface facing, image-center distance and camera distance.
- Blends up to three strong source views per vertex.
- Persists color coverage and per-camera contribution diagnostics.
- Adds colored preview, colored PLY and vertex-colored OBJ exports.
- Adds Stage 8 automatically to Combined Project Diagnostics.
- Does **not** modify Stage 7 mesh geometry.

### Exact next device test

1. Install v0.12.0 and open **test4**.
2. On **Stage 7 — Surface Mesh**, tap **Next: Stage 8 — Project photo colors**.
3. Confirm **Stage 8 — Photo Color Projection** appears with non-zero recovered camera poses, cameras used and colored-vertex coverage.
4. Tap **View Stage 8 photo colors** and inspect several angles.
5. Export the **colored PLY**.
6. Repeat Stage 8 on **test3**.
7. Export **Combined Project Diagnostics** after Stage 8; it must include the Stage 8 section automatically.
8. Export the v0.12.0 version-test report.

Routine upload after this build: version-test report + one combined diagnostic TXT per tested project. Include colored PLY only when geometry/color inspection is needed.


## v0.12.0 device result — PASSED

- Version guide: **8 Works / 0 Problems / 0 Untested**
- Device: Samsung SM-S908U1 / Android 16
- test4 Stage 8: 5,173 source vertices / 12,876 faces, 72/100 connected camera poses recovered, 65 cameras used for best colors, 2,880 colored vertices, **55.67% vertex-color coverage**, readyForExport=true.
- test3 Stage 8: 2,144 source vertices / 4,938 faces, 41/41 connected camera poses recovered, 35 cameras used for best colors, 999 colored vertices, **46.60% vertex-color coverage**, readyForExport=true.
- Combined Project Diagnostics correctly included Stage 8 automatically.
- Colored PLY/OBJ exports preserved Stage 7 topology while adding RGB appearance data.

## v0.13.0 build prepared

- Version: **0.13.0**
- versionCode: **25**
- Intended package: `PhotogrammetryStudioAndroid-v0.13.0-Stage9-Texture-Source-Assignment-Android-Studio-Ready.zip`
- Gradle wrapper JAR included: **yes**
- Full Android compile in recovery environment: blocked because `services.gradle.org` cannot be resolved; Android Studio/device build remains authoritative.

### Stage 8 robustness upgrade

1. Camera pose recovery can bridge a short failed adjacent orientation link by matching to an older recovered camera, up to four connected-camera positions back.
2. Stage 8 reports recovered adjacent/bridged orientation links separately.
3. Each camera builds a coarse depth/visibility map over projected Stage 7 vertices.
4. Vertices substantially behind the nearest projected surface in the same image region are rejected before photo-color sampling.
5. Stage 8 reports how many candidate samples were rejected by visibility filtering.
6. Stage 8 remains appearance-only and never changes Stage 7 vertex/face topology.

### Stage 9 — Texture Source Assignment

1. Uses the same robust camera-pose recovery and visibility test as Stage 8.
2. Considers each Stage 7 triangle in each usable camera.
3. Requires all three triangle vertices to be positively projected, inside the image and visibility-approved.
4. Rejects sub-pixel projected triangles.
5. Scores usable source photos and chooses one source photo per assigned triangle.
6. Persists normalized source-photo coordinates for all three triangle corners.
7. Reports assigned/unassigned face counts, triangle-source coverage, recovered/bridged poses and per-camera face contribution counts.
8. Exports a triangle source-map TSV for inspection.
9. Combined Project Diagnostics now includes Quick Check + Stages 1–9.

Stage 9 does not yet create a UV atlas image. Its purpose is to prove which triangles have a defensible source photo and source-image coordinates before atlas packing/rasterization.

### Exact v0.13.0 device test

1. On test4, rebuild **Stage 8 — Photo Color Projection** and compare recovered/bridged pose counts and visibility-rejected candidates.
2. Inspect **View Stage 8 photo colors** for obvious color bleed/regression.
3. Tap **Next: Stage 9 — Assign triangle texture sources**.
4. Confirm Stage 9 assigns a non-zero number of faces, uses multiple cameras and reports face coverage.
5. Export the test4 Stage 9 source map if convenient.
6. Repeat Stage 8 + Stage 9 on test3.
7. Export Combined Project Diagnostics from test3 and test4; each must contain a Stage 9 section.
8. Export the v0.13.0 version-test report.

Routine upload: v0.13.0 version-test report + one Combined Project Diagnostics TXT per tested project. Upload the Stage 9 source map only if coverage looks wrong or deeper assignment inspection is needed.

If Stage 9 coverage is healthy, the next major version will generate a real UV texture atlas and UV-mapped model export.

## v0.13.0 device result — PASSED

- Version guide: **8 Works / 0 Problems / 0 Untested**
- test4 Stage 8: recovered all 100 connected camera poses; Stage 9 assigned 3,768 / 12,876 faces (**29.3%**) using 90 cameras; ready for atlas work.
- test3 Stage 8: recovered 41 / 41 camera poses; Stage 9 assigned 898 / 4,938 faces (**18.19%**) using 39 cameras; low coverage is retained honestly rather than fabricating sources.
- Stage 9 source map contains face index + source photo + three normalized source-image coordinate pairs + score.

## v0.14.0 build prepared

- Version: **0.14.0**
- versionCode: **26**
- Milestone: **Stage 10 — UV Texture Atlas**
- Stage 10 consumes only valid Stage 9 face assignments.
- Assigned faces get real photo-derived atlas patches and UVs.
- Unassigned faces remain gray/untextured.
- Stage 7 geometry is unchanged.
- Textured export package contains OBJ + MTL + PNG.
- Combined Project Diagnostics covers Stages 1–10.

### Exact device test

1. On test4 Stage 9 tap **Next: Stage 10 — Build UV texture atlas**.
2. Confirm non-zero textured faces, atlas dimensions, source photos used, and Ready for export=true.
3. Export **textured model package (.zip)** and verify it contains `textured_model.obj`, `texture_atlas.mtl`, and `texture_atlas.png`.
4. Export/open the atlas PNG and confirm it contains many real photo-derived patches rather than being blank/flat.
5. Run Stage 10 on test3 as a partial-atlas regression even though its Stage 9 coverage is lower.
6. Confirm Stage 7 vertex/face counts do not change.
7. Export Combined Project Diagnostics and v0.14.0 version-test report.

Next after device validation: viewer compatibility/orientation checks, better UV island packing and seam/exposure blending, plus source-assignment coverage improvements.


## v0.14.0 device result — PASSED

- Version guide: **8 Works / 0 Problems / 0 Untested**.
- test4 Stage 10: 2048×2048 atlas, 3,768 textured / 12,876 total faces (**29.26%**), 90 source photos, 0 missing-photo/rasterization skips, readyForExport=true.
- test3 Stage 10: 2048×2048 atlas, 898 textured / 4,938 total faces (**18.19%**), 39 source photos, 0 missing-photo/rasterization skips, readyForExport=true.
- Both exported ZIP packages contained `textured_model.obj`, `texture_atlas.mtl`, and `texture_atlas.png`.
- User correctly observed that the v0.14 PNG looks like a scrambled mosaic when viewed by itself. That is expected for one-triangle-per-tile packing; OBJ UVs assemble those patches on the 3D model.

## v0.15.0 build prepared

- Version: **0.15.0**
- versionCode: **27**
- Milestone: **connected UV islands + in-app textured model preview**.
- Stage 9 source assignment remains unchanged.
- Stage 10 now groups edge-connected triangles that use the same source photo into a shared UV island.
- Each island preserves the triangles' relative coordinates inside the original photo-space bounding region.
- Variable rectangular islands are shelf-packed into a 2048 or 4096 atlas as needed.
- Stage 10 reports island count, largest island face count, and atlas occupancy.
- New **View textured model in app** button applies the actual atlas PNG/UV coordinates to a rotatable mesh preview.
- Untextured faces remain gray in both preview and OBJ export.
- OBJ + MTL + PNG package format remains unchanged.
- Stage 7 geometry remains unchanged.

### Exact v0.15.0 device test

1. Rebuild Stage 10 on test4. Confirm UV islands > 0, textured faces remain non-zero, and Ready for export=true.
2. Tap **View textured model in app** and inspect Front/Back/Left/Right/Top/Bottom plus rotation/zoom.
3. Export the atlas PNG. It should contain larger rectangular photo regions/islands rather than thousands of isolated one-triangle tiles.
4. Export the textured ZIP and optionally open `textured_model.obj` in MeshLab with the MTL/PNG in the same folder.
5. Repeat Stage 10 on test3 as a partial-texture regression.
6. Confirm Stage 7 vertex/face counts do not change.
7. Export Combined Project Diagnostics and the v0.15.0 version-test report.

Next after v0.15 validation: improve Stage 9 coverage and add seam/exposure blending across neighboring UV islands.

### v0.15.0 validation limitation
The complete Gradle build could not run in this recovery environment because `services.gradle.org` could not be resolved. The Gradle wrapper JAR is included; Android Studio on the development PC remains the authoritative compile/install test.


## v0.15.0 device result — PASSED

- Guide: 8 Works / 0 Problems / 0 Untested on Samsung SM-S908U1 / Android 16.
- test4 Stage 10: 4096×4096 atlas, 1,503 UV islands, largest island 81 faces, 13.60% occupancy, 3,768/12,876 textured faces (29.26%), 90 source photos, 0 missing/mapping skips, readyExport=true.
- test3 Stage 10: 2048×2048 atlas, 365 UV islands, largest island 52 faces, 13.06% occupancy, 898/4,938 textured faces (18.19%), readyExport=true.
- In-app textured preview, standard OBJ/MTL/PNG export, project isolation and Stage 7 geometry preservation all passed.

## v0.16.0 build prepared

- Version: 0.16.0
- versionCode: 28
- Scope: Stage 9 conservative coverage recovery + Stage 10 source-photo exposure normalization.
- Strict Stage 9 source assignments are never replaced by fallback assignments.
- Fallback requires clean geometric projection for all three corners and at least two visibility-approved corners.
- Stage 10 uses median-luminance normalization with gain clamped to 0.82..1.22.
- Stage 7 geometry and v0.15 connected UV-island logic remain unchanged.
- Exact device baseline: test4 Stage 9/10 coverage 29.26%; test3 18.19%. v0.16 coverage must not regress.


## v0.16.0 device result — PASSED

- Guide: **8 Works / 0 Problems / 0 Untested**.
- test4 Stage 9/10: **3810 / 12876 faces = 29.59% coverage**, up from 29.26% in v0.15.
- test4 v0.16 fallback: **42 recovered assignments** from 20,683 relaxed candidates.
- test4 Stage 10: 1535 UV islands, largest 81 faces, 13.79% occupancy, 90 source photos, 0 missing/mapping failures.
- test4 exposure normalization adjusted 41/90 source photos by at least 3%.
- test3 Stage 9/10: **927 / 4938 faces = 18.77% coverage**, up from 18.19% in v0.15.
- test3 v0.16 fallback: **29 recovered assignments** from 672 relaxed candidates.
- test3 Stage 10: 384 UV islands, largest 52 faces, 13.52% occupancy, 39 source photos, 0 missing/mapping failures.
- test3 exposure normalization adjusted 16/39 source photos by at least 3%.
- User noted the coverage increase was only slight, so v0.17 does not simply loosen the same fallback further.

## v0.17.0 build prepared

- Version: **0.17.0**
- versionCode: **29**
- Scope: neighbor-consistent Stage 9 recovery + clearer capture-quality guidance.
- Strict Stage 9 assignment remains first priority.
- v0.16 two-of-three visibility fallback remains second priority.
- A third recovery pass considers only still-unassigned faces.
- A recovery source photo must already be selected by at least **two edge-neighbor faces**.
- The target face must still project positive-depth, in-image, front-facing, with non-trivial projected area and at least one coarse visibility-approved corner.
- Recovered v0.17 faces never vote for other faces, preventing uncertain chain propagation.
- Stage 10 v0.16 exposure normalization and v0.15 connected UV islands remain unchanged.
- Capture guidance now includes 70–80% overlap, same lens/zoom, low/middle/high rings, stable lighting/sharpness, reflection avoidance, and temporary-marker advice.

### v0.17.0 device baselines

- test4 Stage 9/10 coverage must be **>= 29.59%**.
- test3 Stage 9/10 coverage must be **>= 18.77%**.
- Stage 7 geometry must remain unchanged.
- Texture alignment must remain usable in the in-app preview.
- Combined diagnostics must report the v0.17 neighbor-consistency assignment count.

Next after v0.17 validation: evaluate whether coverage gain is meaningful. If still small, prioritize camera calibration/intrinsics and graph-based source-camera recovery rather than further relaxing visibility.

## v0.18.0 build prepared — camera calibration milestone

Reason for pivot:
- v0.17.0 passed 8/0/0 but neighbor-consistency texture recovery produced no measurable coverage gain beyond v0.16.
- test4 stayed 3810/12876 = 29.59%.
- test3 stayed 927/4938 = 18.77%.
- current diagnostics still identify approximate EXIF camera intrinsics / zero-distortion assumptions as a major accuracy limitation.

v0.18.0 changes:
1. New Camera Calibration screen accessible from the project list.
2. Built-in printable US Letter landscape checkerboard PDF (9×6 inner corners, 25 mm squares).
3. Import a dedicated calibration photo set; minimum 10 accepted, 15–25 recommended.
4. OpenCV full-board detection + sub-pixel corner refinement.
5. Solve and persist fx/fy/cx/cy and k1/k2/p1/p2/k3.
6. Store RMS reprojection error and per-frame detected/rejected diagnostics.
7. Automatically activate a profile only when minimum-frame and RMS <=1.5 px checks pass.
8. Existing reconstruction camera-matrix helpers use calibrated focal/principal-point values on compatible image dimensions.
9. Distortion coefficients are saved but full distortion-aware raster/feature correction is deliberately deferred until the profile is validated.
10. Future marker modes explicitly separated into reflective feature dots, coded fiducials/tape, and known-size scale references.

Exact v0.18 device test:
- export/print the target at 100% Actual Size;
- capture/import 15–25 sharp views with one fixed lens/zoom/orientation;
- run calibration and export the calibration report;
- prefer RMS <1.0 px, accept <=1.5 px for this milestone;
- rebuild Stage 2 and confirm Intrinsics source begins with 'Calibrated';
- optionally rebuild test4 Stage 8/9 to confirm no major regression;
- export v0.18 version-test report.

## v0.19.0 compile-fix r1
- User Android Studio build reached `:app:compileDebugKotlin` and failed at `LaserLineLabScreen.kt:86` because `TopAppBar` requires `ExperimentalMaterial3Api` opt-in.
- Root cause isolated to the new Laser Line Lab screen; existing Material3 screens already use the required opt-in pattern.
- Fix is limited to importing `ExperimentalMaterial3Api` and adding `@OptIn(ExperimentalMaterial3Api::class)` to `LaserLineLabScreen`.
- No functional feature changes; keep app version 0.19.0 / versionCode 31.
- Local Gradle recompile cannot complete in the assistant environment because `services.gradle.org` is unresolved. Android Studio remains the authoritative compile test.

## v0.20.0 prepared — selectable calibration print sizes

Current milestone: support inexpensive Letter cardstock or the larger 12×18 print set without blocking calibration work.

Implemented:
- Photo target presets: US Letter 8.5×11 and 12×18.
- Both photo targets: 9×6 inner corners, 25.0 mm squares.
- Photo target choice persists and is recorded in newly solved camera-calibration profiles.
- Laser target presets: US Letter and 12×18, each with LEFT/RIGHT 90°-corner panels.
- Laser target choice persists and is included in laser diagnostic reports.
- Calibration and Laser Line Lab screens export their selected PDFs from app assets.
- Print instructions PDF is exportable in-app.
- `CALIBRATION_PRINT_PACK/` carries the same PDFs in the Android Studio source package.
- v0.20 in-app guided test covers selection persistence, all exports, profile regression and version-test report.

Important boundaries:
- Proper physical camera calibration is still awaiting the user's printed target.
- Do not tune Stages 2–7 geometry around the temporary monitor-displayed calibration.
- v0.20 does not yet decode laser-background markers or perform laser 3D triangulation.
- Existing v0.19 laser OFF/ON line extraction remains unchanged.

Next device action after successful Android Studio compile:
1. Open Camera Calibration and switch Letter ↔ 12×18; confirm selection persists after leaving/reopening.
2. Export both photo PDFs.
3. Open a Laser/Hybrid project → Laser Line Lab; switch Letter ↔ 12×18 and export matching LEFT/RIGHT panels.
4. Export print-shop instructions.
5. Confirm any existing camera profile still loads; no new physical calibration is required for this software regression test.
6. Export v0.20 test report.


## v0.21.0 prepared — standard copy-size calibration targets

- Version: **0.21.0** / versionCode **33**
- Status: **CANDIDATE**
- Starting point preserved: v0.20.0 package SHA-256 `9f74ce9955f189af29ba7c011714cd840911ae52a98262d084555a05ecf99a58`.
- Added standard copy-size presets: Letter 8.5x11, Legal 8.5x14, Ledger 11x17.
- Retained 12x18 as optional poster/backward-compatible preset.
- Added exact inches/mm page dimensions and laser marker size to UI/reporting.
- Added dedicated photo PDFs and laser LEFT/RIGHT PDFs for all four sizes.
- Photo checker geometry remains 9x6 inner corners / 25.0 mm squares / 250x175 mm pattern for every page size.
- Existing calibration profile IDs and v0.19 laser extraction behavior preserved.
- v0.21 guided test has 9 steps.
- Models.kt standalone compile passed; PDF render/size verification passed.
- Android Studio compile/install: pending user test.

Exact next action: build/install v0.21.0 in Android Studio and run the in-app Test This Version guide. Physical printing/calibration is not required for this software regression.


## v0.22.0 candidate — laser run history + cross-platform foundation
- versionCode 34
- Preserves every Analyze attempt in bounded project JSONL history.
- Recent run metrics shown in Laser Line Lab.
- History export is platform-neutral for future Windows use.
- Existing latest laser report/preview behavior remains.
- Laser extraction math unchanged.
- Windows implementation: NOT STARTED; separate future ownership/baseline.
- Full Android Studio/device test pending.


## v0.23.0 candidate - tiled Letter calibration panels
- Version: **0.23.0** / versionCode **35**.
- Starting point: preserved v0.22.0 candidate; v0.22 laser extraction/history behavior is unchanged.
- New laser preset: **12x18 tiled (4 Letter sheets)**, separate LEFT/RIGHT 4-page PDFs.
- Physical laser geometry remains exactly the existing 12x18 / 35.0 mm-marker geometry.
- Tiled split: vertical 4.25 in from left; horizontal 9.75 in from top, chosen through clear regions rather than coded markers/reference dots.
- Tile pages carry crop/registration marks outside the calibration artwork; final assembly uses trimmed butt joints on a flat rigid board.
- Photo calibration geometry is unchanged. The existing Letter target remains one sheet: 9x6 inner corners / 25.0 mm squares / 250x175 mm checker pattern.
- Existing Letter, Legal, Ledger and single-sheet 12x18 presets remain available and saved IDs remain backward-compatible.
- Added tiled/poster-board assembly instructions export.
- `CALIBRATION_PRINT_PACK/` includes the new LEFT/RIGHT tiled PDFs, assembly instructions and combined budget calibration set.
- Off-device PDF verification: all new PDFs rendered successfully; software reassembly of both tiled panels matched the original 12x18 v0.22 artwork pixel-for-pixel at 120 dpi (mean/max difference 0).
- Status: **CANDIDATE / not yet Android Studio or device verified**.

Exact next action:
1. Build/install v0.23.0 in Android Studio.
2. Run the 8-step in-app Test This Version guide.
3. Export tiled LEFT and RIGHT PDFs and assembly instructions from the app.
4. After software regression passes, print at 100% Actual Size, verify scale, trim/mount the eight laser pages, and mount the one-sheet photo checkerboard flat.
5. Keep v0.22.0 and earlier artifacts preserved until v0.23 is user-tested.

## v0.24.0 candidate — pin-align four-Letter calibration boards

- Version: **0.24.0** / versionCode **36**.
- v0.23.0 remains preserved as the previous unverified candidate.
- New camera-calibration preset: **Large 4-Letter (38.1 mm)**.
- Large photo board uses 9x6 inner corners / 10x7 squares, exact 38.1 mm (1.5 in) squares, 15.0 x 10.5 in checkerboard, 16.0 x 11.5 in finished target.
- The four photo pages are US Letter landscape A1/A2/B1/B2 with 0.5 in total seam overlap.
- Laser tiled preset keeps the same saved ID but now exports pin-align A1/A2/B1/B2 Letter pages with sacrificial matching crosshairs.
- Finished laser geometry remains exactly the existing 12 x 18 in / 35.0 mm-marker LEFT/RIGHT target.
- Registration crosshairs are outside each final kept tile. The user may pierce matching center dots, align sheets with pins, straight-cut both overlapped layers through the pin centers, remove excess, and butt the fresh edges. No paper overlap should cover the final calibration artwork.
- Existing 25 mm Letter/Legal/Ledger/Poster 12x18 photo presets and all existing single-sheet laser presets remain available.
- OpenCV camera calibration already builds object points from the selected preset's `squareSizeMm`; the new 38.1 mm board therefore has a correct independent physical calibration geometry.
- PDF verification: every tiled file renders; page sizes are correct; digital reassembly differs from its master only at negligible raster antialiasing seam pixels (<0.006 mean channel difference at 160 dpi).
- `Models.kt` standalone Kotlin compile: **PASSED**.
- Full Gradle compile: **BLOCKED by environment network resolution** before compilation because the wrapper cannot download Gradle 9.6 from services.gradle.org. Android Studio remains authoritative.
- Status: **CANDIDATE / not yet Android Studio or device verified**.

Exact next action:
1. Build/install v0.24.0 in Android Studio.
2. Run the 8-step in-app **Test This Version** guide.
3. Export the new four-page photo PDF, pin-align LEFT/RIGHT laser PDFs, and instructions from the app.
4. Print at 100% / Actual Size and verify one photo square = 38.1 mm / 1.5 in before assembly.
5. Keep v0.23 and prior packages preserved until v0.24 is user-tested.

## v0.26.0 candidate — distortion-aware geometry + laser single-frame 3D

Starting point: v0.25.0 clean single-sheet calibration candidate. Preserve v0.25 and all older artifacts as rollback points.

Photogrammetry implementation:
- Stage 1 descriptor extraction remains on original pixels by design.
- Stages 2–4 use undistorted feature/track coordinates from the active calibrated camera model.
- Stages 5–6 use real saved distortion during stereo rectification.
- Stage 6 now selects up to 12 stereo candidates using a half quality-ranked / half distribution-spread policy and may retain up to 80,000 fused points.
- Stage 8/9 projection applies the saved Brown-Conrady model when mapping geometry into original source photographs.
- Combined/version diagnostics expose saved distortion and v0.26 engine identity.

Laser implementation:
- Dual-orientation line extractor chooses ROW_WISE or COLUMN_WISE per frame.
- Existing JSONL schema v1 remains compatible; extractionOrientation and sampleAxisLength are optional additions.
- New multi-marker backdrop solver detects expected DICT_4X4_50 IDs for Letter/Legal/Ledger/12x18 presets.
- Each panel is solved from all detected marker corners and known printed marker-center geometry as one rigid plane.
- The app measures LEFT/RIGHT panel angle instead of assuming the physical corner is exactly 90 degrees.
- Backdrop stripe rays intersect the known panel planes to produce millimeter calibration points.
- Those points fit the instantaneous hand-swept laser plane; the analyzed stripe is triangulated and exportable as an ASCII PLY in millimeters.
- v0.26 is single-frame 3D only. Multi-frame hand-sweep accumulation/fusion remains the next laser milestone.

Baseline to compare after device test:
- test5 has 274 photos and previously reached Stage 10 with 91 connected cameras, 2 dense pairs fused, and 34.85% textured-face coverage.
- current camera calibration is Main 1x, Letter 25 mm target, RMS about 0.821 px and ready=true.
- current real Letter laser threshold sweep showed useful runs around 68–81; v0.26 must re-run Analyze so the new orientation selector is exercised before plane solving.

Validation here:
- Models.kt standalone Kotlin compile PASSED.
- Full Gradle compile could not start because this runtime cannot resolve/download Gradle 9.6 from services.gradle.org. Android Studio/device build remains authoritative.
- OpenCV Java API contracts for ArucoDetector/DICT_4X4_50, solvePnP IPPE/iterative pose, and undistortPoints were checked against current 4.x Java documentation.

Exact next user test:
1. Build/install v0.26.0 in Android Studio.
2. Run the built-in 8-step v0.26 guide.
3. On test5, rerun Stages 2–10 from the saved Stage 1 output and export Combined Project Diagnostics + textured model package.
4. On the real laser project, set ~68–81, run Analyze again in v0.26, then run Solve laser plane + build 3D stripe.
5. Export the laser-plane report/preview/PLY and the v0.26 test report.
