package com.photogrammetrystudio.app.util

import com.photogrammetrystudio.app.model.SparsePoint
import org.junit.Assert.assertTrue
import org.junit.Test

class SurfaceMesherTest {
    @Test
    fun buildsTrianglesFromDenseLocalSurface() {
        val points = buildList {
            for (y in 0 until 25) {
                for (x in 0 until 25) {
                    val z = 0.08 * kotlin.math.sin(x * 0.35) + 0.05 * kotlin.math.cos(y * 0.3)
                    add(SparsePoint(x.toDouble(), y.toDouble(), z))
                }
            }
        }
        val report = LocalSurfaceMesher.reconstruct(points).getOrThrow()
        assertTrue(report.meshVertices >= 180)
        assertTrue(report.triangles >= 100)
        assertTrue(report.readyForExport)
        assertTrue(report.nonManifoldEdges == 0)
        assertTrue(report.meshVertices == report.vertices.size)
        assertTrue(report.vertexNormals.size == report.meshVertices)
        assertTrue(report.validVertexNormals > 0)
        assertTrue(report.smoothingIterations == 2)
        assertTrue(report.closedLoopsBeforeFill >= report.filledBoundaryLoops)
        assertTrue(report.boundaryLoops <= report.closedLoopsBeforeFill)
        assertTrue(report.holeFillAddedFaces >= 0)
    }
}
