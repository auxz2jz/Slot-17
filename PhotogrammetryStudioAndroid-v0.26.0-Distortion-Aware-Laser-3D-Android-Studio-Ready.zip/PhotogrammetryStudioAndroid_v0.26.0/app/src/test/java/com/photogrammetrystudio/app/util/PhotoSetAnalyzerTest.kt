package com.photogrammetrystudio.app.util

import org.junit.Assert.assertFalse
import org.junit.Test

class PhotoSetAnalyzerTest {
    @Test
    fun tooFewPhotosIsNotReady() {
        val report = PhotoSetAnalyzer.analyze(emptyList())
        assertFalse(report.readyForReconstruction)
    }
}
