package com.photogrammetrystudio.app.util

import java.security.MessageDigest

fun reportFingerprint(vararg parts: Any?): String {
    val payload = parts.joinToString("\u241F") { it?.toString().orEmpty() }
    val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
    return digest.take(12).joinToString("") { "%02x".format(it) }
}
