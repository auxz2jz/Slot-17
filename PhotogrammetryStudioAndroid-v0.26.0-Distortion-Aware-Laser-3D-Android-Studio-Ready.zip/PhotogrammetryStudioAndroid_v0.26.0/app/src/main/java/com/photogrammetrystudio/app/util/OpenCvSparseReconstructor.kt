package com.photogrammetrystudio.app.util

import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.SparsePairEvaluation
import com.photogrammetrystudio.app.model.SparsePoint
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object OpenCvSparseReconstructor {
    private const val MAX_IMAGE_SIDE = 1600
    private const val MAX_FEATURES = 2500
    private const val RATIO_TEST = 0.75f
    private const val RANSAC_THRESHOLD_PX = 1.5
    private const val MIN_RATIO_MATCHES = 12
    private const val MIN_POSE_INLIERS = 20

    @Volatile
    private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    private data class Features(
        val file: File,
        val keypoints: Array<org.opencv.core.KeyPoint>,
        val descriptors: Mat,
        val width: Int,
        val height: Int,
        val focalPixels: Double,
        val intrinsicsSource: String
    )

    private data class PairGeometry(
        val evaluation: SparsePairEvaluation,
        val points: List<SparsePoint>,
        val focalPixels: Double,
        val intrinsicsSource: String,
        val rotationDegrees: Double
    )

    fun reconstruct(
        files: List<File>,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<SparseReconstructionReport> = runCatching {
        require(files.size >= 2) { "Take or import at least 2 photos before sparse reconstruction." }
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }

        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        val featureSets = mutableListOf<Features>()
        val warnings = mutableListOf<String>()

        try {
            files.forEachIndexed { index, file ->
                onProgress(
                    (index.toFloat() / (files.size + files.size - 1).coerceAtLeast(1)) * 0.45f,
                    "Preparing geometry features in ${file.name}"
                )
                val bitmap = decodeScaled(file)
                if (bitmap == null) {
                    warnings += "Could not decode ${file.name}."
                    return@forEachIndexed
                }

                val rgba = Mat()
                val gray = Mat()
                val keypointMat = MatOfKeyPoint()
                val descriptors = Mat()
                try {
                    Utils.bitmapToMat(bitmap, rgba)
                    Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                    orb.detectAndCompute(gray, Mat(), keypointMat, descriptors)
                    val focal = estimateFocalPixels(file, bitmap.width, bitmap.height)
                    featureSets += Features(
                        file = file,
                        keypoints = keypointMat.toArray(),
                        descriptors = descriptors,
                        width = bitmap.width,
                        height = bitmap.height,
                        focalPixels = focal.first,
                        intrinsicsSource = focal.second
                    )
                } finally {
                    bitmap.recycle()
                    rgba.release()
                    gray.release()
                    keypointMat.release()
                }
            }

            require(featureSets.size >= 2) { "Fewer than 2 photos could be decoded for sparse reconstruction." }

            val evaluations = mutableListOf<SparsePairEvaluation>()
            var best: PairGeometry? = null
            val pairCount = featureSets.size - 1

            for (i in 0 until pairCount) {
                val a = featureSets[i]
                val b = featureSets[i + 1]
                onProgress(
                    0.45f + (i.toFloat() / pairCount.coerceAtLeast(1)) * 0.5f,
                    "RANSAC geometry ${a.file.name} ↔ ${b.file.name}"
                )

                val ratioMatches = mutableListOf<org.opencv.core.DMatch>()
                if (!a.descriptors.empty() && !b.descriptors.empty()) {
                    val knn = mutableListOf<MatOfDMatch>()
                    matcher.knnMatch(a.descriptors, b.descriptors, knn, 2)
                    knn.forEach { set ->
                        val matches = set.toArray()
                        if (matches.size >= 2 && matches[0].distance < RATIO_TEST * matches[1].distance) {
                            ratioMatches += matches[0]
                        }
                        set.release()
                    }
                }

                if (ratioMatches.size < MIN_RATIO_MATCHES) {
                    evaluations += SparsePairEvaluation(
                        a.file.name, b.file.name, ratioMatches.size, 0, 0
                    )
                    continue
                }

                val p1Array = ratioMatches.mapNotNull { match ->
                    a.keypoints.getOrNull(match.queryIdx)?.pt
                }.toTypedArray()
                val p2Array = ratioMatches.mapNotNull { match ->
                    b.keypoints.getOrNull(match.trainIdx)?.pt
                }.toTypedArray()
                val n = min(p1Array.size, p2Array.size)
                if (n < MIN_RATIO_MATCHES) {
                    evaluations += SparsePairEvaluation(a.file.name, b.file.name, n, 0, 0)
                    continue
                }

                val points1 = MatOfPoint2f(*p1Array.copyOf(n))
                val points2 = MatOfPoint2f(*p2Array.copyOf(n))
                val mask = Mat()
                val r = Mat()
                val t = Mat()
                val triangulated = Mat()
                val workingWidth = (a.width + b.width) / 2
                val workingHeight = (a.height + b.height) / 2
                val geometryModel = OpenCvCalibrationGeometry.model(
                    workingWidth, workingHeight, (a.focalPixels + b.focalPixels) / 2.0
                )
                val geometryPoints1 = OpenCvCalibrationGeometry.undistortPixelPoints(points1, geometryModel)
                val geometryPoints2 = OpenCvCalibrationGeometry.undistortPixelPoints(points2, geometryModel)

                try {
                    val essential = Calib3d.findEssentialMat(
                        geometryPoints1,
                        geometryPoints2,
                        geometryModel.k,
                        Calib3d.RANSAC,
                        0.999,
                        RANSAC_THRESHOLD_PX,
                        1000,
                        mask
                    )
                    if (essential.empty()) {
                        evaluations += SparsePairEvaluation(a.file.name, b.file.name, n, 0, 0)
                        essential.release()
                        continue
                    }

                    val ransacInliers = countMask(mask)
                    val poseInliers = if (ransacInliers >= 5) {
                        Calib3d.recoverPose(
                            essential,
                            geometryPoints1,
                            geometryPoints2,
                            geometryModel.k,
                            r,
                            t,
                            50.0,
                            mask,
                            triangulated
                        )
                    } else 0

                    val evaluation = SparsePairEvaluation(
                        firstPhoto = a.file.name,
                        secondPhoto = b.file.name,
                        ratioMatches = n,
                        ransacInliers = ransacInliers,
                        poseInliers = poseInliers
                    )
                    evaluations += evaluation

                    val cloud = if (poseInliers >= MIN_POSE_INLIERS && !triangulated.empty()) {
                        extractPoints(triangulated, mask)
                    } else emptyList()
                    val rotation = if (!r.empty()) rotationAngleDegrees(r) else 0.0
                    val geometry = PairGeometry(
                        evaluation = evaluation,
                        points = cloud,
                        focalPixels = (a.focalPixels + b.focalPixels) / 2.0,
                        intrinsicsSource = if (a.intrinsicsSource == b.intrinsicsSource) {
                            a.intrinsicsSource
                        } else {
                            "Mixed estimate (${a.intrinsicsSource}; ${b.intrinsicsSource})"
                        },
                        rotationDegrees = rotation
                    )

                    if (cloud.isNotEmpty() && (best == null || geometry.evaluation.poseInliers > best!!.evaluation.poseInliers)) {
                        best = geometry
                    }
                    essential.release()
                } finally {
                    points1.release()
                    points2.release()
                    geometryPoints1.release()
                    geometryPoints2.release()
                    mask.release()
                    r.release()
                    t.release()
                    triangulated.release()
                    geometryModel.close()
                }
            }

            val chosen = best ?: error(
                "No adjacent photo pair produced a stable camera pose. Try more overlap, sharper photos, or a slightly larger viewpoint change."
            )

            if (chosen.points.size < 50) {
                warnings += "Only ${chosen.points.size} stable 3D points were triangulated. This is enough to test the pipeline but not enough for a detailed model."
            }
            if (chosen.intrinsicsSource.startsWith("Fallback")) {
                warnings += "Camera focal length was approximated because usable EXIF focal metadata was unavailable. A later calibration stage will improve accuracy."
            }
            warnings += if (CameraCalibrationManager.activeProfile() != null) {
                "v0.26 uses the active camera calibration for sparse geometry and removes measured lens distortion from matched feature coordinates before essential-matrix/pose recovery."
            } else {
                "No compatible camera calibration was active; sparse geometry used the fallback pinhole model."
            }
            warnings += "This sparse cloud still uses the best adjacent photo pair only; Stage 3 expands geometry across the connected sequence."

            onProgress(1f, "Sparse 3D reconstruction complete")
            SparseReconstructionReport(
                engine = "OpenCV distortion-aware Essential Matrix + RANSAC 4.14 / v0.26",
                firstPhoto = chosen.evaluation.firstPhoto,
                secondPhoto = chosen.evaluation.secondPhoto,
                ratioMatches = chosen.evaluation.ratioMatches,
                ransacInliers = chosen.evaluation.ransacInliers,
                poseInliers = chosen.evaluation.poseInliers,
                triangulatedPoints = chosen.points.size,
                focalPixels = chosen.focalPixels,
                intrinsicsSource = chosen.intrinsicsSource,
                relativeRotationDegrees = chosen.rotationDegrees,
                pairEvaluations = evaluations,
                points = chosen.points,
                warnings = warnings,
                readyForMultiView = chosen.points.size >= 30 && chosen.evaluation.poseInliers >= MIN_POSE_INLIERS
            )
        } finally {
            featureSets.forEach { it.descriptors.release() }
            orb.clear()
            matcher.clear()
        }
    }

    private fun decodeScaled(file: File): android.graphics.Bitmap? =
        ExifBitmapLoader.decodeScaled(file, MAX_IMAGE_SIDE)

    private fun estimateFocalPixels(file: File, width: Int, height: Int): Pair<Double, String> {
        CameraCalibrationManager.focalEstimate(width, height)?.let { return it }
        val focal35 = runCatching {
            ExifInterface(file).getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
        }.getOrDefault(0)
        if (focal35 > 0) {
            val imageDiagonal = sqrt(width.toDouble() * width + height.toDouble() * height)
            val focalPixels = focal35.toDouble() * imageDiagonal / 43.2666153
            return focalPixels to "EXIF 35mm-equivalent focal length"
        }
        return (0.9 * max(width, height)) to "Fallback 0.9× max image dimension"
    }

    private fun cameraMatrix(width: Int, height: Int, focal: Double): Mat {
        CameraCalibrationManager.intrinsicsFor(width, height)?.let { intr ->
            val calibrated = Mat.eye(3, 3, CvType.CV_64F)
            calibrated.put(0, 0, intr.fx); calibrated.put(1, 1, intr.fy)
            calibrated.put(0, 2, intr.cx); calibrated.put(1, 2, intr.cy)
            return calibrated
        }
        val k = Mat.eye(3, 3, CvType.CV_64F)
        k.put(0, 0, focal)
        k.put(1, 1, focal)
        k.put(0, 2, width / 2.0)
        k.put(1, 2, height / 2.0)
        return k
    }

    private fun countMask(mask: Mat): Int {
        if (mask.empty()) return 0
        var count = 0
        val total = mask.rows() * mask.cols()
        for (i in 0 until total) {
            val value = if (mask.rows() == 1) mask.get(0, i) else mask.get(i, 0)
            if ((value?.getOrNull(0) ?: 0.0) != 0.0) count++
        }
        return count
    }

    private fun maskValue(mask: Mat, index: Int): Boolean {
        if (mask.empty()) return true
        val value = if (mask.rows() == 1) mask.get(0, index) else mask.get(index, 0)
        return (value?.getOrNull(0) ?: 0.0) != 0.0
    }

    private fun extractPoints(homogeneous: Mat, mask: Mat): List<SparsePoint> {
        if (homogeneous.rows() != 4) return emptyList()
        val points = ArrayList<SparsePoint>(homogeneous.cols())
        for (i in 0 until homogeneous.cols()) {
            if (!maskValue(mask, i)) continue
            val xh = homogeneous.get(0, i)?.getOrNull(0) ?: continue
            val yh = homogeneous.get(1, i)?.getOrNull(0) ?: continue
            val zh = homogeneous.get(2, i)?.getOrNull(0) ?: continue
            val wh = homogeneous.get(3, i)?.getOrNull(0) ?: continue
            if (!xh.isFinite() || !yh.isFinite() || !zh.isFinite() || !wh.isFinite() || abs(wh) < 1e-9) continue
            val x = xh / wh
            val y = yh / wh
            val z = zh / wh
            if (!x.isFinite() || !y.isFinite() || !z.isFinite() || z <= 0.0) continue
            val norm = sqrt(x * x + y * y + z * z)
            if (norm > 0.0 && norm < 1000.0) points += SparsePoint(x, y, z)
        }
        return trimExtremeDepth(points)
    }

    private fun trimExtremeDepth(points: List<SparsePoint>): List<SparsePoint> {
        if (points.size < 20) return points
        val sorted = points.map { it.z }.sorted()
        val low = sorted[(sorted.size * 0.02).toInt().coerceIn(0, sorted.lastIndex)]
        val high = sorted[(sorted.size * 0.98).toInt().coerceIn(0, sorted.lastIndex)]
        return points.filter { it.z in low..high }
    }

    private fun rotationAngleDegrees(r: Mat): Double {
        if (r.rows() != 3 || r.cols() != 3) return 0.0
        val trace = (r.get(0, 0)?.getOrNull(0) ?: 1.0) +
            (r.get(1, 1)?.getOrNull(0) ?: 1.0) +
            (r.get(2, 2)?.getOrNull(0) ?: 1.0)
        val cosAngle = ((trace - 1.0) / 2.0).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(cosAngle))
    }
}
