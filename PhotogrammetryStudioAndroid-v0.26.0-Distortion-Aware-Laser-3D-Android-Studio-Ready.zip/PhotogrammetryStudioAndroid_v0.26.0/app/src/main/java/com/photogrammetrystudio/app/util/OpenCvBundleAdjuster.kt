package com.photogrammetrystudio.app.util

import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.CameraPoseSummary
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.SparsePoint
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.CvType
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.6 milestone: build shared multi-view feature tracks and run a limited bundle adjustment.
 *
 * The optimization intentionally keeps camera rotations and intrinsics fixed. It alternates:
 *  - 3D point refinement against all observations in each track
 *  - camera translation refinement (with the first two cameras fixed to preserve gauge/scale)
 *
 * This is a real reprojection-error optimization and provides the shared observations needed for
 * the later full bundle-adjustment stage, while staying light enough for on-device testing.
 */
object OpenCvBundleAdjuster {
    private const val MAX_IMAGE_SIDE = 1600
    private const val MAX_FEATURES = 2500
    private const val RATIO_TEST = 0.75f
    private const val RANSAC_THRESHOLD_PX = 1.5
    private const val MIN_RATIO_MATCHES = 12
    private const val MIN_POSE_INLIERS = 20
    private const val MIN_TRACK_VIEWS = 3
    private const val MAX_TRACKS = 1600
    private const val BA_ITERATIONS = 4
    private const val MAX_INITIAL_TRACK_RMS = 25.0
    private const val HUBER_PX = 3.0

    @Volatile private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    private data class Features(
        val file: File,
        val globalIndex: Int,
        val keypoints: Array<org.opencv.core.KeyPoint>,
        val geometryPoints: Array<org.opencv.core.Point>,
        val descriptors: Mat,
        val width: Int,
        val height: Int,
        val focalPixels: Double,
        val fx: Double,
        val fy: Double,
        val cx: Double,
        val cy: Double,
        val intrinsicsSource: String
    )

    private data class Pose(var r: DoubleArray, var t: DoubleArray)
    private data class Observation(val camera: Int, val keypoint: Int, val x: Double, val y: Double)
    private data class Track(var point: SparsePoint, val observations: List<Observation>)

    private class UnionFind {
        private val parent = HashMap<Long, Long>()
        private val rank = HashMap<Long, Int>()

        fun add(x: Long) {
            if (x !in parent) {
                parent[x] = x
                rank[x] = 0
            }
        }

        fun find(x: Long): Long {
            add(x)
            val p = parent[x]!!
            if (p != x) parent[x] = find(p)
            return parent[x]!!
        }

        fun union(a: Long, b: Long) {
            var ra = find(a)
            var rb = find(b)
            if (ra == rb) return
            val rka = rank[ra] ?: 0
            val rkb = rank[rb] ?: 0
            if (rka < rkb) {
                val tmp = ra; ra = rb; rb = tmp
            }
            parent[rb] = ra
            if (rka == rkb) rank[ra] = rka + 1
        }

        fun keys(): Set<Long> = parent.keys
    }

    fun refine(
        files: List<File>,
        multiView: MultiViewReconstructionReport,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<BundleAdjustmentReport> = runCatching {
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }
        val connectedIndices = multiView.cameras.filter { it.connected }.map { it.index }.sorted()
        require(connectedIndices.size >= 4) { "At least 4 connected cameras are required for refinement." }
        require(connectedIndices.zipWithNext().all { (a, b) -> b == a + 1 }) {
            "v0.6 currently expects the selected multi-view component to be contiguous."
        }

        val start = connectedIndices.first()
        val end = connectedIndices.last()
        require(start >= 0 && end < files.size) { "Connected camera indices do not match the current photo set." }

        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        val features = mutableListOf<Features>()
        val warnings = mutableListOf<String>()

        try {
            val segmentFiles = files.subList(start, end + 1)
            segmentFiles.forEachIndexed { localIndex, file ->
                onProgress(localIndex.toFloat() / segmentFiles.size * 0.20f, "Preparing track features ${localIndex + 1}/${segmentFiles.size}")
                val bitmap = decodeScaled(file) ?: error("Could not decode ${file.name}.")
                val rgba = Mat(); val gray = Mat(); val kpMat = MatOfKeyPoint(); val desc = Mat()
                try {
                    Utils.bitmapToMat(bitmap, rgba)
                    Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                    orb.detectAndCompute(gray, Mat(), kpMat, desc)
                    val rawKeypoints = kpMat.toArray()
                    val focal = estimateFocalPixels(file, bitmap.width, bitmap.height)
                    val geometryModel = OpenCvCalibrationGeometry.model(bitmap.width, bitmap.height, focal.first)
                    val rawPoints = MatOfPoint2f(*rawKeypoints.map { it.pt }.toTypedArray())
                    val geometryMat = OpenCvCalibrationGeometry.undistortPixelPoints(rawPoints, geometryModel)
                    val geometryPoints = geometryMat.toArray()
                    rawPoints.release(); geometryMat.release()
                    features += Features(
                        file, start + localIndex, rawKeypoints, geometryPoints, desc, bitmap.width, bitmap.height, focal.first,
                        geometryModel.fx, geometryModel.fy, geometryModel.cx, geometryModel.cy, focal.second
                    )
                    geometryModel.close()
                } finally {
                    bitmap.recycle(); rgba.release(); gray.release(); kpMat.release()
                }
            }

            val poses = MutableList(features.size) { Pose(identity3(), doubleArrayOf(0.0, 0.0, 0.0)) }
            val uf = UnionFind()
            var totalPoseInliers = 0

            for (i in 0 until features.lastIndex) {
                onProgress(0.20f + i.toFloat() / features.lastIndex.coerceAtLeast(1) * 0.35f, "Building shared tracks ${i + 1}/${features.lastIndex}")
                val a = features[i]
                val b = features[i + 1]
                val ratio = mutableListOf<org.opencv.core.DMatch>()
                if (!a.descriptors.empty() && !b.descriptors.empty()) {
                    val knn = mutableListOf<MatOfDMatch>()
                    matcher.knnMatch(a.descriptors, b.descriptors, knn, 2)
                    knn.forEach { set ->
                        val m = set.toArray()
                        if (m.size >= 2 && m[0].distance < RATIO_TEST * m[1].distance) ratio += m[0]
                        set.release()
                    }
                }
                require(ratio.size >= MIN_RATIO_MATCHES) { "Connected pair ${a.file.name} → ${b.file.name} no longer has enough descriptor matches." }

                val p1 = MatOfPoint2f(*ratio.map { a.geometryPoints[it.queryIdx] }.toTypedArray())
                val p2 = MatOfPoint2f(*ratio.map { b.geometryPoints[it.trainIdx] }.toTypedArray())
                val mask = Mat(); val rMat = Mat(); val tMat = Mat(); val tri = Mat()
                val focal = (a.focalPixels + b.focalPixels) / 2.0
                val k = cameraMatrix((a.width + b.width) / 2, (a.height + b.height) / 2, focal)
                try {
                    val essential = Calib3d.findEssentialMat(p1, p2, k, Calib3d.RANSAC, 0.999, RANSAC_THRESHOLD_PX, 1000, mask)
                    require(!essential.empty()) { "Essential matrix failed for connected pair ${a.file.name} → ${b.file.name}." }
                    val poseInliers = Calib3d.recoverPose(essential, p1, p2, k, rMat, tMat, 50.0, mask, tri)
                    essential.release()
                    require(poseInliers >= MIN_POSE_INLIERS) { "Connected pair ${a.file.name} → ${b.file.name} dropped below the pose-inlier threshold ($poseInliers)." }
                    totalPoseInliers += poseInliers

                    poses[i + 1] = composePose(poses[i], mat3(rMat), vec3(tMat))
                    ratio.forEachIndexed { index, match ->
                        if (!maskValue(mask, index)) return@forEachIndexed
                        val ka = node(i, match.queryIdx)
                        val kb = node(i + 1, match.trainIdx)
                        uf.union(ka, kb)
                    }
                } finally {
                    p1.release(); p2.release(); mask.release(); rMat.release(); tMat.release(); tri.release(); k.release()
                }
            }

            val grouped = LinkedHashMap<Long, MutableList<Pair<Int, Int>>>()
            uf.keys().forEach { key ->
                val root = uf.find(key)
                grouped.getOrPut(root) { mutableListOf() } += decodeNode(key)
            }

            val rawTrackObservations = grouped.values.mapNotNull { nodes ->
                val uniqueByCamera = LinkedHashMap<Int, Pair<Int, Int>>()
                nodes.sortedBy { it.first }.forEach { pair -> uniqueByCamera.putIfAbsent(pair.first, pair) }
                if (uniqueByCamera.size < MIN_TRACK_VIEWS) {
                    null
                } else {
                    uniqueByCamera.values.mapNotNull { (cam, kpIndex) ->
                        val point = features.getOrNull(cam)?.geometryPoints?.getOrNull(kpIndex)
                        if (point == null) null else Observation(cam, kpIndex, point.x, point.y)
                    }
                }
            }.sortedByDescending { it.size }

            val tracksBuilt = rawTrackObservations.size
            val selectedObservations = rawTrackObservations.take(MAX_TRACKS)
            val tracks = mutableListOf<Track>()
            selectedObservations.forEachIndexed { index, obs ->
                if (index % 50 == 0) onProgress(0.55f + index.toFloat() / selectedObservations.size.coerceAtLeast(1) * 0.10f, "Triangulating shared track ${index + 1}/${selectedObservations.size}")
                val initial = triangulateTrack(obs, poses, features) ?: return@forEachIndexed
                val rms = trackRms(initial, obs, poses, features)
                if (rms.isFinite() && rms <= MAX_INITIAL_TRACK_RMS) tracks += Track(initial, obs)
            }

            require(tracks.size >= 20) { "Only ${tracks.size} stable 3+ view tracks survived initial triangulation; more overlap is needed." }
            val initialRms = globalRms(tracks, poses, features)
            val initialPoints = tracks.size

            repeat(BA_ITERATIONS) { iteration ->
                onProgress(0.65f + iteration.toFloat() / BA_ITERATIONS * 0.28f, "Bundle refinement iteration ${iteration + 1}/$BA_ITERATIONS")
                tracks.forEach { track -> track.point = optimizePoint(track.point, track.observations, poses, features) }
                // Keep camera 0 and camera 1 fixed: this removes global translation and scale gauge freedom.
                for (camera in 2 until poses.size) {
                    optimizeCameraTranslation(camera, tracks, poses, features)
                }
            }

            // One final point pass after camera translations move.
            tracks.forEach { track -> track.point = optimizePoint(track.point, track.observations, poses, features) }

            val filtered = tracks.filter { track ->
                val rms = trackRms(track.point, track.observations, poses, features)
                rms.isFinite() && rms <= 6.0 && positiveInMostViews(track.point, track.observations, poses)
            }
            val finalRms = globalRms(filtered, poses, features)
            val observationsUsed = filtered.sumOf { it.observations.size }

            if (tracksBuilt > MAX_TRACKS) warnings += "Built $tracksBuilt multi-view tracks; optimized the strongest $MAX_TRACKS to limit phone memory/CPU use."
            warnings += if (CameraCalibrationManager.activeProfile() != null) "v0.26 bundle observations are undistorted into calibrated pixel coordinates before triangulation and reprojection refinement." else "No compatible active camera calibration; bundle refinement uses fallback pinhole observations."
            if (filtered.size < tracks.size) warnings += "${tracks.size - filtered.size} high-error tracks were removed after refinement."
            if (!finalRms.isFinite() || finalRms > initialRms * 1.02) warnings += "Reprojection RMS did not improve as expected; this component may need stronger bridge/loop-closure constraints."
            if (connectedIndices.size < multiView.photosRequested) warnings += "Refinement covers ${connectedIndices.size} connected cameras only; disconnected cameras remain outside this bundle."
            warnings += "The bounded mobile bundle still fixes camera rotations/intrinsics and refines camera translations plus shared 3D points. Full rotation/intrinsic bundle adjustment remains a later milestone."

            val cameraSummaries = features.mapIndexed { local, f -> cameraSummary(f.globalIndex, f.file.name, poses[local]) }
            val finalPoints = filtered.map { it.point }
            val improved = finalRms.isFinite() && initialRms.isFinite() && finalRms <= initialRms * 1.02
            val readyForDense = connectedIndices.size >= 6 && filtered.size >= 100 && observationsUsed >= 300 && improved && finalRms < 5.0

            onProgress(1f, "Track bundle refinement complete")
            BundleAdjustmentReport(
                engine = "OpenCV calibrated shared tracks + limited bundle adjustment 4.14 / v0.26",
                connectedCameras = connectedIndices.size,
                tracksBuilt = tracksBuilt,
                tracksUsed = selectedObservations.size,
                observationsUsed = observationsUsed,
                initialPoints = initialPoints,
                refinedPoints = finalPoints.size,
                initialRmsPixels = initialRms,
                finalRmsPixels = finalRms,
                iterations = BA_ITERATIONS,
                cameras = cameraSummaries,
                points = finalPoints,
                warnings = warnings,
                readyForDenseReconstruction = readyForDense
            )
        } finally {
            features.forEach { it.descriptors.release() }
            orb.clear(); matcher.clear()
        }
    }

    private fun optimizePoint(start: SparsePoint, obs: List<Observation>, poses: List<Pose>, features: List<Features>): SparsePoint {
        var x = doubleArrayOf(start.x, start.y, start.z)
        repeat(5) {
            val h = DoubleArray(9); val g = DoubleArray(3)
            var used = 0
            obs.forEach { o ->
                val p = poses[o.camera]; val f = features[o.camera]
                val pc = worldToCamera(x, p)
                val z = pc[2]
                if (z <= 1e-6 || !z.isFinite()) return@forEach
                val predU = f.focalPixels * pc[0] / z + f.width / 2.0
                val predV = f.focalPixels * pc[1] / z + f.height / 2.0
                val ru = predU - o.x; val rv = predV - o.y
                val w = huberWeight(sqrt(ru * ru + rv * rv))
                val z2 = z * z
                val ju = DoubleArray(3) { c -> f.focalPixels * (z * p.r[c] - pc[0] * p.r[6 + c]) / z2 }
                val jv = DoubleArray(3) { c -> f.focalPixels * (z * p.r[3 + c] - pc[1] * p.r[6 + c]) / z2 }
                accumulateNormal(h, g, ju, ru, w); accumulateNormal(h, g, jv, rv, w)
                used += 2
            }
            if (used < 6) return@repeat
            for (d in 0..2) h[d * 3 + d] += 1e-4
            val delta = solve3(h, doubleArrayOf(-g[0], -g[1], -g[2])) ?: return@repeat
            x[0] += delta[0]; x[1] += delta[1]; x[2] += delta[2]
            if (sqrt(delta.sumOf { it * it }) < 1e-6) return@repeat
        }
        return SparsePoint(x[0], x[1], x[2])
    }

    private fun optimizeCameraTranslation(camera: Int, tracks: List<Track>, poses: MutableList<Pose>, features: List<Features>) {
        val pose = poses[camera]
        repeat(3) {
            val h = DoubleArray(9); val g = DoubleArray(3); var used = 0
            tracks.forEach { track ->
                val o = track.observations.firstOrNull { it.camera == camera } ?: return@forEach
                val xyz = doubleArrayOf(track.point.x, track.point.y, track.point.z)
                val pc = worldToCamera(xyz, pose)
                val z = pc[2]
                if (z <= 1e-6 || !z.isFinite()) return@forEach
                val f = features[camera]
                val predU = f.fx * pc[0] / z + f.cx
                val predV = f.fy * pc[1] / z + f.cy
                val ru = predU - o.x; val rv = predV - o.y
                val w = huberWeight(sqrt(ru * ru + rv * rv))
                val z2 = z * z
                val ju = doubleArrayOf(f.fx / z, 0.0, -f.fx * pc[0] / z2)
                val jv = doubleArrayOf(0.0, f.fy / z, -f.fy * pc[1] / z2)
                accumulateNormal(h, g, ju, ru, w); accumulateNormal(h, g, jv, rv, w)
                used += 2
            }
            if (used < 12) return@repeat
            for (d in 0..2) h[d * 3 + d] += 1e-3
            val delta = solve3(h, doubleArrayOf(-g[0], -g[1], -g[2])) ?: return@repeat
            val maxStep = 0.15
            pose.t[0] += delta[0].coerceIn(-maxStep, maxStep)
            pose.t[1] += delta[1].coerceIn(-maxStep, maxStep)
            pose.t[2] += delta[2].coerceIn(-maxStep, maxStep)
        }
    }

    private fun triangulateTrack(obs: List<Observation>, poses: List<Pose>, features: List<Features>): SparsePoint? {
        if (obs.size < 2) return null
        val a = obs.first(); val b = obs.last()
        val pa = projectionMatrix(poses[a.camera], features[a.camera])
        val pb = projectionMatrix(poses[b.camera], features[b.camera])
        val aMat = Mat(4, 4, CvType.CV_64F)
        try {
            for (c in 0..3) {
                aMat.put(0, c, a.x * pa[8 + c] - pa[c])
                aMat.put(1, c, a.y * pa[8 + c] - pa[4 + c])
                aMat.put(2, c, b.x * pb[8 + c] - pb[c])
                aMat.put(3, c, b.y * pb[8 + c] - pb[4 + c])
            }
            val ata = Mat(4, 4, CvType.CV_64F); val eigenValues = Mat(); val eigenVectors = Mat()
            try {
                for (r in 0..3) {
                    for (c in 0..3) {
                        var sum = 0.0
                        for (k in 0..3) sum += (aMat.get(k, r)?.getOrNull(0) ?: 0.0) * (aMat.get(k, c)?.getOrNull(0) ?: 0.0)
                        ata.put(r, c, sum)
                    }
                }
                if (!Core.eigen(ata, eigenValues, eigenVectors)) return null
                val row = eigenVectors.rows() - 1
                val h = DoubleArray(4) { c -> eigenVectors.get(row, c)?.getOrNull(0) ?: 0.0 }
                if (abs(h[3]) < 1e-9) return null
                val p = SparsePoint(h[0] / h[3], h[1] / h[3], h[2] / h[3])
                return if (p.x.isFinite() && p.y.isFinite() && p.z.isFinite() && positiveInMostViews(p, obs, poses)) p else null
            } finally { ata.release(); eigenValues.release(); eigenVectors.release() }
        } finally { aMat.release() }
    }

    private fun projectionMatrix(pose: Pose, f: Features): DoubleArray {
        val out = DoubleArray(12)
        // K * [R|t] in the undistorted calibrated pixel coordinate system.
        for (c in 0..2) {
            out[c] = f.fx * pose.r[c] + f.cx * pose.r[6 + c]
            out[4 + c] = f.fy * pose.r[3 + c] + f.cy * pose.r[6 + c]
            out[8 + c] = pose.r[6 + c]
        }
        out[3] = f.fx * pose.t[0] + f.cx * pose.t[2]
        out[7] = f.fy * pose.t[1] + f.cy * pose.t[2]
        out[11] = pose.t[2]
        return out
    }

    private fun globalRms(tracks: List<Track>, poses: List<Pose>, features: List<Features>): Double {
        var sum = 0.0; var n = 0
        tracks.forEach { track ->
            track.observations.forEach { o ->
                val err = reprojectionError(track.point, o, poses[o.camera], features[o.camera])
                if (err.isFinite()) { sum += err * err; n++ }
            }
        }
        return if (n == 0) Double.NaN else sqrt(sum / n)
    }

    private fun trackRms(point: SparsePoint, obs: List<Observation>, poses: List<Pose>, features: List<Features>): Double {
        var sum = 0.0; var n = 0
        obs.forEach { o ->
            val e = reprojectionError(point, o, poses[o.camera], features[o.camera])
            if (e.isFinite()) { sum += e * e; n++ }
        }
        return if (n == 0) Double.NaN else sqrt(sum / n)
    }

    private fun reprojectionError(point: SparsePoint, o: Observation, pose: Pose, f: Features): Double {
        val pc = worldToCamera(doubleArrayOf(point.x, point.y, point.z), pose)
        if (pc[2] <= 1e-6) return Double.POSITIVE_INFINITY
        val u = f.fx * pc[0] / pc[2] + f.cx
        val v = f.fy * pc[1] / pc[2] + f.cy
        val du = u - o.x; val dv = v - o.y
        return sqrt(du * du + dv * dv)
    }

    private fun positiveInMostViews(point: SparsePoint, obs: List<Observation>, poses: List<Pose>): Boolean {
        val xyz = doubleArrayOf(point.x, point.y, point.z)
        val positive = obs.count { worldToCamera(xyz, poses[it.camera])[2] > 1e-6 }
        return positive >= max(2, (obs.size * 2 + 2) / 3)
    }

    private fun worldToCamera(x: DoubleArray, pose: Pose): DoubleArray {
        val rx = multiply3Vec(pose.r, x)
        return doubleArrayOf(rx[0] + pose.t[0], rx[1] + pose.t[1], rx[2] + pose.t[2])
    }

    private fun huberWeight(error: Double): Double = if (error <= HUBER_PX || error <= 1e-9) 1.0 else HUBER_PX / error

    private fun accumulateNormal(h: DoubleArray, g: DoubleArray, j: DoubleArray, residual: Double, weight: Double) {
        for (r in 0..2) {
            g[r] += weight * j[r] * residual
            for (c in 0..2) h[r * 3 + c] += weight * j[r] * j[c]
        }
    }

    private fun solve3(a: DoubleArray, b: DoubleArray): DoubleArray? {
        val m = Array(3) { r -> DoubleArray(4) { c -> if (c < 3) a[r * 3 + c] else b[r] } }
        for (col in 0..2) {
            var pivot = col
            for (r in col + 1..2) if (abs(m[r][col]) > abs(m[pivot][col])) pivot = r
            if (abs(m[pivot][col]) < 1e-10) return null
            val tmp = m[col]; m[col] = m[pivot]; m[pivot] = tmp
            val div = m[col][col]
            for (c in col..3) m[col][c] /= div
            for (r in 0..2) if (r != col) {
                val f = m[r][col]
                for (c in col..3) m[r][c] -= f * m[col][c]
            }
        }
        return doubleArrayOf(m[0][3], m[1][3], m[2][3])
    }

    private fun node(camera: Int, keypoint: Int): Long = (camera.toLong() shl 32) or (keypoint.toLong() and 0xffffffffL)
    private fun decodeNode(node: Long): Pair<Int, Int> = ((node ushr 32).toInt()) to node.toInt()

    private fun decodeScaled(file: File): android.graphics.Bitmap? =
        ExifBitmapLoader.decodeScaled(file, MAX_IMAGE_SIDE)

    private fun estimateFocalPixels(file: File, width: Int, height: Int): Pair<Double, String> {
        CameraCalibrationManager.focalEstimate(width, height)?.let { return it }
        val focal35 = runCatching { ExifInterface(file).getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0) }.getOrDefault(0)
        if (focal35 > 0) {
            val diagonal = sqrt(width.toDouble() * width + height.toDouble() * height)
            return focal35.toDouble() * diagonal / 43.2666153 to "EXIF 35mm-equivalent focal length"
        }
        return 0.9 * max(width, height) to "Fallback 0.9× max image dimension"
    }

    private fun cameraMatrix(width: Int, height: Int, focal: Double): Mat {
        CameraCalibrationManager.intrinsicsFor(width, height)?.let { intr ->
            return Mat.eye(3, 3, CvType.CV_64F).apply {
                put(0, 0, intr.fx); put(1, 1, intr.fy); put(0, 2, intr.cx); put(1, 2, intr.cy)
            }
        }
        return Mat.eye(3, 3, CvType.CV_64F).apply {
            put(0, 0, focal); put(1, 1, focal); put(0, 2, width / 2.0); put(1, 2, height / 2.0)
        }
    }

    private fun maskValue(mask: Mat, index: Int): Boolean {
        if (mask.empty()) return true
        val value = if (mask.rows() == 1) mask.get(0, index) else mask.get(index, 0)
        return (value?.getOrNull(0) ?: 0.0) != 0.0
    }

    private fun mat3(mat: Mat): DoubleArray = DoubleArray(9).also { out ->
        for (r in 0..2) for (c in 0..2) out[r * 3 + c] = mat.get(r, c)?.getOrNull(0) ?: if (r == c) 1.0 else 0.0
    }
    private fun vec3(mat: Mat): DoubleArray = doubleArrayOf(mat.get(0, 0)?.getOrNull(0) ?: 0.0, mat.get(1, 0)?.getOrNull(0) ?: 0.0, mat.get(2, 0)?.getOrNull(0) ?: 0.0)
    private fun identity3(): DoubleArray = doubleArrayOf(1.0,0.0,0.0, 0.0,1.0,0.0, 0.0,0.0,1.0)

    private fun multiply3(a: DoubleArray, b: DoubleArray): DoubleArray {
        val out = DoubleArray(9)
        for (r in 0..2) for (c in 0..2) out[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c]
        return out
    }
    private fun multiply3Vec(a: DoubleArray, v: DoubleArray): DoubleArray = doubleArrayOf(
        a[0]*v[0]+a[1]*v[1]+a[2]*v[2], a[3]*v[0]+a[4]*v[1]+a[5]*v[2], a[6]*v[0]+a[7]*v[1]+a[8]*v[2]
    )
    private fun transpose3(a: DoubleArray): DoubleArray = doubleArrayOf(a[0],a[3],a[6], a[1],a[4],a[7], a[2],a[5],a[8])

    private fun composePose(current: Pose, relR: DoubleArray, relT: DoubleArray): Pose {
        val nextR = multiply3(relR, current.r)
        val rt = multiply3Vec(relR, current.t)
        return Pose(nextR, doubleArrayOf(rt[0] + relT[0], rt[1] + relT[1], rt[2] + relT[2]))
    }

    private fun cameraSummary(globalIndex: Int, photo: String, pose: Pose): CameraPoseSummary {
        val center = multiply3Vec(transpose3(pose.r), doubleArrayOf(-pose.t[0], -pose.t[1], -pose.t[2]))
        return CameraPoseSummary(photo, globalIndex, true, center[0], center[1], center[2])
    }
}
