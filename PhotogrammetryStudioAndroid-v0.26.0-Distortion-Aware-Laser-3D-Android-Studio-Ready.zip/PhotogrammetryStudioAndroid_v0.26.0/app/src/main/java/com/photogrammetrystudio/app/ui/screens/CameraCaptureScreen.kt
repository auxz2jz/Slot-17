package com.photogrammetrystudio.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.coroutines.resume

private enum class CaptureStyle(val label: String) {
    SINGLE("Single"),
    RAPID_HOLD("Hold Rapid"),
    RAPID_TOGGLE("Tap Rapid")
}

private enum class RapidInterval(val label: String, val intervalMs: Long) {
    FIVE_PER_SECOND("5/sec", 200L),
    TWO_PER_SECOND("2/sec", 500L),
    ONE_PER_SECOND("1/sec", 1_000L),
    EVERY_TWO_SECONDS("2 sec", 2_000L),
    EVERY_FIVE_SECONDS("5 sec", 5_000L)
}

@Composable
fun CameraCaptureScreen(
    projectName: String,
    outputFileProvider: () -> File,
    onPhotoSaved: () -> Unit,
    onBack: () -> Unit,
    onOpenTestGuide: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var status by remember { mutableStateOf("Move around the object and keep strong overlap.") }

    var captureStyleIndex by rememberSaveable { mutableIntStateOf(CaptureStyle.SINGLE.ordinal) }
    val captureStyle = CaptureStyle.entries[captureStyleIndex.coerceIn(0, CaptureStyle.entries.lastIndex)]
    var rapidIntervalIndex by rememberSaveable { mutableIntStateOf(RapidInterval.ONE_PER_SECOND.ordinal) }
    val rapidInterval = RapidInterval.entries[rapidIntervalIndex.coerceIn(0, RapidInterval.entries.lastIndex)]
    var rapidMenuOpen by remember { mutableStateOf(false) }
    var useCountdown by rememberSaveable { mutableStateOf(true) }
    var rapidActive by remember { mutableStateOf(false) }
    var rapidJob by remember { mutableStateOf<Job?>(null) }
    var rapidSaved by remember { mutableIntStateOf(0) }
    var rapidStopReason by remember { mutableStateOf("Not started") }
    var singleCaptureBusy by remember { mutableStateOf(false) }
    val currentRapidActive by rememberUpdatedState(rapidActive)
    val rapidDiagnosticsPreferences = remember(context) {
        context.getSharedPreferences("rapid_capture_diagnostics", Context.MODE_PRIVATE)
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permissionGranted = it
    }

    LaunchedEffect(Unit) {
        if (!permissionGranted) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    suspend fun captureOne(updateSingleProject: Boolean): Boolean {
        val capture = imageCapture ?: return false
        if (singleCaptureBusy) return false
        singleCaptureBusy = true
        val file = outputFileProvider()
        status = "Saving ${file.name}…"
        val options = ImageCapture.OutputFileOptions.Builder(file).build()

        val saved = try {
            suspendCancellableCoroutine<Boolean> { continuation ->
                capture.takePicture(
                    options,
                    ContextCompat.getMainExecutor(context),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                            if (continuation.isActive) continuation.resume(true)
                        }

                        override fun onError(exception: ImageCaptureException) {
                            status = "Capture failed: ${exception.message ?: "unknown error"}"
                            if (continuation.isActive) continuation.resume(false)
                        }
                    }
                )
            }
        } finally {
            singleCaptureBusy = false
        }
        if (saved && updateSingleProject) {
            status = "Saved ${file.name}. Move to the next overlapping viewpoint."
            onPhotoSaved()
        }
        return saved
    }

    fun stopRapid(reason: String = "User stopped") {
        rapidStopReason = reason
        rapidActive = false
        status = if (rapidSaved > 0) {
            "Stopping Rapid… ${rapidSaved} photo(s) saved so far."
        } else {
            "Stopping Rapid…"
        }
    }

    fun recordRapidRun(
        mode: String,
        target: RapidInterval,
        saved: Int,
        elapsedMs: Long,
        captureTimeMs: Long,
        reason: String
    ) {
        val actualRate = if (elapsedMs > 0L) saved * 1000.0 / elapsedMs else 0.0
        val averageSaveMs = if (saved > 0) captureTimeMs.toDouble() / saved else 0.0
        val timestamp = DateFormat.getDateTimeInstance().format(Date())
        val line = buildString {
            append(timestamp)
            append(" | mode=").append(mode)
            append(" | target=").append(target.label).append(" (").append(target.intervalMs).append(" ms)")
            append(" | saved=").append(saved)
            append(" | elapsed=").append("%.2f".format(elapsedMs / 1000.0)).append(" s")
            append(" | actual=").append("%.2f".format(actualRate)).append(" photos/sec")
            append(" | avg full-res save=").append("%.0f".format(averageSaveMs)).append(" ms")
            append(" | stop=").append(reason)
        }
        val previous = rapidDiagnosticsPreferences.getString("history", "").orEmpty()
            .lineSequence().filter { it.isNotBlank() }.toList()
        rapidDiagnosticsPreferences.edit()
            .putString("history", (previous + line).takeLast(12).joinToString("\n"))
            .putString("last_run", line)
            .apply()
    }

    fun startRapid(withCountdown: Boolean) {
        if (rapidActive || rapidJob?.isActive == true || imageCapture == null) return
        val modeAtStart = captureStyle.label
        val targetAtStart = rapidInterval
        rapidStopReason = "Running"
        rapidActive = true
        rapidSaved = 0
        rapidJob = scope.launch {
            var savedThisRun = 0
            var captureTimeMs = 0L
            var runStartedAt = 0L
            try {
                if (withCountdown) {
                    for (second in 3 downTo 1) {
                        if (!rapidActive) return@launch
                        status = "Rapid starts in $second…"
                        delay(1_000L)
                    }
                }
                runStartedAt = SystemClock.elapsedRealtime()
                while (rapidActive && isActive) {
                    val captureStartedAt = SystemClock.elapsedRealtime()
                    val saved = captureOne(updateSingleProject = false)
                    val captureElapsed = SystemClock.elapsedRealtime() - captureStartedAt
                    captureTimeMs += captureElapsed
                    if (!saved) {
                        rapidStopReason = "Capture error"
                        rapidActive = false
                        break
                    }
                    savedThisRun++
                    rapidSaved = savedThisRun
                    val elapsedRun = (SystemClock.elapsedRealtime() - runStartedAt).coerceAtLeast(1L)
                    val actualRate = savedThisRun * 1000.0 / elapsedRun
                    status = "Rapid running • $savedThisRun saved • target ${targetAtStart.label} • actual ${"%.2f".format(actualRate)}/sec"

                    // Full-resolution still capture is serialized. If saving takes longer than
                    // the requested interval, the next shot starts immediately after save instead
                    // of queuing overlapping ImageCapture requests.
                    val remaining = targetAtStart.intervalMs - captureElapsed
                    if (remaining > 0L) delay(remaining)
                }
            } finally {
                rapidActive = false
                val elapsedRun = if (runStartedAt > 0L) {
                    (SystemClock.elapsedRealtime() - runStartedAt).coerceAtLeast(1L)
                } else 0L
                val reason = if (rapidStopReason == "Running") "Sequence ended" else rapidStopReason
                recordRapidRun(modeAtStart, targetAtStart, savedThisRun, elapsedRun, captureTimeMs, reason)
                if (savedThisRun > 0) {
                    val actualRate = if (elapsedRun > 0L) savedThisRun * 1000.0 / elapsedRun else 0.0
                    status = "Rapid stopped • $savedThisRun saved • actual ${"%.2f".format(actualRate)}/sec • target ${targetAtStart.label}"
                    // Refresh/analyze the project once for the entire sequence rather than once
                    // for every frame in a long burst.
                    onPhotoSaved()
                } else if (!singleCaptureBusy) {
                    status = "Rapid stopped • no photos saved."
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            rapidStopReason = "Camera screen closed"
            rapidActive = false
            rapidJob?.cancel()
            cameraProvider?.unbindAll()
            imageCapture = null
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (permissionGranted) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
                },
                modifier = Modifier.fillMaxSize(),
                update = { previewView ->
                    val providerFuture = ProcessCameraProvider.getInstance(context)
                    providerFuture.addListener({
                        val provider = providerFuture.get()
                        cameraProvider = provider
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        val capture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                            .build()
                        imageCapture = capture
                        runCatching {
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                capture
                            )
                        }.onFailure { status = it.message ?: "Unable to open camera" }
                    }, ContextCompat.getMainExecutor(context))
                }
            )
        } else {
            Column(
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Camera permission is required to capture photogrammetry photos.", color = Color.White)
                Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                    Text("Allow camera")
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.50f))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(projectName, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(status, color = Color.White, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onOpenTestGuide) {
                Icon(Icons.Default.HelpOutline, contentDescription = "Test this version", tint = Color.White)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.62f))
                .padding(horizontal = 12.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CaptureStyle.entries.forEach { style ->
                    FilterChip(
                        selected = captureStyle == style,
                        onClick = {
                            if (!rapidActive) captureStyleIndex = style.ordinal
                        },
                        label = { Text(style.label) },
                        enabled = !rapidActive
                    )
                }
            }

            if (captureStyle != CaptureStyle.SINGLE) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        OutlinedButton(onClick = { rapidMenuOpen = true }, enabled = !rapidActive) {
                            Text("Target: ${rapidInterval.label}")
                        }
                        DropdownMenu(expanded = rapidMenuOpen, onDismissRequest = { rapidMenuOpen = false }) {
                            RapidInterval.entries.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option.label) },
                                    onClick = {
                                        rapidIntervalIndex = option.ordinal
                                        rapidMenuOpen = false
                                    }
                                )
                            }
                        }
                    }
                    if (captureStyle == CaptureStyle.RAPID_TOGGLE) {
                        Spacer(Modifier.size(12.dp))
                        Text("3s delay", color = Color.White, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.size(6.dp))
                        Switch(
                            checked = useCountdown,
                            onCheckedChange = { useCountdown = it },
                            enabled = !rapidActive
                        )
                    }
                }
            }

            if (rapidActive) {
                Text(
                    "Rapid active • ${rapidSaved} saved • tap/hold control to stop",
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Surface(
                modifier = Modifier
                    .size(78.dp)
                    .pointerInput(captureStyle, rapidInterval, useCountdown, imageCapture) {
                        detectTapGestures(
                            onPress = {
                                when (captureStyle) {
                                    CaptureStyle.SINGLE -> {
                                        if (!singleCaptureBusy && !currentRapidActive) {
                                            scope.launch { captureOne(updateSingleProject = true) }
                                        }
                                        tryAwaitRelease()
                                    }
                                    CaptureStyle.RAPID_HOLD -> {
                                        if (!currentRapidActive) startRapid(withCountdown = false)
                                        try {
                                            tryAwaitRelease()
                                        } finally {
                                            stopRapid("Hold released")
                                        }
                                    }
                                    CaptureStyle.RAPID_TOGGLE -> {
                                        if (currentRapidActive) stopRapid("Tap stop") else startRapid(withCountdown = useCountdown)
                                        tryAwaitRelease()
                                    }
                                }
                            }
                        )
                    },
                shape = CircleShape,
                color = if (rapidActive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                shadowElevation = 6.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        if (rapidActive) Icons.Default.Stop else Icons.Default.Camera,
                        contentDescription = when (captureStyle) {
                            CaptureStyle.SINGLE -> "Take photo"
                            CaptureStyle.RAPID_HOLD -> "Hold for Rapid capture"
                            CaptureStyle.RAPID_TOGGLE -> if (rapidActive) "Stop Rapid capture" else "Start Rapid capture"
                        },
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Text(
                when (captureStyle) {
                    CaptureStyle.SINGLE -> "Tap once for one full-resolution photo."
                    CaptureStyle.RAPID_HOLD -> "Hold the shutter to capture; release to stop. Actual full-resolution speed is measured."
                    CaptureStyle.RAPID_TOGGLE -> "Tap once to start automatic capture; tap again to stop. Actual speed may be below the target."
                },
                color = Color.White,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
