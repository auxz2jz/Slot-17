package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.DenseFusionPairEvaluation
import com.photogrammetrystudio.app.model.DenseFusionReport
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.SparsePoint
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.calib3d.StereoSGBM
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Size
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * v0.8 milestone: fuse several verified dense stereo pairs into one shared world cloud.
 *
 * The global camera rotations are rebuilt from the same adjacent relative-pose chain used by
 * v0.5.1. Camera centers come from the v0.6 refinement report. Each local dense pair is first
 * rotated out of the rectified left-camera frame, scaled to the refined adjacent baseline, then
 * transformed into the shared world frame. Low-quality pairs are reported and skipped rather than
 * contaminating the fused cloud.
 */
object OpenCvDenseFusionReconstructor {
    private const val MAX_IMAGE_SIDE = 720
    private const val MAX_FEATURES = 3000
    private const val RATIO_TEST = 0.75f
    private const val RANSAC_THRESHOLD_PX = 1.5
    private const val MIN_RATIO_MATCHES = 20
    private const val MIN_POSE_INLIERS = 20
    private const val BLOCK_SIZE = 5
    private const val MAX_PAIRS_TO_DENSIFY = 12
    private const val MAX_POINTS_PER_PAIR = 12000
    private const val MAX_FUSED_POINTS = 80000
    private const val VOXEL_SIZE = 0.035

    private data class Pose(val r: DoubleArray, val t: DoubleArray)
    private data class RelativePose(val r: DoubleArray, val t: DoubleArray, val poseInliers: Int)
    private data class DisparityPlan(
        val minDisparity: Int,
        val numDisparities: Int,
        val low: Double,
        val median: Double,
        val high: Double
    )
    private data class DensePairResult(
        val evaluation: DenseFusionPairEvaluation,
        val worldPoints: List<SparsePoint>
    )

    @Volatile private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    fun fuse(
        files: List<File>,
        multi: MultiViewReconstructionReport,
        bundle: BundleAdjustmentReport,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<DenseFusionReport> = runCatching {
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }
        require(multi.readyForBundleAdjustment) { "Build a connected multi-view component before dense fusion." }
        require(bundle.readyForDenseReconstruction) { "Run successful shared-track refinement before dense fusion." }

        val fileByName = files.associateBy { it.name }
        val cameraIndexByPhoto = multi.cameras.associate { it.photo to it.index }
        val connectedPairIndices = multi.pairEvaluations.mapIndexedNotNull { index, pair ->
            if (pair.connected) index else null
        }
        require(connectedPairIndices.isNotEmpty()) { "No connected adjacent camera pairs are available for dense fusion." }

        val connectedCameraIndices = multi.cameras.filter { it.connected }.map { it.index }.sorted()
        require(connectedCameraIndices.size >= 3) { "Dense fusion needs at least 3 connected cameras." }

        // Rebuild the global orientation chain for every connected camera. This is lightweight
        // compared with SGBM and gives each selected dense pair a shared world transform.
        val relativePoses = HashMap<Int, RelativePose>()
        val globalR = HashMap<Int, DoubleArray>()
        val firstCamera = connectedCameraIndices.first()
        globalR[firstCamera] = identity3()

        connectedPairIndices.forEachIndexed { ordinal, pairIndex ->
            val pair = multi.pairEvaluations[pairIndex]
            val a = fileByName[pair.firstPhoto]
            val b = fileByName[pair.secondPhoto]
            if (a == null || b == null) return@forEachIndexed
            onProgress(
                0.02f + 0.18f * (ordinal.toFloat() / connectedPairIndices.size.coerceAtLeast(1)),
                "Recovering fusion camera pose ${ordinal + 1}/${connectedPairIndices.size}"
            )
            val rel = recoverRelativePose(a, b).getOrNull() ?: return@forEachIndexed
            relativePoses[pairIndex] = rel
            val firstIndex = cameraIndexByPhoto[pair.firstPhoto] ?: return@forEachIndexed
            val secondIndex = cameraIndexByPhoto[pair.secondPhoto] ?: return@forEachIndexed
            val currentR = globalR[firstIndex] ?: return@forEachIndexed
            globalR[secondIndex] = multiply3(rel.r, currentR)
        }

        val refinedCenters = bundle.cameras.associateBy { it.index }
        val poses = HashMap<Int, Pose>()
        connectedCameraIndices.forEach { index ->
            val r = globalR[index] ?: return@forEach
            val center = refinedCenters[index] ?: return@forEach
            val c = doubleArrayOf(center.x, center.y, center.z)
            val rc = multiply3Vec(r, c)
            poses[index] = Pose(r, doubleArrayOf(-rc[0], -rc[1], -rc[2]))
        }

        // v0.8.4 preflight: only select pairs that can actually be transformed into the shared
        // world frame. v0.8.3 could select a later pair whose own relative pose was valid even
        // though an earlier break in the rebuilt rotation chain meant its first camera had no
        // world pose. Those pairs then failed later with the misleading generic "missing" reason.
        val geometricCandidateIndices = connectedPairIndices.filter { index ->
            val pair = multi.pairEvaluations[index]
            pair.poseInliers >= MIN_POSE_INLIERS && relativePoses.containsKey(index)
        }
        val candidateIndices = geometricCandidateIndices.filter { index ->
            val pair = multi.pairEvaluations[index]
            val firstIndex = cameraIndexByPhoto[pair.firstPhoto]
            val secondIndex = cameraIndexByPhoto[pair.secondPhoto]
            firstIndex != null &&
                secondIndex != null &&
                fileByName.containsKey(pair.firstPhoto) &&
                fileByName.containsKey(pair.secondPhoto) &&
                refinedCenters.containsKey(firstIndex) &&
                refinedCenters.containsKey(secondIndex) &&
                poses.containsKey(firstIndex)
        }
        require(candidateIndices.isNotEmpty()) {
            "No connected dense-fusion pair has complete images, refined camera centers, and a recovered world pose."
        }
        val selectedIndices = qualityDistributedSelect(candidateIndices, multi, MAX_PAIRS_TO_DENSIFY)

        val evaluations = mutableListOf<DenseFusionPairEvaluation>()
        val allWorldPoints = mutableListOf<SparsePoint>()
        var rawDensePoints = 0
        var fusedPairs = 0

        selectedIndices.forEachIndexed { ordinal, pairIndex ->
            val pair = multi.pairEvaluations[pairIndex]
            val firstIndex = cameraIndexByPhoto[pair.firstPhoto]
            val secondIndex = cameraIndexByPhoto[pair.secondPhoto]
            val firstFile = fileByName[pair.firstPhoto]
            val secondFile = fileByName[pair.secondPhoto]
            val unavailableReason = when {
                firstIndex == null -> "Missing camera index for ${pair.firstPhoto}."
                secondIndex == null -> "Missing camera index for ${pair.secondPhoto}."
                firstFile == null -> "Missing first image file: ${pair.firstPhoto}."
                secondFile == null -> "Missing second image file: ${pair.secondPhoto}."
                refinedCenters[firstIndex] == null -> "Missing refined camera center for ${pair.firstPhoto}."
                refinedCenters[secondIndex] == null -> "Missing refined camera center for ${pair.secondPhoto}."
                poses[firstIndex] == null -> "Missing recovered world pose for ${pair.firstPhoto}; an earlier pose-chain link was not recovered."
                else -> null
            }
            if (unavailableReason != null) {
                evaluations += DenseFusionPairEvaluation(
                    pair.firstPhoto, pair.secondPhoto, pair.poseInliers, 0.0, 0, 0, 0,
                    false, unavailableReason
                )
                return@forEachIndexed
            }

            val usableFirstIndex = requireNotNull(firstIndex)
            val usableSecondIndex = requireNotNull(secondIndex)
            val usableFirstFile = requireNotNull(firstFile)
            val usableSecondFile = requireNotNull(secondFile)
            val firstPose = requireNotNull(poses[usableFirstIndex])
            val centerA = requireNotNull(refinedCenters[usableFirstIndex])
            val centerB = requireNotNull(refinedCenters[usableSecondIndex])
            val baseline = sqrt(
                (centerB.x - centerA.x) * (centerB.x - centerA.x) +
                    (centerB.y - centerA.y) * (centerB.y - centerA.y) +
                    (centerB.z - centerA.z) * (centerB.z - centerA.z)
            ).coerceIn(0.25, 2.50)

            onProgress(
                0.22f + 0.68f * (ordinal.toFloat() / selectedIndices.size.coerceAtLeast(1)),
                "Dense fusion pair ${ordinal + 1}/${selectedIndices.size}: ${usableFirstFile.name}"
            )
            val result = reconstructDensePair(usableFirstFile, usableSecondFile, firstPose, baseline)
            result.fold(
                onSuccess = { dense ->
                    evaluations += dense.evaluation
                    rawDensePoints += dense.evaluation.localDensePoints
                    if (dense.evaluation.accepted) {
                        fusedPairs++
                        allWorldPoints += dense.worldPoints
                    }
                },
                onFailure = { error ->
                    evaluations += DenseFusionPairEvaluation(
                        firstPhoto = usableFirstFile.name,
                        secondPhoto = usableSecondFile.name,
                        poseInliers = pair.poseInliers,
                        observedDisparityMedian = 0.0,
                        validDisparityPixels = 0,
                        localDensePoints = 0,
                        fusedPoints = 0,
                        accepted = false,
                        reason = error.message ?: "Dense pair failed."
                    )
                }
            )
        }

        require(allWorldPoints.isNotEmpty()) { "No dense stereo pair produced geometry suitable for fusion." }
        onProgress(0.92f, "Merging dense pair clouds…")
        val robust = trimGlobalOutliers(allWorldPoints)
        val voxel = voxelDownsample(robust, VOXEL_SIZE)
        val fused = evenlyDownsample(voxel, MAX_FUSED_POINTS)
        require(fused.isNotEmpty()) { "Dense fusion removed every point during global filtering." }

        val warnings = mutableListOf<String>()
        val preflightFiltered = geometricCandidateIndices.size - candidateIndices.size
        if (preflightFiltered > 0) {
            warnings += "v0.8.4 preflight filtered $preflightFiltered connected candidate(s) before distributed selection because a required image, refined camera center, or recovered world pose was unavailable."
        }
        if (selectedIndices.size < candidateIndices.size) {
            warnings += "v0.26 evaluated ${selectedIndices.size} quality/distribution-balanced pairs out of ${candidateIndices.size} eligible connected candidates to improve accepted dense coverage while keeping the pass bounded."
        }
        val rejected = evaluations.count { !it.accepted }
        if (rejected > 0) warnings += "$rejected selected dense pair(s) were rejected instead of being merged because their geometry was unstable or too sparse."
        if (fusedPairs < 3) warnings += "Only $fusedPairs dense pair(s) were fused. More accepted viewpoints will improve coverage before surface meshing."
        warnings += if (CameraCalibrationManager.activeProfile() != null) "v0.26 dense fusion uses calibrated intrinsics and measured lens distortion for pair pose geometry and rectification." else "No compatible active calibration; dense fusion uses the fallback pinhole model."
        warnings += "Dense fusion is a point-cloud milestone. Surface/mesh reconstruction is the next stage after fusion quality is validated."

        val ready = fusedPairs >= 2 && fused.size >= 3000
        onProgress(1f, "Multi-pair dense fusion complete")
        DenseFusionReport(
            engine = "OpenCV calibrated quality-distributed multi-pair StereoSGBM fusion 4.14 / v0.26",
            photosRequested = multi.photosRequested,
            connectedCameras = bundle.connectedCameras,
            candidatePairs = candidateIndices.size,
            pairsFused = fusedPairs,
            rawDensePoints = rawDensePoints,
            fusedPoints = fused.size,
            pairEvaluations = evaluations,
            points = fused,
            warnings = warnings,
            readyForSurfaceReconstruction = ready
        )
    }

    private fun recoverRelativePose(first: File, second: File): Result<RelativePose> = runCatching {
        val left = decodeScaled(first) ?: error("Could not decode ${first.name}.")
        var right = decodeScaled(second) ?: run { left.recycle(); error("Could not decode ${second.name}.") }
        val leftRgba = Mat(); val rightRgba = Mat(); val leftGray = Mat(); val rightGray = Mat()
        val kp1Mat = MatOfKeyPoint(); val kp2Mat = MatOfKeyPoint(); val d1 = Mat(); val d2 = Mat()
        val mask = Mat(); val r = Mat(); val t = Mat(); val tri = Mat()
        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        try {
            if (right.width != left.width || right.height != left.height) {
                val resized = Bitmap.createBitmap(left.width, left.height, Bitmap.Config.ARGB_8888)
                val src = Mat(); val dst = Mat()
                try {
                    Utils.bitmapToMat(right, src)
                    Imgproc.resize(src, dst, Size(left.width.toDouble(), left.height.toDouble()))
                    Utils.matToBitmap(dst, resized)
                } finally { src.release(); dst.release(); right.recycle() }
                right = resized
            }
            Utils.bitmapToMat(left, leftRgba); Utils.bitmapToMat(right, rightRgba)
            Imgproc.cvtColor(leftRgba, leftGray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.cvtColor(rightRgba, rightGray, Imgproc.COLOR_RGBA2GRAY)
            orb.detectAndCompute(leftGray, Mat(), kp1Mat, d1)
            orb.detectAndCompute(rightGray, Mat(), kp2Mat, d2)
            require(!d1.empty() && !d2.empty()) { "Not enough detail to recover relative pose." }
            val kp1 = kp1Mat.toArray(); val kp2 = kp2Mat.toArray()
            val ratio = ratioMatches(matcher, d1, d2)
            require(ratio.size >= MIN_RATIO_MATCHES) { "Only ${ratio.size} ratio matches." }
            val pts1 = MatOfPoint2f(*ratio.map { kp1[it.queryIdx].pt }.toTypedArray())
            val pts2 = MatOfPoint2f(*ratio.map { kp2[it.trainIdx].pt }.toTypedArray())
            val focal = (estimateFocalPixels(first, left.width, left.height).first + estimateFocalPixels(second, right.width, right.height).first) / 2.0
            val geometryModel = OpenCvCalibrationGeometry.model(left.width, left.height, focal)
            val geometryPts1 = OpenCvCalibrationGeometry.undistortPixelPoints(pts1, geometryModel)
            val geometryPts2 = OpenCvCalibrationGeometry.undistortPixelPoints(pts2, geometryModel)
            try {
                val e = Calib3d.findEssentialMat(geometryPts1, geometryPts2, geometryModel.k, Calib3d.RANSAC, 0.999, RANSAC_THRESHOLD_PX, 1000, mask)
                require(!e.empty()) { "Essential matrix failed." }
                val inliers = Calib3d.recoverPose(e, geometryPts1, geometryPts2, geometryModel.k, r, t, 50.0, mask, tri)
                e.release()
                require(inliers >= MIN_POSE_INLIERS) { "Only $inliers recovered-pose inliers." }
                RelativePose(mat3(r), vec3(t), inliers)
            } finally { pts1.release(); pts2.release(); geometryPts1.release(); geometryPts2.release(); geometryModel.close() }
        } finally {
            left.recycle(); right.recycle(); leftRgba.release(); rightRgba.release(); leftGray.release(); rightGray.release()
            kp1Mat.release(); kp2Mat.release(); d1.release(); d2.release(); mask.release(); r.release(); t.release(); tri.release()
            orb.clear(); matcher.clear()
        }
    }

    private fun reconstructDensePair(
        firstFile: File,
        secondFile: File,
        firstPose: Pose,
        baselineScale: Double
    ): Result<DensePairResult> = runCatching {
        val left = decodeScaled(firstFile) ?: error("Could not decode ${firstFile.name}.")
        var right = decodeScaled(secondFile) ?: run { left.recycle(); error("Could not decode ${secondFile.name}.") }
        val leftRgba = Mat(); val rightRgba = Mat(); val leftGray = Mat(); val rightGray = Mat()
        val kp1Mat = MatOfKeyPoint(); val kp2Mat = MatOfKeyPoint(); val d1 = Mat(); val d2 = Mat()
        val mask = Mat(); val r = Mat(); val t = Mat(); val tri = Mat()
        val r1 = Mat(); val r2 = Mat(); val p1 = Mat(); val p2 = Mat(); val q = Mat()
        val rectifiedPts1 = MatOfPoint2f(); val rectifiedPts2 = MatOfPoint2f()
        val map11 = Mat(); val map12 = Mat(); val map21 = Mat(); val map22 = Mat(); val rectLeft = Mat(); val rectRight = Mat()
        val disparity16 = Mat(); val disparity32 = Mat(); val xyz = Mat()
        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        var stereo: StereoSGBM? = null
        try {
            if (right.width != left.width || right.height != left.height) {
                val resized = Bitmap.createBitmap(left.width, left.height, Bitmap.Config.ARGB_8888)
                val src = Mat(); val dst = Mat()
                try {
                    Utils.bitmapToMat(right, src); Imgproc.resize(src, dst, Size(left.width.toDouble(), left.height.toDouble())); Utils.matToBitmap(dst, resized)
                } finally { src.release(); dst.release(); right.recycle() }
                right = resized
            }
            Utils.bitmapToMat(left, leftRgba); Utils.bitmapToMat(right, rightRgba)
            Imgproc.cvtColor(leftRgba, leftGray, Imgproc.COLOR_RGBA2GRAY); Imgproc.cvtColor(rightRgba, rightGray, Imgproc.COLOR_RGBA2GRAY)
            orb.detectAndCompute(leftGray, Mat(), kp1Mat, d1); orb.detectAndCompute(rightGray, Mat(), kp2Mat, d2)
            require(!d1.empty() && !d2.empty()) { "Not enough detail for dense stereo." }
            val kp1 = kp1Mat.toArray(); val kp2 = kp2Mat.toArray(); val ratio = ratioMatches(matcher, d1, d2)
            require(ratio.size >= MIN_RATIO_MATCHES) { "Only ${ratio.size} descriptor matches." }
            val pts1 = MatOfPoint2f(*ratio.map { kp1[it.queryIdx].pt }.toTypedArray())
            val pts2 = MatOfPoint2f(*ratio.map { kp2[it.trainIdx].pt }.toTypedArray())
            val focal = (estimateFocalPixels(firstFile, left.width, left.height).first + estimateFocalPixels(secondFile, right.width, right.height).first) / 2.0
            val geometryModel = OpenCvCalibrationGeometry.model(left.width, left.height, focal)
            val geometryPts1 = OpenCvCalibrationGeometry.undistortPixelPoints(pts1, geometryModel)
            val geometryPts2 = OpenCvCalibrationGeometry.undistortPixelPoints(pts2, geometryModel)
            try {
                val e = Calib3d.findEssentialMat(geometryPts1, geometryPts2, geometryModel.k, Calib3d.RANSAC, 0.999, RANSAC_THRESHOLD_PX, 1000, mask)
                require(!e.empty()) { "Essential matrix failed." }
                val poseInliers = Calib3d.recoverPose(e, geometryPts1, geometryPts2, geometryModel.k, r, t, 50.0, mask, tri)
                e.release()
                require(poseInliers >= MIN_POSE_INLIERS) { "Only $poseInliers pose inliers." }

                val size = Size(left.width.toDouble(), left.height.toDouble())
                Calib3d.stereoRectify(geometryModel.k, geometryModel.dist, geometryModel.k, geometryModel.dist, size, r, t, r1, r2, p1, p2, q)
                Calib3d.initUndistortRectifyMap(geometryModel.k, geometryModel.dist, r1, p1, size, CvType.CV_32FC1, map11, map12)
                Calib3d.initUndistortRectifyMap(geometryModel.k, geometryModel.dist, r2, p2, size, CvType.CV_32FC1, map21, map22)
                Imgproc.remap(leftGray, rectLeft, map11, map12, Imgproc.INTER_LINEAR)
                Imgproc.remap(rightGray, rectRight, map21, map22, Imgproc.INTER_LINEAR)
                Calib3d.undistortPoints(pts1, rectifiedPts1, geometryModel.k, geometryModel.dist, r1, p1)
                Calib3d.undistortPoints(pts2, rectifiedPts2, geometryModel.k, geometryModel.dist, r2, p2)
                val plan = chooseDisparityPlan(rectifiedPts1, rectifiedPts2, mask, left.width)
                val spread = abs(plan.high - plan.low)
                if (abs(plan.median) < 0.20 && spread < 1.25) {
                    return@runCatching DensePairResult(
                        DenseFusionPairEvaluation(firstFile.name, secondFile.name, poseInliers, plan.median, 0, 0, 0, false, "Rejected: extremely low rectified parallax."),
                        emptyList()
                    )
                }
                stereo = StereoSGBM.create(
                    plan.minDisparity, plan.numDisparities, BLOCK_SIZE,
                    8 * BLOCK_SIZE * BLOCK_SIZE, 32 * BLOCK_SIZE * BLOCK_SIZE,
                    1, 31, 10, 100, 2, StereoSGBM.MODE_SGBM_3WAY
                )
                stereo!!.compute(rectLeft, rectRight, disparity16)
                disparity16.convertTo(disparity32, CvType.CV_32F, 1.0 / 16.0)
                Calib3d.reprojectImageTo3D(disparity32, xyz, q, true)

                val margin = max(4.0, spread * 0.75)
                val bandLow = plan.low - margin
                val bandHigh = plan.high + margin
                var validPixels = 0
                val localRectified = ArrayList<SparsePoint>()
                val stride = 2
                for (y in 0 until disparity32.rows()) {
                    for (x in 0 until disparity32.cols()) {
                        val d = disparity32.get(y, x)?.getOrNull(0) ?: continue
                        if (!d.isFinite() || d <= plan.minDisparity + 1.0) continue
                        if (d !in bandLow..bandHigh) continue
                        validPixels++
                        if (x % stride != 0 || y % stride != 0) continue
                        val value = xyz.get(y, x) ?: continue
                        if (value.size < 3) continue
                        val px = value[0]; val py = value[1]; val pz = value[2]
                        if (!px.isFinite() || !py.isFinite() || !pz.isFinite() || pz <= 0.0 || pz > 1000.0) continue
                        localRectified += SparsePoint(px, py, pz)
                    }
                }
                if (localRectified.size < 250) {
                    return@runCatching DensePairResult(
                        DenseFusionPairEvaluation(firstFile.name, secondFile.name, poseInliers, plan.median, validPixels, localRectified.size, 0, false, "Rejected: fewer than 250 dense points remained inside the verified disparity band."),
                        emptyList()
                    )
                }

                val depths = localRectified.map { it.z }.sorted()
                val lowDepth = percentile(depths, 0.02)
                val highDepth = percentile(depths, 0.95)
                val rectFiltered = evenlyDownsample(localRectified.filter { it.z in lowDepth..highDepth }, MAX_POINTS_PER_PAIR)
                val r1Inv = transpose3(mat3(r1))
                val world = rectFiltered.mapNotNull { p ->
                    val originalCam = multiply3Vec(r1Inv, doubleArrayOf(p.x * baselineScale, p.y * baselineScale, p.z * baselineScale))
                    cameraToWorld(SparsePoint(originalCam[0], originalCam[1], originalCam[2]), firstPose)
                }
                if (world.size < 200) {
                    return@runCatching DensePairResult(
                        DenseFusionPairEvaluation(firstFile.name, secondFile.name, poseInliers, plan.median, validPixels, rectFiltered.size, world.size, false, "Rejected: too few transformed world points."),
                        emptyList()
                    )
                }
                DensePairResult(
                    DenseFusionPairEvaluation(firstFile.name, secondFile.name, poseInliers, plan.median, validPixels, rectFiltered.size, world.size, true, "Fused"),
                    world
                )
            } finally { pts1.release(); pts2.release(); geometryPts1.release(); geometryPts2.release(); geometryModel.close() }
        } finally {
            left.recycle(); right.recycle(); leftRgba.release(); rightRgba.release(); leftGray.release(); rightGray.release()
            kp1Mat.release(); kp2Mat.release(); d1.release(); d2.release(); mask.release(); r.release(); t.release(); tri.release()
            r1.release(); r2.release(); p1.release(); p2.release(); q.release(); rectifiedPts1.release(); rectifiedPts2.release()
            map11.release(); map12.release(); map21.release(); map22.release(); rectLeft.release(); rectRight.release(); disparity16.release(); disparity32.release(); xyz.release()
            orb.clear(); matcher.clear(); stereo?.clear()
        }
    }

    private fun ratioMatches(matcher: DescriptorMatcher, d1: Mat, d2: Mat): List<org.opencv.core.DMatch> {
        val knn = mutableListOf<MatOfDMatch>()
        matcher.knnMatch(d1, d2, knn, 2)
        val out = mutableListOf<org.opencv.core.DMatch>()
        knn.forEach { set ->
            val m = set.toArray()
            if (m.size >= 2 && m[0].distance < RATIO_TEST * m[1].distance) out += m[0]
            set.release()
        }
        return out
    }

    private fun decodeScaled(file: File): Bitmap? =
        ExifBitmapLoader.decodeScaled(file, MAX_IMAGE_SIDE)

    private fun estimateFocalPixels(file: File, width: Int, height: Int): Pair<Double, String> {
        CameraCalibrationManager.focalEstimate(width, height)?.let { return it }
        val focal35 = runCatching { ExifInterface(file).getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0) }.getOrDefault(0)
        if (focal35 > 0) {
            val diagonal = sqrt(width.toDouble() * width + height.toDouble() * height)
            return focal35.toDouble() * diagonal / 43.2666153 to "EXIF 35mm-equivalent focal length"
        }
        return 0.9 * max(width, height) to "Fallback 0.9× max image dimension"
    }

    private fun cameraMatrix(width: Int, height: Int, focal: Double): Mat {
        CameraCalibrationManager.intrinsicsFor(width, height)?.let { intr ->
            val calibrated = Mat.eye(3, 3, CvType.CV_64F)
            calibrated.put(0, 0, intr.fx); calibrated.put(1, 1, intr.fy)
            calibrated.put(0, 2, intr.cx); calibrated.put(1, 2, intr.cy)
            return calibrated
        }
        val k = Mat.eye(3, 3, CvType.CV_64F)
        k.put(0, 0, focal); k.put(1, 1, focal); k.put(0, 2, width / 2.0); k.put(1, 2, height / 2.0)
        return k
    }

    private fun chooseDisparityPlan(left: MatOfPoint2f, right: MatOfPoint2f, mask: Mat, width: Int): DisparityPlan {
        val a = left.toArray(); val b = right.toArray(); val n = min(a.size, b.size)
        val values = ArrayList<Double>()
        for (i in 0 until n) {
            if (!maskValue(mask, i)) continue
            val d = a[i].x - b[i].x
            if (d.isFinite() && abs(d) < width * 0.90) values += d
        }
        if (values.size < 12) {
            val num = (((width / 6).coerceIn(64, 192) + 15) / 16) * 16
            return DisparityPlan(-num / 4, num, 0.0, 0.0, 0.0)
        }
        values.sort()
        val low = percentile(values, 0.05); val med = percentile(values, 0.50); val high = percentile(values, 0.95)
        val spread = (high - low).coerceAtLeast(8.0); val margin = max(12.0, spread * 0.40)
        var minD = floor(low - margin).toInt(); val requestedHigh = ceil(high + margin).toInt()
        val maxWidth = (((width * 0.70).toInt().coerceAtLeast(64)) / 16 * 16).coerceIn(64, 256)
        var num = (((requestedHigh - minD + 1).coerceAtLeast(64) + 15) / 16) * 16
        if (num > maxWidth) { num = maxWidth; minD = floor(med - num / 2.0).toInt() } else num = num.coerceIn(64, maxWidth)
        var actualHigh = minD + num - 1
        if (high > actualHigh - 2) { minD += ceil(high - (actualHigh - 2)).toInt(); actualHigh = minD + num - 1 }
        minD = minD.coerceIn(-width / 2, width - 16)
        return DisparityPlan(minD, num, low, med, high)
    }

    private fun maskValue(mask: Mat, index: Int): Boolean {
        if (mask.empty()) return true
        val value = if (mask.rows() == 1) mask.get(0, index) else mask.get(index, 0)
        return (value?.getOrNull(0) ?: 0.0) != 0.0
    }

    private fun mat3(mat: Mat): DoubleArray {
        val out = DoubleArray(9)
        for (r in 0..2) for (c in 0..2) out[r * 3 + c] = mat.get(r, c)?.getOrNull(0) ?: if (r == c) 1.0 else 0.0
        return out
    }

    private fun vec3(mat: Mat): DoubleArray = doubleArrayOf(
        mat.get(0, 0)?.getOrNull(0) ?: 0.0,
        mat.get(1, 0)?.getOrNull(0) ?: 0.0,
        mat.get(2, 0)?.getOrNull(0) ?: 0.0
    )

    private fun identity3(): DoubleArray = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

    private fun multiply3(a: DoubleArray, b: DoubleArray): DoubleArray {
        val out = DoubleArray(9)
        for (r in 0..2) for (c in 0..2) out[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c]
        return out
    }

    private fun multiply3Vec(a: DoubleArray, v: DoubleArray): DoubleArray = doubleArrayOf(
        a[0] * v[0] + a[1] * v[1] + a[2] * v[2],
        a[3] * v[0] + a[4] * v[1] + a[5] * v[2],
        a[6] * v[0] + a[7] * v[1] + a[8] * v[2]
    )

    private fun transpose3(a: DoubleArray): DoubleArray = doubleArrayOf(a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8])

    private fun cameraToWorld(point: SparsePoint, pose: Pose): SparsePoint? {
        val shifted = doubleArrayOf(point.x - pose.t[0], point.y - pose.t[1], point.z - pose.t[2])
        val w = multiply3Vec(transpose3(pose.r), shifted)
        if (!w.all { it.isFinite() }) return null
        return SparsePoint(w[0], w[1], w[2])
    }

    private fun qualityDistributedSelect(
        indices: List<Int>,
        multi: MultiViewReconstructionReport,
        maxCount: Int
    ): List<Int> {
        if (indices.size <= maxCount) return indices
        val qualityCount = (maxCount / 2).coerceAtLeast(1)
        val topQuality = indices
            .sortedByDescending { multi.pairEvaluations[it].poseInliers }
            .take(qualityCount)
            .toMutableSet()
        val remainingSlots = (maxCount - topQuality.size).coerceAtLeast(0)
        if (remainingSlots > 0) {
            evenlySelect(indices.filterNot { it in topQuality }, remainingSlots).forEach { topQuality += it }
        }
        return topQuality.sorted()
    }

    private fun evenlySelect(indices: List<Int>, maxCount: Int): List<Int> {
        if (indices.size <= maxCount) return indices
        val selected = LinkedHashSet<Int>()
        for (i in 0 until maxCount) {
            val pos = (i.toDouble() * (indices.lastIndex.toDouble()) / (maxCount - 1).coerceAtLeast(1)).roundToInt()
            selected += indices[pos.coerceIn(0, indices.lastIndex)]
        }
        return selected.toList().sorted()
    }

    private fun trimGlobalOutliers(points: List<SparsePoint>): List<SparsePoint> {
        if (points.size < 500) return points
        val xs = points.map { it.x }.sorted(); val ys = points.map { it.y }.sorted(); val zs = points.map { it.z }.sorted()
        val cx = percentile(xs, 0.50); val cy = percentile(ys, 0.50); val cz = percentile(zs, 0.50)
        val radii = points.map { p -> sqrt((p.x-cx)*(p.x-cx)+(p.y-cy)*(p.y-cy)+(p.z-cz)*(p.z-cz)) }.sorted()
        val maxRadius = percentile(radii, 0.98)
        return points.filter { p ->
            sqrt((p.x-cx)*(p.x-cx)+(p.y-cy)*(p.y-cy)+(p.z-cz)*(p.z-cz)) <= maxRadius
        }
    }

    private fun voxelDownsample(points: List<SparsePoint>, voxel: Double): List<SparsePoint> {
        if (points.isEmpty()) return emptyList()
        val cells = LinkedHashMap<String, DoubleArray>()
        points.forEach { p ->
            val key = "${(p.x/voxel).roundToInt()}:${(p.y/voxel).roundToInt()}:${(p.z/voxel).roundToInt()}"
            val acc = cells[key]
            if (acc == null) cells[key] = doubleArrayOf(p.x, p.y, p.z, 1.0)
            else { acc[0]+=p.x; acc[1]+=p.y; acc[2]+=p.z; acc[3]+=1.0 }
        }
        return cells.values.map { a -> SparsePoint(a[0]/a[3], a[1]/a[3], a[2]/a[3]) }
    }

    private fun evenlyDownsample(points: List<SparsePoint>, maxPoints: Int): List<SparsePoint> {
        if (points.size <= maxPoints) return points
        val step = points.size.toDouble() / maxPoints
        val out = ArrayList<SparsePoint>(maxPoints); var cursor = 0.0
        while (out.size < maxPoints && cursor.toInt() < points.size) { out += points[cursor.toInt()]; cursor += step }
        return out
    }

    private fun percentile(sorted: List<Double>, fraction: Double): Double {
        if (sorted.isEmpty()) return 0.0
        val index = ((sorted.size - 1) * fraction).toInt().coerceIn(0, sorted.lastIndex)
        return sorted[index]
    }
}
