package com.photogrammetrystudio.app.ui.screens

import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.photogrammetrystudio.app.BuildConfig
import com.photogrammetrystudio.app.model.PhotoProject
import com.photogrammetrystudio.app.model.FeatureMatchReport
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.CameraCalibrationProfile
import com.photogrammetrystudio.app.model.CameraCalibrationReport
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset
import com.photogrammetrystudio.app.model.LaserCalibrationTargetPreset
import com.photogrammetrystudio.app.model.LaserAnalysisRun
import com.photogrammetrystudio.app.model.LaserPlaneCalibrationReport
import com.photogrammetrystudio.app.model.DenseReconstructionReport
import com.photogrammetrystudio.app.model.DenseFusionReport
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureProjectionReport
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import com.photogrammetrystudio.app.model.TextureAtlasReport
import com.photogrammetrystudio.app.model.ReconstructionStatus
import com.photogrammetrystudio.app.util.ExifBitmapLoader
import com.photogrammetrystudio.app.util.reportFingerprint
import java.text.DateFormat
import java.util.Date

private enum class TestResult { UNTESTED, WORKS, PROBLEM }

private data class TestStep(
    val title: String,
    val action: String,
    val expected: String
)

private val v022Steps = listOf(
    TestStep(
        "Launch and test guide",
        "Confirm this guide appeared automatically for v0.2.2. Tap Test now to close it, then use the ? button on the main screen to reopen it.",
        "The guide appears for the new version and can always be reopened with the ? button."
    ),
    TestStep(
        "Create all three scan modes",
        "Create one Photo Scan, one Laser Scan, and one Hybrid Scan project.",
        "All three projects are created and show the correct scan-mode name."
    )
)

private val v030Steps = listOf(
    TestStep(
        "Launch v0.3 test guide",
        "Confirm this guide appeared automatically, close it, and reopen it with the ? button.",
        "The guide appears once automatically and can always be reopened."
    ),
    TestStep(
        "Run real feature matching",
        "Capture several overlapping photos, tap Match photos, and wait for processing to finish.",
        "A Real feature matching card appears with OpenCV ORB statistics and adjacent-pair results."
    )
)

private val v031Steps = listOf(
    TestStep(
        "Launch v0.3.1 guide",
        "Confirm this guide appears for v0.3.1. Close it with Test now and reopen it with the ? button.",
        "The guide can be closed and reopened without losing your current test step or prior results."
    ),
    TestStep(
        "Regression: capture and match",
        "Open or create a Photo Scan project, capture/import at least 6 overlapping photos, then tap Match photos.",
        "Feature matching completes and shows a summary without crashing."
    ),
    TestStep(
        "View every match result",
        "In the Real feature matching card tap View all. Scroll from the first adjacent pair to the final pair.",
        "All adjacent-pair results can be inspected in a vertically scrollable window. With 30 photos there should be 29 adjacent pairs."
    ),
    TestStep(
        "Export feature-match results",
        "Tap Export results, choose a location/name in Android's file picker, and save the text file. Open it if convenient.",
        "A .txt report is created containing the project summary, warnings, and every adjacent-pair match result."
    ),
    TestStep(
        "Match results persist",
        "After matching, go back to the project list and reopen the same project without changing its photos.",
        "The Real feature matching result is still present. It should survive navigation and app restarts until the photo set changes."
    ),
    TestStep(
        "Stale results clear after photo change",
        "With a saved match report visible, add/import one photo or delete one photo.",
        "The old feature-match report disappears because it no longer describes the current photo set. Run Match photos again to create a new saved report."
    ),
    TestStep(
        "Delete a project",
        "Create a disposable test project. Return to the project list, tap its trash icon, cancel once, then repeat and confirm Delete.",
        "Cancel keeps the project. Confirming Delete removes the project and its local photos/reports after a warning."
    ),
    TestStep(
        "Problem explanation field",
        "If any test step has a real problem, mark that step ! Problem and type what happened in the explanation box. If nothing failed, simply mark this reporting feature Works.",
        "Problem steps provide a saved explanation field so you can describe the failure in your own words."
    ),
    TestStep(
        "Export this test report",
        "On this final step, review the Works / Problems / Untested summary and tap Export test report. Save the text file.",
        "The exported .txt file lists the app version, every test step, each status, and your problem explanations. You can upload that file to ChatGPT."
    )
)



private val v0140Steps = listOf(
    TestStep(
        "Build test4 Stage 10 UV atlas",
        "Open test4 with its saved Stage 9 result. On 'Stage 9 — Texture Source Assignment' tap the exact button 'Next: Stage 10 — Build UV texture atlas' and wait for Stage 10 to finish.",
        "A new 'Stage 10 — UV Texture Atlas' card appears with a non-zero textured-face count, atlas dimensions, source-photo count, and Ready for export=true."
    ),
    TestStep(
        "Export test4 textured model package",
        "On test4 Stage 10 tap 'Export textured model package (.zip)' and save the ZIP.",
        "The ZIP saves successfully and contains textured_model.obj, texture_atlas.mtl, and texture_atlas.png."
    ),
    TestStep(
        "Inspect test4 texture atlas PNG",
        "On test4 Stage 10 tap 'Export texture atlas PNG'. Open the PNG in a normal image viewer if convenient.",
        "The PNG is a real photo-derived atlas made from many small triangle patches; it is not blank or a single flat color."
    ),
    TestStep(
        "Build test3 partial atlas",
        "Open test3 and run 'Next: Stage 10 — Build UV texture atlas' from its saved Stage 9 card.",
        "Stage 10 still exports a valid partial atlas even though test3 has lower Stage 9 coverage. Unassigned mesh faces remain gray/untextured rather than receiving invented photo content."
    ),
    TestStep(
        "Stage 7 topology remains unchanged",
        "Compare the Stage 7 vertex/triangle counts before and after Stage 10 on either project.",
        "Stage 10 adds UV/material/atlas data only; Stage 7 geometry counts do not change."
    ),
    TestStep(
        "Combined diagnostics includes Stage 10",
        "After Stage 10 finishes, tap 'Export combined project diagnostics'.",
        "The single text file contains Quick Check plus Stages 1–10 and includes atlas size, textured faces, untextured faces, coverage and source-photo count."
    ),
    TestStep(
        "Project isolation regression through Stage 10",
        "If convenient, start Stage 10 on one project and briefly open another project while it runs.",
        "The other project does not show the first project's Stage 10 progress/result, and background completion does not switch projects."
    ),
    TestStep(
        "Export v0.14.0 test report",
        "Mark every step Works or Problem and tap Export test report.",
        "The report identifies app version 0.14.0 and includes the Stage 10 texture-atlas diagnostic snapshot."
    )
)






private val v0260Steps = listOf(
    TestStep(
        "Calibration profile remains active",
        "Open Camera Calibration and confirm the saved Main 1× profile is still Ready for use, then return to a photo project.",
        "The existing profile remains intact. v0.26 reuses its fx/fy/cx/cy and k1/k2/p1/p2/k3 values; no recalibration is required for this regression run."
    ),
    TestStep(
        "Distortion-aware sparse geometry",
        "On the existing test5 project, rebuild Stage 2 after Stage 1 is available.",
        "Stage 2 completes and its report identifies distortion-aware calibrated geometry. ORB descriptors still come from original pixels, while matched feature coordinates are undistorted before essential-matrix/pose recovery."
    ),
    TestStep(
        "Distortion-aware multi-view and bundle",
        "Continue through Stages 3 and 4 on test5.",
        "Stages 3–4 complete without losing the saved camera calibration. Bundle observations use calibrated undistorted coordinates and the report records the new v0.26 engine."
    ),
    TestStep(
        "Calibrated dense stereo / fusion",
        "Run Stages 5 and 6 on test5.",
        "Stereo rectification uses the measured distortion model. Stage 6 evaluates up to 12 quality/distribution-balanced connected pairs instead of only six and reports how many are accepted."
    ),
    TestStep(
        "Distortion-aware photo projection",
        "Continue through Stages 8, 9 and 10 on test5.",
        "Stage 8/9 projection maps geometry back into the original source photos using calibrated fx/fy/cx/cy plus lens distortion. Stage 10 still exports a valid OBJ/MTL/PNG package."
    ),
    TestStep(
        "Laser marker and corner solve",
        "Open the real Letter laser project, set roughly threshold 68–81, tap Analyze again in v0.26 so the new dual-orientation extractor runs, then tap 'Solve laser plane + build 3D stripe'.",
        "Expected LEFT/RIGHT DICT_4X4_50 markers are detected, both panel planes are solved, and the reported panel angle is reasonably close to the physical 90° corner."
    ),
    TestStep(
        "Laser plane and metric PLY",
        "Inspect the new laser-plane result and export its preview, text report, and 3D PLY.",
        "The report includes backdrop stripe-point counts, mean laser-plane residual in millimeters, triangulated stripe-point count, and Ready for single-frame 3D. The PLY uses millimeter coordinates."
    ),
    TestStep(
        "Export v0.26.0 test report",
        "Mark each step Works or Problem and export the version test report.",
        "The report identifies v0.26.0 and preserves normal pipeline/laser diagnostics for recovery."
    )
)

private val v0240Steps = listOf(
    TestStep(
        "Large four-Letter photo target appears",
        "Open Camera Calibration and inspect the target selector.",
        "Existing Letter/Legal/Ledger/Poster 12×18 presets remain. A new 'Large 4-Letter (38.1 mm)' preset appears and reports 9×6 inner corners, 38.1 mm squares, a 15.0×10.5 in checkerboard, and four Letter landscape sheets."
    ),
    TestStep(
        "Export four-page photo target",
        "Select 'Large 4-Letter (38.1 mm)' and export the photo calibration PDF.",
        "A 4-page US Letter landscape PDF saves as A1/A2/B1/B2. Guidance says pin-align matching crosshairs and straight-cut the overlapped seams; registration tabs are outside the final target."
    ),
    TestStep(
        "Photo square-size calibration contract",
        "With the large target selected, read the size guidance and start calibration only if you have the matching physical board/photos.",
        "The app reports exactly 38.1 mm squares for this preset. Existing 25.0 mm presets still report 25.0 mm; calibration object points use the selected preset's square size."
    ),
    TestStep(
        "Pin-align laser preset",
        "Open Laser Line Lab and select '12×18 pin-align (4 Letter sheets)'.",
        "The app reports a finished 12×18 in panel, 35.0 mm markers, and four Letter portrait sheets per LEFT/RIGHT panel. Existing laser presets remain available."
    ),
    TestStep(
        "Export pin-align LEFT and RIGHT",
        "Export both LEFT and RIGHT while the pin-align preset is selected.",
        "Each export is a separate 4-page Letter PDF labeled A1/A2/B1/B2 with matching sacrificial registration crosshairs. The physical target geometry remains the original 12×18 / 35 mm-marker layout."
    ),
    TestStep(
        "Export pin-align instructions",
        "Export 'tiled / poster-board assembly instructions'.",
        "The PDF explains pinholes through crosshair center dots, overlap registration, straight-cutting both layers, removing excess strips, and butting the final edges so no paper overlap covers the calibration artwork."
    ),
    TestStep(
        "v0.22 laser history regression",
        "Open a project with laser history or run Analyze once if convenient.",
        "Laser Analyze history still loads/appends/persists normally; the calibration-print change does not alter stripe extraction math or photogrammetry Stages 1–10."
    ),
    TestStep(
        "Export v0.24.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.24.0 and records the selected photo target including square size/print representation plus the selected laser target/print representation."
    )
)

private val v0230Steps = listOf(
    TestStep(
        "Camera calibration target regression",
        "Open Camera Calibration. Verify Letter, Legal, Ledger, and Poster 12×18 are still available. Select Letter and inspect its dimensions.",
        "The existing photo targets are unchanged. Letter still reports a 250×175 mm checker pattern with exact 25.0 mm squares and can be mounted flat on poster board without enlargement."
    ),
    TestStep(
        "Tiled laser preset appears",
        "Open Laser Line Lab and inspect the calibration-background selector.",
        "Letter, Legal, Ledger, Poster 12×18, and '12×18 tiled (4 Letter sheets)' are all available. Existing preset IDs still load normally."
    ),
    TestStep(
        "Export tiled LEFT panel",
        "Select '12×18 tiled (4 Letter sheets)' and export LEFT.",
        "A 4-page US Letter PDF saves. Pages are labeled A1, A2, B1, B2; the app reports a finished 12×18 in panel, 35.0 mm markers, and 4 Letter sheets per panel."
    ),
    TestStep(
        "Export tiled RIGHT panel",
        "Keep the tiled preset selected and export RIGHT.",
        "A separate 4-page US Letter PDF saves with A1, A2, B1, B2 pages and the matching RIGHT-panel geometry/corner reference."
    ),
    TestStep(
        "Export tiled assembly instructions",
        "Tap 'Export tiled / poster-board assembly instructions' and save the PDF.",
        "The instructions explain 100% / Actual Size printing, the one-sheet photo target, four-sheet LEFT/RIGHT laser assembly, trim/crop marks, the 4.25 in vertical seam, and the 9.75 in horizontal seam."
    ),
    TestStep(
        "Existing laser presets still export",
        "Switch to one existing preset (Letter, Legal, Ledger, or Poster 12×18) and export LEFT or RIGHT once.",
        "The existing single-sheet export still works and its dimensions/marker size remain unchanged."
    ),
    TestStep(
        "Laser history regression",
        "Open a project with saved v0.22 laser analysis history or run Analyze once if convenient.",
        "Persistent laser run history still loads/appends normally. The calibration-print change does not alter laser extraction math or photogrammetry Stages 1–10."
    ),
    TestStep(
        "Export v0.23.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.23.0 and records the selected laser preset plus its finished panel size and print-sheet description."
    )
)

private val v0220Steps = listOf(
    TestStep(
        "Open Laser Line Lab with real pair",
        "Open the Laser/Hybrid project that contains your real laser-OFF and laser-ON images. Open Laser Line Lab.",
        "Both imported frame names are visible. The screen explains that each Analyze press appends one diagnostic run and slider movement alone does not."
    ),
    TestStep(
        "Record threshold 32 run",
        "Set Red and threshold 32, then tap 'Analyze laser line' once and wait for it to finish.",
        "The newest history row says Red / threshold 32 and shows the measured coverage, continuity, stripe width, and READY/NOT READY result. The history count increases by exactly one."
    ),
    TestStep(
        "Record threshold 64 run",
        "Change only the threshold to 64 and tap 'Analyze laser line' once.",
        "A second run is appended rather than replacing threshold 32. Threshold 64 appears newest and the normal Laser line result/preview also updates to the newest run."
    ),
    TestStep(
        "Repeated threshold is still a new run",
        "Leave threshold at 64 and tap 'Analyze laser line' one more time.",
        "Another threshold-64 run is appended with its own run ID/duration. The previous threshold-64 and threshold-32 runs remain in history."
    ),
    TestStep(
        "History survives reopen",
        "Back out of Laser Line Lab, then reopen it for the same project.",
        "The previously recorded run count and recent threshold rows are still present. Restarting/reopening does not erase the history."
    ),
    TestStep(
        "Export cross-platform JSONL",
        "Tap 'Export analysis run history (.jsonl)' and save the file.",
        "The file saves successfully and contains one JSON object per Analyze attempt with schemaVersion=1, runId, threshold, color, success, duration, and result metrics or failure details."
    ),
    TestStep(
        "Export human-readable laser report",
        "Tap 'Export report' after the last analysis.",
        "The normal laser report still describes the newest extraction and now includes a recent laser-analysis run-history summary instead of losing the earlier threshold experiments."
    ),
    TestStep(
        "Calibration and photogrammetry regression",
        "Confirm the calibration size selectors still list Letter, Legal, Ledger, and 12×18. Open an existing photogrammetry project if convenient.",
        "v0.21 calibration presets still load and existing photogrammetry stages/results are unchanged. v0.22 does not change laser extraction math or Stages 1–10."
    ),
    TestStep(
        "Export v0.22.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.22.0 and includes the current laser analysis history snapshot so threshold-test evidence is attached to the test result."
    )
)

private val v0210Steps = listOf(
    TestStep(
        "Photo standard-size selector",
        "Open Camera Calibration. Verify Letter 8.5×11, Legal 8.5×14, Ledger 11×17, and Poster 12×18 are available. Select Legal, close the screen, and reopen it.",
        "All four presets are listed with dimensions. Legal remains selected after reopening, and the selected target shows a 250×175 mm checker pattern with 25 mm squares."
    ),
    TestStep(
        "Export standard photo PDFs",
        "Export the Letter, Legal, and Ledger photo calibration PDFs one at a time.",
        "Each PDF saves with the matching size name, says 100% / Actual Size, and preserves the same 9×6-inner-corner / 25 mm checker geometry."
    ),
    TestStep(
        "Laser standard-size selector",
        "Open Laser Line Lab. Verify Letter, Legal, Ledger, and Poster 12×18 presets are available. Select Ledger, close the screen, and reopen it.",
        "Ledger remains selected and the screen shows 11×17 in / 279.4×431.8 mm plus the preset marker size."
    ),
    TestStep(
        "Export Legal laser pair",
        "Select Legal 8.5×14 and export LEFT and RIGHT.",
        "Both Legal PDFs save separately, identify the 8.5×14 panel dimensions, include a 100 mm scale check, and use matching Legal-family marker geometry."
    ),
    TestStep(
        "Export Ledger laser pair",
        "Select Ledger 11×17 and export LEFT and RIGHT.",
        "Both Ledger PDFs save separately, identify 11×17 dimensions, include the corner-reference line and 100 mm scale check, and use the same Ledger preset family."
    ),
    TestStep(
        "12×18 backward compatibility",
        "Select Poster 12×18 in both calibration screens and confirm its export controls still work.",
        "The older 12×18 choice remains available as an optional poster preset; existing saved preset IDs continue to resolve correctly."
    ),
    TestStep(
        "Print-shop instructions",
        "Export the print-shop instructions PDF.",
        "The instructions list Letter 8.5×11, Legal 8.5×14, Ledger 11×17, and optional 12×18, and say 100% / Actual Size with no Fit/Scale to Fit."
    ),
    TestStep(
        "Existing calibration/profile regression",
        "If an older camera-calibration profile exists, inspect it without recalibrating. Also open an existing photo project and a Laser/Hybrid project.",
        "Older profiles/projects still load; photo reconstruction and the existing v0.19 laser OFF/ON line extractor are unchanged."
    ),
    TestStep(
        "Export v0.21.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.21.0 and records the selected photo and laser preset names and exact dimensions."
    )
)

private val v0200Steps = listOf(
    TestStep(
        "Photo calibration target selector",
        "Open Camera Calibration. Switch between 'US Letter 8.5×11' and '12×18'. Close and reopen the screen once.",
        "The selected target changes immediately and remains selected after reopening. Both choices state 9×6 inner corners with 25 mm squares."
    ),
    TestStep(
        "Export US Letter photo target",
        "Select 'US Letter 8.5×11' in Camera Calibration and tap 'Export selected photo calibration PDF'. Save the PDF.",
        "A PDF named for the Letter target is created. Its printed instructions say 100% / Actual Size and one checker square must measure 25.0 mm."
    ),
    TestStep(
        "Export 12×18 photo target",
        "Switch to '12×18' and export the selected photo calibration PDF.",
        "A separate 12×18 PDF is created while the calibration geometry remains 9×6 inner corners / 25 mm squares."
    ),
    TestStep(
        "Laser background target selector",
        "Open a Laser Scan or Hybrid project, open Laser Line Lab, and switch between the US Letter and 12×18 background presets.",
        "The selected laser background changes and remains selected. The screen explains that LEFT and RIGHT panels must use the same preset and form a 90° corner."
    ),
    TestStep(
        "Export laser LEFT/RIGHT pair",
        "For one laser-background preset, tap 'Export LEFT' and 'Export RIGHT' and save both PDFs.",
        "Two separate PDFs are created for the selected size, with matching target family, 100 mm scale checks, and corner-reference instructions."
    ),
    TestStep(
        "Export print-shop instructions",
        "From either calibration screen tap 'Export print-shop instructions'. Save the PDF.",
        "A standalone printing-instructions PDF is created and states 100% / Actual Size, matte material, no auto-scaling, and scale-check requirements."
    ),
    TestStep(
        "Existing calibration/profile regression",
        "If an older camera-calibration profile already exists, inspect it without recalibrating. If no profile exists, simply leave calibration unsolved for now.",
        "Older profiles still load. Profiles without target metadata default safely to the US Letter preset; existing photo projects and Stages 1–10 are unchanged."
    ),
    TestStep(
        "Export v0.20.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.20.0 and includes the currently selected photo and laser calibration target presets."
    )
)

private val v0190Steps = listOf(
    TestStep(
        "Open Laser Line Lab",
        "Create/open a Laser Scan or Hybrid Scan project and tap 'Open Laser Line Lab'.",
        "The Laser Line Lab opens and shows separate laser-OFF and laser-ON import controls, color selection, threshold, analysis, and export controls."
    ),
    TestStep(
        "Import matched OFF/ON pair",
        "With camera/object fixed, import one frame with the line laser OFF and a matching frame with it ON.",
        "Both filenames appear and Analyze laser line becomes available."
    ),
    TestStep(
        "Extract visible laser stripe",
        "Choose the actual laser color, leave threshold near 28 initially, and tap 'Analyze laser line'.",
        "A Laser line result appears with detected-row coverage, continuity, mean stripe width, and a cyan overlay preview. No 3D triangulation is claimed yet."
    ),
    TestStep(
        "Tune threshold if needed",
        "If the overlay misses the stripe or follows bright background detail, adjust the signal threshold and analyze again.",
        "Higher threshold rejects weak false detections; lower threshold can recover a dim stripe. The saved result is replaced by the newest analysis."
    ),
    TestStep(
        "Export laser diagnostics",
        "Tap Export report and Export preview.",
        "A text report and PNG overlay save successfully for later comparison/debugging."
    ),
    TestStep(
        "Photo pipeline regression",
        "Open test3/test4 or another Photo Scan project without rebuilding calibration.",
        "Existing photogrammetry stages/results still load normally; the v0.19 laser foundation does not alter Stages 1–10."
    ),
    TestStep(
        "Calibration remains optional for line extraction",
        "Open Camera Calibration if convenient but do not recalibrate unless you have the proper printed board.",
        "Laser stripe extraction works without a calibration profile; the app explicitly defers metric 3D triangulation until camera + laser-plane calibration exist."
    ),
    TestStep(
        "Export v0.19.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.19.0 and records the laser-line foundation regression test."
    )
)

private val v0180Steps = listOf(
    TestStep(
        "Open Camera Calibration",
        "From the project list tap the tuning/calibration icon in the top bar.",
        "A Camera Calibration screen opens with target, photo-import, solve, and active-profile sections."
    ),
    TestStep(
        "Export printable calibration target",
        "Tap 'Export printable calibration target PDF' and save the PDF.",
        "A US Letter landscape PDF saves successfully and says 9×6 inner corners with 25 mm squares. Print later at 100% / Actual Size, not Fit to Page."
    ),
    TestStep(
        "Import calibration photos",
        "Photograph the printed target 15–25 times using one fixed lens/zoom and orientation, then import the images on the Calibration screen.",
        "The calibration photo count increases. Use straight, tilted, near/far, center and corner-of-frame views while keeping the whole board visible and sharp."
    ),
    TestStep(
        "Run camera calibration",
        "Leave the profile label as 'Main 1×' (or enter the exact lens/zoom used), then tap 'Run camera calibration'.",
        "At least 10 board views are accepted and the solve reports fx/fy/cx/cy, lens-distortion coefficients, and an RMS reprojection error. A profile with RMS <= 1.5 px becomes active."
    ),
    TestStep(
        "Export calibration report",
        "After the solve tap 'Export calibration report'.",
        "The text file lists accepted/rejected frames, RMS, intrinsics, distortion coefficients and whether the profile is ready for use."
    ),
    TestStep(
        "Verify calibrated intrinsics are used",
        "With an active profile, open a photo project and rebuild Stage 2 sparse reconstruction (Stage 1 can stay saved).",
        "Stage 2 Intrinsics source begins with 'Calibrated' for image dimensions compatible with the saved profile instead of EXIF/fallback intrinsics."
    ),
    TestStep(
        "Rebuild appearance regression",
        "On test4, rebuild Stage 8 and Stage 9 after calibration if convenient.",
        "The stages still complete and texture-source coverage does not catastrophically regress. v0.18 is primarily validating the camera profile before full distortion correction is enabled in a later pass."
    ),
    TestStep(
        "Export v0.18.0 test report",
        "Mark every step Works or Problem and export the version test report.",
        "The report identifies v0.18.0 and includes the active camera-calibration snapshot along with normal project diagnostics."
    )
)

private val v0170Steps = listOf(
    TestStep(
        "Rebuild test4 Stage 9 neighbor-consistent coverage",
        "Open test4. On Stage 8 tap 'Next: Stage 9 — Assign triangle texture sources' and wait for Stage 9 to finish.",
        "Stage 9 completes. Coverage must not be lower than the v0.16 baseline of 29.59%. The warnings report strict/fallback behavior plus any neighbor-consistency assignments."
    ),
    TestStep(
        "Inspect test4 neighbor-consistency recovery",
        "Read the test4 Stage 9 card/report after the rebuild.",
        "Strict assignments remain first priority, v0.16 fallback remains second, and any v0.17 neighbor recovery only fills previously unassigned faces whose edge neighbors agree on the same source photo."
    ),
    TestStep(
        "Build and inspect test4 atlas",
        "Tap 'Next: Stage 10 — Build UV texture atlas', then open 'View textured model in app'.",
        "Stage 10 exports successfully, texture alignment remains usable, and exposure normalization/UV islands remain active."
    ),
    TestStep(
        "Run test3 Stage 9/10 regression",
        "Open test3. Rebuild Stage 9 and Stage 10, then inspect the textured preview.",
        "Coverage must not be lower than the v0.16 baseline of 18.77%. Unassigned faces remain gray and the model still exports."
    ),
    TestStep(
        "Stage 7 geometry remains unchanged",
        "Compare Stage 7 vertex/triangle counts with Stage 9/10 source mesh counts on either project.",
        "v0.17 changes texture-source assignment only; Stage 7 geometry counts remain unchanged."
    ),
    TestStep(
        "Capture guidance is clearer",
        "Scroll to the Capture guidance card near the top of a Photo Scan project.",
        "It now gives overlap, same-lens/zoom, multi-height-ring, sharpness/lighting, reflection, and temporary-marker guidance."
    ),
    TestStep(
        "Combined diagnostics includes v0.17 recovery notes",
        "Export combined project diagnostics after Stage 10.",
        "The Stage 9 warnings identify neighbor-consistency recovery counts and Stage 10 still reports UV-island/exposure-normalization statistics."
    ),
    TestStep(
        "Export v0.17.0 test report",
        "Mark every step Works or Problem and tap Export test report.",
        "The report identifies app version 0.17.0 and includes the rebuilt Stage 9/10 diagnostic snapshot."
    )
)

private val v0160Steps = listOf(
    TestStep(
        "Rebuild test4 Stage 9 coverage recovery",
        "Open test4. On Stage 8 tap 'Next: Stage 9 — Assign triangle texture sources' and wait for Stage 9 to finish.",
        "Stage 9 completes with non-zero assignments. Coverage must not be lower than the v0.15 baseline of 29.26%; the report notes any conservative fallback assignments used."
    ),
    TestStep(
        "Inspect recovered test4 texture coverage",
        "Read the test4 Stage 9 card/report after the rebuild.",
        "Strict visibility assignments remain preferred. Any recovered faces come only from the two-of-three visibility fallback; geometry and camera-pose counts remain valid."
    ),
    TestStep(
        "Build exposure-normalized test4 atlas",
        "Tap 'Next: Stage 10 — Build UV texture atlas' on test4 and wait for Stage 10 to finish.",
        "Stage 10 completes with UV islands, Ready for export=true, and the report states that conservative per-photo exposure normalization was applied."
    ),
    TestStep(
        "Inspect test4 textured preview",
        "Tap 'View textured model in app' and rotate/zoom through several angles.",
        "The textured model remains aligned and usable. Brightness jumps between photo regions should be no worse than v0.15 and ideally less obvious."
    ),
    TestStep(
        "Run test3 Stage 9/10 regression",
        "Open test3. Rebuild Stage 9, then Stage 10, and open the textured preview.",
        "Coverage must not be lower than the v0.15 baseline of 18.19%; the partial textured model still exports and unassigned faces remain gray."
    ),
    TestStep(
        "Stage 7 geometry remains unchanged",
        "Compare Stage 7 vertex/triangle counts with Stage 9/10 source mesh counts on either project.",
        "The coverage/exposure changes affect appearance only; Stage 7 geometry counts are unchanged."
    ),
    TestStep(
        "Combined diagnostics includes v0.16 notes",
        "Export combined project diagnostics after Stage 10.",
        "The Stage 9 warnings include coverage-recovery information and Stage 10 warnings include exposure-normalization information."
    ),
    TestStep(
        "Export v0.16.0 test report",
        "Mark every step Works or Problem and tap Export test report.",
        "The report identifies app version 0.16.0 and includes the rebuilt Stage 9/10 diagnostic snapshot."
    )
)

private val v0150Steps = listOf(
    TestStep(
        "Rebuild test4 Stage 10 UV-island atlas",
        "Open test4. On 'Stage 9 — Texture Source Assignment' tap 'Next: Stage 10 — Build UV texture atlas' and wait for Stage 10 to finish.",
        "Stage 10 completes with non-zero UV islands, textured faces, atlas occupancy, and Ready for export=true."
    ),
    TestStep(
        "View test4 textured model in the app",
        "On test4 Stage 10 tap the exact button 'View textured model in app'. Rotate/zoom it and try Front, Back, Left, Right, Top and Bottom.",
        "The dialog shows a textured 3D surface. Textured faces use the photo atlas and untextured faces remain gray; the controls remain usable."
    ),
    TestStep(
        "Inspect the new UV-island atlas",
        "Export the test4 texture atlas PNG and open it in an image viewer.",
        "Compared with v0.14's one-triangle mosaic, the PNG contains larger rectangular photo regions/UV islands. It still is not supposed to look like the assembled object by itself."
    ),
    TestStep(
        "Export test4 textured package",
        "Tap 'Export textured model package (.zip)' on test4 Stage 10.",
        "The ZIP contains textured_model.obj, texture_atlas.mtl, and texture_atlas.png and saves successfully."
    ),
    TestStep(
        "Run test3 Stage 10 regression",
        "Open test3 and rebuild Stage 10 from its saved Stage 9 result, then open 'View textured model in app'.",
        "The partial test3 atlas and preview still work even though many faces remain intentionally gray/untextured."
    ),
    TestStep(
        "Stage 7 geometry remains unchanged",
        "Compare Stage 7 vertex/triangle counts with the Stage 10 source mesh counts on either project.",
        "Stage 10 changes only atlas/UV appearance data; Stage 7 geometry counts are unchanged."
    ),
    TestStep(
        "Combined diagnostics includes v0.15 atlas statistics",
        "After rebuilding Stage 10 tap 'Export combined project diagnostics'.",
        "Stage 10 includes UV island count, largest island size, atlas occupancy, textured/untextured faces, coverage and source-photo count."
    ),
    TestStep(
        "Export v0.15.0 test report",
        "Mark every step Works or Problem and tap Export test report.",
        "The report identifies app version 0.15.0 and includes the Stage 10 UV-island/textured-preview diagnostic snapshot."
    )
)

private val v0130Steps = listOf(
    TestStep(
        "Rebuild test4 Stage 8 with pose bridging",
        "Open test4. On 'Stage 7 — Surface Mesh' tap 'Next: Stage 8 — Project photo colors' and wait for Stage 8 to finish.",
        "Stage 8 completes and reports recovered orientation links, bridged orientation links, visibility-rejected candidates, recovered camera poses, and non-zero photo-color coverage."
    ),
    TestStep(
        "Inspect test4 visibility-refined colors",
        "On test4 tap 'View Stage 8 photo colors' and rotate/zoom the colored mesh.",
        "The preview remains responsive. Photo colors remain visible while obvious farther-surface color bleed should be reduced by the coarse depth visibility check."
    ),
    TestStep(
        "Build test4 Stage 9 triangle sources",
        "On the test4 Stage 8 card tap the exact button 'Next: Stage 9 — Assign triangle texture sources'.",
        "A new 'Stage 9 — Texture Source Assignment' card appears with assigned triangles, triangle source coverage, recovered cameras, bridged links, cameras used, and Ready for texture atlas."
    ),
    TestStep(
        "Export test4 Stage 9 source map",
        "On test4 Stage 9 tap 'Export triangle source map' and save the TSV file.",
        "The file contains faceIndex, source photo, three normalized photo-coordinate pairs, and a score for every assigned triangle."
    ),
    TestStep(
        "test3 Stage 8 and Stage 9 regression",
        "Open test3, rebuild Stage 8, then tap 'Next: Stage 9 — Assign triangle texture sources'.",
        "Both stages complete, test3 retains its Stage 7 geometry, and Stage 9 reports non-zero triangle source coverage using multiple cameras."
    ),
    TestStep(
        "Combined diagnostics includes Stage 9",
        "After Stage 9 finishes, tap 'Export combined project diagnostics' on test3 or test4.",
        "The single text file contains Quick Check plus Stages 1–9, including Stage 8 bridging/visibility statistics and Stage 9 triangle-source coverage/camera contributions."
    ),
    TestStep(
        "Project isolation regression through Stage 9",
        "If convenient, start Stage 9 on one project and briefly open another project while it runs.",
        "The other project does not display the first project's Stage 9 progress/result, and background completion does not switch projects."
    ),
    TestStep(
        "Export v0.13.0 test report",
        "Mark every step Works or Problem, add notes where useful, then tap Export test report.",
        "The report identifies app version 0.13.0 and includes the Stage 8 visibility and Stage 9 triangle-source diagnostic snapshot."
    )
)

private val v0120Steps = listOf(
    TestStep(
        "Build test4 Stage 8 photo colors",
        "Open test4 with its saved Stage 7 result. On 'Stage 7 — Surface Mesh' tap the exact button 'Next: Stage 8 — Project photo colors' and wait for Stage 8 to finish.",
        "A new 'Stage 8 — Photo Color Projection' card appears. It reports recovered camera poses, cameras used, colored vertices, color coverage, and Ready for export."
    ),
    TestStep(
        "Inspect the photo-color preview",
        "On test4 tap 'View Stage 8 photo colors'. Rotate, zoom, and try several preset views.",
        "The Stage 7 wireframe remains visible and colored mesh vertices are overlaid from the original photos. The viewer stays responsive and does not crash."
    ),
    TestStep(
        "Export colored PLY",
        "On test4 tap 'Export colored PLY' and save the file.",
        "The PLY exports with x/y/z, normals when available, red/green/blue vertex properties, and the same triangle face count as Stage 7."
    ),
    TestStep(
        "test3 Stage 8 regression",
        "Open test3 and build 'Stage 8 — Photo Color Projection' from its saved Stage 7 result.",
        "Stage 8 completes without changing the Stage 7 topology. It reports non-zero recovered cameras and non-zero colored-vertex coverage."
    ),
    TestStep(
        "Combined diagnostics now includes Stage 8",
        "After Stage 8 finishes, tap 'Export combined project diagnostics' on test3 or test4.",
        "The single text file contains Quick Check plus Stages 1–8, including Stage 8 coverage and per-camera contribution diagnostics."
    ),
    TestStep(
        "Project isolation regression",
        "If convenient, start Stage 8 on one project and briefly open another project while it is processing.",
        "The other project does not show the first project's live progress or Stage 8 result, and background completion does not switch projects."
    ),
    TestStep(
        "Stage 7 geometry remains unchanged",
        "Compare the Stage 7 card before and after Stage 8, or reopen the project after Stage 8 completes.",
        "Stage 8 adds color data only. The saved Stage 7 vertex/triangle/non-manifold/hole-fill counts do not change."
    ),
    TestStep(
        "Export v0.12.0 test report",
        "Mark every step Works or Problem, add notes where useful, then tap Export test report.",
        "The report identifies app version 0.12.0 and includes the Stage 8 color-projection diagnostic snapshot."
    )
)

private val v0110Steps = listOf(
    TestStep(
        "Export one combined project diagnostic",
        "Open test3 after its saved stages are visible. Tap the exact button 'Export combined project diagnostics' and save the text file.",
        "One text file contains Quick Check plus every available Stage 1–7 diagnostic section. It identifies app version 0.11.0 and says geometry PLY/OBJ is separate."
    ),
    TestStep(
        "test3 safe closed-loop fill",
        "On test3, rebuild only 'Stage 7 — Surface Mesh' from its saved Stage 6 result.",
        "Stage 7 stays topology-clean with Non-manifold edges: 0. The card/report shows closed loops before fill, how many were safely filled, remaining closed loops, and added hole-fill faces/vertices."
    ),
    TestStep(
        "test4 safe closed-loop fill",
        "Open test4 and rebuild only 'Stage 7 — Surface Mesh' from its saved Stage 6 result.",
        "Stage 7 remains export-ready with Non-manifold edges: 0. Only simple closed loops that pass safety checks are filled; open/branched boundary components remain untouched."
    ),
    TestStep(
        "Combined report updates after a rebuilt stage",
        "After rebuilding Stage 7, export 'Export combined project diagnostics' again for that project.",
        "The same single diagnostic export now contains the newest Stage 7 hole-fill statistics automatically; you do not need to export Stage 1–7 reports separately."
    ),
    TestStep(
        "Normals and geometry exports still work",
        "From the rebuilt Stage 7 card, open 'View Stage 7 mesh'. Export OBJ or triangle PLY if convenient.",
        "The mesh viewer still works, OBJ/PLY retains vertex normals, and the filled mesh remains at 0 non-manifold edges."
    ),
    TestStep(
        "Project isolation regression",
        "Start Stage 1 on one project and briefly open the other project while the first is still processing, if convenient.",
        "The second project does not show the first project's live progress or results, and background completion does not switch projects."
    ),
    TestStep(
        "Export v0.11.0 test report",
        "Mark every step Works or Problem, add notes where useful, then tap Export test report.",
        "The report identifies app version 0.11.0 and records the combined-diagnostic and safe-hole-fill test results."
    )
)

private val v0100Steps = listOf(
    TestStep(
        "Background job stays with its project",
        "Open test4 and tap the exact button 'Stage 1 — Match photos'. While test4 is still matching, return to the project list and open test3.",
        "test3 does NOT show test4's live matching progress or replace test3 cards. Its status may say that test4 is processing in the background, but test3 remains a separate project."
    ),
    TestStep(
        "Second heavy job is blocked clearly",
        "While test4 is still processing in the background, try to start a reconstruction stage on test3 if the first job is still running.",
        "A message names test4 as the project already processing. No second heavy reconstruction job starts and no test3 results are overwritten."
    ),
    TestStep(
        "Background completion never changes the selected project",
        "Stay on test3 until the test4 Stage 1 job finishes.",
        "The app remains on test3. It must not automatically switch back to test4 when test4 finishes."
    ),
    TestStep(
        "Owner project receives its completed result",
        "After test4 matching finishes, return to the project list and reopen test4.",
        "test4 shows its newly saved Stage 1 result. test3 still shows only its own saved results. Project data did not cross over."
    ),
    TestStep(
        "Build v0.10.0 Stage 7 quality pass",
        "On test4 with Stage 6 available, tap 'Next: Stage 7 — Build surface mesh'. Wait for Stage 7 to finish.",
        "Stage 7 remains topology-clean with Non-manifold edges: 0 and now also reports smoothing, vertex normals, closed boundary loops, open/branched boundary components, and boundary branch vertices."
    ),
    TestStep(
        "Inspect smoothing and boundary diagnostics",
        "On test4 read the Stage 7 card, open 'View Stage 7 mesh', and export 'Export Stage 7 mesh report'.",
        "The mesh remains viewable. Valid vertex normals should be close to the mesh vertex count. Boundary diagnostics are present; v0.10.0 analyzes remaining holes/open borders but does not blindly fill them."
    ),
    TestStep(
        "Export normals in OBJ and PLY",
        "Export 'Export mesh OBJ' and 'Export triangle PLY' from the v0.10.0 Stage 7 card.",
        "OBJ contains vn normal records and face records that reference vertex normals. PLY includes nx, ny, nz vertex properties when normals are available."
    ),
    TestStep(
        "Export v0.10.0 test report",
        "Mark every step Works or Problem, add notes where useful, then tap Export test report.",
        "The report identifies app version 0.10.0 and includes project-isolation results plus the new Stage 7 smoothing/normal/boundary fields."
    )
)

private val v092Steps = listOf(
    TestStep(
        "Cancel reconstruction reset",
        "Open test3 or test4 with saved reconstruction results. Tap 'Reset reconstruction stages', then tap 'Cancel'.",
        "The dialog closes and all existing Stage 1–7 cards remain unchanged."
    ),
    TestStep(
        "Reset stages but keep photos",
        "On test3, tap 'Reset reconstruction stages', then tap 'Reset stages' in the confirmation dialog.",
        "All generated Stage 1–7 cards disappear immediately, but the project still shows the same 95 photos. The status says to start again with Stage 1 — Match photos."
    ),
    TestStep(
        "Stage 1 rebuild clears stale downstream cards immediately",
        "With test4 containing saved downstream results, tap the exact button 'Stage 1 — Match photos'. Watch the project screen as matching starts.",
        "Stages 2–7 disappear as soon as Stage 1 starts. An old Stage 7 card must not remain visible while Stage 1 is rebuilding."
    ),
    TestStep(
        "Stage 2 rebuild invalidates only later stages",
        "After Stage 1 completes on a project, build Stage 2. If later-stage results existed before the rebuild, confirm they remain gone.",
        "Stage 1 remains visible. Stage 2 is replaced by the new result, and Stages 3–7 stay hidden until rebuilt."
    ),
    TestStep(
        "Reset persists after leaving the project",
        "After resetting test3, return to the project list and reopen test3.",
        "The photos are still present and the cleared Stage 1–7 results do not reappear from disk."
    ),
    TestStep(
        "Stage 7 topology regression",
        "On a project that still has a saved v0.9.1 Stage 7 result, verify the Stage 7 card still shows Non-manifold edges: 0. Rebuild Stage 7 only if convenient.",
        "The v0.9.2 state-management change does not alter the topology-clean Stage 7 mesh format or counts unless you intentionally rebuild upstream stages."
    ),
    TestStep(
        "Export v0.9.2 test report",
        "Mark every step Works or Problem, add notes where useful, then tap Export test report.",
        "The report identifies app version 0.9.2 and records the reset/state-invalidation test results."
    )
)

private val v091Steps = listOf(
    TestStep(
        "Build test4 topology-clean Stage 7 mesh",
        "Open test4. On the Stage 6 — Dense Fusion card tap 'Next: Stage 7 — Build surface mesh' and wait for it to finish.",
        "Stage 7 completes with at least 100 triangles, Ready for export is true, and the Stage 7 card shows Non-manifold edges: 0."
    ),
    TestStep(
        "Inspect test4 topology numbers",
        "On test4, read the Stage 7 — Surface Mesh card and then export 'Export Stage 7 mesh report'.",
        "The report includes Candidate triangles proposed, Cleanup-rejected faces, Unused vertices removed, Boundary edges, Non-manifold edges, and Retained surface components. Non-manifold edges should be 0."
    ),
    TestStep(
        "View the cleaned test4 mesh",
        "On test4 tap 'View Stage 7 mesh'. Try Front/Back/Left/Right/Top/Bottom, rotate, pinch, and twist.",
        "The topology-clean wireframe remains visible and responsive. The triangle count may be lower than v0.9.0 because overlapping faces were deliberately removed; open borders/holes are still allowed."
    ),
    TestStep(
        "Export test4 cleaned mesh files",
        "On test4 export 'Export Stage 7 mesh report', 'Export mesh OBJ', and 'Export triangle PLY'.",
        "All three files save. OBJ has v/f records, PLY has vertex and face sections, and the report identifies app version 0.9.1."
    ),
    TestStep(
        "test3 topology regression",
        "Open test3. On Stage 6 — Dense Fusion tap 'Next: Stage 7 — Build surface mesh'. Inspect the Stage 7 card and open 'View Stage 7 mesh'.",
        "test3 creates a non-empty cleaned mesh, Ready for export is true, and Non-manifold edges is 0."
    ),
    TestStep(
        "Stage 7 cleanup result persists",
        "Return to the project list, reopen either rebuilt project, and scroll back to Stage 7 — Surface Mesh.",
        "The v0.9.1 topology counts and mesh remain present without rebuilding."
    ),
    TestStep(
        "Export v0.9.1 test report",
        "Mark every step Works or Problem, add notes where useful, and tap Export test report.",
        "The report identifies app version 0.9.1 and includes Stage 7 topology fields plus all test statuses and notes."
    )
)

private val v090Steps = listOf(
    TestStep(
        "Stage labels match the instructions",
        "Open test4 and scroll through the reconstruction cards. Find the card titled Stage 6 — Dense Fusion.",
        "The reconstruction cards use stable Stage 1 through Stage 7 names. The Stage 6 card contains the exact button text 'Next: Stage 7 — Build surface mesh'."
    ),
    TestStep(
        "Build test4 Stage 7 surface mesh",
        "On test4, on the Stage 6 — Dense Fusion card, tap 'Next: Stage 7 — Build surface mesh' and wait for it to finish.",
        "A new Stage 7 — Surface Mesh card appears with a non-zero mesh vertex count and at least 100 triangles. Ready for export should be true."
    ),
    TestStep(
        "View the test4 mesh",
        "On the Stage 7 — Surface Mesh card tap 'View Stage 7 mesh'. Drag, pinch, twist, and try Front/Back/Left/Right/Top/Bottom.",
        "A full-screen wireframe triangle mesh stays visible and can be inspected from all directions without crashing. Holes/noise are allowed in this first experimental mesh."
    ),
    TestStep(
        "Export test4 mesh files",
        "On the Stage 7 — Surface Mesh card export 'Export Stage 7 mesh report', 'Export mesh OBJ', and 'Export triangle PLY'.",
        "All three files save successfully. The report identifies app version 0.9.0; OBJ contains v/f records; PLY contains both vertex and face sections."
    ),
    TestStep(
        "Stage 7 result persists",
        "Return to the project list, reopen test4, and scroll back to Stage 7 — Surface Mesh.",
        "The saved Stage 7 card and mesh are still present without rebuilding."
    ),
    TestStep(
        "test3 Stage 7 regression",
        "Open test3. On Stage 6 — Dense Fusion tap 'Next: Stage 7 — Build surface mesh'. Then open 'View Stage 7 mesh'.",
        "test3 also creates a non-empty triangle mesh and the viewer opens normally."
    ),
    TestStep(
        "Export v0.9.0 test report",
        "Mark every step Works or Problem, add notes where useful, and tap Export test report.",
        "The report identifies app version 0.9.0 and includes the Stage 7 mesh snapshot plus the exact test statuses and notes."
    )
)

private val v084Steps = listOf(
    TestStep(
        "test4 fusion candidate preflight",
        "Open test4 and run Fuse multiple dense pairs (v0.8.4). Then open View pair diagnostics.",
        "Fusion selects only pairs with both image files, both refined camera centers, and a recovered world pose. The old generic 'Missing refined pose or image file' rejection should not appear for a pair that was selected."
    ),
    TestStep(
        "test4 fusion still produces geometry",
        "After the v0.8.4 test4 fusion finishes, inspect the fusion card and fused cloud.",
        "At least 2 pair clouds fuse, the fused cloud is non-empty, and Ready for surface reconstruction remains true. Geometry-based rejections are allowed when a pair is unstable or too sparse."
    ),
    TestStep(
        "Inspect v0.8.4 preflight note",
        "Export the test4 dense fusion report and read Warnings / notes.",
        "If the rebuilt rotation chain cannot reach some later cameras, the report says how many candidates were filtered before selection instead of selecting them and later calling them missing."
    ),
    TestStep(
        "test3 fusion regression",
        "Open test3 and run Fuse multiple dense pairs (v0.8.4), then inspect pair diagnostics and the fused cloud.",
        "test3 remains healthy: fusion completes without a missing-file/world-pose selection error and produces a non-empty cloud ready for surface reconstruction."
    ),
    TestStep(
        "Precise defensive diagnostics",
        "If any selected pair still fails before dense reconstruction, read its pair diagnostic.",
        "The reason identifies the exact missing item (camera index, first/second image, refined center, or recovered world pose) instead of the old catch-all missing-pose-or-image message."
    ),
    TestStep(
        "Export v0.8.4 report",
        "Mark every step Works or Problem, add notes if useful, and export the version test report.",
        "The report identifies app version 0.8.4 and includes the current reconstruction snapshot plus your saved test statuses and notes."
    )
)

private val v083Steps = listOf(
    TestStep(
        "Full-screen point-cloud viewer",
        "Open any saved point cloud. Rotate it on all three axes, pinch to zoom, try all six preset views, and open/close the optional sliders.",
        "The cloud stays visible in a full-screen viewer. Preset buttons fit without horizontal scrolling, and sliders no longer force the cloud off-screen."
    ),
    TestStep(
        "test3 dense regression",
        "Open test3 and rebuild the corrected dense stereo pair if convenient.",
        "Dense stereo still completes and creates a non-empty saved report/cloud."
    ),
    TestStep(
        "test4 large-project dense recovery",
        "Open test4 with its 175 photos and existing sparse/multi-view/bundle reports. Tap Build corrected dense stereo pair (v0.8.3) and wait for it to finish.",
        "The app selects a usable pair from the refined connected camera component when the global sparse-best pair is outside that component. Progress messages advance and a dense report/cloud is produced, or a persistent diagnostic records the exact failing stage."
    ),
    TestStep(
        "Inspect dense-stage diagnostics",
        "After the test4 dense attempt, export this version test report and inspect the Pipeline stage diagnostics section.",
        "The report records the dense start, selected project/photo count, each major progress stage, and either SUCCESS with point counts or FAILED with the exception message."
    ),
    TestStep(
        "Fusion after recovered dense seed",
        "If test4 produces a corrected dense seed, run Fuse multiple dense pairs and inspect the fused cloud.",
        "Fusion can continue from the recovered connected-component dense seed without relying on the old global sparse-best pair."
    ),
    TestStep(
        "Export v0.8.3 report",
        "Add notes to any Works/Problem steps and export the test report.",
        "The report includes reconstruction snapshot, Rapid diagnostics, EXIF audit, and persistent dense-stage diagnostics."
    )
)

private val v082Steps = listOf(
    TestStep(
        "Launch v0.8.2 guide and keep your place",
        "Open the guide from the project list, inside a project, and from the camera screen. Close/reopen it once.",
        "The same v0.8.2 guide opens from all major screens and keeps the current step, statuses, and notes."
    ),
    TestStep(
        "Rapid Hold regression",
        "Choose Hold Rapid, set target 1/sec, press and continuously hold the shutter for about 5 seconds, then release.",
        "Several full-resolution photos are saved while your finger remains down. Releasing stops the sequence. It must not stop after only the first photo."
    ),
    TestStep(
        "Measure Rapid speed instead of guessing",
        "Run Tap Rapid or Hold Rapid for several seconds at target 5/sec, then try target 2/sec or 1/sec. Read the actual speed shown after each run.",
        "Rapid keeps capturing without crashing. The displayed actual rate may be lower than the requested target because full-resolution saves are serialized; the exported test report records the measured rate and average save time."
    ),
    TestStep(
        "Rotate the phone while the camera is open",
        "Open the camera in portrait, rotate the phone to landscape, then rotate back to portrait without pressing Back.",
        "The app stays on the camera screen instead of returning to the project list or reopening the guide. Your selected capture style, interval, and countdown setting remain selected."
    ),
    TestStep(
        "Mixed portrait/landscape photo orientation",
        "Capture or import overlapping photos in both portrait and landscape orientations, then run Match photos.",
        "Matching completes using EXIF-normalized pixels. The exported test report lists the detected EXIF orientation and normalized rotation for the selected project's photos."
    ),
    TestStep(
        "Inspect a point cloud on all three axes",
        "Open any sparse, multi-view, refined, dense, or fused cloud. Drag horizontally and vertically, pinch to zoom, twist with two fingers for roll, and try Front/Back/Left/Right/Top/Bottom presets and the Yaw/Pitch/Roll sliders.",
        "The cloud can be viewed from arbitrary yaw, pitch, and roll angles instead of only spinning around one axis. Reset returns to the front view."
    ),
    TestStep(
        "Fusion regression on test3/test4",
        "Open test3 or test4 and confirm its saved dense-fusion result still opens. If you rebuild fusion, inspect pair diagnostics and the fused cloud.",
        "Existing v0.8.1 fusion results persist, or a rebuilt fusion completes without the old single-pair 1,000-point gate blocking it."
    ),
    TestStep(
        "Add a note to a successful test",
        "Mark this step Works, type an optional note in the note box, close the guide, then reopen it.",
        "Notes are available for Works as well as Problems, save automatically, and remain attached to the correct test step."
    ),
    TestStep(
        "Export v0.8.2 diagnostic report",
        "Review all statuses and notes, then export the version test report before changing the photo set.",
        "The report contains test statuses, Works/Problem notes, device/build identity, reconstruction diagnostics, EXIF orientation audit, and recent Rapid capture measurements."
    )
)

private val v081Steps = listOf(
    TestStep(
        "Launch v0.8.1 guide from camera and project screens",
        "Open this guide from the project list, inside a project, and from the camera screen.",
        "The same v0.8.1 guide opens from all major screens and keeps your test progress."
    ),
    TestStep(
        "Single capture regression",
        "Open a Photo Scan project, choose Single, and tap the shutter once.",
        "Exactly one full-resolution photo is saved and the camera remains usable."
    ),
    TestStep(
        "Rapid Hold capture",
        "Choose Hold Rapid, set 1/sec, hold the shutter for about 5 seconds, then release it.",
        "Photos are captured only while held. Releasing stops the sequence and the project refreshes once for the completed burst."
    ),
    TestStep(
        "Tap-to-run Rapid with countdown",
        "Choose Tap Rapid, leave the 3s delay enabled, tap once, let it capture several photos, then tap again to stop.",
        "A 3-second countdown appears, automatic capture continues without holding the phone, and the second tap stops it."
    ),
    TestStep(
        "Rapid interval / hardware limit",
        "Try a faster target such as 5/sec, then a slower target such as every 2 sec.",
        "The requested interval changes. Full-resolution saves remain serialized; if the phone cannot sustain 5/sec it simply runs at its fastest safe rate without piling up requests or crashing."
    ),
    TestStep(
        "Mixed portrait/landscape orientation",
        "Capture or import several overlapping views with a mix of portrait and landscape orientation, then run Match photos.",
        "Matching still works because OpenCV receives EXIF-normalized pixels. The exported test report lists the EXIF orientation audit for every photo in the selected project."
    ),
    TestStep(
        "test3 fusion gate regression",
        "Open test3 after its corrected dense result. Its seed cloud may still show only about 713 points. Tap Fuse multiple dense pairs (v0.8.1).",
        "Fusion is no longer hidden or blocked solely by the old 1,000-point single-pair threshold. The fusion engine itself evaluates connected pairs."
    ),
    TestStep(
        "Review dense-fusion diagnostics",
        "If fusion creates a result, open pair diagnostics and inspect FUSED versus SKIPPED pairs and the fused point count.",
        "Every attempted pair has a real acceptance/skip reason. A weak pair is rejected instead of being forced into the shared cloud."
    ),
    TestStep(
        "Export v0.8.1 test report",
        "Mark every step Works or Problem, add explanations where needed, and export this report before changing the photo set.",
        "The report contains capture-test results, current reconstruction diagnostics, device/build identity, and the EXIF orientation audit."
    )
)

private val v080Steps = listOf(
    TestStep(
        "Launch v0.8 guide",
        "Open the guide from the project list or inside test2 and confirm the current v0.7.1 dense result is still available.",
        "The v0.8 guide opens and the existing dense-pair card remains saved."
    ),
    TestStep(
        "Run multi-pair dense fusion",
        "On the v0.7.1 dense card tap Fuse multiple dense pairs (v0.8) and wait for processing to finish.",
        "A v0.8 multi-pair dense fusion card appears without crashing and reports candidate pairs, fused pairs, and fused point count."
    ),
    TestStep(
        "Check pair acceptance",
        "Tap View pair diagnostics. Scroll through every selected pair and note which were FUSED or SKIPPED.",
        "Every selected pair has real diagnostics. Unstable/very-low-parallax pairs may be skipped instead of contaminating the fused cloud."
    ),
    TestStep(
        "Check fusion coverage",
        "Read Dense pairs fused and Fused 3D points on the v0.8 card.",
        "At least 2 dense pairs should fuse and the result should contain at least several thousand points. More accepted pairs are better, but the app should not force bad pairs into the cloud."
    ),
    TestStep(
        "View fused dense cloud",
        "Tap View fused dense cloud and rotate it through several angles. Compare it mentally with the one-pair cloud.",
        "The preview rotates without crashing and represents several viewpoints in one shared frame. It may still be noisy and is not a finished mesh yet."
    ),
    TestStep(
        "Export dense fusion report",
        "Tap Export dense fusion report and save it.",
        "The report includes project identity, pair-by-pair accept/skip diagnostics, raw/fused point counts, warnings, and readiness for surface reconstruction."
    ),
    TestStep(
        "Export fused dense PLY",
        "Tap Export fused dense PLY and save it.",
        "The PLY vertex count matches Fused 3D points and includes app/project/fingerprint metadata."
    ),
    TestStep(
        "Fusion result persists",
        "Return to the project list and reopen test2 without changing photos.",
        "The v0.8 fusion card remains saved without rebuilding."
    ),
    TestStep(
        "Export v0.8 test report",
        "Mark every step Works or Problem, add notes if needed, then export this test report before changing any photos.",
        "The automatic diagnostic snapshot contains the v0.7.1 dense-pair metrics plus the new v0.8 fusion metrics."
    )
)

private val v071Steps = listOf(
    TestStep(
        "Launch v0.7.1 guide from any major screen",
        "Open this guide from the project list, project screen, and camera screen.",
        "The same v0.7.1 guide opens from all three screens and preserves your test progress."
    ),
    TestStep(
        "Restore the known photo pipeline if needed",
        "Open test2. If the v0.7 invalidation test cleared its saved geometry, rerun Match photos, Build sparse 3D, Build multi-view 3D, and Refine shared tracks.",
        "The project again reaches Ready for dense reconstruction without crashing. This is expected if the final v0.7 photo-change test cleared the saved stages."
    ),
    TestStep(
        "Build corrected dense stereo pair",
        "Tap Build corrected dense stereo pair (v0.7.1) and wait for it to finish.",
        "A v0.7.1 corrected dense card appears with a non-zero observed inlier disparity range, valid disparity pixels, and dense points."
    ),
    TestStep(
        "Check adaptive disparity window",
        "Read Verified disparity and SGBM search on the dense card.",
        "The observed median disparity should fall inside the displayed SGBM search range. This confirms the matcher is searching where the verified object features actually are."
    ),
    TestStep(
        "Check sparse-depth guidance",
        "Read Sparse-depth-guided candidates and Dense 3D points.",
        "Sparse-depth-guided candidates should normally be greater than zero. If the app reports a fallback instead, export the dense report so the reason is captured."
    ),
    TestStep(
        "View corrected dense cloud",
        "Tap View dense cloud and rotate it through several angles.",
        "The preview remains stable and uses robust zoom so a few distant outliers do not compress the main shape. It does not need to look like a finished model yet."
    ),
    TestStep(
        "Export corrected dense report",
        "Tap Export dense report and save the text file.",
        "The report includes observed disparity low/median/high, the adaptive SGBM window, sparse-depth-guided candidate count, dense point count, depth range, and fingerprints."
    ),
    TestStep(
        "Export corrected dense PLY",
        "Tap Export dense PLY and save the file.",
        "The PLY vertex count matches Dense 3D points and retains app/project/fingerprint metadata."
    ),
    TestStep(
        "Corrected dense result persists",
        "Return to the project list and reopen test2 without changing its photos.",
        "The v0.7.1 dense result is still present without rebuilding."
    ),
    TestStep(
        "Export v0.7.1 test report before changing photos",
        "Mark every step Works or Problem, add notes if needed, then export this test report. Do not add/delete a photo until after saving this report.",
        "The automatic Diagnostic snapshot still contains the feature, sparse, multi-view, bundle, and corrected dense metrics instead of showing them as cleared."
    )
)


private val v070Steps = listOf(
    TestStep(
        "Launch v0.7 guide from any major screen",
        "Open this guide from the project list, project screen, and camera screen.",
        "The same v0.7 guide opens from all three screens and preserves your test progress."
    ),
    TestStep(
        "Regression: saved bundle refinement",
        "Open the project that passed v0.6.1 and confirm the shared-track refinement card is still present.",
        "The bundle card remains saved and reports Ready for dense reconstruction = true."
    ),
    TestStep(
        "Build first dense stereo pair",
        "On the bundle-refinement card tap Build dense stereo pair (v0.7) and wait for it to finish.",
        "A v0.7 dense reconstruction card appears without crashing and reports valid disparity pixels plus a non-zero dense point count."
    ),
    TestStep(
        "Check dense coverage",
        "Read Valid disparity pixels and Dense 3D points on the v0.7 card.",
        "Both values are greater than zero. A useful first dense result should normally export at least about 1,000 filtered points."
    ),
    TestStep(
        "View dense cloud",
        "Tap View dense cloud and rotate the preview.",
        "A much denser point cloud than the sparse pair is visible and rotates without crashing. The shape can still contain noise because this is only one stereo pair."
    ),
    TestStep(
        "Export dense report",
        "Tap Export dense report and save the text file.",
        "The report includes app/project identity, pair names, match/inlier counts, stereo settings, disparity count, dense point count, depth range, warnings, and readiness for multi-pair fusion."
    ),
    TestStep(
        "Export dense PLY",
        "Tap Export dense PLY and save the file.",
        "The PLY vertex count matches Dense 3D points and its header contains app version, project ID, and a report fingerprint."
    ),
    TestStep(
        "Dense result persists",
        "Back to the project list and reopen the project without changing photos.",
        "The v0.7 dense card is still present without rebuilding."
    ),
    TestStep(
        "Photo change invalidates dense geometry",
        "After a dense result exists, add/import or delete one photo.",
        "Feature matching, sparse, multi-view, bundle, and dense results clear because the geometry no longer matches the photo set."
    ),
    TestStep(
        "Export v0.7 test report",
        "Mark every step Works or Problem, add notes if needed, and export this test report.",
        "The report includes the automatic diagnostic snapshot including the v0.7 dense metrics."
    )
)

private val v061Steps = listOf(
    TestStep(
        "Open test guide from anywhere",
        "Open the ? test guide from the project list, from inside a project, and while the camera screen is open.",
        "The same v0.6.1 guide opens from all three major screens and returns you to the screen you were using when you close it."
    ),
    TestStep(
        "Check clear RMS explanation",
        "Open the saved v0.6 shared-track refinement card and read the RMS reprojection section.",
        "The card shows the before/after RMS values, explicitly says lower is better, and states the percentage improvement when the final RMS is lower."
    ),
    TestStep(
        "Check automatic diagnostic snapshot",
        "Open this guide on the same project that has matching, sparse, multi-view, and bundle results, then go to the final test-report step.",
        "The exported version test report contains a Diagnostic snapshot with project ID/photo count and the important metrics from every currently available reconstruction stage."
    ),
    TestStep(
        "Check report identity metadata",
        "Export the v0.6 refinement report once from the project screen and inspect the first few lines.",
        "The report includes App version, Project ID, and a stable Report fingerprint so duplicate result files can be recognized."
    ),
    TestStep(
        "Regression: saved reconstruction still present",
        "Back out of the project and reopen it without changing photos.",
        "Feature matching, sparse, multi-view, and bundle-refinement results remain available exactly as before this maintenance update."
    ),
    TestStep(
        "Export v0.6.1 test report",
        "Mark each step Works or Problem, add any explanation you want, and export this test report.",
        "The file includes test statuses, your notes, device/build information, report fingerprint, and the automatic reconstruction diagnostic snapshot."
    )
)

private val v060Steps = listOf(
    TestStep(
        "Launch v0.6 guide",
        "Confirm this guide appears for v0.6.0 and can be reopened with the ? button.",
        "The guide opens for v0.6.0 and preserves statuses/notes while you test."
    ),
    TestStep(
        "Regression: v0.5.1 multi-view component",
        "Open the same project that connected 14 cameras in v0.5.1. If necessary rerun Match photos, Build sparse 3D, and Build multi-view 3D.",
        "The multi-view card still reports a connected component ready for bundle adjustment without crashing."
    ),
    TestStep(
        "Run shared-track refinement",
        "On the Multi-view sparse reconstruction card tap Refine shared tracks (v0.6) and wait for all iterations to finish.",
        "A v0.6 shared-track bundle refinement card appears with track counts, observation count, refined points, and RMS reprojection error."
    ),
    TestStep(
        "Check multi-view feature tracks",
        "Inspect 3+ view tracks built and Tracks optimized on the v0.6 card.",
        "Both values should be greater than zero. A useful set should normally produce dozens or hundreds of tracks spanning at least 3 photos."
    ),
    TestStep(
        "Check reprojection improvement",
        "Compare Initial RMS reprojection error with Final RMS reprojection error.",
        "Final RMS should normally be lower than Initial RMS. If it rises noticeably, mark Problem and include both numbers in your explanation."
    ),
    TestStep(
        "View refined point cloud",
        "Tap View refined cloud and rotate the preview.",
        "The refined sparse cloud appears and rotates without crashing. It may have fewer points than the raw v0.5 cloud because v0.6 keeps only shared multi-view tracks."
    ),
    TestStep(
        "Export v0.6 refinement report",
        "Tap Export v0.6 refinement report and save the text file.",
        "The report contains track/observation counts, before/after RMS error, refined camera centers, warnings, and readiness for dense reconstruction."
    ),
    TestStep(
        "Export refined PLY",
        "Tap Export refined PLY and save the file.",
        "A PLY file is saved and its vertex count matches Refined sparse points."
    ),
    TestStep(
        "Refinement result persists",
        "Return to the project list and reopen the same project without changing photos. Restart the app if convenient.",
        "The v0.6 refinement card is still present without rerunning the optimizer."
    ),
    TestStep(
        "Photo changes invalidate refinement",
        "After a saved v0.6 result exists, add/import or delete one photo.",
        "Feature-match, sparse, multi-view, and v0.6 refinement results all clear because the geometry is stale."
    ),
    TestStep(
        "Export v0.6 test report",
        "Mark every step Works or Problem, add explanations for any problems, then export this version test report.",
        "The report records every v0.6 result and can be uploaded to ChatGPT with the refinement report and refined PLY."
    )
)

private val v051Steps = listOf(
    TestStep(
        "Launch v0.5.1 guide",
        "Confirm this guide appears for v0.5.1 and can be reopened with the ? button.",
        "The guide opens for v0.5.1 and preserves your test statuses and notes."
    ),
    TestStep(
        "Regression: matching and two-view sparse",
        "Open the same Photo Scan project from v0.5.0. Run Match photos and Build sparse 3D if needed.",
        "Feature matching and the known-good two-view sparse reconstruction still complete without crashing."
    ),
    TestStep(
        "Rebuild multi-view after weak-link fix",
        "Tap Build multi-view 3D on the same project that connected only 2 cameras in v0.5.0.",
        "v0.5.1 evaluates all adjacent pairs and selects the largest connected segment instead of stopping permanently at the first weak pair."
    ),
    TestStep(
        "Check connected camera recovery",
        "Inspect Connected cameras and Connected adjacent pairs.",
        "More than 2 cameras should now be connected. Your current test set is expected to recover a substantial later segment even if one or more early links remain weak."
    ),
    TestStep(
        "Inspect every pair after a break",
        "Tap View path and scroll beyond the first weak pair.",
        "Pairs after an early weak link still contain real ratio/RANSAC/pose results. They should no longer all become zero simply because an earlier link failed."
    ),
    TestStep(
        "Check largest-component warnings",
        "Read the warnings on the multi-view card and exported report.",
        "The report identifies the largest connected camera segment and separately identifies weak/disconnected links rather than claiming the entire sequence stopped."
    ),
    TestStep(
        "View recovered combined cloud",
        "Tap View combined cloud and rotate it.",
        "A combined sparse cloud from the recovered main segment is visible and rotates without crashing. It should contain more than the 31 points from the failed v0.5.0 run."
    ),
    TestStep(
        "Export v0.5.1 multi-view report",
        "Export the multi-view report and save it.",
        "The report contains full-sequence pair diagnostics, connected camera count, main-segment information, point counts, and readiness for bundle adjustment."
    ),
    TestStep(
        "Export v0.5.1 PLY",
        "Export the multi-view PLY file.",
        "The PLY vertex count matches the Combined sparse points count."
    ),
    TestStep(
        "Export v0.5.1 test report",
        "Mark each step Works or Problem, add explanations where needed, then export the test report.",
        "The text report records every v0.5.1 result and can be uploaded to ChatGPT with the multi-view report."
    )
)
private val v050Steps = listOf(
    TestStep(
        "Launch v0.5 guide",
        "Confirm this guide appears for v0.5.0. Close it with Test now and reopen it with the ? button.",
        "The guide reopens on the same step and preserves prior results."
    ),
    TestStep(
        "Regression: existing photo project",
        "Open the photo project that passed v0.4. If needed, run Match photos and Build sparse 3D again.",
        "The existing feature matching and two-view sparse reconstruction still work without crashing."
    ),
    TestStep(
        "Build multi-view 3D",
        "On a successful sparse reconstruction card, tap Build multi-view 3D and wait for the sequence to finish.",
        "A Multi-view sparse reconstruction card appears with connected camera and point counts."
    ),
    TestStep(
        "Check connected camera count",
        "Inspect Connected cameras and Connected adjacent pairs on the multi-view card.",
        "More than two cameras should be connected. A strong sequence should connect most or all photos."
    ),
    TestStep(
        "Inspect camera path",
        "Tap View path and scroll through the adjacent-pair entries.",
        "Each pair shows ratio matches, RANSAC inliers, pose inliers, triangulated points, rotation, and CONNECTED/STOPPED status."
    ),
    TestStep(
        "View combined point cloud",
        "Tap View combined cloud and rotate the preview.",
        "A larger combined cloud appears and the preview rotates without crashing. Shape may still drift because bundle adjustment is not added yet."
    ),
    TestStep(
        "Export multi-view report",
        "Tap Export multi-view report and save the text file.",
        "A text report is created with camera centers, pair geometry, connected counts, warnings, and readiness for bundle adjustment."
    ),
    TestStep(
        "Export multi-view PLY",
        "Tap Export multi-view PLY and save the file.",
        "A PLY file is created and its vertex count matches the Combined sparse points count in the app."
    ),
    TestStep(
        "Multi-view result persists",
        "Go back to the project list and reopen the same project without changing its photos. Restart the app if convenient.",
        "The multi-view reconstruction card is still present without rebuilding."
    ),
    TestStep(
        "Photo change invalidates all geometry",
        "After a multi-view result exists, add/import or delete one photo.",
        "Feature-match, two-view sparse, and multi-view reports all disappear because they are now stale."
    ),
    TestStep(
        "Export v0.5 test report",
        "Review the test summary, export the version test report, and upload it to ChatGPT along with the multi-view report if possible.",
        "The report lists every v0.5 step, status, and any problem explanations."
    )
)

private val v040Steps = listOf(
    TestStep(
        "Launch v0.4 guide",
        "Confirm this guide appears for v0.4.0, close it with Test now, and reopen it with the ? button.",
        "The guide can be closed/reopened and keeps prior test statuses and problem explanations."
    ),
    TestStep(
        "Regression: feature matching",
        "Open your existing Photo Scan project or create one with at least 6 overlapping photos. Tap Match photos.",
        "Feature matching completes and reports the photo set as ready when enough adjacent pairs have usable overlap."
    ),
    TestStep(
        "Build first sparse 3D cloud",
        "After a successful Match photos result, tap Build sparse 3D and wait for geometric verification and triangulation to finish.",
        "A First sparse 3D reconstruction card appears with a best photo pair, ratio matches, RANSAC inliers, pose inliers, and a non-zero 3D point count."
    ),
    TestStep(
        "Check geometric verification",
        "Inspect the sparse reconstruction card. Compare Ratio matches, RANSAC inliers, and Pose inliers.",
        "RANSAC and pose inliers should be greater than zero and normally lower than or equal to the raw ratio-test match count."
    ),
    TestStep(
        "View and rotate point cloud",
        "Tap View cloud. Move the Rotate view slider through several angles.",
        "A visible group of white points appears on a black preview and changes orientation as the slider moves without crashing. The shape may still be rough/sparse in this version."
    ),
    TestStep(
        "Export sparse report",
        "Tap Export report on the sparse reconstruction card and save the text file.",
        "A .txt file is created containing the chosen pair, match/inlier counts, focal estimate, warnings, and all adjacent-pair geometry checks."
    ),
    TestStep(
        "Export PLY point cloud",
        "Tap Export PLY point cloud and save the file. If you have a PLY viewer available, opening it is optional.",
        "A .ply file is saved and its vertex count matches the 3D point count shown in the app."
    ),
    TestStep(
        "Sparse result persists",
        "Go back to the project list, reopen the same project without changing its photos, and if convenient restart the app once.",
        "The sparse reconstruction card is still present without rebuilding it."
    ),
    TestStep(
        "Photo changes invalidate geometry",
        "After a saved sparse result exists, add/import or delete one photo.",
        "Both the old feature-match report and sparse reconstruction report disappear because they no longer match the current photo set."
    ),
    TestStep(
        "Export v0.4 test report",
        "Review the Works / Problems / Untested summary and tap Export test report. Upload it to ChatGPT, especially if any step is marked Problem.",
        "The exported report lists every v0.4 test status and any explanations you entered for problems."
    )
)

@Composable
fun VersionTestGuideDialog(
    versionName: String,
    selectedProject: PhotoProject?,
    featureMatchReport: FeatureMatchReport?,
    sparseReport: SparseReconstructionReport?,
    multiViewReport: MultiViewReconstructionReport?,
    bundleReport: BundleAdjustmentReport?,
    denseReport: DenseReconstructionReport?,
    denseFusionReport: DenseFusionReport?,
    surfaceMeshReport: SurfaceMeshReport?,
    textureProjectionReport: TextureProjectionReport?,
    textureSourceAssignmentReport: TextureSourceAssignmentReport?,
    textureAtlasReport: TextureAtlasReport?,
    calibrationProfile: CameraCalibrationProfile?,
    calibrationReport: CameraCalibrationReport?,
    photoCalibrationTargetPreset: PhotoCalibrationTargetPreset,
    laserCalibrationTargetPreset: LaserCalibrationTargetPreset,
    laserAnalysisHistory: List<LaserAnalysisRun>,
    laserPlaneReport: LaserPlaneCalibrationReport?,
    reconstructionStatus: ReconstructionStatus,
    onPause: () -> Unit,
    onFinish: () -> Unit
) {
    val context = LocalContext.current
    val preferences = remember(versionName) {
        context.getSharedPreferences("version_test_results_$versionName", Context.MODE_PRIVATE)
    }
    val rapidDiagnosticsPreferences = remember {
        context.getSharedPreferences("rapid_capture_diagnostics", Context.MODE_PRIVATE)
    }
    val pipelineDiagnosticsPreferences = remember {
        context.getSharedPreferences("pipeline_stage_diagnostics", Context.MODE_PRIVATE)
    }
    val steps = remember(versionName) {
        when (versionName) {
            "0.26.0" -> v0260Steps
            "0.24.0" -> v0240Steps
            "0.23.0" -> v0230Steps
            "0.22.0" -> v0220Steps
            "0.21.0" -> v0210Steps
            "0.20.0" -> v0200Steps
            "0.19.0" -> v0190Steps
            "0.18.0" -> v0180Steps
            "0.17.0" -> v0170Steps
            "0.16.0" -> v0160Steps
            "0.15.0" -> v0150Steps
            "0.14.0" -> v0140Steps
            "0.13.0" -> v0130Steps
            "0.12.0" -> v0120Steps
            "0.11.0" -> v0110Steps
            "0.10.0" -> v0100Steps
            "0.9.2" -> v092Steps
            "0.9.1" -> v091Steps
            "0.9.0" -> v090Steps
            "0.8.4" -> v084Steps
            "0.8.3" -> v083Steps
            "0.8.2" -> v082Steps
            "0.8.1" -> v081Steps
            "0.8.0" -> v080Steps
            "0.7.1" -> v071Steps
            "0.7.0" -> v070Steps
            "0.6.1" -> v061Steps
            "0.6.0" -> v060Steps
            "0.5.1" -> v051Steps
            "0.5.0" -> v050Steps
            "0.4.0" -> v040Steps
            "0.3.1" -> v031Steps
            "0.3.0" -> v030Steps
            "0.2.2" -> v022Steps
            else -> v061Steps
        }
    }
    var currentStep by remember(versionName) {
        mutableIntStateOf(preferences.getInt("current_step", 0).coerceIn(0, steps.lastIndex))
    }
    val results = remember(versionName) {
        mutableStateMapOf<Int, TestResult>().apply {
            steps.indices.forEach { index ->
                val stored = preferences.getString("result_$index", TestResult.UNTESTED.name)
                put(index, runCatching { TestResult.valueOf(stored ?: TestResult.UNTESTED.name) }
                    .getOrDefault(TestResult.UNTESTED))
            }
        }
    }
    val notes = remember(versionName) {
        mutableStateMapOf<Int, String>().apply {
            steps.indices.forEach { index -> put(index, preferences.getString("note_$index", "").orEmpty()) }
        }
    }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    val step = steps[currentStep]
    val complete = currentStep == steps.lastIndex

    fun saveResult(result: TestResult) {
        results[currentStep] = result
        preferences.edit().putString("result_$currentStep", result.name).apply()
    }

    fun saveNote(value: String) {
        notes[currentStep] = value
        preferences.edit().putString("note_$currentStep", value).apply()
    }

    fun moveTo(index: Int) {
        currentStep = index.coerceIn(0, steps.lastIndex)
        preferences.edit().putInt("current_step", currentStep).apply()
    }

    fun buildTestReport(): String {
        val works = steps.indices.count { results[it] == TestResult.WORKS }
        val problems = steps.indices.count { results[it] == TestResult.PROBLEM }
        val untested = steps.size - works - problems
        val resultSignature = steps.indices.joinToString("|") { index ->
            "${index}:${results[index] ?: TestResult.UNTESTED}:${notes[index].orEmpty().trim()}"
        }
        val orientationAudit = selectedProject?.photos?.let { ExifBitmapLoader.auditLines(it) }.orEmpty()
        val rapidHistory = rapidDiagnosticsPreferences.getString("history", "").orEmpty()
            .lineSequence().filter { it.isNotBlank() }.toList()
        val pipelineHistory = pipelineDiagnosticsPreferences.getString("history", "").orEmpty()
            .lineSequence().filter { it.isNotBlank() }.toList()
        val fingerprint = reportFingerprint(
            "version-test",
            versionName,
            selectedProject?.id,
            resultSignature,
            orientationAudit.joinToString("|"),
            rapidHistory.joinToString("|"),
            pipelineHistory.joinToString("|"),
            featureMatchReport,
            sparseReport,
            multiViewReport,
            bundleReport,
            denseReport,
            denseFusionReport,
            surfaceMeshReport,
            textureProjectionReport,
            textureSourceAssignmentReport,
            calibrationProfile,
            calibrationReport,
            photoCalibrationTargetPreset.id,
            laserCalibrationTargetPreset.id,
            laserAnalysisHistory,
            laserPlaneReport,
            reconstructionStatus
        )

        return buildString {
            appendLine("3D Scan Studio - Version Test Report")
            appendLine("App version: $versionName")
            appendLine("Version code: ${BuildConfig.VERSION_CODE}")
            appendLine("Report fingerprint: $fingerprint")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
            appendLine("Summary: Works=$works Problems=$problems Untested=$untested")
            appendLine()

            appendLine("Diagnostic snapshot:")
            appendLine("- Current pipeline state: ${reconstructionStatus.state} | progress=${"%.1f".format(reconstructionStatus.progress * 100f)}% | ${reconstructionStatus.message}")
            if (rapidHistory.isEmpty()) {
                appendLine("- Rapid capture diagnostics: no saved Rapid runs yet")
            } else {
                appendLine("- Rapid capture diagnostics (oldest to newest, up to 12 runs):")
                rapidHistory.forEach { appendLine("  $it") }
            }
            if (pipelineHistory.isEmpty()) {
                appendLine("- Pipeline stage diagnostics: no saved stage attempts yet")
            } else {
                appendLine("- Pipeline stage diagnostics (oldest to newest, up to 40 events):")
                pipelineHistory.forEach { appendLine("  $it") }
            }
            appendLine("- Selected photo calibration target: ${photoCalibrationTargetPreset.displayName} (${photoCalibrationTargetPreset.id}) | ${photoCalibrationTargetPreset.pageWidthIn} x ${photoCalibrationTargetPreset.pageHeightIn} in | square=${photoCalibrationTargetPreset.squareSizeMm} mm | pattern=${"%.1f".format(photoCalibrationTargetPreset.patternWidthMm)} x ${"%.1f".format(photoCalibrationTargetPreset.patternHeightMm)} mm | print=${photoCalibrationTargetPreset.printSheetDescription}")
            appendLine("- Selected laser calibration background: ${laserCalibrationTargetPreset.displayName} (${laserCalibrationTargetPreset.id}) | ${laserCalibrationTargetPreset.pageWidthIn} x ${laserCalibrationTargetPreset.pageHeightIn} in | ${"%.1f".format(laserCalibrationTargetPreset.pageWidthMm)} x ${"%.1f".format(laserCalibrationTargetPreset.pageHeightMm)} mm | marker=${laserCalibrationTargetPreset.markerSizeMm} mm | print=${laserCalibrationTargetPreset.printSheetDescription}")
            if (laserAnalysisHistory.isEmpty()) {
                appendLine("- Laser analysis run history: no v0.22+ runs saved yet")
            } else {
                appendLine("- Laser analysis run history: ${laserAnalysisHistory.size} retained run(s), newest first")
                laserAnalysisHistory.take(12).forEach { run ->
                    if (run.success) {
                        appendLine(
                            "  run=${run.runId.take(8)} color=${run.laserColor.displayName} threshold=${run.threshold} " +
                                "coverage=${run.coveragePercent?.let { "%.2f".format(it) } ?: "n/a"}% " +
                                "continuity=${run.continuityPercent?.let { "%.2f".format(it) } ?: "n/a"}% " +
                                "width=${run.meanLineWidthPx?.let { "%.2f".format(it) } ?: "n/a"}px " +
                                "orientation=${run.extractionOrientation ?: "n/a"} samples=${run.sampleAxisLength ?: 0} " +
                                "ready=${run.readyForTriangulation ?: false} durationMs=${run.durationMs}"
                        )
                    } else {
                        appendLine("  run=${run.runId.take(8)} color=${run.laserColor.displayName} threshold=${run.threshold} FAILED ${run.errorType ?: "Error"}: ${run.errorMessage.orEmpty()} durationMs=${run.durationMs}")
                    }
                }
            }
            laserPlaneReport?.let { p ->
                appendLine("- Laser plane solve: engine=${p.engine} | panelAngle=${"%.2f".format(p.panelAngleDegrees)}° | leftMarkers=${p.leftMarkerIds.size} rightMarkers=${p.rightMarkerIds.size} | backdropPoints=${p.leftBackgroundStripePoints}+${p.rightBackgroundStripePoints} | meanResidual=${"%.3f".format(p.meanLaserPlaneResidualMm)} mm | triangulated=${p.triangulatedStripePoints.size} nonBackdrop=${p.nonBackdropStripePoints.size} | ready3D=${p.readyForSingleFrame3d}")
            } ?: appendLine("- Laser plane solve: no saved v0.26 result")
            calibrationProfile?.let { p ->
                appendLine("- Active camera calibration: ${p.label} | target=${PhotoCalibrationTargetPreset.fromId(p.targetPresetId).displayName} | ${p.imageWidth}x${p.imageHeight} | accepted=${p.acceptedImages} rejected=${p.rejectedImages} | RMS=${"%.4f".format(p.rmsReprojectionError)} px | fx=${"%.2f".format(p.fx)} fy=${"%.2f".format(p.fy)} cx=${"%.2f".format(p.cx)} cy=${"%.2f".format(p.cy)} | ready=${p.readyForUse}")
                appendLine("- Calibration distortion: k1=${"%.6f".format(p.k1)} k2=${"%.6f".format(p.k2)} p1=${"%.6f".format(p.p1)} p2=${"%.6f".format(p.p2)} k3=${"%.6f".format(p.k3)}")
            } ?: appendLine("- Active camera calibration: none")
            calibrationReport?.let { r ->
                appendLine("- Last calibration solve: ${r.acceptedImages}/${r.totalImages} views accepted, ${r.rejectedImages} rejected")
            }
            if (selectedProject == null) {
                appendLine("- No project selected when this report was exported.")
            } else {
                appendLine("- Project: ${selectedProject.name}")
                appendLine("- Project ID: ${selectedProject.id}")
                appendLine("- Scan mode: ${selectedProject.scanMode.displayName}")
                appendLine("- Photos currently in project: ${selectedProject.photos.size}")
                if (orientationAudit.isEmpty()) {
                    appendLine("- EXIF orientation audit: no photos available")
                } else {
                    val orientationCounts = selectedProject.photos
                        .map { ExifBitmapLoader.orientationInfo(it).label }
                        .groupingBy { it }
                        .eachCount()
                        .entries
                        .sortedBy { it.key }
                        .joinToString(", ") { "${it.key}=${it.value}" }
                    appendLine("- EXIF orientation audit summary: $orientationCounts")
                    appendLine("- EXIF orientation audit details:")
                    orientationAudit.forEach { appendLine("  $it") }
                }
                featureMatchReport?.let {
                    appendLine("- Feature matching: ${it.analyzedPhotos} photos, ${it.totalKeypoints} keypoints, ${it.strongOrUsablePairs}/${it.adjacentPairs.size} usable/strong pairs, ready=${it.readyForSparseReconstruction}")
                } ?: appendLine("- Feature matching: no saved report")
                sparseReport?.let {
                    appendLine("- Two-view sparse: best pair ${it.firstPhoto} -> ${it.secondPhoto}, ratio=${it.ratioMatches}, RANSAC=${it.ransacInliers}, pose=${it.poseInliers}, points=${it.triangulatedPoints}, readyMultiView=${it.readyForMultiView}")
                } ?: appendLine("- Two-view sparse: no saved report")
                multiViewReport?.let {
                    appendLine("- Multi-view: connected cameras=${it.connectedCameras}/${it.photosRequested}, connected pairs=${it.connectedPairs}, raw points=${it.rawTriangulatedPoints}, combined points=${it.combinedPoints}, readyBundle=${it.readyForBundleAdjustment}")
                } ?: appendLine("- Multi-view: no saved report")
                bundleReport?.let {
                    val improvement = if (it.initialRmsPixels > 0.0) ((it.initialRmsPixels - it.finalRmsPixels) / it.initialRmsPixels) * 100.0 else 0.0
                    appendLine("- Bundle refinement: cameras=${it.connectedCameras}, tracks=${it.tracksBuilt}/${it.tracksUsed}, observations=${it.observationsUsed}, refined points=${it.refinedPoints}, RMS=${"%.4f".format(it.initialRmsPixels)} -> ${"%.4f".format(it.finalRmsPixels)} px (${"%.1f".format(improvement)}% change), readyDense=${it.readyForDenseReconstruction}")
                } ?: appendLine("- Bundle refinement: no saved report")
                denseReport?.let {
                    appendLine("- Dense stereo: pair ${it.firstPhoto} -> ${it.secondPhoto}, size=${it.width}x${it.height}, pose=${it.poseInliers}, observed disparity=${"%.2f".format(it.observedDisparityLow)}..${"%.2f".format(it.observedDisparityHigh)} (median ${"%.2f".format(it.observedDisparityMedian)}), search=${it.minDisparity}..${it.minDisparity + it.numDisparities - 1}, valid disparity pixels=${it.validDisparityPixels}, sparse-guided candidates=${it.geometryGuidedPoints}, dense points=${it.densePoints}, depth=${"%.4f".format(it.minDepth)}..${"%.4f".format(it.maxDepth)} (median ${"%.4f".format(it.medianDepth)}), readyFusion=${it.readyForDenseFusion}")
                } ?: appendLine("- Dense stereo: no saved report")
                denseFusionReport?.let {
                    appendLine("- Dense fusion: connected cameras=${it.connectedCameras}, candidates=${it.candidatePairs}, pairs fused=${it.pairsFused}, raw pair points=${it.rawDensePoints}, fused points=${it.fusedPoints}, readySurface=${it.readyForSurfaceReconstruction}")
                } ?: appendLine("- Dense fusion: no saved report")
                surfaceMeshReport?.let {
                    appendLine("- Surface mesh: source points=${it.sourcePoints}, vertices=${it.meshVertices}, triangles=${it.triangles}, voxel=${"%.6f".format(it.voxelSize)}, max edge=${"%.6f".format(it.maxAcceptedEdge)}, boundary edges=${it.boundaryEdges}, closed loops before/fill/remain=${it.closedLoopsBeforeFill}/${it.filledBoundaryLoops}/${it.boundaryLoops}, hole-fill +vertices/+faces=${it.holeFillAddedVertices}/${it.holeFillAddedFaces}, skipped closed loops=${it.skippedClosedLoops}, open/branched boundary components=${it.openBoundaryChains}, boundary branch vertices=${it.boundaryBranchVertices}, non-manifold edges=${it.nonManifoldEdges}, components=${it.surfaceComponents}, smoothing=${it.smoothingIterations} pass(es)/${it.smoothedVertices} moved, avg smoothing displacement=${"%.6f".format(it.averageSmoothingDisplacement)}, vertex normals=${it.validVertexNormals}/${it.meshVertices}, candidate triangles=${it.candidateTriangles}, cleanup rejected=${it.cleanupRejectedFaces}, unused vertices removed=${it.unusedVerticesRemoved}, readyExport=${it.readyForExport}")
                } ?: appendLine("- Surface mesh: no saved report")
                textureProjectionReport?.let {
                    appendLine("- Photo color projection: mesh vertices=${it.sourceMeshVertices}, mesh faces=${it.sourceMeshFaces}, connected cameras=${it.connectedCameras}, recovered poses=${it.recoveredCameraPoses}, orientation links=${it.recoveredOrientationLinks}, bridged links=${it.bridgedOrientationLinks}, cameras used=${it.camerasUsed}, visibility-approved candidates=${it.projectedCandidates}, visibility-rejected=${it.visibilityRejectedCandidates}, colored vertices=${it.coloredVertices}, uncolored=${it.uncoloredVertices}, coverage=${"%.2f".format(it.coveragePercent)}%, avg samples=${"%.2f".format(it.averageSamplesPerColoredVertex)}, readyExport=${it.readyForExport}")
                } ?: appendLine("- Photo color projection: no saved Stage 8 report")
                textureSourceAssignmentReport?.let {
                    appendLine("- Texture source assignment: mesh faces=${it.sourceMeshFaces}, connected cameras=${it.connectedCameras}, recovered poses=${it.recoveredCameraPoses}, orientation links=${it.recoveredOrientationLinks}, bridged links=${it.bridgedOrientationLinks}, cameras used=${it.camerasUsed}, visible face candidates=${it.visibleFaceCandidates}, assigned faces=${it.assignedFaces}, unassigned=${it.unassignedFaces}, coverage=${"%.2f".format(it.faceCoveragePercent)}%, readyAtlas=${it.readyForAtlas}")
                } ?: appendLine("- Texture source assignment: no saved Stage 9 report")
                textureAtlasReport?.let {
                    appendLine("- UV texture atlas: atlas=${it.atlasWidth}x${it.atlasHeight}, islands=${it.uvIslands}, largestIsland=${it.largestIslandFaces} faces, occupancy=${"%.2f".format(it.atlasOccupancyPercent)}%, stage9 assigned=${it.stage9AssignedFaces}, textured faces=${it.texturedFaces}, untextured=${it.untexturedFaces}, coverage=${"%.2f".format(it.textureCoveragePercent)}%, source photos=${it.sourcePhotosUsed}, skipped missing/mapping=${it.skippedMissingPhotos}/${it.skippedRasterizationFaces}, readyExport=${it.readyForExport}")
                } ?: appendLine("- UV texture atlas: no saved Stage 10 report")
            }
            appendLine()

            appendLine("Version test steps:")
            steps.forEachIndexed { index, item ->
                val result = results[index] ?: TestResult.UNTESTED
                appendLine("${index + 1}. ${item.title}")
                appendLine("Status: $result")
                appendLine("What to do: ${item.action}")
                appendLine("Expected: ${item.expected}")
                val note = notes[index].orEmpty().trim()
                if (note.isNotEmpty()) {
                    appendLine(if (result == TestResult.PROBLEM) "Tester explanation: $note" else "Tester note: $note")
                }
                appendLine()
            }
        }
    }

    AlertDialog(
        onDismissRequest = onPause,
        title = {
            Column {
                Text("Test This Version", fontWeight = FontWeight.Bold)
                Text(
                    "3D Scan Studio v$versionName • ${currentStep + 1} of ${steps.size}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(step.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text("What to do", fontWeight = FontWeight.SemiBold)
                        Text(step.action)
                        Spacer(Modifier.height(10.dp))
                        Text("Expected result", fontWeight = FontWeight.SemiBold)
                        Text(step.expected)
                    }
                }

                Text("After you try it, reopen the guide and mark the result:", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val result = results[currentStep] ?: TestResult.UNTESTED
                    if (result == TestResult.WORKS) {
                        Button(onClick = { saveResult(TestResult.WORKS) }) { Text("✓ Works") }
                    } else {
                        FilledTonalButton(onClick = { saveResult(TestResult.WORKS) }) { Text("✓ Works") }
                    }
                    if (result == TestResult.PROBLEM) {
                        Button(onClick = { saveResult(TestResult.PROBLEM) }) { Text("! Problem") }
                    } else {
                        OutlinedButton(onClick = { saveResult(TestResult.PROBLEM) }) { Text("! Problem") }
                    }
                }

                val currentResult = results[currentStep] ?: TestResult.UNTESTED
                if (currentResult != TestResult.UNTESTED) {
                    OutlinedTextField(
                        value = notes[currentStep].orEmpty(),
                        onValueChange = ::saveNote,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(if (currentResult == TestResult.PROBLEM) "What happened?" else "Note (optional)") },
                        placeholder = {
                            Text(
                                if (currentResult == TestResult.PROBLEM)
                                    "Describe what you tapped, what you expected, and what actually happened."
                                else
                                    "Add anything useful you noticed even though the test worked."
                            )
                        },
                        minLines = if (currentResult == TestResult.PROBLEM) 3 else 2
                    )
                    Text("Your note is saved automatically.", style = MaterialTheme.typography.bodySmall)
                }

                if (complete) {
                    val works = steps.indices.count { results[it] == TestResult.WORKS }
                    val problems = steps.indices.count { results[it] == TestResult.PROBLEM }
                    val untested = steps.size - works - problems
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Test summary", fontWeight = FontWeight.Bold)
                            Text("Works: $works   Problems: $problems   Untested: $untested")
                            Spacer(Modifier.height(8.dp))
                            FilledTonalButton(
                                onClick = {
                                    pendingExportText = buildTestReport()
                                    exportLauncher.launch("3D_Scan_Studio_v${versionName}_test_report.txt")
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Export test report")
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Upload that text file to ChatGPT when a test fails. It includes your problem explanations and all test statuses.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (complete) {
                Button(onClick = onFinish) { Text("Finish guide") }
            } else {
                Button(onClick = { moveTo(currentStep + 1) }) { Text("Next") }
            }
        },
        dismissButton = {
            Row {
                if (currentStep > 0) {
                    TextButton(onClick = { moveTo(currentStep - 1) }) { Text("Back") }
                }
                TextButton(onClick = onPause) { Text("Test now") }
            }
        }
    )
}
