package com.photogrammetrystudio.app.util

import org.opencv.calib3d.Calib3d
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point

/**
 * v0.26 shared calibrated camera geometry.
 *
 * ORB descriptors still run on the original pixels. Geometry stages call this helper so measured
 * distortion is removed from feature coordinates before epipolar/pose calculations, while dense
 * stages can rectify the original raster using the same measured camera model.
 */
object OpenCvCalibrationGeometry {
    data class Model(
        val k: Mat,
        val dist: Mat,
        val calibrated: Boolean,
        val distortionApplied: Boolean,
        val rotatedProfile: Boolean,
        val tangentialSuppressedForRotation: Boolean,
        val fx: Double,
        val fy: Double,
        val cx: Double,
        val cy: Double,
        val k1: Double,
        val k2: Double,
        val p1: Double,
        val p2: Double,
        val k3: Double
    ) : AutoCloseable {
        override fun close() {
            k.release()
            dist.release()
        }
    }

    fun model(width: Int, height: Int, fallbackFocal: Double): Model {
        val intr = CameraCalibrationManager.intrinsicsFor(width, height)
        val d = CameraCalibrationManager.distortionFor(width, height)
        val fx = intr?.fx ?: fallbackFocal
        val fy = intr?.fy ?: fallbackFocal
        val cx = intr?.cx ?: width / 2.0
        val cy = intr?.cy ?: height / 2.0
        val k = Mat.eye(3, 3, CvType.CV_64F).apply {
            put(0, 0, fx); put(1, 1, fy); put(0, 2, cx); put(1, 2, cy)
        }
        val dist = Mat.zeros(5, 1, CvType.CV_64F)
        if (d != null) {
            dist.put(0, 0, d.k1)
            dist.put(1, 0, d.k2)
            dist.put(2, 0, d.p1)
            dist.put(3, 0, d.p2)
            dist.put(4, 0, d.k3)
        }
        return Model(
            k = k,
            dist = dist,
            calibrated = intr != null,
            distortionApplied = d != null,
            rotatedProfile = intr?.rotatedProfile == true,
            tangentialSuppressedForRotation = d?.tangentialSuppressedForRotation == true,
            fx = fx, fy = fy, cx = cx, cy = cy,
            k1 = d?.k1 ?: 0.0, k2 = d?.k2 ?: 0.0, p1 = d?.p1 ?: 0.0,
            p2 = d?.p2 ?: 0.0, k3 = d?.k3 ?: 0.0
        )
    }

    /** Returns undistorted pixel coordinates in the same K coordinate system. */
    fun undistortPixelPoints(points: MatOfPoint2f, model: Model): MatOfPoint2f {
        if (!model.distortionApplied || points.empty()) {
            return MatOfPoint2f(*points.toArray())
        }
        val out = MatOfPoint2f()
        val identity = Mat.eye(3, 3, CvType.CV_64F)
        try {
            Calib3d.undistortPoints(points, out, model.k, model.dist, identity, model.k)
        } finally {
            identity.release()
        }
        return out
    }

    /** Converts one raw/distorted pixel into a normalized camera ray. */
    fun normalizedRay(u: Double, v: Double, model: Model): DoubleArray {
        if (!model.distortionApplied) {
            return doubleArrayOf((u - model.cx) / model.fx, (v - model.cy) / model.fy, 1.0)
        }
        val src = MatOfPoint2f(Point(u, v))
        val dst = MatOfPoint2f()
        try {
            Calib3d.undistortPoints(src, dst, model.k, model.dist)
            val p = dst.toArray().firstOrNull() ?: Point((u - model.cx) / model.fx, (v - model.cy) / model.fy)
            return doubleArrayOf(p.x, p.y, 1.0)
        } finally {
            src.release(); dst.release()
        }
    }

    /** Projects a camera-space point into the original (distorted) source raster. */
    fun projectToSource(x: Double, y: Double, z: Double, model: Model): Point? {
        if (!z.isFinite() || z <= 1e-9) return null
        var xn = x / z
        var yn = y / z
        if (!xn.isFinite() || !yn.isFinite()) return null
        if (model.distortionApplied) {
            val r2 = xn * xn + yn * yn
            val radial = 1.0 + model.k1 * r2 + model.k2 * r2 * r2 + model.k3 * r2 * r2 * r2
            val x0 = xn
            val y0 = yn
            xn = x0 * radial + 2.0 * model.p1 * x0 * y0 + model.p2 * (r2 + 2.0 * x0 * x0)
            yn = y0 * radial + model.p1 * (r2 + 2.0 * y0 * y0) + 2.0 * model.p2 * x0 * y0
        }
        return Point(model.fx * xn + model.cx, model.fy * yn + model.cy)
    }

    fun status(model: Model): String = when {
        !model.calibrated -> "No compatible camera calibration; fallback pinhole geometry"
        model.tangentialSuppressedForRotation -> "Calibrated radial distortion active; p1/p2 suppressed for rotated-profile compatibility"
        model.distortionApplied -> "Full calibrated distortion active (k1/k2/p1/p2/k3)"
        else -> "Calibrated intrinsics active; distortion unavailable"
    }
}
