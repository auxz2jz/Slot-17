package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.photogrammetrystudio.app.model.LaserCalibrationTargetPreset
import com.photogrammetrystudio.app.model.LaserLineReport
import com.photogrammetrystudio.app.model.LaserPlane3D
import com.photogrammetrystudio.app.model.LaserPlaneCalibrationReport
import com.photogrammetrystudio.app.model.SparsePoint
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.MatOfPoint2f
import org.opencv.core.MatOfPoint3f
import org.opencv.core.Point
import org.opencv.core.Point3
import org.opencv.imgproc.Imgproc
import org.opencv.objdetect.ArucoDetector
import org.opencv.objdetect.Objdetect
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.26 laser-calibration milestone.
 *
 * Detects the known DICT_4X4_50 markers on the two 90-degree calibration sheets, estimates each
 * physical sheet plane using the calibrated camera, uses the already-extracted laser stripe where
 * it crosses those known planes to fit the instantaneous hand-swept laser plane, then triangulates
 * the entire detected stripe for this one frame. Coordinates are metric millimeters because the
 * printed marker size is known.
 */
object LaserPlaneCalibrator {
    data class Result(
        val report: LaserPlaneCalibrationReport,
        val previewPng: ByteArray,
        val plyBytes: ByteArray
    )

    private data class MarkerObservation(val id: Int, val corners: Array<Point>)
    private data class ImageRegion(val minX: Double, val minY: Double, val maxX: Double, val maxY: Double) {
        fun contains(x: Double, y: Double): Boolean = x in minX..maxX && y in minY..maxY
    }

    @Volatile private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    fun calibrateAndTriangulate(
        laserOff: File,
        laserOn: File,
        line: LaserLineReport,
        target: LaserCalibrationTargetPreset,
        maxImageSide: Int = 1280
    ): kotlin.Result<Result> = runCatching {
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }
        require(line.points.isNotEmpty()) { "Analyze the laser line before solving the laser plane." }
        val off0 = ExifBitmapLoader.decodeScaledRaw(laserOff, maxImageSide)
            ?: error("Could not decode laser-OFF image")
        val on0 = ExifBitmapLoader.decodeScaledRaw(laserOn, maxImageSide)
            ?: run { off0.recycle(); error("Could not decode laser-ON image") }

        val width = line.imageWidth
        val height = line.imageHeight
        val off = if (off0.width == width && off0.height == height) off0 else {
            Bitmap.createScaledBitmap(off0, width, height, true).also { off0.recycle() }
        }
        val on = if (on0.width == width && on0.height == height) on0 else {
            Bitmap.createScaledBitmap(on0, width, height, true).also { on0.recycle() }
        }

        val model = OpenCvCalibrationGeometry.model(width, height, max(width, height) * 0.9)
        require(model.calibrated) {
            "A compatible active camera calibration profile is required before laser-plane calibration."
        }

        val rgba = Mat(); val gray = Mat(); val ids = Mat()
        val corners = mutableListOf<Mat>()
        val detector = ArucoDetector(Objdetect.getPredefinedDictionary(Objdetect.DICT_4X4_50))
        try {
            Utils.bitmapToMat(off, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            detector.detectMarkers(gray, corners, ids)
            val observations = decodeMarkers(corners, ids)
            val expected = expectedIds(target)
            val leftObs = observations.filter { it.id in expected.first }
            val rightObs = observations.filter { it.id in expected.second }
            require(leftObs.isNotEmpty() && rightObs.isNotEmpty()) {
                "Could not detect at least one expected marker on both LEFT and RIGHT calibration panels. Detected IDs: ${observations.map { it.id }.sorted()}"
            }

            require(leftObs.size >= 2 && rightObs.size >= 2) {
                "For a stable panel pose, detect at least two expected markers on each panel (LEFT ${leftObs.size}, RIGHT ${rightObs.size}). Detected IDs: ${observations.map { it.id }.sorted()}"
            }
            val layouts = markerCentersMm(target)
            val leftPlane = panelPlane(leftObs, layouts.first, target.markerSizeMm, model)
                ?: error("LEFT panel multi-marker pose solve failed.")
            val rightPlane = panelPlane(rightObs, layouts.second, target.markerSizeMm, model)
                ?: error("RIGHT panel multi-marker pose solve failed.")
            val angle = panelAngleDegrees(leftPlane, rightPlane)

            val leftRegion = markerRegion(leftObs, width, height)
            val rightRegion = markerRegion(rightObs, width, height)
            val leftBackground = mutableListOf<SparsePoint>()
            val rightBackground = mutableListOf<SparsePoint>()
            val usedPixels = HashSet<Int>()

            line.points.forEachIndexed { index, p ->
                val inLeft = leftRegion?.contains(p.x, p.row.toDouble()) == true
                val inRight = rightRegion?.contains(p.x, p.row.toDouble()) == true
                if (!inLeft && !inRight) return@forEachIndexed
                val ray = OpenCvCalibrationGeometry.normalizedRay(p.x, p.row.toDouble(), model)
                val leftHit = if (inLeft) intersectRayPlane(ray, leftPlane) else null
                val rightHit = if (inRight) intersectRayPlane(ray, rightPlane) else null
                val chosen = when {
                    leftHit != null && rightHit != null -> if (norm(leftHit) <= norm(rightHit)) leftHit to true else rightHit to false
                    leftHit != null -> leftHit to true
                    rightHit != null -> rightHit to false
                    else -> null
                }
                chosen?.let { (hit, isLeft) ->
                    if (isLeft) leftBackground += hit else rightBackground += hit
                    usedPixels += index
                }
            }

            require(leftBackground.size >= 6 && rightBackground.size >= 6) {
                "Laser stripe did not provide enough backdrop points on both panels (LEFT ${leftBackground.size}, RIGHT ${rightBackground.size}). Sweep the line across both calibration sheets."
            }
            val fitPoints = leftBackground + rightBackground
            val laserPlane = fitPlane(fitPoints) ?: error("Could not fit an instantaneous laser plane from the backdrop stripe.")
            val residual = fitPoints.map { abs(planeValue(laserPlane, it)) }.average()

            val all3d = mutableListOf<SparsePoint>()
            val nonBackdrop = mutableListOf<SparsePoint>()
            line.points.forEachIndexed { index, p ->
                val ray = OpenCvCalibrationGeometry.normalizedRay(p.x, p.row.toDouble(), model)
                val hit = intersectRayPlane(ray, laserPlane) ?: return@forEachIndexed
                val distance = norm(hit)
                if (!distance.isFinite() || distance < 20.0 || distance > 10000.0) return@forEachIndexed
                all3d += hit
                if (index !in usedPixels) nonBackdrop += hit
            }

            val warnings = mutableListOf<String>()
            warnings += OpenCvCalibrationGeometry.status(model)
            if (abs(angle - 90.0) > 8.0) {
                warnings += "Detected LEFT/RIGHT panel angle is ${"%.2f".format(angle)}°, which is far from the expected 90°. Check the physical corner and marker visibility."
            }
            if (residual > 3.0) {
                warnings += "Laser-plane fit residual is ${"%.2f".format(residual)} mm. A thinner/steadier stripe or less glare should improve the fit."
            }
            if (nonBackdrop.isEmpty()) {
                warnings += "No non-backdrop stripe points were isolated in this frame. This is normal for a calibration-only image; place an object in front of the corner for object points."
            }
            warnings += "v0.26 triangulates one analyzed frame. Multi-frame hand-sweep accumulation/alignment is the next laser milestone."

            val ready = fitPoints.size >= 20 && all3d.size >= 30 && abs(angle - 90.0) <= 12.0 && residual <= 6.0
            val report = LaserPlaneCalibrationReport(
                engine = "ArUco 4x4_50 backdrop pose + instantaneous laser-plane fit v0.26.0",
                targetPresetId = target.id,
                imageWidth = width,
                imageHeight = height,
                detectedMarkerIds = observations.map { it.id }.sorted(),
                leftMarkerIds = leftObs.map { it.id }.sorted(),
                rightMarkerIds = rightObs.map { it.id }.sorted(),
                leftPlane = leftPlane,
                rightPlane = rightPlane,
                panelAngleDegrees = angle,
                leftBackgroundStripePoints = leftBackground.size,
                rightBackgroundStripePoints = rightBackground.size,
                fittedLaserPoints = fitPoints.size,
                laserPlane = laserPlane,
                meanLaserPlaneResidualMm = residual,
                triangulatedStripePoints = all3d,
                nonBackdropStripePoints = nonBackdrop,
                warnings = warnings,
                readyForSingleFrame3d = ready
            )
            val preview = drawPreview(on, observations, expected.first, expected.second, line, usedPixels)
            val png = ByteArrayOutputStream().use { stream ->
                preview.compress(Bitmap.CompressFormat.PNG, 100, stream)
                stream.toByteArray()
            }
            val ply = plyBytes(all3d)
            if (preview !== on) preview.recycle()
            Result(report, png, ply)
        } finally {
            corners.forEach { it.release() }
            ids.release(); rgba.release(); gray.release(); detector.clear(); model.close()
            off.recycle(); on.recycle()
        }
    }

    private fun expectedIds(target: LaserCalibrationTargetPreset): Pair<Set<Int>, Set<Int>> = when (target) {
        LaserCalibrationTargetPreset.US_LETTER -> setOf(20, 21, 22, 23) to setOf(30, 31, 32, 33)
        LaserCalibrationTargetPreset.US_LEGAL -> (24..29).toSet() to (34..39).toSet()
        LaserCalibrationTargetPreset.US_LEDGER -> setOf(40, 41, 42, 43, 48) to setOf(44, 45, 46, 47, 49)
        LaserCalibrationTargetPreset.POSTER_12X18,
        LaserCalibrationTargetPreset.TILED_12X18_ON_LETTER -> (0..5).toSet() to (10..15).toSet()
    }

    private fun decodeMarkers(corners: List<Mat>, ids: Mat): List<MarkerObservation> {
        if (ids.empty()) return emptyList()
        val out = mutableListOf<MarkerObservation>()
        for (i in 0 until min(ids.rows(), corners.size)) {
            val id = ids.get(i, 0)?.getOrNull(0)?.toInt() ?: continue
            val mat = corners[i]
            val points = ArrayList<Point>(4)
            if (mat.rows() == 1) {
                for (j in 0 until min(4, mat.cols())) {
                    val v = mat.get(0, j) ?: continue
                    if (v.size >= 2) points += Point(v[0], v[1])
                }
            } else {
                for (j in 0 until min(4, mat.rows())) {
                    val v = mat.get(j, 0) ?: continue
                    if (v.size >= 2) points += Point(v[0], v[1])
                }
            }
            if (points.size == 4) out += MarkerObservation(id, points.toTypedArray())
        }
        return out
    }

    /**
     * Estimate one whole printed panel from all detected marker corners at once. This is much more
     * stable than averaging independent single-marker poses because the known spacing between
     * markers constrains the panel orientation and translation as one rigid sheet.
     */
    private fun panelPlane(
        markers: List<MarkerObservation>,
        centersMm: Map<Int, Point>,
        markerSizeMm: Double,
        model: OpenCvCalibrationGeometry.Model
    ): LaserPlane3D? {
        val half = markerSizeMm / 2.0
        val objectCorners = mutableListOf<Point3>()
        val imageCorners = mutableListOf<Point>()
        markers.forEach { marker ->
            val center = centersMm[marker.id] ?: return@forEach
            // Detector order: top-left, top-right, bottom-right, bottom-left.
            objectCorners += Point3(center.x - half, center.y - half, 0.0)
            objectCorners += Point3(center.x + half, center.y - half, 0.0)
            objectCorners += Point3(center.x + half, center.y + half, 0.0)
            objectCorners += Point3(center.x - half, center.y + half, 0.0)
            imageCorners += marker.corners
        }
        if (objectCorners.size < 8 || imageCorners.size != objectCorners.size) return null
        val objectPoints = MatOfPoint3f(*objectCorners.toTypedArray())
        val imagePoints = MatOfPoint2f(*imageCorners.toTypedArray())
        val distCoeffs = MatOfDouble(model.k1, model.k2, model.p1, model.p2, model.k3)
        val rvec = Mat(); val tvec = Mat(); val r = Mat()
        return try {
            val ok = Calib3d.solvePnP(
                objectPoints, imagePoints, model.k, distCoeffs,
                rvec, tvec, false, Calib3d.SOLVEPNP_ITERATIVE
            )
            if (!ok) return null
            Calib3d.Rodrigues(rvec, r)
            var nx = r.get(0, 2)?.getOrNull(0) ?: return null
            var ny = r.get(1, 2)?.getOrNull(0) ?: return null
            var nz = r.get(2, 2)?.getOrNull(0) ?: return null
            val nlen = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-12)
            nx /= nlen; ny /= nlen; nz /= nlen
            val tx = tvec.get(0, 0)?.getOrNull(0) ?: return null
            val ty = tvec.get(1, 0)?.getOrNull(0) ?: return null
            val tz = tvec.get(2, 0)?.getOrNull(0) ?: return null
            LaserPlane3D(nx, ny, nz, -(nx * tx + ny * ty + nz * tz))
        } finally {
            objectPoints.release(); imagePoints.release(); distCoeffs.release(); rvec.release(); tvec.release(); r.release()
        }
    }

    /** Physical marker-center positions in millimeters on the printed sheets. */
    private fun markerCentersMm(target: LaserCalibrationTargetPreset): Pair<Map<Int, Point>, Map<Int, Point>> = when (target) {
        LaserCalibrationTargetPreset.US_LETTER -> {
            mapOf(
                20 to Point(30.0, 69.0), 21 to Point(146.0, 69.0),
                22 to Point(30.0, 169.0), 23 to Point(146.0, 169.0)
            ) to mapOf(
                30 to Point(52.0, 69.0), 31 to Point(186.0, 69.0),
                32 to Point(52.0, 169.0), 33 to Point(186.0, 169.0)
            )
        }
        LaserCalibrationTargetPreset.US_LEGAL -> {
            mapOf(
                24 to Point(30.0, 69.0), 25 to Point(146.0, 69.0),
                26 to Point(30.0, 164.0), 27 to Point(146.0, 164.0),
                28 to Point(30.0, 259.0), 29 to Point(146.0, 259.0)
            ) to mapOf(
                34 to Point(52.0, 69.0), 35 to Point(186.0, 69.0),
                36 to Point(52.0, 164.0), 37 to Point(186.0, 164.0),
                38 to Point(52.0, 259.0), 39 to Point(186.0, 259.0)
            )
        }
        LaserCalibrationTargetPreset.US_LEDGER -> {
            mapOf(
                40 to Point(40.0, 78.0), 41 to Point(179.0, 78.0),
                42 to Point(40.0, 212.0), 43 to Point(179.0, 212.0),
                48 to Point(109.5, 346.0)
            ) to mapOf(
                44 to Point(68.0, 78.0), 45 to Point(207.0, 78.0),
                46 to Point(68.0, 212.0), 47 to Point(207.0, 212.0),
                49 to Point(137.5, 346.0)
            )
        }
        LaserCalibrationTargetPreset.POSTER_12X18,
        LaserCalibrationTargetPreset.TILED_12X18_ON_LETTER -> {
            mapOf(
                0 to Point(53.5, 89.5), 1 to Point(162.5, 89.5),
                2 to Point(53.5, 222.5), 3 to Point(162.5, 222.5),
                4 to Point(53.5, 355.5), 5 to Point(162.5, 355.5)
            ) to mapOf(
                10 to Point(251.25, 89.5), 11 to Point(142.25, 89.5),
                12 to Point(251.25, 222.5), 13 to Point(142.25, 222.5),
                14 to Point(251.25, 355.5), 15 to Point(142.25, 355.5)
            )
        }
    }

    private fun panelAngleDegrees(a: LaserPlane3D, b: LaserPlane3D): Double {
        val dot = abs(a.nx * b.nx + a.ny * b.ny + a.nz * b.nz).coerceIn(0.0, 1.0)
        return Math.toDegrees(acos(dot))
    }

    private fun markerRegion(markers: List<MarkerObservation>, width: Int, height: Int): ImageRegion? {
        if (markers.isEmpty()) return null
        val xs = markers.flatMap { it.corners.map { p -> p.x } }
        val ys = markers.flatMap { it.corners.map { p -> p.y } }
        val minX0 = xs.minOrNull() ?: return null; val maxX0 = xs.maxOrNull() ?: return null
        val minY0 = ys.minOrNull() ?: return null; val maxY0 = ys.maxOrNull() ?: return null
        val spanX = max(40.0, maxX0 - minX0); val spanY = max(40.0, maxY0 - minY0)
        val ex = spanX * 0.30; val ey = spanY * 0.35
        return ImageRegion(max(0.0, minX0 - ex), max(0.0, minY0 - ey), min(width - 1.0, maxX0 + ex), min(height - 1.0, maxY0 + ey))
    }

    private fun intersectRayPlane(ray: DoubleArray, plane: LaserPlane3D): SparsePoint? {
        val denom = plane.nx * ray[0] + plane.ny * ray[1] + plane.nz * ray[2]
        if (abs(denom) < 1e-9) return null
        val t = -plane.d / denom
        if (!t.isFinite() || t <= 0.0) return null
        return SparsePoint(ray[0] * t, ray[1] * t, ray[2] * t)
    }

    private fun fitPlane(points: List<SparsePoint>): LaserPlane3D? {
        if (points.size < 3) return null
        val cx = points.sumOf { it.x } / points.size
        val cy = points.sumOf { it.y } / points.size
        val cz = points.sumOf { it.z } / points.size
        val cov = Mat.zeros(3, 3, CvType.CV_64F)
        val vals = DoubleArray(9)
        points.forEach { p ->
            val x = p.x - cx; val y = p.y - cy; val z = p.z - cz
            vals[0] += x*x; vals[1] += x*y; vals[2] += x*z
            vals[3] += y*x; vals[4] += y*y; vals[5] += y*z
            vals[6] += z*x; vals[7] += z*y; vals[8] += z*z
        }
        for (r in 0..2) for (c in 0..2) cov.put(r, c, vals[r*3+c] / points.size)
        val eigenValues = Mat(); val eigenVectors = Mat()
        return try {
            if (!Core.eigen(cov, eigenValues, eigenVectors)) return null
            val row = eigenVectors.rows() - 1
            var nx = eigenVectors.get(row, 0)?.getOrNull(0) ?: return null
            var ny = eigenVectors.get(row, 1)?.getOrNull(0) ?: return null
            var nz = eigenVectors.get(row, 2)?.getOrNull(0) ?: return null
            val n = sqrt(nx*nx + ny*ny + nz*nz).coerceAtLeast(1e-12)
            nx/=n; ny/=n; nz/=n
            LaserPlane3D(nx, ny, nz, -(nx*cx + ny*cy + nz*cz))
        } finally { cov.release(); eigenValues.release(); eigenVectors.release() }
    }

    private fun planeValue(p: LaserPlane3D, x: SparsePoint): Double = p.nx*x.x + p.ny*x.y + p.nz*x.z + p.d
    private fun norm(p: SparsePoint): Double = sqrt(p.x*p.x + p.y*p.y + p.z*p.z)

    private fun drawPreview(
        source: Bitmap,
        observations: List<MarkerObservation>,
        leftIds: Set<Int>,
        rightIds: Set<Int>,
        line: LaserLineReport,
        backdropPointIndices: Set<Int>
    ): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = max(2f, source.width/400f) }
        observations.forEach { obs ->
            markerPaint.color = when (obs.id) {
                in leftIds -> Color.GREEN
                in rightIds -> Color.MAGENTA
                else -> Color.GRAY
            }
            for (i in 0..3) {
                val a = obs.corners[i]; val b = obs.corners[(i+1)%4]
                canvas.drawLine(a.x.toFloat(), a.y.toFloat(), b.x.toFloat(), b.y.toFloat(), markerPaint)
            }
        }
        val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; strokeWidth = 2f }
        line.points.forEachIndexed { index, p ->
            pointPaint.color = if (index in backdropPointIndices) Color.YELLOW else Color.CYAN
            canvas.drawCircle(p.x.toFloat(), p.row.toFloat(), max(1.5f, source.width/700f), pointPaint)
        }
        return out
    }

    private fun plyBytes(points: List<SparsePoint>): ByteArray {
        val text = buildString {
            appendLine("ply")
            appendLine("format ascii 1.0")
            appendLine("comment 3D Scan Studio v0.26 single-frame laser triangulation; units millimeters")
            appendLine("element vertex ${points.size}")
            appendLine("property float x")
            appendLine("property float y")
            appendLine("property float z")
            appendLine("end_header")
            points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
        }
        return text.toByteArray(Charsets.UTF_8)
    }
}
