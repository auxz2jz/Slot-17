package com.photogrammetrystudio.app.engine

import com.photogrammetrystudio.app.model.PhotoProject

interface PhotogrammetryEngine {
    val name: String
    fun isAvailable(): Boolean
    suspend fun reconstruct(project: PhotoProject, onProgress: (Float, String) -> Unit): Result<String>
}

/**
 * v0.1 deliberately does not pretend that native photogrammetry is already integrated.
 * This adapter is the stable seam where an Android/NDK engine can be added next.
 */
class LocalNativeEngineStub : PhotogrammetryEngine {
    override val name: String = "Local native engine"

    override fun isAvailable(): Boolean = false

    override suspend fun reconstruct(
        project: PhotoProject,
        onProgress: (Float, String) -> Unit
    ): Result<String> = Result.failure(
        IllegalStateException(
            "No Android-native reconstruction engine is bundled in v0.1. Photo capture/import and project storage are ready for engine integration."
        )
    )
}
