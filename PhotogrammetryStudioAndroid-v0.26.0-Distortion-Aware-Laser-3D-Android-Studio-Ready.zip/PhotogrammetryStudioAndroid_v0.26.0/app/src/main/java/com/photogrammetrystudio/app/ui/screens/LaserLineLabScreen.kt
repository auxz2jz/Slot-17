package com.photogrammetrystudio.app.ui.screens

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.photogrammetrystudio.app.model.LaserLineColor
import com.photogrammetrystudio.app.model.LaserCalibrationTargetPreset
import com.photogrammetrystudio.app.model.LaserCalibrationPanelSide
import com.photogrammetrystudio.app.model.LaserLineReport
import com.photogrammetrystudio.app.model.LaserAnalysisRun
import com.photogrammetrystudio.app.model.LaserPlaneCalibrationReport
import com.photogrammetrystudio.app.model.PhotoProject
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LaserLineLabScreen(
    project: PhotoProject?,
    laserOffFile: File?,
    laserOnFile: File?,
    report: LaserLineReport?,
    planeReport: LaserPlaneCalibrationReport?,
    analysisHistory: List<LaserAnalysisRun>,
    status: String,
    targetPreset: LaserCalibrationTargetPreset,
    onBack: () -> Unit,
    onImportLaserOff: (android.net.Uri) -> Unit,
    onImportLaserOn: (android.net.Uri) -> Unit,
    onAnalyze: (LaserLineColor, Int) -> Unit,
    onCalibrateLaserPlane: () -> Unit,
    onTargetPresetChange: (LaserCalibrationTargetPreset) -> Unit,
    onTargetPdf: (LaserCalibrationTargetPreset, LaserCalibrationPanelSide) -> ByteArray,
    onPrintInstructionsPdf: () -> ByteArray,
    onTiledInstructionsPdf: () -> ByteArray,
    onPreviewPng: () -> ByteArray?,
    onHistoryJsonl: () -> ByteArray?,
    onReportText: () -> String?,
    onPlanePreviewPng: () -> ByteArray?,
    onPlanePly: () -> ByteArray?,
    onPlaneReportText: () -> String?,
    onOpenTestGuide: () -> Unit
) {
    val context = LocalContext.current
    var color by remember { mutableStateOf(LaserLineColor.RED) }
    var threshold by remember { mutableIntStateOf(28) }
    var pendingTargetPreset by remember { mutableStateOf(targetPreset) }
    var pendingPanelSide by remember { mutableStateOf(LaserCalibrationPanelSide.LEFT) }

    val offLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onImportLaserOff(uri)
    }
    val onLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onImportLaserOn(uri)
    }
    val targetExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use {
                it.write(onTargetPdf(pendingTargetPreset, pendingPanelSide))
            }
        }
    }
    val instructionsExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(onPrintInstructionsPdf()) }
        }
    }

    val tiledInstructionsExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(onTiledInstructionsPdf()) }
        }
    }

    val previewExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) onPreviewPng()?.let { bytes ->
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
        }
    }
    val historyExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) onHistoryJsonl()?.let { bytes ->
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
        }
    }
    val reportExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) onReportText()?.let { text ->
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) } }
        }
    }

    val planePreviewExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) onPlanePreviewPng()?.let { bytes ->
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
        }
    }
    val planePlyExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) onPlanePly()?.let { bytes ->
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
        }
    }
    val planeReportExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) onPlaneReportText()?.let { text ->
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) } }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Laser Line Lab") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = onOpenTestGuide) { Icon(Icons.Default.HelpOutline, contentDescription = "Test this version") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(project?.name ?: "Laser project", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("v0.26 keeps the threshold-history workflow and adds the first metric laser 3D stage: detect the known calibration markers, verify the LEFT/RIGHT corner, fit the instantaneous hand-swept laser plane, and triangulate the current stripe into millimeter coordinates.")
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Laser calibration background", fontWeight = FontWeight.SemiBold)
                    Text("Choose the physical LEFT/RIGHT background you can print. Letter, Legal, Ledger, and single-sheet 12×18 remain available. The pin-align 12×18 preset reproduces the exact same 12×18 / 35 mm-marker geometry from four ordinary Letter sheets per panel. Matching sacrificial crosshairs are pinned together before the overlapped seams are straight-cut and butted edge-to-edge.", style = MaterialTheme.typography.bodySmall)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        LaserCalibrationTargetPreset.entries.chunked(2).forEach { options ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                options.forEach { option ->
                                    FilterChip(
                                        modifier = Modifier.weight(1f),
                                        selected = targetPreset == option,
                                        onClick = { onTargetPresetChange(option) },
                                        label = { Text(option.displayName) }
                                    )
                                }
                                if (options.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    Text("Selected: ${targetPreset.displayName} • ${targetPreset.printClassLabel}", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "Panel: ${targetPreset.pageWidthIn} × ${targetPreset.pageHeightIn} in (${"%.1f".format(targetPreset.pageWidthMm)} × ${"%.1f".format(targetPreset.pageHeightMm)} mm) • marker size ${targetPreset.markerSizeMm} mm • ${targetPreset.printSheetDescription}.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (targetPreset.printSheetCountPerPanel > 1) {
                        Text("Pin-align preset: each LEFT/RIGHT export is a 4-page Letter PDF labeled A1, A2, B1, B2. Match/pin the registration crosshairs, straight-cut both overlapped layers through the pin centers, remove the excess, and butt the fresh edges together. The crosshair tabs are outside the final calibration artwork and are discarded.", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                pendingTargetPreset = targetPreset
                                pendingPanelSide = LaserCalibrationPanelSide.LEFT
                                targetExport.launch(targetPreset.leftFileName)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Export LEFT") }
                        OutlinedButton(
                            onClick = {
                                pendingTargetPreset = targetPreset
                                pendingPanelSide = LaserCalibrationPanelSide.RIGHT
                                targetExport.launch(targetPreset.rightFileName)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Export RIGHT") }
                    }
                    OutlinedButton(
                        onClick = { instructionsExport.launch("3D_Scan_Studio_Calibration_Print_Instructions.pdf") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Export print-shop instructions") }
                    OutlinedButton(
                        onClick = { tiledInstructionsExport.launch("3D_Scan_Studio_Tiled_Calibration_Instructions.pdf") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Export tiled / poster-board assembly instructions") }
                    Text("v0.26 uses the selected target's ArUco IDs and physical marker size for metric backdrop pose and laser-plane recovery.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1 — Matched frame pair", fontWeight = FontWeight.SemiBold)
                    Text("Keep the camera and object completely still. Capture/import one frame with the laser OFF and then the same view with the laser ON.", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { offLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Import laser OFF") }
                        OutlinedButton(onClick = { onLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Import laser ON") }
                    }
                    Text("OFF: ${laserOffFile?.name ?: "not imported"}", style = MaterialTheme.typography.bodySmall)
                    Text("ON: ${laserOnFile?.name ?: "not imported"}", style = MaterialTheme.typography.bodySmall)
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("2 — Laser extraction", fontWeight = FontWeight.SemiBold)
                    Text("Laser color")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        LaserLineColor.entries.forEach { option ->
                            FilterChip(selected = color == option, onClick = { color = option }, label = { Text(option.displayName) })
                        }
                    }
                    Text("Signal threshold: $threshold")
                    Slider(
                        value = threshold.toFloat(),
                        onValueChange = { threshold = it.toInt().coerceIn(8, 120) },
                        valueRange = 8f..120f
                    )
                    Button(
                        onClick = { onAnalyze(color, threshold) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = laserOffFile != null && laserOnFile != null
                    ) { Text("Analyze laser line") }
                    Text(status, style = MaterialTheme.typography.bodySmall)
                    Text("Diagnostic rule: each Analyze press appends one run; changing the threshold slider alone does not append a run.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("3 — Backdrop solve + single-frame 3D", fontWeight = FontWeight.SemiBold)
                    Text(
                        "After a clean 2D stripe run, detect the known LEFT/RIGHT markers, verify the physical 90° corner, fit the instantaneous hand-swept laser plane from the stripe on the calibration sheets, then triangulate the full stripe in millimeters.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = onCalibrateLaserPlane,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = report?.readyForTriangulation == true
                    ) { Text("Solve laser plane + build 3D stripe") }
                    if (planeReport != null) {
                        Text("Panel angle: ${"%.2f".format(planeReport.panelAngleDegrees)}°")
                        Text("Markers: LEFT ${planeReport.leftMarkerIds.size} • RIGHT ${planeReport.rightMarkerIds.size}")
                        Text("Backdrop fit points: ${planeReport.fittedLaserPoints}")
                        Text("Mean laser-plane residual: ${"%.2f".format(planeReport.meanLaserPlaneResidualMm)} mm")
                        Text("Triangulated stripe points: ${planeReport.triangulatedStripePoints.size}")
                        Text("Non-backdrop stripe points: ${planeReport.nonBackdropStripePoints.size}")
                        Text("Ready for single-frame 3D: ${planeReport.readyForSingleFrame3d}", fontWeight = FontWeight.Medium)
                        planeReport.warnings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { planePreviewExport.launch("${project?.name ?: "laser"}_laser_plane_preview.png") },
                                modifier = Modifier.weight(1f)
                            ) { Text("Export plane preview") }
                            OutlinedButton(
                                onClick = { planePlyExport.launch("${project?.name ?: "laser"}_laser_single_frame.ply") },
                                modifier = Modifier.weight(1f)
                            ) { Text("Export 3D PLY") }
                        }
                        OutlinedButton(
                            onClick = { planeReportExport.launch("${project?.name ?: "laser"}_laser_plane_report.txt") },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Export laser-plane report") }
                    }
                }
            }

            if (analysisHistory.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Laser analysis run history (${analysisHistory.size})", fontWeight = FontWeight.SemiBold)
                        Text("Newest runs are shown first. The exported JSONL is chronological and uses the shared Android/Windows interchange schema.", style = MaterialTheme.typography.bodySmall)
                        analysisHistory.take(10).forEach { run ->
                            val summary = if (run.success) {
                                val coverage = run.coveragePercent?.let { "%.1f".format(it) } ?: "n/a"
                                val continuity = run.continuityPercent?.let { "%.1f".format(it) } ?: "n/a"
                                val width = run.meanLineWidthPx?.let { "%.1f".format(it) } ?: "n/a"
                                "${run.laserColor.displayName} • threshold ${run.threshold} • coverage $coverage% • continuity $continuity% • width ${width}px • ${if (run.readyForTriangulation == true) "READY" else "NOT READY"}"
                            } else {
                                "${run.laserColor.displayName} • threshold ${run.threshold} • FAILED: ${run.errorMessage ?: run.errorType ?: "unknown error"}"
                            }
                            Text(summary, style = MaterialTheme.typography.bodySmall)
                        }
                        if (analysisHistory.size > 10) {
                            Text("${analysisHistory.size - 10} older run(s) are retained in the export.", style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(
                            onClick = { historyExport.launch("${project?.name ?: "laser"}_laser_analysis_history.jsonl") },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Export analysis run history (.jsonl)") }
                    }
                }
            }

            if (report != null) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Laser line result", fontWeight = FontWeight.SemiBold)
                        Text("Engine: ${report.engine}")
                        Text("Extraction: ${report.extractionOrientation}")
                        Text("Detected samples: ${report.detectedRows} / ${report.sampleAxisLength.coerceAtLeast(report.imageHeight)}")
                        Text("Coverage: ${"%.1f".format(report.coveragePercent)}%")
                        Text("Continuity: ${"%.1f".format(report.continuityPercent)}%")
                        Text("Mean stripe width: ${"%.1f".format(report.meanLineWidthPx)} px")
                        Text("Ready for future calibrated triangulation: ${report.readyForTriangulation}", fontWeight = FontWeight.Medium)
                        report.warnings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }

                val previewBytes = remember(report) { onPreviewPng() }
                val previewBitmap = remember(previewBytes) {
                    previewBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                }
                if (previewBitmap != null) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text("Detected-line preview", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Image(
                                bitmap = previewBitmap.asImageBitmap(),
                                contentDescription = "Detected laser line overlay",
                                modifier = Modifier.fillMaxWidth(),
                                contentScale = ContentScale.FillWidth
                            )
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { reportExport.launch("${project?.name ?: "laser"}_laser_line_report.txt") }, modifier = Modifier.weight(1f)) {
                        Text("Export report")
                    }
                    OutlinedButton(onClick = { previewExport.launch("${project?.name ?: "laser"}_laser_line_preview.png") }, modifier = Modifier.weight(1f)) {
                        Text("Export preview")
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("Research foundation", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text("The laser pipeline is modeled after open-source sheet-of-light workflows. The first hardware target is a fixed camera, stationary object, 90° calibration corner, and hand-swept line laser. Planned next steps are laser-background/plane calibration, camera-ray/laser-plane triangulation, and multi-view fusion. Turntable automation remains optional/later.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
