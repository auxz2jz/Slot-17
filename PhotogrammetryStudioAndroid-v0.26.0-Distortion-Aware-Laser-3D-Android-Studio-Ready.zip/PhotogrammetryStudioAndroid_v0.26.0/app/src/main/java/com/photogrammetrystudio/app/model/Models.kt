package com.photogrammetrystudio.app.model

import java.io.File

enum class ScanMode(
    val displayName: String,
    val description: String
) {
    PHOTOGRAMMETRY(
        displayName = "Photo Scan",
        description = "Build a 3D model from many overlapping photos."
    ),
    LASER(
        displayName = "Laser Scan",
        description = "DAVID-style laser-line scanning with a calibrated camera and motion controller."
    ),
    HYBRID(
        displayName = "Hybrid Scan",
        description = "Combine photographic detail and texture with laser-derived geometry."
    )
}

data class PhotoProject(
    val id: String,
    val name: String,
    val createdAt: Long,
    val directory: File,
    val scanMode: ScanMode = ScanMode.PHOTOGRAMMETRY,
    val photos: List<File> = emptyList(),
    val modelFiles: List<File> = emptyList()
)

data class PhotoSetReport(
    val photoCount: Int,
    val readyForReconstruction: Boolean,
    val warnings: List<String>
)

enum class ReconstructionState {
    IDLE,
    ANALYZING,
    READY,
    RUNNING,
    COMPLETED,
    FAILED,
    ENGINE_UNAVAILABLE
}

data class ReconstructionStatus(
    val state: ReconstructionState = ReconstructionState.IDLE,
    val progress: Float = 0f,
    val message: String = "Not started"
)


data class FeatureMatchPair(
    val firstPhoto: String,
    val secondPhoto: String,
    val firstKeypoints: Int,
    val secondKeypoints: Int,
    val goodMatches: Int,
    val quality: String
)

data class FeatureMatchReport(
    val engine: String,
    val analyzedPhotos: Int,
    val totalKeypoints: Int,
    val adjacentPairs: List<FeatureMatchPair>,
    val strongOrUsablePairs: Int,
    val warnings: List<String>,
    val readyForSparseReconstruction: Boolean
)


data class SparsePoint(
    val x: Double,
    val y: Double,
    val z: Double
)

data class SparsePairEvaluation(
    val firstPhoto: String,
    val secondPhoto: String,
    val ratioMatches: Int,
    val ransacInliers: Int,
    val poseInliers: Int
)

data class SparseReconstructionReport(
    val engine: String,
    val firstPhoto: String,
    val secondPhoto: String,
    val ratioMatches: Int,
    val ransacInliers: Int,
    val poseInliers: Int,
    val triangulatedPoints: Int,
    val focalPixels: Double,
    val intrinsicsSource: String,
    val relativeRotationDegrees: Double,
    val pairEvaluations: List<SparsePairEvaluation>,
    val points: List<SparsePoint>,
    val warnings: List<String>,
    val readyForMultiView: Boolean
)


data class MultiViewPairEvaluation(
    val firstPhoto: String,
    val secondPhoto: String,
    val ratioMatches: Int,
    val ransacInliers: Int,
    val poseInliers: Int,
    val triangulatedPoints: Int,
    val connected: Boolean,
    val relativeRotationDegrees: Double
)

data class CameraPoseSummary(
    val photo: String,
    val index: Int,
    val connected: Boolean,
    val x: Double,
    val y: Double,
    val z: Double
)

data class MultiViewReconstructionReport(
    val engine: String,
    val photosRequested: Int,
    val connectedCameras: Int,
    val connectedPairs: Int,
    val rawTriangulatedPoints: Int,
    val combinedPoints: Int,
    val focalPixels: Double,
    val intrinsicsSource: String,
    val pairEvaluations: List<MultiViewPairEvaluation>,
    val cameras: List<CameraPoseSummary>,
    val points: List<SparsePoint>,
    val warnings: List<String>,
    val readyForBundleAdjustment: Boolean
)


data class BundleAdjustmentReport(
    val engine: String,
    val connectedCameras: Int,
    val tracksBuilt: Int,
    val tracksUsed: Int,
    val observationsUsed: Int,
    val initialPoints: Int,
    val refinedPoints: Int,
    val initialRmsPixels: Double,
    val finalRmsPixels: Double,
    val iterations: Int,
    val cameras: List<CameraPoseSummary>,
    val points: List<SparsePoint>,
    val warnings: List<String>,
    val readyForDenseReconstruction: Boolean
)


data class DenseReconstructionReport(
    val engine: String,
    val firstPhoto: String,
    val secondPhoto: String,
    val width: Int,
    val height: Int,
    val ratioMatches: Int,
    val ransacInliers: Int,
    val poseInliers: Int,
    val minDisparity: Int,
    val numDisparities: Int,
    val blockSize: Int,
    val observedDisparityLow: Double,
    val observedDisparityMedian: Double,
    val observedDisparityHigh: Double,
    val validDisparityPixels: Int,
    val geometryGuidedPoints: Int,
    val densePoints: Int,
    val minDepth: Double,
    val medianDepth: Double,
    val maxDepth: Double,
    val points: List<SparsePoint>,
    val warnings: List<String>,
    val readyForDenseFusion: Boolean
)


data class DenseFusionPairEvaluation(
    val firstPhoto: String,
    val secondPhoto: String,
    val poseInliers: Int,
    val observedDisparityMedian: Double,
    val validDisparityPixels: Int,
    val localDensePoints: Int,
    val fusedPoints: Int,
    val accepted: Boolean,
    val reason: String
)

data class DenseFusionReport(
    val engine: String,
    val photosRequested: Int,
    val connectedCameras: Int,
    val candidatePairs: Int,
    val pairsFused: Int,
    val rawDensePoints: Int,
    val fusedPoints: Int,
    val pairEvaluations: List<DenseFusionPairEvaluation>,
    val points: List<SparsePoint>,
    val warnings: List<String>,
    val readyForSurfaceReconstruction: Boolean
)


data class MeshTriangle(
    val a: Int,
    val b: Int,
    val c: Int
)

data class SurfaceMeshReport(
    val engine: String,
    val sourcePoints: Int,
    val meshVertices: Int,
    val triangles: Int,
    val voxelSize: Double,
    val maxAcceptedEdge: Double,
    val vertices: List<SparsePoint>,
    val faces: List<MeshTriangle>,
    val warnings: List<String>,
    val readyForExport: Boolean,
    val boundaryEdges: Int = 0,
    val nonManifoldEdges: Int = 0,
    val surfaceComponents: Int = 0,
    val candidateTriangles: Int = triangles,
    val cleanupRejectedFaces: Int = 0,
    val unusedVerticesRemoved: Int = 0,
    val boundaryLoops: Int = 0,
    val closedLoopsBeforeFill: Int = boundaryLoops,
    val filledBoundaryLoops: Int = 0,
    val holeFillAddedVertices: Int = 0,
    val holeFillAddedFaces: Int = 0,
    val skippedClosedLoops: Int = 0,
    val openBoundaryChains: Int = 0,
    val boundaryBranchVertices: Int = 0,
    val smoothingIterations: Int = 0,
    val smoothedVertices: Int = 0,
    val averageSmoothingDisplacement: Double = 0.0,
    val vertexNormals: List<SparsePoint> = emptyList(),
    val validVertexNormals: Int = 0
)


data class VertexColor(
    val red: Int,
    val green: Int,
    val blue: Int
)

data class TextureCameraContribution(
    val photo: String,
    val projectedVertices: Int,
    val selectedVertices: Int,
    val poseRecovered: Boolean,
    val visibilityRejectedVertices: Int = 0
)

data class TextureProjectionReport(
    val engine: String,
    val sourceMeshVertices: Int,
    val sourceMeshFaces: Int,
    val photosRequested: Int,
    val connectedCameras: Int,
    val recoveredCameraPoses: Int,
    val camerasUsed: Int,
    val projectedCandidates: Int,
    val coloredVertices: Int,
    val uncoloredVertices: Int,
    val coveragePercent: Double,
    val averageSamplesPerColoredVertex: Double,
    val vertexColors: List<VertexColor>,
    val cameraContributions: List<TextureCameraContribution>,
    val warnings: List<String>,
    val readyForExport: Boolean,
    val recoveredOrientationLinks: Int = 0,
    val bridgedOrientationLinks: Int = 0,
    val visibilityRejectedCandidates: Int = 0
)

data class FaceTextureAssignment(
    val faceIndex: Int,
    val photo: String,
    val u0: Double,
    val v0: Double,
    val u1: Double,
    val v1: Double,
    val u2: Double,
    val v2: Double,
    val score: Double
)

data class FaceTextureCameraContribution(
    val photo: String,
    val visibleCandidateFaces: Int,
    val selectedFaces: Int,
    val poseRecovered: Boolean
)

data class TextureSourceAssignmentReport(
    val engine: String,
    val sourceMeshVertices: Int,
    val sourceMeshFaces: Int,
    val connectedCameras: Int,
    val recoveredCameraPoses: Int,
    val recoveredOrientationLinks: Int,
    val bridgedOrientationLinks: Int,
    val camerasUsed: Int,
    val visibleFaceCandidates: Int,
    val assignedFaces: Int,
    val unassignedFaces: Int,
    val faceCoveragePercent: Double,
    val assignments: List<FaceTextureAssignment>,
    val cameraContributions: List<FaceTextureCameraContribution>,
    val warnings: List<String>,
    val readyForAtlas: Boolean
)


data class FaceAtlasUv(
    val faceIndex: Int,
    val u0: Double,
    val v0: Double,
    val u1: Double,
    val v1: Double,
    val u2: Double,
    val v2: Double
)

data class TextureAtlasReport(
    val engine: String,
    val atlasWidth: Int,
    val atlasHeight: Int,
    val tileSize: Int,
    val padding: Int,
    val sourceMeshVertices: Int,
    val sourceMeshFaces: Int,
    val stage9AssignedFaces: Int,
    val texturedFaces: Int,
    val untexturedFaces: Int,
    val textureCoveragePercent: Double,
    val sourcePhotosUsed: Int,
    val skippedMissingPhotos: Int,
    val skippedRasterizationFaces: Int,
    val faceUvs: List<FaceAtlasUv>,
    val warnings: List<String>,
    val readyForExport: Boolean,
    val uvIslands: Int = 0,
    val largestIslandFaces: Int = 0,
    val atlasOccupancyPercent: Double = 0.0
)

// v0.24.0 — selectable physical calibration-target presets, including pin-align tiled Letter assemblies.
// Standard single-sheet photo presets keep the original 9x6-inner-corner / 25 mm geometry.
// The optional large four-Letter photo preset keeps 9x6 inner corners but uses exact 38.1 mm (1.5 in) squares.
// Laser pin-align tiling preserves the original 12x18 / 35 mm-marker physical geometry.
enum class PhotoCalibrationTargetPreset(
    val id: String,
    val displayName: String,
    val assetPath: String,
    val defaultFileName: String,
    val pageWidthIn: Double,
    val pageHeightIn: Double,
    val isStandardCopySize: Boolean,
    val patternColumns: Int,
    val patternRows: Int,
    val squareSizeMm: Double,
    val printSheetCount: Int = 1,
    val printSheetDescription: String = "Single sheet"
) {
    US_LETTER(
        id = "photo_letter_8_5x11",
        displayName = "Letter 8.5×11",
        assetPath = "calibration_targets/photo_calibration_letter_25mm.pdf",
        defaultFileName = "3D_Scan_Studio_Photo_Calibration_Letter_25mm.pdf",
        pageWidthIn = 8.5,
        pageHeightIn = 11.0,
        isStandardCopySize = true,
        patternColumns = 9,
        patternRows = 6,
        squareSizeMm = 25.0
    ),
    US_LEGAL(
        id = "photo_legal_8_5x14",
        displayName = "Legal 8.5×14",
        assetPath = "calibration_targets/photo_calibration_legal_25mm.pdf",
        defaultFileName = "3D_Scan_Studio_Photo_Calibration_Legal_25mm.pdf",
        pageWidthIn = 8.5,
        pageHeightIn = 14.0,
        isStandardCopySize = true,
        patternColumns = 9,
        patternRows = 6,
        squareSizeMm = 25.0
    ),
    US_LEDGER(
        id = "photo_ledger_11x17",
        displayName = "Ledger 11×17",
        assetPath = "calibration_targets/photo_calibration_ledger_25mm.pdf",
        defaultFileName = "3D_Scan_Studio_Photo_Calibration_Ledger_25mm.pdf",
        pageWidthIn = 11.0,
        pageHeightIn = 17.0,
        isStandardCopySize = true,
        patternColumns = 9,
        patternRows = 6,
        squareSizeMm = 25.0
    ),
    POSTER_12X18(
        id = "photo_12x18",
        displayName = "Poster 12×18",
        assetPath = "calibration_targets/photo_calibration_12x18_25mm.pdf",
        defaultFileName = "3D_Scan_Studio_Photo_Calibration_12x18_25mm.pdf",
        pageWidthIn = 12.0,
        pageHeightIn = 18.0,
        isStandardCopySize = false,
        patternColumns = 9,
        patternRows = 6,
        squareSizeMm = 25.0
    ),
    TILED_4_LETTER_38_1MM(
        id = "photo_4letter_38_1mm_pin_align",
        displayName = "Large 4-Letter (38.1 mm)",
        assetPath = "calibration_targets/photo_calibration_4xletter_38_1mm_pin_align.pdf",
        defaultFileName = "3D_Scan_Studio_Photo_Calibration_4xLetter_38.1mm_PIN_ALIGN.pdf",
        pageWidthIn = 16.0,
        pageHeightIn = 11.5,
        isStandardCopySize = false,
        patternColumns = 9,
        patternRows = 6,
        squareSizeMm = 38.1,
        printSheetCount = 4,
        printSheetDescription = "4 × US Letter 8.5×11 landscape sheets, pin-align + straight-cut seams"
    );

    val pageWidthMm: Double get() = pageWidthIn * 25.4
    val pageHeightMm: Double get() = pageHeightIn * 25.4
    val patternWidthMm: Double get() = (patternColumns + 1) * squareSizeMm
    val patternHeightMm: Double get() = (patternRows + 1) * squareSizeMm
    val printClassLabel: String get() = when {
        printSheetCount > 1 -> "Tiled Letter assembly"
        isStandardCopySize -> "Standard copy size"
        else -> "Poster / optional"
    }

    companion object {
        fun fromId(id: String?): PhotoCalibrationTargetPreset = entries.firstOrNull { it.id == id } ?: US_LETTER
    }
}

enum class LaserCalibrationTargetPreset(
    val id: String,
    val displayName: String,
    val leftAssetPath: String,
    val rightAssetPath: String,
    val leftFileName: String,
    val rightFileName: String,
    val pageWidthIn: Double,
    val pageHeightIn: Double,
    val markerSizeMm: Double,
    val isStandardCopySize: Boolean,
    val printSheetCountPerPanel: Int = 1,
    val printSheetDescription: String = "Single sheet"
) {
    US_LETTER(
        id = "laser_letter_8_5x11",
        displayName = "Letter 8.5×11",
        leftAssetPath = "calibration_targets/laser_background_letter_left.pdf",
        rightAssetPath = "calibration_targets/laser_background_letter_right.pdf",
        leftFileName = "3D_Scan_Studio_Laser_Background_Letter_LEFT.pdf",
        rightFileName = "3D_Scan_Studio_Laser_Background_Letter_RIGHT.pdf",
        pageWidthIn = 8.5,
        pageHeightIn = 11.0,
        markerSizeMm = 28.0,
        isStandardCopySize = true
    ),
    US_LEGAL(
        id = "laser_legal_8_5x14",
        displayName = "Legal 8.5×14",
        leftAssetPath = "calibration_targets/laser_background_legal_left.pdf",
        rightAssetPath = "calibration_targets/laser_background_legal_right.pdf",
        leftFileName = "3D_Scan_Studio_Laser_Background_Legal_LEFT.pdf",
        rightFileName = "3D_Scan_Studio_Laser_Background_Legal_RIGHT.pdf",
        pageWidthIn = 8.5,
        pageHeightIn = 14.0,
        markerSizeMm = 28.0,
        isStandardCopySize = true
    ),
    US_LEDGER(
        id = "laser_ledger_11x17",
        displayName = "Ledger 11×17",
        leftAssetPath = "calibration_targets/laser_background_ledger_left.pdf",
        rightAssetPath = "calibration_targets/laser_background_ledger_right.pdf",
        leftFileName = "3D_Scan_Studio_Laser_Background_Ledger_LEFT.pdf",
        rightFileName = "3D_Scan_Studio_Laser_Background_Ledger_RIGHT.pdf",
        pageWidthIn = 11.0,
        pageHeightIn = 17.0,
        markerSizeMm = 32.0,
        isStandardCopySize = true
    ),
    POSTER_12X18(
        id = "laser_12x18",
        displayName = "Poster 12×18",
        leftAssetPath = "calibration_targets/laser_background_12x18_left.pdf",
        rightAssetPath = "calibration_targets/laser_background_12x18_right.pdf",
        leftFileName = "3D_Scan_Studio_Laser_Background_12x18_LEFT.pdf",
        rightFileName = "3D_Scan_Studio_Laser_Background_12x18_RIGHT.pdf",
        pageWidthIn = 12.0,
        pageHeightIn = 18.0,
        markerSizeMm = 35.0,
        isStandardCopySize = false
    ),
    TILED_12X18_ON_LETTER(
        id = "laser_12x18_tiled_letter",
        displayName = "12×18 pin-align (4 Letter sheets)",
        leftAssetPath = "calibration_targets/laser_background_12x18_tiled_letter_left.pdf",
        rightAssetPath = "calibration_targets/laser_background_12x18_tiled_letter_right.pdf",
        leftFileName = "3D_Scan_Studio_Laser_Background_12x18_4xLetter_PIN_ALIGN_LEFT.pdf",
        rightFileName = "3D_Scan_Studio_Laser_Background_12x18_4xLetter_PIN_ALIGN_RIGHT.pdf",
        pageWidthIn = 12.0,
        pageHeightIn = 18.0,
        markerSizeMm = 35.0,
        isStandardCopySize = false,
        printSheetCountPerPanel = 4,
        printSheetDescription = "4 × US Letter 8.5×11 portrait sheets per panel, pin-align + straight-cut seams"
    );

    val pageWidthMm: Double get() = pageWidthIn * 25.4
    val pageHeightMm: Double get() = pageHeightIn * 25.4
    val printClassLabel: String get() = when {
        printSheetCountPerPanel > 1 -> "Tiled Letter assembly"
        isStandardCopySize -> "Standard copy size"
        else -> "Poster / optional"
    }

    companion object {
        fun fromId(id: String?): LaserCalibrationTargetPreset = entries.firstOrNull { it.id == id } ?: US_LETTER
    }
}

enum class LaserCalibrationPanelSide { LEFT, RIGHT }

// v0.18.0 — reusable physical-camera calibration, independent of any one scan project.
data class CameraCalibrationFrameResult(
    val fileName: String,
    val detected: Boolean,
    val width: Int,
    val height: Int,
    val reason: String
)

data class CameraCalibrationProfile(
    val id: String,
    val label: String,
    val deviceModel: String,
    val imageWidth: Int,
    val imageHeight: Int,
    val patternColumns: Int,
    val patternRows: Int,
    val squareSizeMm: Double,
    val acceptedImages: Int,
    val rejectedImages: Int,
    val rmsReprojectionError: Double,
    val fx: Double,
    val fy: Double,
    val cx: Double,
    val cy: Double,
    val k1: Double,
    val k2: Double,
    val p1: Double,
    val p2: Double,
    val k3: Double,
    val targetPresetId: String = PhotoCalibrationTargetPreset.US_LETTER.id,
    val createdAt: Long,
    val readyForUse: Boolean
)

data class CameraCalibrationReport(
    val totalImages: Int,
    val acceptedImages: Int,
    val rejectedImages: Int,
    val frames: List<CameraCalibrationFrameResult>,
    val profile: CameraCalibrationProfile?,
    val warnings: List<String>
)


enum class LaserLineColor(val displayName: String) {
    RED("Red"),
    GREEN("Green"),
    BLUE("Blue")
}

data class LaserLinePoint(
    val row: Int,
    val x: Double,
    val strength: Double
)

data class LaserLineReport(
    val engine: String,
    val laserColor: LaserLineColor,
    val threshold: Int,
    val imageWidth: Int,
    val imageHeight: Int,
    val detectedRows: Int,
    val coveragePercent: Double,
    val meanSignal: Double,
    val meanLineWidthPx: Double,
    val continuityPercent: Double,
    val minX: Double,
    val maxX: Double,
    val points: List<LaserLinePoint>,
    val warnings: List<String>,
    val readyForTriangulation: Boolean,
    val extractionOrientation: String = "ROW_WISE",
    val sampleAxisLength: Int = 0
)


data class LaserPlane3D(
    val nx: Double,
    val ny: Double,
    val nz: Double,
    val d: Double
)

data class LaserPlaneCalibrationReport(
    val engine: String,
    val targetPresetId: String,
    val imageWidth: Int,
    val imageHeight: Int,
    val detectedMarkerIds: List<Int>,
    val leftMarkerIds: List<Int>,
    val rightMarkerIds: List<Int>,
    val leftPlane: LaserPlane3D?,
    val rightPlane: LaserPlane3D?,
    val panelAngleDegrees: Double,
    val leftBackgroundStripePoints: Int,
    val rightBackgroundStripePoints: Int,
    val fittedLaserPoints: Int,
    val laserPlane: LaserPlane3D?,
    val meanLaserPlaneResidualMm: Double,
    val triangulatedStripePoints: List<SparsePoint>,
    val nonBackdropStripePoints: List<SparsePoint>,
    val warnings: List<String>,
    val readyForSingleFrame3d: Boolean
)

/**
 * Platform-neutral summary of one Laser Line Lab Analyze attempt.
 *
 * v0.22 persists these records as UTF-8 JSON Lines so a future Windows
 * implementation can consume the same threshold-test history. The detailed
 * latest LaserLineReport remains separate and still contains the extracted points.
 */
data class LaserAnalysisRun(
    val schemaVersion: Int = 1,
    val runId: String,
    val timestampEpochMs: Long,
    val projectId: String,
    val laserColor: LaserLineColor,
    val threshold: Int,
    val success: Boolean,
    val durationMs: Long,
    val engine: String? = null,
    val laserOffFileName: String? = null,
    val laserOnFileName: String? = null,
    val laserOffSizeBytes: Long? = null,
    val laserOnSizeBytes: Long? = null,
    val laserOffModifiedMs: Long? = null,
    val laserOnModifiedMs: Long? = null,
    val laserTargetPresetId: String? = null,
    val imageWidth: Int? = null,
    val imageHeight: Int? = null,
    val detectedRows: Int? = null,
    val coveragePercent: Double? = null,
    val continuityPercent: Double? = null,
    val meanSignal: Double? = null,
    val meanLineWidthPx: Double? = null,
    val minX: Double? = null,
    val maxX: Double? = null,
    val readyForTriangulation: Boolean? = null,
    val extractionOrientation: String? = null,
    val sampleAxisLength: Int? = null,
    val errorType: String? = null,
    val errorMessage: String? = null,
    val errorStackTrace: String? = null
)
