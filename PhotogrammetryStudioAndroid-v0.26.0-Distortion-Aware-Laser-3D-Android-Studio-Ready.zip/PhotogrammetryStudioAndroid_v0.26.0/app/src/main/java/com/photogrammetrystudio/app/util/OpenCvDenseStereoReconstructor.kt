package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.DenseReconstructionReport
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.SparsePoint
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.calib3d.StereoSGBM
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Size
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.7 milestone: first dense stereo reconstruction from one already-verified photo pair.
 *
 * This deliberately does not fuse every camera yet. It re-estimates the best pair pose, rectifies
 * the two views, runs StereoSGBM, and reprojects valid disparity pixels into a dense 3D cloud.
 * Scale is arbitrary because recoverPose() returns translation direction only.
 */
object OpenCvDenseStereoReconstructor {
    private const val MAX_IMAGE_SIDE = 720
    private const val MAX_FEATURES = 3000
    private const val RATIO_TEST = 0.75f
    private const val RANSAC_THRESHOLD_PX = 1.5
    private const val MIN_RATIO_MATCHES = 20
    private const val MIN_POSE_INLIERS = 20
    private const val BLOCK_SIZE = 5
    private const val MAX_EXPORT_POINTS = 30000

    private data class DisparityPlan(
        val minDisparity: Int,
        val numDisparities: Int,
        val observedLow: Double,
        val observedMedian: Double,
        val observedHigh: Double,
        val adaptive: Boolean
    )

    @Volatile private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    fun reconstruct(
        files: List<File>,
        sparse: SparseReconstructionReport,
        multiView: MultiViewReconstructionReport,
        bundle: BundleAdjustmentReport,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<DenseReconstructionReport> = runCatching {
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }
        require(bundle.readyForDenseReconstruction) { "Run a successful shared-track refinement before dense reconstruction." }

        val sparsePairConnected = multiView.pairEvaluations.any { pair ->
            pair.connected && pair.firstPhoto == sparse.firstPhoto && pair.secondPhoto == sparse.secondPhoto
        }
        val fallbackPair = multiView.pairEvaluations
            .asSequence()
            .filter { it.connected && it.poseInliers >= MIN_POSE_INLIERS }
            .maxWithOrNull(compareBy<com.photogrammetrystudio.app.model.MultiViewPairEvaluation> { it.poseInliers }
                .thenBy { it.triangulatedPoints })
        val selectedFirst = if (sparsePairConnected || fallbackPair == null) sparse.firstPhoto else fallbackPair.firstPhoto
        val selectedSecond = if (sparsePairConnected || fallbackPair == null) sparse.secondPhoto else fallbackPair.secondPhoto
        val usingOriginalSparsePair = selectedFirst == sparse.firstPhoto && selectedSecond == sparse.secondPhoto

        val firstFile = files.firstOrNull { it.name == selectedFirst }
            ?: error("Could not find $selectedFirst in the current project.")
        val secondFile = files.firstOrNull { it.name == selectedSecond }
            ?: error("Could not find $selectedSecond in the current project.")

        onProgress(0.04f, if (usingOriginalSparsePair) {
            "Loading verified dense stereo pair…"
        } else {
            "Loading dense pair from the refined connected camera component…"
        })
        val leftBitmap = decodeScaled(firstFile) ?: error("Could not decode ${firstFile.name}.")
        var rightBitmap = decodeScaled(secondFile) ?: run {
            leftBitmap.recycle()
            error("Could not decode ${secondFile.name}.")
        }

        val warnings = mutableListOf<String>()
        val leftRgba = Mat(); val rightRgba = Mat()
        val leftGray = Mat(); val rightGray = Mat()
        val leftKeypoints = MatOfKeyPoint(); val rightKeypoints = MatOfKeyPoint()
        val leftDesc = Mat(); val rightDesc = Mat()
        val mask = Mat(); val r = Mat(); val t = Mat(); val tri = Mat()
        val r1 = Mat(); val r2 = Mat(); val p1 = Mat(); val p2 = Mat(); val q = Mat()
        val rectifiedPts1 = MatOfPoint2f(); val rectifiedPts2 = MatOfPoint2f()
        val map11 = Mat(); val map12 = Mat(); val map21 = Mat(); val map22 = Mat()
        val rectLeft = Mat(); val rectRight = Mat(); val disparity16 = Mat(); val disparity32 = Mat(); val xyz = Mat()
        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        var stereo: StereoSGBM? = null

        try {
            if (rightBitmap.width != leftBitmap.width || rightBitmap.height != leftBitmap.height) {
                val resized = Bitmap.createBitmap(leftBitmap.width, leftBitmap.height, Bitmap.Config.ARGB_8888)
                val src = Mat(); val dst = Mat()
                try {
                    Utils.bitmapToMat(rightBitmap, src)
                    Imgproc.resize(src, dst, Size(leftBitmap.width.toDouble(), leftBitmap.height.toDouble()))
                    Utils.matToBitmap(dst, resized)
                } finally {
                    src.release(); dst.release(); rightBitmap.recycle()
                }
                rightBitmap = resized
                warnings += "The second image was resized to match the first image for this v0.7 dense-pair test."
            }

            Utils.bitmapToMat(leftBitmap, leftRgba)
            Utils.bitmapToMat(rightBitmap, rightRgba)
            Imgproc.cvtColor(leftRgba, leftGray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.cvtColor(rightRgba, rightGray, Imgproc.COLOR_RGBA2GRAY)

            onProgress(0.12f, "Re-verifying dense pair geometry…")
            orb.detectAndCompute(leftGray, Mat(), leftKeypoints, leftDesc)
            orb.detectAndCompute(rightGray, Mat(), rightKeypoints, rightDesc)
            require(!leftDesc.empty() && !rightDesc.empty()) { "Not enough image detail for dense-pair pose verification." }

            val kp1 = leftKeypoints.toArray()
            val kp2 = rightKeypoints.toArray()
            val knn = mutableListOf<MatOfDMatch>()
            matcher.knnMatch(leftDesc, rightDesc, knn, 2)
            val ratio = mutableListOf<org.opencv.core.DMatch>()
            knn.forEach { set ->
                val m = set.toArray()
                if (m.size >= 2 && m[0].distance < RATIO_TEST * m[1].distance) ratio += m[0]
                set.release()
            }
            require(ratio.size >= MIN_RATIO_MATCHES) { "Dense pair no longer has enough descriptor matches (${ratio.size})." }

            val pts1 = MatOfPoint2f(*ratio.map { kp1[it.queryIdx].pt }.toTypedArray())
            val pts2 = MatOfPoint2f(*ratio.map { kp2[it.trainIdx].pt }.toTypedArray())
            val focal1 = estimateFocalPixels(firstFile, leftBitmap.width, leftBitmap.height)
            val focal2 = estimateFocalPixels(secondFile, rightBitmap.width, rightBitmap.height)
            val focal = (focal1.first + focal2.first) / 2.0
            val geometryModel = OpenCvCalibrationGeometry.model(leftBitmap.width, leftBitmap.height, focal)
            val geometryPts1 = OpenCvCalibrationGeometry.undistortPixelPoints(pts1, geometryModel)
            val geometryPts2 = OpenCvCalibrationGeometry.undistortPixelPoints(pts2, geometryModel)
            var ransacInliers = 0
            var poseInliers = 0

            try {
                val essential = Calib3d.findEssentialMat(
                    geometryPts1, geometryPts2, geometryModel.k, Calib3d.RANSAC, 0.999, RANSAC_THRESHOLD_PX, 1000, mask
                )
                require(!essential.empty()) { "Essential matrix failed for the dense stereo pair." }
                ransacInliers = countMask(mask)
                poseInliers = Calib3d.recoverPose(essential, geometryPts1, geometryPts2, geometryModel.k, r, t, 50.0, mask, tri)
                essential.release()
                require(poseInliers >= MIN_POSE_INLIERS) {
                    "Dense pair pose verification produced only $poseInliers inliers."
                }

                onProgress(0.28f, "Rectifying stereo images…")
                val imageSize = Size(leftBitmap.width.toDouble(), leftBitmap.height.toDouble())
                Calib3d.stereoRectify(geometryModel.k, geometryModel.dist, geometryModel.k, geometryModel.dist, imageSize, r, t, r1, r2, p1, p2, q)
                Calib3d.initUndistortRectifyMap(geometryModel.k, geometryModel.dist, r1, p1, imageSize, CvType.CV_32FC1, map11, map12)
                Calib3d.initUndistortRectifyMap(geometryModel.k, geometryModel.dist, r2, p2, imageSize, CvType.CV_32FC1, map21, map22)
                Imgproc.remap(leftGray, rectLeft, map11, map12, Imgproc.INTER_LINEAR)
                Imgproc.remap(rightGray, rectRight, map21, map22, Imgproc.INTER_LINEAR)

                // v0.7.1: estimate the object's rectified disparity band from verified
                // pose inliers. The v0.7 generic window could miss a close target and
                // accidentally favor far/background structure.
                Calib3d.undistortPoints(pts1, rectifiedPts1, geometryModel.k, geometryModel.dist, r1, p1)
                Calib3d.undistortPoints(pts2, rectifiedPts2, geometryModel.k, geometryModel.dist, r2, p2)
                val disparityPlan = chooseDisparityPlan(rectifiedPts1, rectifiedPts2, mask, leftBitmap.width)
                val numDisparities = disparityPlan.numDisparities
                val minDisparity = disparityPlan.minDisparity
                val p1Penalty = 8 * BLOCK_SIZE * BLOCK_SIZE
                val p2Penalty = 32 * BLOCK_SIZE * BLOCK_SIZE
                stereo = StereoSGBM.create(
                    minDisparity,
                    numDisparities,
                    BLOCK_SIZE,
                    p1Penalty,
                    p2Penalty,
                    1,
                    31,
                    10,
                    100,
                    2,
                    StereoSGBM.MODE_SGBM_3WAY
                )

                onProgress(0.45f, "Computing dense disparity map…")
                stereo!!.compute(rectLeft, rectRight, disparity16)
                disparity16.convertTo(disparity32, CvType.CV_32F, 1.0 / 16.0)

                onProgress(0.70f, "Reprojecting disparity into 3D…")
                Calib3d.reprojectImageTo3D(disparity32, xyz, q, true)

                var validPixels = 0
                val candidates = ArrayList<SparsePoint>(MAX_EXPORT_POINTS * 2)
                val stride = 2
                for (y in 0 until disparity32.rows()) {
                    for (x in 0 until disparity32.cols()) {
                        val d = disparity32.get(y, x)?.getOrNull(0) ?: continue
                        if (!d.isFinite() || d <= minDisparity + 1.0) continue
                        validPixels++
                        if (y % stride != 0 || x % stride != 0) continue
                        val value = xyz.get(y, x) ?: continue
                        if (value.size < 3) continue
                        val px = value[0]
                        val py = value[1]
                        val pz = value[2]
                        if (!px.isFinite() || !py.isFinite() || !pz.isFinite()) continue
                        if (pz <= 0.0 || abs(px) > 1000.0 || abs(py) > 1000.0 || pz > 1000.0) continue
                        candidates += SparsePoint(px, py, pz)
                    }
                }
                require(candidates.size >= 200) { "Dense stereo produced too few valid 3D samples (${candidates.size})." }

                onProgress(0.84f, "Filtering dense geometry with sparse depth guidance…")
                // Sparse and dense points use the same unit baseline. Rectification rotates
                // the left camera frame but preserves Euclidean distance, so sparse radii
                // give us a useful object-depth band for rejecting far background.
                val sparseRadii = if (usingOriginalSparsePair) {
                    sparse.points.map { pointNorm(it) }.filter { it.isFinite() && it > 0.0 }.sorted()
                } else {
                    emptyList()
                }
                val sparseLowRadius = if (sparseRadii.size >= 20) percentile(sparseRadii, 0.02) * 0.70 else 0.0
                val sparseHighRadius = if (sparseRadii.size >= 20) percentile(sparseRadii, 0.98) * 1.60 else Double.POSITIVE_INFINITY
                val geometryGuided = if (sparseRadii.size >= 20) {
                    candidates.filter { pointNorm(it) in sparseLowRadius..sparseHighRadius }
                } else {
                    emptyList()
                }
                val guidedUsable = geometryGuided.size >= 300
                val depthInput = if (guidedUsable) geometryGuided else candidates

                val depths = depthInput.map { it.z }.sorted()
                val low = percentile(depths, 0.01)
                val high = percentile(depths, 0.99)
                val filtered = depthInput.filter { it.z in low..high }
                val points = evenlyDownsample(filtered, MAX_EXPORT_POINTS)
                require(points.isNotEmpty()) { "Dense stereo points were removed during depth filtering." }
                val finalDepths = points.map { it.z }.sorted()
                val minDepth = finalDepths.first()
                val medianDepth = percentile(finalDepths, 0.50)
                val maxDepth = finalDepths.last()

                if (!usingOriginalSparsePair) {
                    warnings += "The global best sparse pair was outside the largest refined camera component, so v0.8.3 selected ${firstFile.name} -> ${secondFile.name} from the connected component for dense stereo."
                    warnings += "Sparse-radius guidance was intentionally skipped for this fallback pair because the saved sparse cloud belongs to a different camera pair."
                }
                if (disparityPlan.adaptive) {
                    warnings += "v0.7.1 adapted the disparity search from verified rectified inliers: ${"%.1f".format(disparityPlan.observedLow)} .. ${"%.1f".format(disparityPlan.observedHigh)} px (median ${"%.1f".format(disparityPlan.observedMedian)} px)."
                } else {
                    warnings += "Too few stable rectified inlier disparities were available, so the dense matcher used the fallback disparity window."
                }
                if (guidedUsable) {
                    warnings += "Sparse-depth guidance retained ${geometryGuided.size} candidate dense samples before final percentile filtering."
                } else if (sparseRadii.size >= 20) {
                    warnings += "Sparse-depth guidance was too restrictive for this run (${geometryGuided.size} samples), so final filtering fell back to the dense candidates."
                }
                if (validPixels < 5000) warnings += "Only $validPixels pixels had valid disparity. More texture and steadier exposure may improve dense coverage."
                if (points.size < 3000) warnings += "The corrected dense cloud contains ${points.size} exported points. It is still useful for testing, but later multi-pair fusion should provide more coverage."
                if (focal1.second.startsWith("Fallback") || focal2.second.startsWith("Fallback")) {
                    warnings += "Focal length was approximated for at least one image. Camera calibration will improve metric accuracy later."
                }
                warnings += "v0.7.1 still reconstructs one verified stereo pair only. Multi-pair dense fusion remains the next milestone."
                warnings += OpenCvCalibrationGeometry.status(geometryModel) + ". Dense rectification now uses the same model; reconstruction scale is still arbitrary until a deliberate metric-scale stage."

                onProgress(1f, "Dense stereo pair reconstruction complete")
                DenseReconstructionReport(
                    engine = "OpenCV calibrated connected-component adaptive StereoSGBM 4.14 / v0.26",
                    firstPhoto = firstFile.name,
                    secondPhoto = secondFile.name,
                    width = leftBitmap.width,
                    height = leftBitmap.height,
                    ratioMatches = ratio.size,
                    ransacInliers = ransacInliers,
                    poseInliers = poseInliers,
                    minDisparity = minDisparity,
                    numDisparities = numDisparities,
                    blockSize = BLOCK_SIZE,
                    observedDisparityLow = disparityPlan.observedLow,
                    observedDisparityMedian = disparityPlan.observedMedian,
                    observedDisparityHigh = disparityPlan.observedHigh,
                    validDisparityPixels = validPixels,
                    geometryGuidedPoints = if (guidedUsable) geometryGuided.size else 0,
                    densePoints = points.size,
                    minDepth = minDepth,
                    medianDepth = medianDepth,
                    maxDepth = maxDepth,
                    points = points,
                    warnings = warnings,
                    readyForDenseFusion = points.size >= 1000 && poseInliers >= MIN_POSE_INLIERS
                )
            } finally {
                pts1.release(); pts2.release(); geometryPts1.release(); geometryPts2.release(); geometryModel.close()
            }
        } finally {
            leftBitmap.recycle(); rightBitmap.recycle()
            leftRgba.release(); rightRgba.release(); leftGray.release(); rightGray.release()
            leftKeypoints.release(); rightKeypoints.release(); leftDesc.release(); rightDesc.release()
            mask.release(); r.release(); t.release(); tri.release(); r1.release(); r2.release(); p1.release(); p2.release(); q.release()
            rectifiedPts1.release(); rectifiedPts2.release()
            map11.release(); map12.release(); map21.release(); map22.release(); rectLeft.release(); rectRight.release()
            disparity16.release(); disparity32.release(); xyz.release()
            orb.clear(); matcher.clear(); stereo?.clear()
        }
    }

    private fun decodeScaled(file: File): Bitmap? =
        ExifBitmapLoader.decodeScaled(file, MAX_IMAGE_SIDE)

    private fun estimateFocalPixels(file: File, width: Int, height: Int): Pair<Double, String> {
        CameraCalibrationManager.focalEstimate(width, height)?.let { return it }
        val focal35 = runCatching {
            ExifInterface(file).getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
        }.getOrDefault(0)
        if (focal35 > 0) {
            val diagonal = sqrt(width.toDouble() * width + height.toDouble() * height)
            return (focal35.toDouble() * diagonal / 43.2666153) to "EXIF 35mm-equivalent focal length"
        }
        return (0.9 * max(width, height)) to "Fallback 0.9× max image dimension"
    }

    private fun cameraMatrix(width: Int, height: Int, focal: Double): Mat {
        CameraCalibrationManager.intrinsicsFor(width, height)?.let { intr ->
            val calibrated = Mat.eye(3, 3, CvType.CV_64F)
            calibrated.put(0, 0, intr.fx); calibrated.put(1, 1, intr.fy)
            calibrated.put(0, 2, intr.cx); calibrated.put(1, 2, intr.cy)
            return calibrated
        }
        val k = Mat.eye(3, 3, CvType.CV_64F)
        k.put(0, 0, focal); k.put(1, 1, focal)
        k.put(0, 2, width / 2.0); k.put(1, 2, height / 2.0)
        return k
    }

    private fun countMask(mask: Mat): Int {
        if (mask.empty()) return 0
        var count = 0
        val total = mask.rows() * mask.cols()
        for (i in 0 until total) {
            val value = if (mask.rows() == 1) mask.get(0, i) else mask.get(i, 0)
            if ((value?.getOrNull(0) ?: 0.0) != 0.0) count++
        }
        return count
    }

    private fun chooseNumDisparities(width: Int): Int {
        val desired = (width / 6).coerceIn(64, 192)
        return ((desired + 15) / 16) * 16
    }

    private fun chooseDisparityPlan(
        left: MatOfPoint2f,
        right: MatOfPoint2f,
        mask: Mat,
        width: Int
    ): DisparityPlan {
        val a = left.toArray()
        val b = right.toArray()
        val count = min(a.size, b.size)
        val disparities = ArrayList<Double>(count)
        for (i in 0 until count) {
            if (!maskValue(mask, i)) continue
            val d = a[i].x - b[i].x
            if (d.isFinite() && abs(d) < width * 0.90) disparities += d
        }

        if (disparities.size < 12) {
            val fallbackNum = chooseNumDisparities(width)
            return DisparityPlan(
                minDisparity = -fallbackNum / 4,
                numDisparities = fallbackNum,
                observedLow = 0.0,
                observedMedian = 0.0,
                observedHigh = 0.0,
                adaptive = false
            )
        }

        disparities.sort()
        val low = percentile(disparities, 0.05)
        val median = percentile(disparities, 0.50)
        val high = percentile(disparities, 0.95)
        val spread = (high - low).coerceAtLeast(8.0)
        val margin = max(12.0, spread * 0.40)
        var requestedLow = floor(low - margin).toInt()
        val requestedHigh = ceil(high + margin).toInt()

        val maxWidth = (((width * 0.70).toInt().coerceAtLeast(64)) / 16 * 16).coerceIn(64, 256)
        val span = (requestedHigh - requestedLow + 1).coerceAtLeast(64)
        var num = ((span + 15) / 16) * 16

        if (num > maxWidth) {
            num = maxWidth
            requestedLow = floor(median - num / 2.0).toInt()
        } else {
            num = num.coerceIn(64, maxWidth)
        }

        var actualHigh = requestedLow + num - 1
        if (high > actualHigh - 2) {
            requestedLow += ceil(high - (actualHigh - 2)).toInt()
            actualHigh = requestedLow + num - 1
        }
        requestedLow = requestedLow.coerceIn(-width / 2, width - 16)

        return DisparityPlan(
            minDisparity = requestedLow,
            numDisparities = num,
            observedLow = low,
            observedMedian = median,
            observedHigh = high,
            adaptive = true
        )
    }

    private fun maskValue(mask: Mat, index: Int): Boolean {
        if (mask.empty()) return true
        val value = if (mask.rows() == 1) mask.get(0, index) else mask.get(index, 0)
        return (value?.getOrNull(0) ?: 0.0) != 0.0
    }

    private fun pointNorm(point: SparsePoint): Double =
        sqrt(point.x * point.x + point.y * point.y + point.z * point.z)

    private fun percentile(sorted: List<Double>, fraction: Double): Double {
        if (sorted.isEmpty()) return 0.0
        val index = ((sorted.size - 1) * fraction).toInt().coerceIn(0, sorted.lastIndex)
        return sorted[index]
    }

    private fun evenlyDownsample(points: List<SparsePoint>, maxPoints: Int): List<SparsePoint> {
        if (points.size <= maxPoints) return points
        val step = points.size.toDouble() / maxPoints.toDouble()
        val out = ArrayList<SparsePoint>(maxPoints)
        var cursor = 0.0
        while (out.size < maxPoints && cursor.toInt() < points.size) {
            out += points[cursor.toInt()]
            cursor += step
        }
        return out
    }
}
