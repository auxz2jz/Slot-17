package com.photogrammetrystudio.app.util

import android.graphics.BitmapFactory
import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.PhotoSetReport
import java.io.File
import kotlin.math.abs

object PhotoSetAnalyzer {
    fun analyze(photos: List<File>): PhotoSetReport {
        val warnings = mutableListOf<String>()
        if (photos.size < 20) {
            warnings += "Use at least 20 overlapping photos for a small object; 40–100 is often better."
        }

        val sizes = photos.take(80).mapNotNull { file ->
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, options)
            if (options.outWidth > 0 && options.outHeight > 0) options.outWidth to options.outHeight else null
        }
        if (sizes.isNotEmpty()) {
            // Compare long/short sides rather than raw width/height so portrait and landscape
            // captures from the same camera are not mistaken for resolution changes.
            val baseLong = maxOf(sizes.first().first, sizes.first().second)
            val baseShort = minOf(sizes.first().first, sizes.first().second)
            val inconsistent = sizes.count { (w, h) ->
                val longSide = maxOf(w, h)
                val shortSide = minOf(w, h)
                abs(longSide - baseLong) > baseLong * 0.15 || abs(shortSide - baseShort) > baseShort * 0.15
            }
            if (inconsistent > sizes.size / 4) {
                warnings += "Many photos have different resolutions. Avoid changing camera modes or zoom during a capture set."
            }
        }

        val focalLengths = photos.take(80).mapNotNull { file ->
            runCatching {
                ExifInterface(file).getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, Double.NaN)
                    .takeIf { !it.isNaN() }
            }.getOrNull()
        }
        if (focalLengths.size >= 5) {
            val min = focalLengths.minOrNull() ?: 0.0
            val max = focalLengths.maxOrNull() ?: 0.0
            if (min > 0 && max / min > 1.25) {
                warnings += "Focal length changed noticeably across the set. A mostly fixed zoom/focal length is easier to reconstruct."
            }
        }

        return PhotoSetReport(
            photoCount = photos.size,
            readyForReconstruction = photos.size >= 20,
            warnings = warnings
        )
    }
}
