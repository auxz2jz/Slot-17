package com.photogrammetrystudio.app.util

import com.photogrammetrystudio.app.model.FeatureMatchPair
import com.photogrammetrystudio.app.model.FeatureMatchReport
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File

object OpenCvFeatureAnalyzer {
    private const val MAX_IMAGE_SIDE = 1600
    private const val MAX_FEATURES = 2500
    private const val RATIO_TEST = 0.75f

    @Volatile
    private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    fun analyze(files: List<File>, onProgress: (Float, String) -> Unit = { _, _ -> }): Result<FeatureMatchReport> = runCatching {
        require(files.size >= 2) { "Take or import at least 2 photos before matching." }
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }

        data class Features(val file: File, val keypoints: Int, val descriptors: Mat)

        val orb = ORB.create(MAX_FEATURES)
        val featureSets = mutableListOf<Features>()
        val warnings = mutableListOf<String>()

        files.forEachIndexed { index, file ->
            onProgress(index.toFloat() / (files.size + files.size - 1).coerceAtLeast(1), "Detecting features in ${file.name}")
            val bitmap = decodeScaled(file)
            if (bitmap == null) {
                warnings += "Could not decode ${file.name}."
                return@forEachIndexed
            }

            val rgba = Mat()
            val gray = Mat()
            val keypoints = MatOfKeyPoint()
            val descriptors = Mat()
            try {
                Utils.bitmapToMat(bitmap, rgba)
                Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                orb.detectAndCompute(gray, Mat(), keypoints, descriptors)
                featureSets += Features(file, keypoints.toArray().size, descriptors)
            } finally {
                bitmap.recycle()
                rgba.release()
                gray.release()
                keypoints.release()
            }
        }

        require(featureSets.size >= 2) { "Fewer than 2 photos could be decoded for matching." }

        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        val pairs = mutableListOf<FeatureMatchPair>()
        val pairCount = featureSets.size - 1

        for (i in 0 until pairCount) {
            val a = featureSets[i]
            val b = featureSets[i + 1]
            onProgress(
                (featureSets.size + i).toFloat() / (featureSets.size + pairCount).coerceAtLeast(1),
                "Matching ${a.file.name} ↔ ${b.file.name}"
            )

            var goodMatches = 0
            if (!a.descriptors.empty() && !b.descriptors.empty()) {
                val knn = mutableListOf<MatOfDMatch>()
                matcher.knnMatch(a.descriptors, b.descriptors, knn, 2)
                knn.forEach { set ->
                    val matches = set.toArray()
                    if (matches.size >= 2 && matches[0].distance < RATIO_TEST * matches[1].distance) {
                        goodMatches++
                    }
                    set.release()
                }
            }

            val label = when {
                goodMatches >= 120 -> "Strong"
                goodMatches >= 50 -> "Usable"
                goodMatches >= 20 -> "Weak"
                else -> "Poor"
            }
            pairs += FeatureMatchPair(
                firstPhoto = a.file.name,
                secondPhoto = b.file.name,
                firstKeypoints = a.keypoints,
                secondKeypoints = b.keypoints,
                goodMatches = goodMatches,
                quality = label
            )
        }

        val totalKeypoints = featureSets.sumOf { it.keypoints }
        val weakPairs = pairs.count { it.goodMatches < 50 }
        if (weakPairs > 0) warnings += "$weakPairs adjacent photo pair(s) have weak overlap. Move in smaller steps or add intermediate photos."
        if (featureSets.any { it.keypoints < 250 }) warnings += "At least one photo has few detectable visual features; plain, blurry, reflective, or dark surfaces may reconstruct poorly."

        val report = FeatureMatchReport(
            engine = "OpenCV ORB 4.14",
            analyzedPhotos = featureSets.size,
            totalKeypoints = totalKeypoints,
            adjacentPairs = pairs,
            strongOrUsablePairs = pairs.count { it.goodMatches >= 50 },
            warnings = warnings,
            readyForSparseReconstruction = pairs.isNotEmpty() && pairs.count { it.goodMatches >= 50 } >= (pairs.size * 0.7f)
        )

        featureSets.forEach { it.descriptors.release() }
        orb.clear()
        matcher.clear()
        onProgress(1f, "Feature matching complete")
        report
    }

    private fun decodeScaled(file: File): android.graphics.Bitmap? =
        ExifBitmapLoader.decodeScaled(file, MAX_IMAGE_SIDE)
}
