package com.photogrammetrystudio.app.util

import android.os.Build
import com.photogrammetrystudio.app.model.CameraCalibrationFrameResult
import com.photogrammetrystudio.app.model.CameraCalibrationProfile
import com.photogrammetrystudio.app.model.CameraCalibrationReport
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point3
import org.opencv.core.Size
import org.opencv.core.TermCriteria
import org.opencv.imgproc.Imgproc
import java.io.File
import java.util.UUID

/** v0.18.0 guided planar checkerboard camera calibration. */
object OpenCvCameraCalibrator {
    private const val MAX_IMAGE_SIDE = 2400
    private const val MIN_ACCEPTED_FRAMES = 10
    @Volatile private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    fun calibrate(
        files: List<File>,
        label: String,
        targetPreset: PhotoCalibrationTargetPreset,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<CameraCalibrationReport> = runCatching {
        require(files.size >= MIN_ACCEPTED_FRAMES) { "Import at least $MIN_ACCEPTED_FRAMES calibration photos; 15–25 is recommended." }
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }

        val pattern = Size(targetPreset.patternColumns.toDouble(), targetPreset.patternRows.toDouble())
        val objectTemplate = Mat(targetPreset.patternColumns * targetPreset.patternRows, 1, CvType.CV_32FC3)
        var objectIndex = 0
        for (row in 0 until targetPreset.patternRows) {
            for (col in 0 until targetPreset.patternColumns) {
                objectTemplate.put(objectIndex++, 0,
                    col * targetPreset.squareSizeMm,
                    row * targetPreset.squareSizeMm,
                    0.0)
            }
        }

        val objectPoints = mutableListOf<Mat>()
        val imagePoints = mutableListOf<Mat>()
        val frames = mutableListOf<CameraCalibrationFrameResult>()
        var imageWidth = 0
        var imageHeight = 0

        files.forEachIndexed { index, file ->
            onProgress(index.toFloat() / files.size.coerceAtLeast(1) * 0.65f, "Calibration ${index + 1}/${files.size}: ${file.name}")
            val bitmap = ExifBitmapLoader.decodeScaledRaw(file, MAX_IMAGE_SIDE)
            if (bitmap == null) {
                frames += CameraCalibrationFrameResult(file.name, false, 0, 0, "Image could not be decoded")
                return@forEachIndexed
            }
            if (imageWidth == 0) {
                imageWidth = bitmap.width
                imageHeight = bitmap.height
            }
            if (bitmap.width != imageWidth || bitmap.height != imageHeight) {
                frames += CameraCalibrationFrameResult(file.name, false, bitmap.width, bitmap.height, "Resolution/orientation differs from first accepted calibration image")
                bitmap.recycle()
                return@forEachIndexed
            }

            val rgba = Mat()
            val gray = Mat()
            val corners = MatOfPoint2f()
            try {
                Utils.bitmapToMat(bitmap, rgba)
                Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                val found = Calib3d.findChessboardCorners(
                    gray,
                    pattern,
                    corners,
                    Calib3d.CALIB_CB_ADAPTIVE_THRESH or Calib3d.CALIB_CB_NORMALIZE_IMAGE
                )
                if (!found) {
                    frames += CameraCalibrationFrameResult(file.name, false, bitmap.width, bitmap.height, "${targetPreset.patternColumns}×${targetPreset.patternRows} inner-corner checkerboard not detected")
                    return@forEachIndexed
                }
                Imgproc.cornerSubPix(
                    gray,
                    corners,
                    Size(11.0, 11.0),
                    Size(-1.0, -1.0),
                    TermCriteria(TermCriteria.EPS or TermCriteria.COUNT, 40, 0.001)
                )
                objectPoints += objectTemplate.clone()
                imagePoints += corners.clone()
                frames += CameraCalibrationFrameResult(file.name, true, bitmap.width, bitmap.height, "Board detected")
            } finally {
                bitmap.recycle()
                rgba.release(); gray.release(); corners.release()
            }
        }

        val accepted = imagePoints.size
        val rejected = files.size - accepted
        require(accepted >= MIN_ACCEPTED_FRAMES) { "Only $accepted/${files.size} calibration image(s) contained a usable complete board. Need at least $MIN_ACCEPTED_FRAMES." }

        onProgress(0.72f, "Solving camera intrinsics and lens distortion from $accepted view(s)…")
        val cameraMatrix = Mat.eye(3, 3, CvType.CV_64F)
        val distCoeffs = Mat.zeros(8, 1, CvType.CV_64F)
        val rvecs = mutableListOf<Mat>()
        val tvecs = mutableListOf<Mat>()
        val rms = try {
            Calib3d.calibrateCamera(
                objectPoints,
                imagePoints,
                Size(imageWidth.toDouble(), imageHeight.toDouble()),
                cameraMatrix,
                distCoeffs,
                rvecs,
                tvecs
            )
        } finally {
            objectPoints.forEach { it.release() }
            imagePoints.forEach { it.release() }
            objectTemplate.release()
        }

        val fx = cameraMatrix.get(0, 0)[0]
        val fy = cameraMatrix.get(1, 1)[0]
        val cx = cameraMatrix.get(0, 2)[0]
        val cy = cameraMatrix.get(1, 2)[0]
        val d = DoubleArray(8)
        val count = distCoeffs.total().toInt().coerceAtMost(d.size)
        for (i in 0 until count) d[i] = distCoeffs.get(i, 0)?.getOrNull(0) ?: 0.0
        cameraMatrix.release(); distCoeffs.release(); rvecs.forEach { it.release() }; tvecs.forEach { it.release() }

        val ready = accepted >= MIN_ACCEPTED_FRAMES && rms.isFinite() && rms <= 1.50 && fx > 0.0 && fy > 0.0
        val warnings = buildList {
            if (accepted < 15) add("Calibration used $accepted images. 15–25 varied views are recommended for a stronger profile.")
            if (rms > 1.0) add("RMS reprojection error is ${"%.3f".format(rms)} px. Below 1.0 px is preferred; below 1.5 px is accepted for this milestone.")
            if (!ready) add("This solve is not marked active. Capture more varied, sharp calibration views and run calibration again.")
            add("Target preset: ${targetPreset.displayName}. Physical geometry: ${targetPreset.patternColumns}×${targetPreset.patternRows} inner corners / ${targetPreset.squareSizeMm} mm squares / ${targetPreset.printSheetDescription}.")
            add("v0.26 applies calibrated focal/principal-point intrinsics and measured lens distortion throughout geometric reconstruction where the profile is compatible. Stage 1 ORB descriptors remain on original pixels by design; geometric feature coordinates are undistorted from Stage 2 onward.")
        }

        val profile = CameraCalibrationProfile(
            id = UUID.randomUUID().toString(),
            label = label.trim().ifBlank { "Main 1×" },
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            patternColumns = targetPreset.patternColumns,
            patternRows = targetPreset.patternRows,
            squareSizeMm = targetPreset.squareSizeMm,
            acceptedImages = accepted,
            rejectedImages = rejected,
            rmsReprojectionError = rms,
            fx = fx, fy = fy, cx = cx, cy = cy,
            k1 = d.getOrElse(0) { 0.0 },
            k2 = d.getOrElse(1) { 0.0 },
            p1 = d.getOrElse(2) { 0.0 },
            p2 = d.getOrElse(3) { 0.0 },
            k3 = d.getOrElse(4) { 0.0 },
            targetPresetId = targetPreset.id,
            createdAt = System.currentTimeMillis(),
            readyForUse = ready
        )
        onProgress(1f, "Calibration complete: RMS ${"%.3f".format(rms)} px")
        CameraCalibrationReport(files.size, accepted, rejected, frames, profile, warnings)
    }
}
