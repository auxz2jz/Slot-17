package com.photogrammetrystudio.app.util

import com.photogrammetrystudio.app.model.MeshTriangle
import com.photogrammetrystudio.app.model.SparsePoint
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.11.0 surface-quality milestone.
 *
 * v0.10.0 established boundary-preserving smoothing, normals, and explicit boundary classification.
 * v0.11.0 advances that result conservatively: only small, simple, nearly planar closed boundary
 * loops that pass edge/shape safety checks are capped. Open or branched borders are deliberately
 * left untouched so the app does not invent large surfaces from uncertain geometry.
 */
object LocalSurfaceMesher {
    private const val MAX_VERTICES = 6500
    private const val MAX_TRIANGLES = 30000
    private const val NEIGHBORS_PER_VERTEX = 10
    private const val EDGE_FACTOR = 2.65
    private const val MAX_FAN_GAP_RADIANS = 2.6179938779914944 // 150 degrees
    private const val MIN_COMPONENT_FACES = 24

    private data class Cell(val x: Int, val y: Int, val z: Int)
    private data class Acc(var x: Double = 0.0, var y: Double = 0.0, var z: Double = 0.0, var count: Int = 0)
    private data class Neighbor(val index: Int, val distance: Double)
    private data class FanNeighbor(val index: Int, val angle: Double, val distance: Double)
    private data class Candidate(val face: MeshTriangle, val score: Double)
    private data class CompactMesh(val vertices: List<SparsePoint>, val faces: List<MeshTriangle>, val removedVertices: Int)
    private data class SmoothingResult(
        val vertices: List<SparsePoint>,
        val movedVertices: Int,
        val averageDisplacement: Double
    )
    private data class BoundarySummary(
        val loops: Int,
        val openChains: Int,
        val branchVertices: Int,
        val components: Int
    )
    private data class HoleFillResult(
        val vertices: List<SparsePoint>,
        val faces: List<MeshTriangle>,
        val loopsBefore: Int,
        val filledLoops: Int,
        val skippedLoops: Int,
        val addedVertices: Int,
        val addedFaces: Int,
        val notes: List<String> = emptyList()
    )

    fun reconstruct(
        source: List<SparsePoint>,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<SurfaceMeshReport> = runCatching {
        onProgress(0.03f, "Checking fused dense points…")
        val finite = source.filter { it.x.isFinite() && it.y.isFinite() && it.z.isFinite() }
        require(finite.size >= 250) { "At least 250 finite fused points are required for Stage 7 surface meshing." }

        val sortedX = finite.map { it.x }.sorted()
        val sortedY = finite.map { it.y }.sorted()
        val sortedZ = finite.map { it.z }.sorted()
        fun q(values: List<Double>, fraction: Double): Double =
            values[((values.size - 1) * fraction).toInt().coerceIn(0, values.lastIndex)]

        val loX = q(sortedX, 0.01); val hiX = q(sortedX, 0.99)
        val loY = q(sortedY, 0.01); val hiY = q(sortedY, 0.99)
        val loZ = q(sortedZ, 0.01); val hiZ = q(sortedZ, 0.99)
        val padX = (hiX - loX) * 0.12
        val padY = (hiY - loY) * 0.12
        val padZ = (hiZ - loZ) * 0.12
        val working = finite.filter {
            it.x in (loX - padX)..(hiX + padX) &&
                it.y in (loY - padY)..(hiY + padY) &&
                it.z in (loZ - padZ)..(hiZ + padZ)
        }
        require(working.size >= 250) {
            "Robust outlier trimming left too few points (${working.size}) for a useful mesh."
        }

        val dx = hiX - loX; val dy = hiY - loY; val dz = hiZ - loZ
        val diagonal = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1e-6)

        onProgress(0.12f, "Voxel-reducing the dense cloud…")
        var voxelSize = diagonal / 105.0
        var vertices = voxelDownsample(working, voxelSize)
        var voxelPasses = 0
        while (vertices.size > MAX_VERTICES && voxelPasses < 12) {
            voxelSize *= 1.20
            vertices = voxelDownsample(working, voxelSize)
            voxelPasses++
        }
        require(vertices.size >= 180) {
            "Voxel reduction left too few vertices (${vertices.size}) for a useful mesh."
        }

        onProgress(0.25f, "Indexing local surface neighborhoods…")
        val searchCellSize = voxelSize * 2.0
        val index = buildIndex(vertices, searchCellSize)
        val neighborLists = Array(vertices.size) { emptyList<Neighbor>() }
        val localScale = DoubleArray(vertices.size) { voxelSize }

        vertices.indices.forEach { i ->
            val neighbors = nearestNeighbors(i, vertices, index, searchCellSize)
            neighborLists[i] = neighbors
            val usable = neighbors.take(4).map { it.distance }.filter { it > 1e-9 }.sorted()
            if (usable.isNotEmpty()) {
                localScale[i] = usable[usable.size / 2].coerceAtLeast(voxelSize * 0.35)
            }
            if (i % 300 == 0) {
                onProgress(
                    0.25f + 0.14f * (i.toFloat() / vertices.size),
                    "Measuring local spacing ${i + 1}/${vertices.size}…"
                )
            }
        }

        val cx = vertices.sumOf { it.x } / vertices.size
        val cy = vertices.sumOf { it.y } / vertices.size
        val cz = vertices.sumOf { it.z } / vertices.size
        val centroid = doubleArrayOf(cx, cy, cz)

        onProgress(0.40f, "Building ordered local triangle fans…")
        val candidates = ArrayList<Candidate>(min(MAX_TRIANGLES * 2, vertices.size * 7))
        val seenTriangles = HashSet<Long>()
        var rejectedLong = 0
        var rejectedShape = 0
        var rejectedFrame = 0

        for (i in vertices.indices) {
            val near = neighborLists[i].take(NEIGHBORS_PER_VERTEX)
            val frame = localFrame(i, vertices, near, centroid)
            if (frame == null) {
                rejectedFrame++
                continue
            }
            val normal = frame[0]
            val tangentU = frame[1]
            val tangentV = frame[2]
            val ordered = ArrayList<FanNeighbor>(near.size)
            near.forEach { neighbor ->
                if (neighbor.distance > 1e-9) {
                    val d = vector(vertices[i], vertices[neighbor.index])
                    val x = dot(d, tangentU)
                    val y = dot(d, tangentV)
                    ordered += FanNeighbor(neighbor.index, atan2(y, x), neighbor.distance)
                }
            }
            ordered.sortBy { it.angle }
            if (ordered.size < 2) continue

            for (slot in ordered.indices) {
                val first = ordered[slot]
                val second = ordered[(slot + 1) % ordered.size]
                var gap = second.angle - first.angle
                if (gap <= 0.0) gap += 2.0 * PI
                if (gap > MAX_FAN_GAP_RADIANS) continue

                val j = first.index
                val k = second.index
                if (j == i || k == i || j == k) continue

                val d01 = distance(vertices[i], vertices[j])
                val d02 = distance(vertices[i], vertices[k])
                val d12 = distance(vertices[j], vertices[k])
                val globalLimit = searchCellSize * 2.20
                if (!edgeAllowed(d01, i, j, localScale, globalLimit) ||
                    !edgeAllowed(d02, i, k, localScale, globalLimit) ||
                    !edgeAllowed(d12, j, k, localScale, globalLimit)
                ) {
                    rejectedLong++
                    continue
                }

                val shortest = min(d01, min(d02, d12)).coerceAtLeast(1e-9)
                val longest = max(d01, max(d02, d12))
                val aspect = longest / shortest
                if (aspect > 3.7) {
                    rejectedShape++
                    continue
                }
                val area2 = doubledArea(vertices[i], vertices[j], vertices[k])
                if (area2 < voxelSize * voxelSize * 0.045) {
                    rejectedShape++
                    continue
                }

                val ids = intArrayOf(i, j, k).sortedArray()
                val triangleKey = triangleKey(ids[0], ids[1], ids[2])
                if (!seenTriangles.add(triangleKey)) continue

                var aa = i; var bb = j; var cc = k
                val faceNormal = cross(vertices[aa], vertices[bb], vertices[cc])
                if (dot(faceNormal, normal) < 0.0) {
                    val tmp = bb; bb = cc; cc = tmp
                }
                val scale = max(localScale[i], max(localScale[j], localScale[k])).coerceAtLeast(1e-9)
                val score = aspect + 0.15 * (longest / scale) + 0.10 * (gap / PI)
                candidates += Candidate(MeshTriangle(aa, bb, cc), score)
            }

            if (i % 250 == 0) {
                onProgress(
                    0.40f + 0.22f * (i.toFloat() / vertices.size),
                    "Proposing ordered triangles ${candidates.size}…"
                )
            }
        }

        require(candidates.isNotEmpty()) { "Stage 7 could not form any local triangle candidates." }

        onProgress(0.64f, "Removing non-manifold overlaps…")
        val edgeUse = HashMap<Long, Int>()
        val manifoldFaces = ArrayList<MeshTriangle>(min(MAX_TRIANGLES, candidates.size))
        var rejectedNonManifold = 0
        for (candidate in candidates.sortedBy { it.score }) {
            val face = candidate.face
            val edges = longArrayOf(
                edgeKey(face.a, face.b),
                edgeKey(face.b, face.c),
                edgeKey(face.c, face.a)
            )
            if (edges.any { (edgeUse[it] ?: 0) >= 2 }) {
                rejectedNonManifold++
                continue
            }
            manifoldFaces += face
            edges.forEach { edgeUse[it] = (edgeUse[it] ?: 0) + 1 }
            if (manifoldFaces.size >= MAX_TRIANGLES) break
        }
        require(manifoldFaces.size >= 100) {
            "Topology cleanup left only ${manifoldFaces.size} manifold triangles."
        }

        onProgress(0.76f, "Filtering tiny disconnected fragments…")
        val components = faceComponents(manifoldFaces)
        val largestComponent = components.maxOfOrNull { it.size } ?: 0
        val componentThreshold = max(MIN_COMPONENT_FACES, largestComponent / 100)
        val keepFaceIndices = HashSet<Int>()
        var keptComponents = 0
        components.forEach { component ->
            if (component.size >= componentThreshold) {
                keepFaceIndices.addAll(component)
                keptComponents++
            }
        }
        if (keepFaceIndices.isEmpty() && components.isNotEmpty()) {
            keepFaceIndices.addAll(components.maxBy { it.size })
            keptComponents = 1
        }
        val keptFaces = manifoldFaces.filterIndexed { indexFace, _ -> indexFace in keepFaceIndices }
        val discardedTinyFaces = manifoldFaces.size - keptFaces.size
        require(keptFaces.size >= 100) {
            "Fragment cleanup left only ${keptFaces.size} triangles."
        }

        onProgress(0.84f, "Compacting unused mesh vertices…")
        val compact = compactMesh(vertices, keptFaces)

        onProgress(0.86f, "Smoothing interior vertices while preserving open boundaries…")
        val smoothingIterations = 2
        val smoothing = smoothVertices(compact.vertices, compact.faces, smoothingIterations)
        val smoothedVertices = smoothing.vertices
        val preFillLongestEdge = compact.faces.maxOfOrNull { face ->
            max(
                distance(smoothedVertices[face.a], smoothedVertices[face.b]),
                max(
                    distance(smoothedVertices[face.b], smoothedVertices[face.c]),
                    distance(smoothedVertices[face.c], smoothedVertices[face.a])
                )
            )
        } ?: 0.0

        onProgress(0.91f, "Safely filling simple closed boundary loops…")
        val holeFill = fillSafeClosedLoops(
            vertices = smoothedVertices,
            faces = compact.faces,
            maxAcceptedEdge = preFillLongestEdge.coerceAtLeast(voxelSize * 2.0),
            voxelSize = voxelSize
        )
        val finalVertices = holeFill.vertices
        val finalFaces = holeFill.faces

        onProgress(0.95f, "Calculating vertex normals and remaining boundary structure…")
        val finalEdgeUse = edgeCounts(finalFaces)
        val boundaryEdges = finalEdgeUse.values.count { it == 1 }
        val nonManifoldEdges = finalEdgeUse.values.count { it > 2 }
        val finalComponents = faceComponents(finalFaces).size
        val boundarySummary = analyzeBoundary(finalFaces)
        val normals = computeVertexNormals(finalVertices, finalFaces)
        val validNormals = normals.count { norm(doubleArrayOf(it.x, it.y, it.z)) > 0.5 }
        val longestAcceptedEdge = finalFaces.maxOfOrNull { face ->
            max(
                distance(finalVertices[face.a], finalVertices[face.b]),
                max(
                    distance(finalVertices[face.b], finalVertices[face.c]),
                    distance(finalVertices[face.c], finalVertices[face.a])
                )
            )
        } ?: 0.0

        val warnings = mutableListOf<String>()
        warnings += "v0.11.0 keeps the topology-clean local-fan mesh, preserves boundaries during smoothing, and caps only small/simple closed loops that pass conservative safety checks."
        if (finite.size != source.size) {
            warnings += "Ignored ${source.size - finite.size} non-finite fused point(s)."
        }
        if (working.size != finite.size) {
            warnings += "Robustly trimmed ${finite.size - working.size} extreme fused point(s) before meshing so isolated outliers do not control the surface scale."
        }
        if (voxelPasses > 0) {
            warnings += "Voxel size was increased $voxelPasses time(s) to keep the mesh mobile-friendly."
        }
        warnings += "Proposed ${candidates.size} ordered local triangle candidate(s); rejected $rejectedNonManifold candidate(s) that would have made an edge non-manifold."
        if (discardedTinyFaces > 0) {
            warnings += "Discarded $discardedTinyFaces triangle(s) from tiny disconnected fragments smaller than $componentThreshold faces."
        }
        if (compact.removedVertices > 0) {
            warnings += "Removed ${compact.removedVertices} downsampled vertex/vertices that were not referenced by the cleaned surface."
        }
        warnings += "Final topology: ${compact.faces.size} faces, $boundaryEdges boundary edges, $nonManifoldEdges non-manifold edges, $finalComponents retained surface component(s)."
        warnings += "Hole-fill analysis: ${holeFill.loopsBefore} closed loop(s) before filling; filled ${holeFill.filledLoops}, skipped ${holeFill.skippedLoops}, added ${holeFill.addedVertices} center vertex/vertices and ${holeFill.addedFaces} face(s)."
        warnings += holeFill.notes
        warnings += "Remaining boundary analysis: ${boundarySummary.loops} closed loop(s), ${boundarySummary.openChains} open chain/component(s), ${boundarySummary.branchVertices} branched boundary vertex/vertices."
        warnings += "Calculated $validNormals usable vertex normal(s) after $smoothingIterations boundary-preserving smoothing pass(es); moved ${smoothing.movedVertices} interior vertex/vertices by ${"%.6f".format(smoothing.averageDisplacement)} average arbitrary units."
        warnings += "Rejected $rejectedLong overly long local fan edge combination(s), $rejectedShape degenerate/high-aspect combination(s), and skipped $rejectedFrame vertex neighborhood(s) without a stable local frame."
        if (boundaryEdges > 0) {
            warnings += "Boundary edges remain because v0.11.0 intentionally leaves open or branched borders untouched; only safe simple closed loops are capped."
        }

        onProgress(1.0f, "Smoothed topology-clean surface mesh with safe hole filling complete")
        SurfaceMeshReport(
            engine = "Smoothed local-fan topology + safe closed-loop fill v0.11.0",
            sourcePoints = source.size,
            meshVertices = finalVertices.size,
            triangles = finalFaces.size,
            voxelSize = voxelSize,
            maxAcceptedEdge = longestAcceptedEdge,
            vertices = finalVertices,
            faces = finalFaces,
            warnings = warnings,
            readyForExport = finalFaces.size >= 100 && nonManifoldEdges == 0,
            boundaryEdges = boundaryEdges,
            nonManifoldEdges = nonManifoldEdges,
            surfaceComponents = finalComponents,
            candidateTriangles = candidates.size,
            cleanupRejectedFaces = rejectedNonManifold + discardedTinyFaces,
            unusedVerticesRemoved = compact.removedVertices,
            boundaryLoops = boundarySummary.loops,
            closedLoopsBeforeFill = holeFill.loopsBefore,
            filledBoundaryLoops = holeFill.filledLoops,
            holeFillAddedVertices = holeFill.addedVertices,
            holeFillAddedFaces = holeFill.addedFaces,
            skippedClosedLoops = holeFill.skippedLoops,
            openBoundaryChains = boundarySummary.openChains,
            boundaryBranchVertices = boundarySummary.branchVertices,
            smoothingIterations = smoothingIterations,
            smoothedVertices = smoothing.movedVertices,
            averageSmoothingDisplacement = smoothing.averageDisplacement,
            vertexNormals = normals,
            validVertexNormals = validNormals
        )
    }


    private fun fillSafeClosedLoops(
        vertices: List<SparsePoint>,
        faces: List<MeshTriangle>,
        maxAcceptedEdge: Double,
        voxelSize: Double
    ): HoleFillResult {
        val loops = orderedBoundaryLoops(faces)
        if (loops.isEmpty()) {
            return HoleFillResult(vertices, faces, 0, 0, 0, 0, 0, emptyList())
        }
        val outVertices = vertices.toMutableList()
        val outFaces = faces.toMutableList()
        var filled = 0
        var skipped = 0
        var addedVertices = 0
        var addedFaces = 0
        val notes = mutableListOf<String>()

        loops.forEachIndexed { loopIndex, loop ->
            if (loop.size !in 3..12 || outVertices.size + 1 > MAX_VERTICES || outFaces.size + loop.size > MAX_TRIANGLES) {
                skipped++
                notes += "Closed loop ${loopIndex + 1} skipped: ${loop.size} boundary vertices or mesh safety cap was outside the supported fill range."
                return@forEachIndexed
            }
            val points = loop.map { outVertices[it] }
            val centroid = SparsePoint(
                points.sumOf { it.x } / points.size,
                points.sumOf { it.y } / points.size,
                points.sumOf { it.z } / points.size
            )
            var perimeter = 0.0
            var maxRadius = 0.0
            var maxBoundaryEdge = 0.0
            for (i in points.indices) {
                val edge = distance(points[i], points[(i + 1) % points.size])
                perimeter += edge
                maxBoundaryEdge = max(maxBoundaryEdge, edge)
                maxRadius = max(maxRadius, distance(points[i], centroid))
            }
            if (perimeter > maxAcceptedEdge * 3.0 || maxRadius > maxAcceptedEdge * 0.90 || maxBoundaryEdge > maxAcceptedEdge * 1.02) {
                skipped++
                notes += "Closed loop ${loopIndex + 1} skipped: perimeter/radius/edge size was too large for a conservative local cap."
                return@forEachIndexed
            }

            val polygonNormal = newellNormal(points) ?: run {
                skipped++
                notes += "Closed loop ${loopIndex + 1} skipped: could not estimate a stable loop plane."
                return@forEachIndexed
            }
            val maxPlaneDistance = points.maxOf { p ->
                val offset = doubleArrayOf(p.x - centroid.x, p.y - centroid.y, p.z - centroid.z)
                kotlin.math.abs(dot(offset, polygonNormal))
            }
            if (maxPlaneDistance > maxAcceptedEdge * 0.08) {
                skipped++
                notes += "Closed loop ${loopIndex + 1} skipped: boundary was too non-planar for a safe cap."
                return@forEachIndexed
            }

            val minimumArea2 = max(voxelSize * voxelSize * 0.02, 1e-10)
            val proposed = ArrayList<MeshTriangle>(loop.size)
            var shapeSafe = true
            for (i in loop.indices) {
                val a = loop[i]
                val b = loop[(i + 1) % loop.size]
                val pa = outVertices[a]
                val pb = outVertices[b]
                val dAB = distance(pa, pb)
                val dAC = distance(pa, centroid)
                val dBC = distance(pb, centroid)
                val shortest = min(dAB, min(dAC, dBC)).coerceAtLeast(1e-9)
                val longest = max(dAB, max(dAC, dBC))
                if (longest > maxAcceptedEdge || longest / shortest > 4.5 || doubledArea(pa, pb, centroid) < minimumArea2) {
                    shapeSafe = false
                    break
                }
                proposed += MeshTriangle(a, b, -1)
            }
            if (!shapeSafe) {
                skipped++
                notes += "Closed loop ${loopIndex + 1} skipped: centroid fan would create an overly long, thin, or degenerate triangle."
                return@forEachIndexed
            }

            val centerIndex = outVertices.size
            outVertices += centroid
            proposed.forEach { face ->
                var a = face.a
                var b = face.b
                val normal = cross(outVertices[a], outVertices[b], centroid)
                if (dot(normal, polygonNormal) < 0.0) {
                    val tmp = a; a = b; b = tmp
                }
                outFaces += MeshTriangle(a, b, centerIndex)
            }
            filled++
            addedVertices++
            addedFaces += proposed.size
            notes += "Closed loop ${loopIndex + 1} filled conservatively with ${proposed.size} triangle(s) and one center vertex."
        }

        return HoleFillResult(
            vertices = outVertices,
            faces = outFaces,
            loopsBefore = loops.size,
            filledLoops = filled,
            skippedLoops = skipped,
            addedVertices = addedVertices,
            addedFaces = addedFaces,
            notes = notes
        )
    }

    private fun orderedBoundaryLoops(faces: List<MeshTriangle>): List<List<Int>> {
        val edges = boundaryEdgePairs(faces)
        if (edges.isEmpty()) return emptyList()
        val adjacency = HashMap<Int, MutableSet<Int>>()
        edges.forEach { (a, b) ->
            adjacency.getOrPut(a) { linkedSetOf() }.add(b)
            adjacency.getOrPut(b) { linkedSetOf() }.add(a)
        }
        val visited = HashSet<Int>()
        val loops = ArrayList<List<Int>>()
        adjacency.keys.sorted().forEach { start ->
            if (start in visited) return@forEach
            val queue = ArrayDeque<Int>()
            val component = ArrayList<Int>()
            queue.add(start); visited.add(start)
            while (queue.isNotEmpty()) {
                val v = queue.removeFirst()
                component += v
                adjacency[v].orEmpty().forEach { n -> if (visited.add(n)) queue.add(n) }
            }
            if (component.size < 3 || component.any { adjacency[it]?.size != 2 }) return@forEach

            val ordered = ArrayList<Int>(component.size)
            val loopStart = component.minOrNull() ?: return@forEach
            var previous = -1
            var current = loopStart
            var closed = false
            var steps = 0
            while (steps <= component.size) {
                ordered += current
                val neighbors = adjacency[current].orEmpty().sorted()
                if (neighbors.size != 2) break
                val next = if (previous < 0 || neighbors[0] != previous) neighbors[0] else neighbors[1]
                if (next == loopStart) {
                    closed = true
                    break
                }
                previous = current
                current = next
                steps++
            }
            if (closed && ordered.size == component.size) loops += ordered
        }
        return loops
    }

    private fun newellNormal(points: List<SparsePoint>): DoubleArray? {
        if (points.size < 3) return null
        var nx = 0.0; var ny = 0.0; var nz = 0.0
        for (i in points.indices) {
            val p = points[i]
            val q = points[(i + 1) % points.size]
            nx += (p.y - q.y) * (p.z + q.z)
            ny += (p.z - q.z) * (p.x + q.x)
            nz += (p.x - q.x) * (p.y + q.y)
        }
        return normalize(doubleArrayOf(nx, ny, nz))
    }


    private fun smoothVertices(
        vertices: List<SparsePoint>,
        faces: List<MeshTriangle>,
        iterations: Int
    ): SmoothingResult {
        if (vertices.isEmpty() || faces.isEmpty() || iterations <= 0) {
            return SmoothingResult(vertices, 0, 0.0)
        }
        val adjacency = Array(vertices.size) { linkedSetOf<Int>() }
        faces.forEach { face ->
            adjacency[face.a].add(face.b); adjacency[face.a].add(face.c)
            adjacency[face.b].add(face.a); adjacency[face.b].add(face.c)
            adjacency[face.c].add(face.a); adjacency[face.c].add(face.b)
        }
        val boundaryVertices = HashSet<Int>()
        boundaryEdgePairs(faces).forEach { (a, b) -> boundaryVertices += a; boundaryVertices += b }

        var current = vertices
        repeat(iterations) {
            val next = current.toMutableList()
            for (i in current.indices) {
                if (i in boundaryVertices) continue
                val neighbors = adjacency[i]
                if (neighbors.size < 3) continue
                var ax = 0.0; var ay = 0.0; var az = 0.0
                neighbors.forEach { n ->
                    ax += current[n].x; ay += current[n].y; az += current[n].z
                }
                val inv = 1.0 / neighbors.size
                ax *= inv; ay *= inv; az *= inv
                val p = current[i]
                val lambda = 0.16
                next[i] = SparsePoint(
                    p.x + (ax - p.x) * lambda,
                    p.y + (ay - p.y) * lambda,
                    p.z + (az - p.z) * lambda
                )
            }
            current = next
        }

        var moved = 0
        var displacement = 0.0
        current.indices.forEach { i ->
            val d = distance(vertices[i], current[i])
            if (d > 1e-9) { moved++; displacement += d }
        }
        return SmoothingResult(current, moved, if (moved > 0) displacement / moved else 0.0)
    }

    private fun computeVertexNormals(vertices: List<SparsePoint>, faces: List<MeshTriangle>): List<SparsePoint> {
        val sums = Array(vertices.size) { doubleArrayOf(0.0, 0.0, 0.0) }
        faces.forEach { face ->
            val n = cross(vertices[face.a], vertices[face.b], vertices[face.c])
            intArrayOf(face.a, face.b, face.c).forEach { i ->
                sums[i][0] += n[0]; sums[i][1] += n[1]; sums[i][2] += n[2]
            }
        }
        return sums.map { sum ->
            val n = normalize(sum)
            if (n == null) SparsePoint(0.0, 0.0, 0.0) else SparsePoint(n[0], n[1], n[2])
        }
    }

    private fun boundaryEdgePairs(faces: List<MeshTriangle>): List<Pair<Int, Int>> {
        val counts = edgeCounts(faces)
        val out = LinkedHashMap<Long, Pair<Int, Int>>()
        faces.forEach { face ->
            arrayOf(face.a to face.b, face.b to face.c, face.c to face.a).forEach { pair ->
                val key = edgeKey(pair.first, pair.second)
                if (counts[key] == 1) out[key] = pair
            }
        }
        return out.values.toList()
    }

    private fun analyzeBoundary(faces: List<MeshTriangle>): BoundarySummary {
        val edges = boundaryEdgePairs(faces)
        if (edges.isEmpty()) return BoundarySummary(0, 0, 0, 0)
        val adjacency = HashMap<Int, MutableSet<Int>>()
        edges.forEach { (a, b) ->
            adjacency.getOrPut(a) { linkedSetOf() }.add(b)
            adjacency.getOrPut(b) { linkedSetOf() }.add(a)
        }
        val visited = HashSet<Int>()
        var loops = 0
        var open = 0
        var components = 0
        adjacency.keys.forEach { start ->
            if (!visited.add(start)) return@forEach
            components++
            val queue = ArrayDeque<Int>()
            val component = ArrayList<Int>()
            queue.add(start)
            while (queue.isNotEmpty()) {
                val v = queue.removeFirst()
                component += v
                adjacency[v].orEmpty().forEach { n -> if (visited.add(n)) queue.add(n) }
            }
            val degrees = component.map { adjacency[it]?.size ?: 0 }
            if (degrees.isNotEmpty() && degrees.all { it == 2 }) loops++ else open++
        }
        val branchVertices = adjacency.values.count { it.size > 2 }
        return BoundarySummary(loops, open, branchVertices, components)
    }

    private fun voxelDownsample(points: List<SparsePoint>, size: Double): List<SparsePoint> {
        val cells = LinkedHashMap<Cell, Acc>()
        points.forEach { p ->
            val key = cellOf(p, size)
            val a = cells.getOrPut(key) { Acc() }
            a.x += p.x; a.y += p.y; a.z += p.z; a.count++
        }
        return cells.values.map { a -> SparsePoint(a.x / a.count, a.y / a.count, a.z / a.count) }
    }

    private fun buildIndex(points: List<SparsePoint>, size: Double): Map<Cell, MutableList<Int>> {
        val out = HashMap<Cell, MutableList<Int>>()
        points.indices.forEach { i -> out.getOrPut(cellOf(points[i], size)) { mutableListOf() }.add(i) }
        return out
    }

    private fun nearestNeighbors(
        indexPoint: Int,
        points: List<SparsePoint>,
        index: Map<Cell, MutableList<Int>>,
        size: Double
    ): List<Neighbor> {
        val p = points[indexPoint]
        val c = cellOf(p, size)
        val found = LinkedHashMap<Int, Double>()
        for (radius in 1..2) {
            for (x in c.x - radius..c.x + radius) {
                for (y in c.y - radius..c.y + radius) {
                    for (z in c.z - radius..c.z + radius) {
                        index[Cell(x, y, z)]?.forEach { other ->
                            if (other != indexPoint && other !in found) {
                                found[other] = distance(p, points[other])
                            }
                        }
                    }
                }
            }
            if (found.size >= NEIGHBORS_PER_VERTEX + 4) break
        }
        return found.map { Neighbor(it.key, it.value) }
            .sortedBy { it.distance }
            .take(NEIGHBORS_PER_VERTEX + 4)
    }

    /** Returns [normal, tangentU, tangentV], or null if the neighborhood is nearly collinear. */
    private fun localFrame(
        centerIndex: Int,
        points: List<SparsePoint>,
        neighbors: List<Neighbor>,
        centroid: DoubleArray
    ): Array<DoubleArray>? {
        val usable = neighbors.filter { it.distance > 1e-9 }
        if (usable.size < 2) return null
        val center = points[centerIndex]
        val base = vector(center, points[usable.first().index])
        val baseNorm = norm(base)
        if (baseNorm < 1e-9) return null

        var second: DoubleArray? = null
        var bestSin = 0.0
        usable.drop(1).forEach { neighbor ->
            val v = vector(center, points[neighbor.index])
            val vNorm = norm(v)
            if (vNorm > 1e-9) {
                val sinAngle = norm(cross(base, v)) / (baseNorm * vNorm)
                if (sinAngle > bestSin) {
                    bestSin = sinAngle
                    second = v
                }
            }
        }
        if (second == null || bestSin < 0.08) return null

        var normal = normalize(cross(base, second!!)) ?: return null
        val outward = doubleArrayOf(center.x - centroid[0], center.y - centroid[1], center.z - centroid[2])
        if (dot(normal, outward) < 0.0) normal = doubleArrayOf(-normal[0], -normal[1], -normal[2])

        val baseDotN = dot(base, normal)
        val projected = doubleArrayOf(
            base[0] - normal[0] * baseDotN,
            base[1] - normal[1] * baseDotN,
            base[2] - normal[2] * baseDotN
        )
        val tangentU = normalize(projected) ?: return null
        val tangentV = normalize(cross(normal, tangentU)) ?: return null
        return arrayOf(normal, tangentU, tangentV)
    }

    private fun edgeAllowed(d: Double, a: Int, b: Int, scales: DoubleArray, globalLimit: Double): Boolean {
        val localLimit = EDGE_FACTOR * max(scales[a], scales[b])
        return d <= min(globalLimit, localLimit)
    }

    private fun compactMesh(vertices: List<SparsePoint>, faces: List<MeshTriangle>): CompactMesh {
        val used = java.util.TreeSet<Int>()
        faces.forEach { face -> used += face.a; used += face.b; used += face.c }
        val remap = HashMap<Int, Int>(used.size)
        val compactVertices = ArrayList<SparsePoint>(used.size)
        used.forEachIndexed { newIndex, oldIndex ->
            remap[oldIndex] = newIndex
            compactVertices += vertices[oldIndex]
        }
        val compactFaces = faces.map { face ->
            MeshTriangle(
                remap.getValue(face.a),
                remap.getValue(face.b),
                remap.getValue(face.c)
            )
        }
        return CompactMesh(compactVertices, compactFaces, vertices.size - compactVertices.size)
    }

    private fun edgeCounts(faces: List<MeshTriangle>): Map<Long, Int> {
        val counts = HashMap<Long, Int>()
        faces.forEach { face ->
            longArrayOf(
                edgeKey(face.a, face.b),
                edgeKey(face.b, face.c),
                edgeKey(face.c, face.a)
            ).forEach { key -> counts[key] = (counts[key] ?: 0) + 1 }
        }
        return counts
    }

    private fun faceComponents(faces: List<MeshTriangle>): List<List<Int>> {
        if (faces.isEmpty()) return emptyList()
        val edgeFaces = HashMap<Long, MutableList<Int>>()
        faces.forEachIndexed { index, face ->
            longArrayOf(
                edgeKey(face.a, face.b),
                edgeKey(face.b, face.c),
                edgeKey(face.c, face.a)
            ).forEach { key -> edgeFaces.getOrPut(key) { mutableListOf() }.add(index) }
        }
        val adjacency = Array(faces.size) { mutableListOf<Int>() }
        edgeFaces.values.forEach { list ->
            if (list.size == 2) {
                val a = list[0]; val b = list[1]
                adjacency[a] += b
                adjacency[b] += a
            }
        }
        val visited = BooleanArray(faces.size)
        val components = ArrayList<List<Int>>()
        for (start in faces.indices) {
            if (visited[start]) continue
            val queue = ArrayDeque<Int>()
            val component = ArrayList<Int>()
            queue.add(start); visited[start] = true
            while (queue.isNotEmpty()) {
                val current = queue.removeFirst()
                component += current
                adjacency[current].forEach { next ->
                    if (!visited[next]) {
                        visited[next] = true
                        queue.add(next)
                    }
                }
            }
            components += component
        }
        return components
    }

    private fun cellOf(p: SparsePoint, size: Double): Cell = Cell(
        floor(p.x / size).toInt(), floor(p.y / size).toInt(), floor(p.z / size).toInt()
    )

    private fun distance(a: SparsePoint, b: SparsePoint): Double {
        val dx = a.x - b.x; val dy = a.y - b.y; val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun doubledArea(a: SparsePoint, b: SparsePoint, c: SparsePoint): Double {
        val n = cross(a, b, c)
        return norm(n)
    }

    private fun vector(a: SparsePoint, b: SparsePoint): DoubleArray =
        doubleArrayOf(b.x - a.x, b.y - a.y, b.z - a.z)

    private fun cross(a: SparsePoint, b: SparsePoint, c: SparsePoint): DoubleArray =
        cross(vector(a, b), vector(a, c))

    private fun cross(a: DoubleArray, b: DoubleArray): DoubleArray = doubleArrayOf(
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    )

    private fun dot(a: DoubleArray, b: DoubleArray): Double = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

    private fun norm(v: DoubleArray): Double = sqrt(dot(v, v))

    private fun normalize(v: DoubleArray): DoubleArray? {
        val n = norm(v)
        if (n < 1e-12 || !n.isFinite()) return null
        return doubleArrayOf(v[0] / n, v[1] / n, v[2] / n)
    }

    private fun edgeKey(a: Int, b: Int): Long {
        val lo = min(a, b)
        val hi = max(a, b)
        return (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
    }

    private fun triangleKey(a: Int, b: Int, c: Int): Long {
        // MAX_VERTICES is far below 2^20, so each index safely occupies 20 bits.
        return (a.toLong() shl 40) or (b.toLong() shl 20) or c.toLong()
    }
}
