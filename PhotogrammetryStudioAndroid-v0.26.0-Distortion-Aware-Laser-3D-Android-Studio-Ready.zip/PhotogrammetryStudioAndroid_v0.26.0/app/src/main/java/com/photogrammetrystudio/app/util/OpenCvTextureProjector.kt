package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import android.graphics.Color
import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.FaceTextureAssignment
import com.photogrammetrystudio.app.model.FaceTextureCameraContribution
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.SparsePoint
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureCameraContribution
import com.photogrammetrystudio.app.model.TextureProjectionReport
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import com.photogrammetrystudio.app.model.VertexColor
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Size
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.17.0 Stage 8/9 appearance pipeline.
 *
 * Stage 8 projects source-photo color onto Stage 7 vertices. Compared with v0.12.0 it can bridge
 * short breaks in the adjacent-camera orientation chain and applies a coarse depth-buffer test so
 * a farther surface is less likely to steal color through a nearer surface.
 *
 * Stage 9 uses the same recovered cameras and visibility rules to assign one real source photo to
 * each triangle when all three corners are usable in that view. It stores normalized photo
 * coordinates for all three corners. This is intentionally the preparation step before a later UV
 * atlas image is packed; Stage 9 does not modify Stage 7 geometry.
 */
object OpenCvTextureProjector {
    private const val POSE_IMAGE_SIDE = 720
    private const val COLOR_IMAGE_SIDE = 1280
    private const val MAX_FEATURES = 3000
    private const val RATIO_TEST = 0.75f
    private const val RANSAC_THRESHOLD_PX = 1.5
    private const val MIN_RATIO_MATCHES = 20
    private const val MIN_POSE_INLIERS = 20
    private const val MAX_BLEND_SAMPLES = 3
    private const val MIN_FACING = 0.04
    private const val MAX_BRIDGE_GAP = 4
    private const val VISIBILITY_CELL_PX = 8
    private const val VISIBILITY_DEPTH_FRACTION = 0.018
    private const val VISIBILITY_EDGE_FACTOR = 0.70
    private const val FALLBACK_MIN_VISIBLE_VERTICES = 2
    private const val FALLBACK_MIN_FACE_SCORE = 0.12
    private const val FALLBACK_MIN_PROJECTED_AREA2 = 2.0
    private const val CONTINUITY_MIN_NEIGHBOR_VOTES = 2
    private const val CONTINUITY_MIN_VISIBLE_VERTICES = 1
    private const val CONTINUITY_MIN_FACE_SCORE = 0.10
    private const val CONTINUITY_MIN_PROJECTED_AREA2 = 2.0

    private data class RelativePose(val r: DoubleArray, val poseInliers: Int)
    private data class CameraPose(
        val index: Int,
        val photo: String,
        val r: DoubleArray,
        val t: DoubleArray,
        val center: SparsePoint
    )
    private data class RecoveredCameraSet(
        val poses: List<CameraPose>,
        val connectedCameraCount: Int,
        val recoveredOrientationLinks: Int,
        val bridgedOrientationLinks: Int,
        val attemptedBridges: Int
    )
    private data class ProjectionFrame(
        val width: Int,
        val height: Int,
        val u: DoubleArray,
        val v: DoubleArray,
        val z: DoubleArray,
        val score: DoubleArray,
        val visible: BooleanArray,
        val geometricCandidates: Int,
        val visibilityRejected: Int
    )

    @Volatile private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    fun project(
        files: List<File>,
        multi: MultiViewReconstructionReport,
        bundle: BundleAdjustmentReport,
        mesh: SurfaceMeshReport,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<TextureProjectionReport> = runCatching {
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }
        require(mesh.readyForExport && mesh.vertices.isNotEmpty() && mesh.faces.isNotEmpty()) {
            "Build a valid Stage 7 surface mesh before Stage 8 photo color projection."
        }
        require(bundle.readyForDenseReconstruction) { "Stage 8 needs the saved Stage 4 refined camera centers." }
        require(multi.readyForBundleAdjustment) { "Stage 8 needs the saved Stage 3 connected camera component." }

        val fileByName = files.associateBy { it.name }
        val recovered = recoverCameraSet(files, multi, bundle) { fraction, message ->
            onProgress(0.03f + fraction * 0.27f, message)
        }
        val poses = recovered.poses
        require(poses.size >= 3) {
            "Only ${poses.size} connected camera world poses could be recovered for Stage 8."
        }

        val vertexCount = mesh.vertices.size
        val normals = mesh.vertexNormals
        val scores = Array(vertexCount) { DoubleArray(MAX_BLEND_SAMPLES) { -1.0 } }
        val packedColors = Array(vertexCount) { IntArray(MAX_BLEND_SAMPLES) }
        val photoSlots = Array(vertexCount) { IntArray(MAX_BLEND_SAMPLES) { -1 } }
        val projectedByCamera = IntArray(poses.size)
        val rejectedByCamera = IntArray(poses.size)
        var projectedCandidates = 0
        var visibilityRejected = 0

        poses.forEachIndexed cameraLoop@ { cameraOrdinal, pose ->
            val file = fileByName[pose.photo] ?: return@cameraLoop
            onProgress(
                0.32f + 0.56f * (cameraOrdinal.toFloat() / poses.size.coerceAtLeast(1)),
                "Stage 8 — visibility-checking photo ${cameraOrdinal + 1}/${poses.size}"
            )
            val bitmap = ExifBitmapLoader.decodeScaled(file, COLOR_IMAGE_SIDE) ?: return@cameraLoop
            try {
                val width = bitmap.width
                val height = bitmap.height
                if (width <= 4 || height <= 4) return@cameraLoop
                val focal = estimateFocalPixels(file, width, height)
                val frame = buildProjectionFrame(mesh, pose, width, height, focal)
                rejectedByCamera[cameraOrdinal] = frame.visibilityRejected
                visibilityRejected += frame.visibilityRejected

                for (vertexIndex in 0 until vertexCount) {
                    if (!frame.visible[vertexIndex]) continue
                    val score = frame.score[vertexIndex]
                    if (score <= 0.0) continue
                    val color = sample3x3(bitmap, frame.u[vertexIndex].toInt(), frame.v[vertexIndex].toInt())
                    insertSample(
                        scores[vertexIndex],
                        packedColors[vertexIndex],
                        photoSlots[vertexIndex],
                        score,
                        color,
                        cameraOrdinal
                    )
                    projectedByCamera[cameraOrdinal]++
                    projectedCandidates++
                }
            } finally {
                bitmap.recycle()
            }
        }

        onProgress(0.91f, "Stage 8 — blending visibility-checked photo colors…")
        val colors = ArrayList<VertexColor>(vertexCount)
        val bestPhoto = IntArray(vertexCount) { -1 }
        var coloredVertices = 0
        var totalBlendSamples = 0
        for (i in 0 until vertexCount) {
            val valid = scores[i].indices.filter { scores[i][it] > 0.0 }
            if (valid.isEmpty()) {
                colors += VertexColor(128, 128, 128)
                continue
            }
            var sumWeight = 0.0
            var red = 0.0
            var green = 0.0
            var blue = 0.0
            valid.forEach { slot ->
                val weight = scores[i][slot] * scores[i][slot]
                val packed = packedColors[i][slot]
                red += Color.red(packed) * weight
                green += Color.green(packed) * weight
                blue += Color.blue(packed) * weight
                sumWeight += weight
            }
            val bestSlot = valid.maxByOrNull { scores[i][it] } ?: valid.first()
            bestPhoto[i] = photoSlots[i][bestSlot]
            val denom = sumWeight.coerceAtLeast(1e-9)
            colors += VertexColor(
                (red / denom).toInt().coerceIn(0, 255),
                (green / denom).toInt().coerceIn(0, 255),
                (blue / denom).toInt().coerceIn(0, 255)
            )
            coloredVertices++
            totalBlendSamples += valid.size
        }

        val selectedByCamera = IntArray(poses.size)
        bestPhoto.forEach { camera -> if (camera in selectedByCamera.indices) selectedByCamera[camera]++ }
        val contributions = poses.mapIndexed { index, pose ->
            TextureCameraContribution(
                photo = pose.photo,
                projectedVertices = projectedByCamera[index],
                selectedVertices = selectedByCamera[index],
                poseRecovered = true,
                visibilityRejectedVertices = rejectedByCamera[index]
            )
        }
        val camerasUsed = contributions.count { it.selectedVertices > 0 }
        val uncolored = vertexCount - coloredVertices
        val coverage = if (vertexCount > 0) coloredVertices * 100.0 / vertexCount else 0.0
        val averageSamples = if (coloredVertices > 0) totalBlendSamples.toDouble() / coloredVertices else 0.0
        val warnings = mutableListOf<String>()
        warnings += "v0.13.0 keeps Stage 8 as per-vertex photo color while adding short-gap pose bridging and coarse depth visibility checks."
        warnings += if (CameraCalibrationManager.activeProfile() != null) "v0.26 projects Stage 8 geometry through the saved calibrated Brown-Conrady distortion model back into the original source photographs." else "No compatible active calibration; Stage 8 source projection uses the fallback pinhole model."
        warnings += "Colors are blended from up to three visibility-approved, front-facing source views."
        warnings += "Recovered ${recovered.recoveredOrientationLinks}/${(recovered.connectedCameraCount - 1).coerceAtLeast(0)} camera orientation link(s), including ${recovered.bridgedOrientationLinks} short-gap bridge(s); ${poses.size}/${recovered.connectedCameraCount} connected camera world pose(s) are available."
        warnings += "Coarse depth visibility rejected $visibilityRejected farther vertex projection candidate(s) before color sampling."
        if (coverage < 70.0) warnings += "Only ${"%.1f".format(coverage)}% of mesh vertices received direct photo color. Later UV atlas work can texture triangle interiors even when individual vertices are not directly sampled."
        if (camerasUsed < 3) warnings += "Only $camerasUsed camera(s) supplied best-view colors; inspect capture coverage before relying on the color result."
        val ready = coloredVertices >= max(100, (vertexCount * 0.20).toInt()) && camerasUsed >= 2

        onProgress(1f, "Stage 8 visibility-refined photo color projection complete")
        TextureProjectionReport(
            engine = "OpenCV distortion-aware bridged-camera visibility-refined vertex color projection v0.26.0",
            sourceMeshVertices = vertexCount,
            sourceMeshFaces = mesh.faces.size,
            photosRequested = files.size,
            connectedCameras = recovered.connectedCameraCount,
            recoveredCameraPoses = poses.size,
            camerasUsed = camerasUsed,
            projectedCandidates = projectedCandidates,
            coloredVertices = coloredVertices,
            uncoloredVertices = uncolored,
            coveragePercent = coverage,
            averageSamplesPerColoredVertex = averageSamples,
            vertexColors = colors,
            cameraContributions = contributions,
            warnings = warnings,
            readyForExport = ready,
            recoveredOrientationLinks = recovered.recoveredOrientationLinks,
            bridgedOrientationLinks = recovered.bridgedOrientationLinks,
            visibilityRejectedCandidates = visibilityRejected
        )
    }

    fun assignTextureSources(
        files: List<File>,
        multi: MultiViewReconstructionReport,
        bundle: BundleAdjustmentReport,
        mesh: SurfaceMeshReport,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<TextureSourceAssignmentReport> = runCatching {
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }
        require(mesh.readyForExport && mesh.vertices.isNotEmpty() && mesh.faces.isNotEmpty()) {
            "Build a valid Stage 7 surface mesh before Stage 9 texture-source assignment."
        }
        require(bundle.readyForDenseReconstruction) { "Stage 9 needs the saved Stage 4 refined camera centers." }
        require(multi.readyForBundleAdjustment) { "Stage 9 needs the saved Stage 3 connected camera component." }

        val fileByName = files.associateBy { it.name }
        val recovered = recoverCameraSet(files, multi, bundle) { fraction, message ->
            onProgress(0.03f + fraction * 0.24f, message.replace("Stage 8", "Stage 9"))
        }
        val poses = recovered.poses
        require(poses.size >= 3) { "Only ${poses.size} connected camera poses are available for Stage 9." }

        val faceCount = mesh.faces.size
        val bestScore = DoubleArray(faceCount) { -1.0 }
        val bestCamera = IntArray(faceCount) { -1 }
        val bestUv = Array(faceCount) { DoubleArray(6) }
        // v0.16 keeps the strict Stage 9 assignment as first choice, then records a
        // conservative fallback for faces where all three vertices project cleanly but one
        // vertex misses the coarse visibility cell test. This recovers edge-of-occluder faces
        // without allowing negative-depth, out-of-image, or back-facing geometry.
        val fallbackScore = DoubleArray(faceCount) { -1.0 }
        val fallbackCamera = IntArray(faceCount) { -1 }
        val fallbackUv = Array(faceCount) { DoubleArray(6) }
        val candidateByCamera = IntArray(poses.size)
        var visibleFaceCandidates = 0
        var fallbackFaceCandidates = 0
        val projectionFrames = arrayOfNulls<ProjectionFrame>(poses.size)

        poses.forEachIndexed cameraLoop@ { cameraOrdinal, pose ->
            val file = fileByName[pose.photo] ?: return@cameraLoop
            onProgress(
                0.30f + 0.62f * (cameraOrdinal.toFloat() / poses.size.coerceAtLeast(1)),
                "Stage 9 — assigning visible triangles in photo ${cameraOrdinal + 1}/${poses.size}"
            )
            val bitmap = ExifBitmapLoader.decodeScaled(file, COLOR_IMAGE_SIDE) ?: return@cameraLoop
            try {
                val width = bitmap.width
                val height = bitmap.height
                if (width <= 4 || height <= 4) return@cameraLoop
                val focal = estimateFocalPixels(file, width, height)
                val frame = buildProjectionFrame(mesh, pose, width, height, focal)
                projectionFrames[cameraOrdinal] = frame

                mesh.faces.forEachIndexed { faceIndex, face ->
                    val ids = intArrayOf(face.a, face.b, face.c)
                    if (ids.any { it !in mesh.vertices.indices }) return@forEachIndexed
                    // A geometric projection exists only when buildProjectionFrame accepted the
                    // vertex for positive depth, image bounds and front-facing orientation.
                    if (ids.any { !frame.z[it].isFinite() || !frame.u[it].isFinite() || !frame.v[it].isFinite() || frame.score[it] <= 0.0 }) return@forEachIndexed
                    val u0 = frame.u[face.a]; val v0 = frame.v[face.a]
                    val u1 = frame.u[face.b]; val v1 = frame.v[face.b]
                    val u2 = frame.u[face.c]; val v2 = frame.v[face.c]
                    val area2 = abs((u1 - u0) * (v2 - v0) - (v1 - v0) * (u2 - u0))
                    if (!area2.isFinite() || area2 < 1.0) return@forEachIndexed
                    val score = (frame.score[face.a] + frame.score[face.b] + frame.score[face.c]) / 3.0
                    if (!score.isFinite() || score <= 0.0) return@forEachIndexed
                    val visibleCount = ids.count { frame.visible[it] }
                    fun storeUv(target: DoubleArray) {
                        target[0] = (u0 / width).coerceIn(0.0, 1.0)
                        target[1] = (v0 / height).coerceIn(0.0, 1.0)
                        target[2] = (u1 / width).coerceIn(0.0, 1.0)
                        target[3] = (v1 / height).coerceIn(0.0, 1.0)
                        target[4] = (u2 / width).coerceIn(0.0, 1.0)
                        target[5] = (v2 / height).coerceIn(0.0, 1.0)
                    }
                    if (visibleCount == 3) {
                        candidateByCamera[cameraOrdinal]++
                        visibleFaceCandidates++
                        if (score > bestScore[faceIndex]) {
                            bestScore[faceIndex] = score
                            bestCamera[faceIndex] = cameraOrdinal
                            storeUv(bestUv[faceIndex])
                        }
                    } else if (visibleCount >= FALLBACK_MIN_VISIBLE_VERTICES &&
                        area2 >= FALLBACK_MIN_PROJECTED_AREA2 && score >= FALLBACK_MIN_FACE_SCORE) {
                        fallbackFaceCandidates++
                        if (score > fallbackScore[faceIndex]) {
                            fallbackScore[faceIndex] = score
                            fallbackCamera[faceIndex] = cameraOrdinal
                            storeUv(fallbackUv[faceIndex])
                        }
                    }
                }
            } finally {
                bitmap.recycle()
            }
        }

        onProgress(0.94f, "Stage 9 — finalizing strict/fallback assignments…")
        val selectedCamera = IntArray(faceCount) { -1 }
        val selectedUv = Array(faceCount) { DoubleArray(6) }
        val selectedScore = DoubleArray(faceCount) { -1.0 }
        var fallbackAssignments = 0

        for (faceIndex in 0 until faceCount) {
            val strictCamera = bestCamera[faceIndex]
            val useFallback = strictCamera !in poses.indices && fallbackCamera[faceIndex] in poses.indices
            val cameraOrdinal = if (useFallback) fallbackCamera[faceIndex] else strictCamera
            if (cameraOrdinal !in poses.indices) continue
            selectedCamera[faceIndex] = cameraOrdinal
            val uv = if (useFallback) fallbackUv[faceIndex] else bestUv[faceIndex]
            uv.copyInto(selectedUv[faceIndex])
            selectedScore[faceIndex] = if (useFallback) fallbackScore[faceIndex] else bestScore[faceIndex]
            if (useFallback) fallbackAssignments++
        }

        // v0.17 conservative neighbor-consistency pass.
        // Only faces that still have no source are considered. A source photo must already be
        // chosen by at least two edge-neighbor faces from the strict/v0.16 result, and the missing
        // face must still project cleanly/front-facing into that same camera. We deliberately do
        // not let newly recovered faces vote, preventing chain propagation across uncertain areas.
        onProgress(0.965f, "Stage 9 — checking neighbor-consistent recovery…")
        val edgeFaces = HashMap<Long, MutableList<Int>>()
        fun edgeKey(a0: Int, b0: Int): Long {
            val a = min(a0, b0)
            val b = max(a0, b0)
            return (a.toLong() shl 32) xor (b.toLong() and 0xffffffffL)
        }
        mesh.faces.forEachIndexed { faceIndex, face ->
            val edges = arrayOf(
                edgeKey(face.a, face.b),
                edgeKey(face.b, face.c),
                edgeKey(face.c, face.a)
            )
            edges.forEach { key -> edgeFaces.getOrPut(key) { ArrayList(2) }.add(faceIndex) }
        }
        val neighborFaces = Array(faceCount) { LinkedHashSet<Int>() }
        edgeFaces.values.forEach { facesOnEdge ->
            if (facesOnEdge.size < 2) return@forEach
            for (i in facesOnEdge.indices) {
                for (j in facesOnEdge.indices) {
                    if (i != j) neighborFaces[facesOnEdge[i]].add(facesOnEdge[j])
                }
            }
        }
        val anchorCamera = selectedCamera.copyOf()
        var continuityAssignments = 0
        var continuityCandidates = 0
        for (faceIndex in 0 until faceCount) {
            if (selectedCamera[faceIndex] in poses.indices) continue
            val votes = HashMap<Int, Int>()
            neighborFaces[faceIndex].forEach { neighbor ->
                val camera = anchorCamera[neighbor]
                if (camera in poses.indices) votes[camera] = (votes[camera] ?: 0) + 1
            }
            val candidateCameras = votes.entries
                .filter { it.value >= CONTINUITY_MIN_NEIGHBOR_VOTES }
                .sortedWith(compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
            if (candidateCameras.isEmpty()) continue

            val face = mesh.faces[faceIndex]
            val ids = intArrayOf(face.a, face.b, face.c)
            var chosenCamera = -1
            var chosenScore = -1.0
            var chosenVotes = 0
            val chosenUv = DoubleArray(6)
            for ((cameraOrdinal, voteCount) in candidateCameras) {
                val frame = projectionFrames.getOrNull(cameraOrdinal) ?: continue
                if (ids.any { it !in mesh.vertices.indices }) continue
                if (ids.any { !frame.z[it].isFinite() || !frame.u[it].isFinite() || !frame.v[it].isFinite() || frame.score[it] <= 0.0 }) continue
                val u0 = frame.u[face.a]; val v0 = frame.v[face.a]
                val u1 = frame.u[face.b]; val v1 = frame.v[face.b]
                val u2 = frame.u[face.c]; val v2 = frame.v[face.c]
                val area2 = abs((u1 - u0) * (v2 - v0) - (v1 - v0) * (u2 - u0))
                val score = (frame.score[face.a] + frame.score[face.b] + frame.score[face.c]) / 3.0
                val visibleCount = ids.count { frame.visible[it] }
                if (!area2.isFinite() || area2 < CONTINUITY_MIN_PROJECTED_AREA2) continue
                if (!score.isFinite() || score < CONTINUITY_MIN_FACE_SCORE) continue
                if (visibleCount < CONTINUITY_MIN_VISIBLE_VERTICES) continue
                continuityCandidates++
                if (voteCount > chosenVotes || (voteCount == chosenVotes && score > chosenScore)) {
                    chosenVotes = voteCount
                    chosenCamera = cameraOrdinal
                    chosenScore = score
                    chosenUv[0] = (u0 / frame.width).coerceIn(0.0, 1.0)
                    chosenUv[1] = (v0 / frame.height).coerceIn(0.0, 1.0)
                    chosenUv[2] = (u1 / frame.width).coerceIn(0.0, 1.0)
                    chosenUv[3] = (v1 / frame.height).coerceIn(0.0, 1.0)
                    chosenUv[4] = (u2 / frame.width).coerceIn(0.0, 1.0)
                    chosenUv[5] = (v2 / frame.height).coerceIn(0.0, 1.0)
                }
            }
            if (chosenCamera in poses.indices) {
                selectedCamera[faceIndex] = chosenCamera
                chosenUv.copyInto(selectedUv[faceIndex])
                selectedScore[faceIndex] = chosenScore
                continuityAssignments++
            }
        }

        val selectedByCamera = IntArray(poses.size)
        val assignments = ArrayList<FaceTextureAssignment>()
        for (faceIndex in 0 until faceCount) {
            val cameraOrdinal = selectedCamera[faceIndex]
            if (cameraOrdinal !in poses.indices) continue
            selectedByCamera[cameraOrdinal]++
            val uv = selectedUv[faceIndex]
            assignments += FaceTextureAssignment(
                faceIndex = faceIndex,
                photo = poses[cameraOrdinal].photo,
                u0 = uv[0], v0 = uv[1],
                u1 = uv[2], v1 = uv[3],
                u2 = uv[4], v2 = uv[5],
                score = selectedScore[faceIndex]
            )
        }
        val contributions = poses.mapIndexed { index, pose ->
            FaceTextureCameraContribution(
                photo = pose.photo,
                visibleCandidateFaces = candidateByCamera[index],
                selectedFaces = selectedByCamera[index],
                poseRecovered = true
            )
        }
        val assigned = assignments.size
        val unassigned = faceCount - assigned
        val coverage = if (faceCount > 0) assigned * 100.0 / faceCount else 0.0
        val camerasUsed = contributions.count { it.selectedFaces > 0 }
        val ready = assigned >= max(100, (faceCount * 0.20).toInt()) && camerasUsed >= 2
        val warnings = mutableListOf<String>()
        warnings += "v0.17.0 Stage 9 keeps strict visibility assignments first, then the v0.16 two-of-three visibility fallback, then a neighbor-consistency pass for still-unassigned faces."
        warnings += "Visibility fallback used $fallbackAssignments assignment(s) from $fallbackFaceCandidates relaxed candidate(s); strict assignments always take priority."
        warnings += "Neighbor-consistency recovery used $continuityAssignments assignment(s) from $continuityCandidates validated candidate(s). It requires at least $CONTINUITY_MIN_NEIGHBOR_VOTES already-assigned edge neighbors to agree on the same source photo; recovered faces do not vote for other faces."
        warnings += if (CameraCalibrationManager.activeProfile() != null) "v0.26 Stage 9 source-photo projection uses calibrated fx/fy/cx/cy plus the saved lens-distortion coefficients." else "No compatible active calibration; Stage 9 projection uses the fallback pinhole model."
        warnings += "Recovered ${recovered.recoveredOrientationLinks}/${(recovered.connectedCameraCount - 1).coerceAtLeast(0)} camera orientation link(s), including ${recovered.bridgedOrientationLinks} bridge(s), with ${poses.size}/${recovered.connectedCameraCount} camera poses available."
        if (coverage < 70.0) warnings += "Only ${"%.1f".format(coverage)}% of triangles have a current source-photo assignment. A later atlas build should preserve unassigned faces as untextured rather than inventing image content."

        onProgress(1f, "Stage 9 texture-source assignment complete")
        TextureSourceAssignmentReport(
            engine = "OpenCV distortion-aware visibility-refined + neighbor-consistent source assignment v0.26.0",
            sourceMeshVertices = mesh.vertices.size,
            sourceMeshFaces = faceCount,
            connectedCameras = recovered.connectedCameraCount,
            recoveredCameraPoses = poses.size,
            recoveredOrientationLinks = recovered.recoveredOrientationLinks,
            bridgedOrientationLinks = recovered.bridgedOrientationLinks,
            camerasUsed = camerasUsed,
            visibleFaceCandidates = visibleFaceCandidates,
            assignedFaces = assigned,
            unassignedFaces = unassigned,
            faceCoveragePercent = coverage,
            assignments = assignments,
            cameraContributions = contributions,
            warnings = warnings,
            readyForAtlas = ready
        )
    }

    private fun recoverCameraSet(
        files: List<File>,
        multi: MultiViewReconstructionReport,
        bundle: BundleAdjustmentReport,
        onProgress: (Float, String) -> Unit
    ): RecoveredCameraSet {
        val fileByName = files.associateBy { it.name }
        val connected = multi.cameras.filter { it.connected }.sortedBy { it.index }
        require(connected.size >= 3) { "At least three connected cameras are required." }
        val refinedCenters = bundle.cameras.associateBy { it.index }
        val globalR = HashMap<Int, DoubleArray>()
        globalR[connected.first().index] = identity3()
        var recoveredLinks = 0
        var bridgedLinks = 0
        var attemptedBridges = 0

        for (targetOrdinal in 1 until connected.size) {
            val target = connected[targetOrdinal]
            val targetFile = fileByName[target.photo] ?: continue
            onProgress(
                targetOrdinal.toFloat() / (connected.size - 1).coerceAtLeast(1),
                "Stage 8 — recovering camera orientation $targetOrdinal/${connected.size - 1}"
            )
            val sourceOrdinals = buildList {
                val immediate = targetOrdinal - 1
                if (globalR.containsKey(connected[immediate].index)) add(immediate)
                for (gap in 2..MAX_BRIDGE_GAP) {
                    val ordinal = targetOrdinal - gap
                    if (ordinal >= 0 && globalR.containsKey(connected[ordinal].index)) add(ordinal)
                }
            }.distinct()
            var chosenSourceOrdinal = -1
            var chosenPose: RelativePose? = null
            for (sourceOrdinal in sourceOrdinals) {
                val source = connected[sourceOrdinal]
                val sourceFile = fileByName[source.photo] ?: continue
                if (sourceOrdinal != targetOrdinal - 1) attemptedBridges++
                val relative = recoverRelativePose(sourceFile, targetFile).getOrNull() ?: continue
                chosenSourceOrdinal = sourceOrdinal
                chosenPose = relative
                break
            }
            val relative = chosenPose ?: continue
            val sourceR = globalR[connected[chosenSourceOrdinal].index] ?: continue
            globalR[target.index] = multiply3(relative.r, sourceR)
            recoveredLinks++
            if (chosenSourceOrdinal != targetOrdinal - 1) bridgedLinks++
        }

        val poses = connected.mapNotNull { cameraSummary ->
            val r = globalR[cameraSummary.index] ?: return@mapNotNull null
            val centerSummary = refinedCenters[cameraSummary.index] ?: return@mapNotNull null
            val center = SparsePoint(centerSummary.x, centerSummary.y, centerSummary.z)
            val rc = multiply3Vec(r, doubleArrayOf(center.x, center.y, center.z))
            CameraPose(
                index = cameraSummary.index,
                photo = cameraSummary.photo,
                r = r,
                t = doubleArrayOf(-rc[0], -rc[1], -rc[2]),
                center = center
            )
        }
        return RecoveredCameraSet(
            poses = poses,
            connectedCameraCount = connected.size,
            recoveredOrientationLinks = recoveredLinks,
            bridgedOrientationLinks = bridgedLinks,
            attemptedBridges = attemptedBridges
        )
    }

    private fun buildProjectionFrame(
        mesh: SurfaceMeshReport,
        pose: CameraPose,
        width: Int,
        height: Int,
        focal: Double
    ): ProjectionFrame {
        val model = OpenCvCalibrationGeometry.model(width, height, focal)
        try {
            val n = mesh.vertices.size
            val u = DoubleArray(n) { Double.NaN }
            val v = DoubleArray(n) { Double.NaN }
            val z = DoubleArray(n) { Double.NaN }
            val score = DoubleArray(n) { -1.0 }
            val visible = BooleanArray(n)
            val gridW = ((width + VISIBILITY_CELL_PX - 1) / VISIBILITY_CELL_PX).coerceAtLeast(1)
            val gridH = ((height + VISIBILITY_CELL_PX - 1) / VISIBILITY_CELL_PX).coerceAtLeast(1)
            val minDepth = DoubleArray(gridW * gridH) { Double.POSITIVE_INFINITY }
            val cx = model.cx
            val cy = model.cy
            val halfDiag = sqrt(max(cx, width - cx) * max(cx, width - cx) + max(cy, height - cy) * max(cy, height - cy)).coerceAtLeast(1.0)
            val scaleReference = (mesh.maxAcceptedEdge * 8.0).coerceAtLeast(1e-6)
            var geometric = 0

            mesh.vertices.forEachIndexed { index, vertex ->
                val pc = worldToCamera(vertex, pose)
                val depth = pc[2]
                if (!depth.isFinite() || depth <= 1e-5) return@forEachIndexed
                val projected = OpenCvCalibrationGeometry.projectToSource(pc[0], pc[1], depth, model) ?: return@forEachIndexed
                val px = projected.x
                val py = projected.y
                if (!px.isFinite() || !py.isFinite() || px < 2.0 || py < 2.0 || px > width - 3.0 || py > height - 3.0) return@forEachIndexed
                val facing = if (index < mesh.vertexNormals.size) facingScore(mesh.vertexNormals[index], vertex, pose.center) else 0.55
                if (facing < MIN_FACING) return@forEachIndexed
                val centerDistance = sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy)) / halfDiag
                val centerScore = (1.0 - centerDistance).coerceIn(0.0, 1.0)
                val dx = pose.center.x - vertex.x
                val dy = pose.center.y - vertex.y
                val dz = pose.center.z - vertex.z
                val distance = sqrt(dx * dx + dy * dy + dz * dz)
                val distanceScore = 1.0 / (1.0 + distance / scaleReference)
                val candidateScore = (0.68 * facing + 0.22 * centerScore + 0.10 * distanceScore).coerceIn(0.0, 1.0)
                if (candidateScore <= 0.0) return@forEachIndexed
                u[index] = px; v[index] = py; z[index] = depth; score[index] = candidateScore
                geometric++
                val gx = (px.toInt() / VISIBILITY_CELL_PX).coerceIn(0, gridW - 1)
                val gy = (py.toInt() / VISIBILITY_CELL_PX).coerceIn(0, gridH - 1)
                val cell = gy * gridW + gx
                if (depth < minDepth[cell]) minDepth[cell] = depth
            }

            var rejected = 0
            for (index in 0 until n) {
                val depth = z[index]
                if (!depth.isFinite()) continue
                val gx = (u[index].toInt() / VISIBILITY_CELL_PX).coerceIn(0, gridW - 1)
                val gy = (v[index].toInt() / VISIBILITY_CELL_PX).coerceIn(0, gridH - 1)
                val nearest = minDepth[gy * gridW + gx]
                val tolerance = max(mesh.maxAcceptedEdge * VISIBILITY_EDGE_FACTOR, depth * VISIBILITY_DEPTH_FRACTION)
                if (depth <= nearest + tolerance) visible[index] = true else rejected++
            }
            return ProjectionFrame(width, height, u, v, z, score, visible, geometric, rejected)
        } finally {
            model.close()
        }
    }

    private fun recoverRelativePose(first: File, second: File): Result<RelativePose> = runCatching {
        val left = ExifBitmapLoader.decodeScaled(first, POSE_IMAGE_SIDE) ?: error("Could not decode ${first.name}.")
        var right = ExifBitmapLoader.decodeScaled(second, POSE_IMAGE_SIDE) ?: run { left.recycle(); error("Could not decode ${second.name}.") }
        val leftRgba = Mat(); val rightRgba = Mat(); val leftGray = Mat(); val rightGray = Mat()
        val kp1Mat = MatOfKeyPoint(); val kp2Mat = MatOfKeyPoint(); val d1 = Mat(); val d2 = Mat()
        val mask = Mat(); val r = Mat(); val t = Mat(); val tri = Mat()
        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        try {
            if (right.width != left.width || right.height != left.height) {
                val resized = Bitmap.createBitmap(left.width, left.height, Bitmap.Config.ARGB_8888)
                val src = Mat(); val dst = Mat()
                try {
                    Utils.bitmapToMat(right, src)
                    Imgproc.resize(src, dst, Size(left.width.toDouble(), left.height.toDouble()))
                    Utils.matToBitmap(dst, resized)
                } finally {
                    src.release(); dst.release(); right.recycle()
                }
                right = resized
            }
            Utils.bitmapToMat(left, leftRgba); Utils.bitmapToMat(right, rightRgba)
            Imgproc.cvtColor(leftRgba, leftGray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.cvtColor(rightRgba, rightGray, Imgproc.COLOR_RGBA2GRAY)
            orb.detectAndCompute(leftGray, Mat(), kp1Mat, d1)
            orb.detectAndCompute(rightGray, Mat(), kp2Mat, d2)
            require(!d1.empty() && !d2.empty()) { "Not enough detail to recover a texture camera pose." }
            val kp1 = kp1Mat.toArray(); val kp2 = kp2Mat.toArray()
            val ratio = ratioMatches(matcher, d1, d2)
            require(ratio.size >= MIN_RATIO_MATCHES) { "Only ${ratio.size} ratio matches." }
            val pts1 = MatOfPoint2f(*ratio.map { kp1[it.queryIdx].pt }.toTypedArray())
            val pts2 = MatOfPoint2f(*ratio.map { kp2[it.trainIdx].pt }.toTypedArray())
            val focal = (estimateFocalPixels(first, left.width, left.height) + estimateFocalPixels(second, right.width, right.height)) / 2.0
            val geometryModel = OpenCvCalibrationGeometry.model(left.width, left.height, focal)
            val geometryPts1 = OpenCvCalibrationGeometry.undistortPixelPoints(pts1, geometryModel)
            val geometryPts2 = OpenCvCalibrationGeometry.undistortPixelPoints(pts2, geometryModel)
            try {
                val e = Calib3d.findEssentialMat(geometryPts1, geometryPts2, geometryModel.k, Calib3d.RANSAC, 0.999, RANSAC_THRESHOLD_PX, 1000, mask)
                require(!e.empty()) { "Essential matrix failed." }
                val inliers = Calib3d.recoverPose(e, geometryPts1, geometryPts2, geometryModel.k, r, t, 50.0, mask, tri)
                e.release()
                require(inliers >= MIN_POSE_INLIERS) { "Only $inliers recovered-pose inliers." }
                RelativePose(mat3(r), inliers)
            } finally {
                pts1.release(); pts2.release(); geometryPts1.release(); geometryPts2.release(); geometryModel.close()
            }
        } finally {
            left.recycle(); right.recycle(); leftRgba.release(); rightRgba.release(); leftGray.release(); rightGray.release()
            kp1Mat.release(); kp2Mat.release(); d1.release(); d2.release(); mask.release(); r.release(); t.release(); tri.release()
            orb.clear(); matcher.clear()
        }
    }

    private fun ratioMatches(matcher: DescriptorMatcher, d1: Mat, d2: Mat): List<org.opencv.core.DMatch> {
        val knn = mutableListOf<MatOfDMatch>()
        matcher.knnMatch(d1, d2, knn, 2)
        val out = mutableListOf<org.opencv.core.DMatch>()
        knn.forEach { set ->
            val m = set.toArray()
            if (m.size >= 2 && m[0].distance < RATIO_TEST * m[1].distance) out += m[0]
            set.release()
        }
        return out
    }

    private fun estimateFocalPixels(file: File, width: Int, height: Int): Double {
        CameraCalibrationManager.focalEstimate(width, height)?.let { return it.first }
        val focal35 = runCatching {
            ExifInterface(file).getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
        }.getOrDefault(0)
        if (focal35 > 0) {
            val diagonal = sqrt(width.toDouble() * width + height.toDouble() * height)
            return focal35.toDouble() * diagonal / 43.2666153
        }
        return 0.9 * max(width, height)
    }

    private fun cameraMatrix(width: Int, height: Int, focal: Double): Mat {
        CameraCalibrationManager.intrinsicsFor(width, height)?.let { intr ->
            return Mat.eye(3, 3, CvType.CV_64F).apply {
                put(0, 0, intr.fx); put(1, 1, intr.fy); put(0, 2, intr.cx); put(1, 2, intr.cy)
            }
        }
        return Mat.eye(3, 3, CvType.CV_64F).apply {
            put(0, 0, focal); put(1, 1, focal); put(0, 2, width / 2.0); put(1, 2, height / 2.0)
        }
    }

    private fun worldToCamera(point: SparsePoint, pose: CameraPose): DoubleArray {
        val p = multiply3Vec(pose.r, doubleArrayOf(point.x, point.y, point.z))
        return doubleArrayOf(p[0] + pose.t[0], p[1] + pose.t[1], p[2] + pose.t[2])
    }

    private fun facingScore(normal: SparsePoint, vertex: SparsePoint, camera: SparsePoint): Double {
        val nl = sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z)
        if (nl <= 1e-9) return 0.55
        val vx = camera.x - vertex.x
        val vy = camera.y - vertex.y
        val vz = camera.z - vertex.z
        val vl = sqrt(vx * vx + vy * vy + vz * vz)
        if (vl <= 1e-9) return 0.0
        return ((normal.x * vx + normal.y * vy + normal.z * vz) / (nl * vl)).coerceIn(-1.0, 1.0)
    }

    private fun sample3x3(bitmap: Bitmap, x: Int, y: Int): Int {
        var r = 0; var g = 0; var b = 0; var count = 0
        for (dy in -1..1) for (dx in -1..1) {
            val px = (x + dx).coerceIn(0, bitmap.width - 1)
            val py = (y + dy).coerceIn(0, bitmap.height - 1)
            val c = bitmap.getPixel(px, py)
            r += Color.red(c); g += Color.green(c); b += Color.blue(c); count++
        }
        return Color.rgb(r / count, g / count, b / count)
    }

    private fun insertSample(scores: DoubleArray, colors: IntArray, photos: IntArray, score: Double, color: Int, photoIndex: Int) {
        var target = -1
        for (i in scores.indices) {
            if (score > scores[i]) { target = i; break }
        }
        if (target < 0) return
        for (i in scores.lastIndex downTo target + 1) {
            scores[i] = scores[i - 1]
            colors[i] = colors[i - 1]
            photos[i] = photos[i - 1]
        }
        scores[target] = score
        colors[target] = color
        photos[target] = photoIndex
    }

    private fun mat3(mat: Mat): DoubleArray = DoubleArray(9).also { out ->
        for (r in 0..2) for (c in 0..2) out[r * 3 + c] = mat.get(r, c)?.getOrNull(0) ?: if (r == c) 1.0 else 0.0
    }

    private fun identity3(): DoubleArray = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

    private fun multiply3(a: DoubleArray, b: DoubleArray): DoubleArray {
        val out = DoubleArray(9)
        for (r in 0..2) for (c in 0..2) {
            out[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c]
        }
        return out
    }

    private fun multiply3Vec(a: DoubleArray, v: DoubleArray): DoubleArray = doubleArrayOf(
        a[0] * v[0] + a[1] * v[1] + a[2] * v[2],
        a[3] * v[0] + a[4] * v[1] + a[5] * v[2],
        a[6] * v[0] + a[7] * v[1] + a[8] * v[2]
    )
}
