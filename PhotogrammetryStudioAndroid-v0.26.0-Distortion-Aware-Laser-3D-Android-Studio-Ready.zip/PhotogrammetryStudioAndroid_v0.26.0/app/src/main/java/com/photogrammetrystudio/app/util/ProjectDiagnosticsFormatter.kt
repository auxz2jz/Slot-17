package com.photogrammetrystudio.app.util

import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.DenseFusionReport
import com.photogrammetrystudio.app.model.DenseReconstructionReport
import com.photogrammetrystudio.app.model.FeatureMatchReport
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.PhotoProject
import com.photogrammetrystudio.app.model.PhotoSetReport
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset
import com.photogrammetrystudio.app.model.ReconstructionStatus
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureProjectionReport
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import com.photogrammetrystudio.app.model.TextureAtlasReport
import java.text.DateFormat
import java.util.Date

/**
 * Produces the single text diagnostic the user normally needs to export/upload for one project.
 * Geometry itself (PLY/OBJ) intentionally stays separate because including tens of thousands of
 * coordinates would make the diagnostic unreadable and unnecessarily large.
 */
fun buildCombinedProjectDiagnostics(
    appVersion: String,
    project: PhotoProject,
    photoSetReport: PhotoSetReport?,
    reconstruction: ReconstructionStatus,
    feature: FeatureMatchReport?,
    sparse: SparseReconstructionReport?,
    multi: MultiViewReconstructionReport?,
    bundle: BundleAdjustmentReport?,
    dense: DenseReconstructionReport?,
    fusion: DenseFusionReport?,
    mesh: SurfaceMeshReport?,
    texture: TextureProjectionReport?,
    textureSources: TextureSourceAssignmentReport?,
    textureAtlas: TextureAtlasReport?
): String = buildString {
    appendLine("3D Scan Studio - Combined Project Diagnostics")
    appendLine("App version: $appVersion")
    appendLine("Project: ${project.name}")
    appendLine("Project ID: ${project.id}")
    appendLine("Scan mode: ${project.scanMode.displayName}")
    appendLine("Photos currently in project: ${project.photos.size}")
    appendLine("Generated: ${DateFormat.getDateTimeInstance().format(Date())}")
    appendLine("Current pipeline state: ${reconstruction.state} | progress=${"%.1f".format(reconstruction.progress * 100.0)}% | ${reconstruction.message}")
    appendLine("Geometry note: point-cloud/mesh coordinates are not embedded here; export PLY/OBJ separately only when geometry inspection is needed.")
    CameraCalibrationManager.activeProfile()?.let { p ->
        appendLine("Active camera calibration: ${p.label} | target ${PhotoCalibrationTargetPreset.fromId(p.targetPresetId).displayName} | ${p.imageWidth}x${p.imageHeight} | RMS ${"%.4f".format(p.rmsReprojectionError)} px | fx ${"%.2f".format(p.fx)} | fy ${"%.2f".format(p.fy)} | ready=${p.readyForUse}")
        appendLine("Calibration distortion: k1=${"%.6f".format(p.k1)} k2=${"%.6f".format(p.k2)} p1=${"%.6f".format(p.p1)} p2=${"%.6f".format(p.p2)} k3=${"%.6f".format(p.k3)} | v0.26 geometry stages apply compatible measured distortion")
    } ?: appendLine("Active camera calibration: none; reconstruction uses EXIF/fallback intrinsics.")
    appendLine()

    section("Quick Check / Photo Set") {
        if (photoSetReport == null) {
            appendLine("No current Quick Check result.")
        } else {
            appendLine("Photos checked: ${photoSetReport.photoCount}")
            appendLine("Ready for reconstruction: ${photoSetReport.readyForReconstruction}")
            appendLine("Warnings:")
            if (photoSetReport.warnings.isEmpty()) appendLine("- None") else photoSetReport.warnings.forEach { appendLine("- $it") }
        }
    }

    section("Stage 1 — Feature Matching") {
        if (feature == null) appendLine("No saved Stage 1 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("feature-match", project.id, feature)}")
            appendLine("Engine: ${feature.engine}")
            appendLine("Photos analyzed: ${feature.analyzedPhotos}")
            appendLine("Detected keypoints: ${feature.totalKeypoints}")
            appendLine("Usable/strong adjacent pairs: ${feature.strongOrUsablePairs} / ${feature.adjacentPairs.size}")
            appendLine("Ready for sparse reconstruction: ${feature.readyForSparseReconstruction}")
            appendLine("Warnings:")
            if (feature.warnings.isEmpty()) appendLine("- None") else feature.warnings.forEach { appendLine("- $it") }
            appendLine("Adjacent pair results:")
            feature.adjacentPairs.forEachIndexed { index, pair ->
                appendLine("${index + 1}. ${pair.firstPhoto} -> ${pair.secondPhoto} | keypoints ${pair.firstKeypoints}/${pair.secondKeypoints} | good matches ${pair.goodMatches} | ${pair.quality}")
            }
        }
    }

    section("Stage 2 — Sparse Reconstruction") {
        if (sparse == null) appendLine("No saved Stage 2 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("sparse", project.id, sparse)}")
            appendLine("Engine: ${sparse.engine}")
            appendLine("Best pair: ${sparse.firstPhoto} -> ${sparse.secondPhoto}")
            appendLine("Ratio-test matches: ${sparse.ratioMatches}")
            appendLine("RANSAC inliers: ${sparse.ransacInliers}")
            appendLine("Recovered-pose inliers: ${sparse.poseInliers}")
            appendLine("Triangulated 3D points: ${sparse.triangulatedPoints}")
            appendLine("Estimated focal length: ${"%.1f".format(sparse.focalPixels)} px")
            appendLine("Intrinsics source: ${sparse.intrinsicsSource}")
            appendLine("Relative rotation: ${"%.2f".format(sparse.relativeRotationDegrees)} degrees")
            appendLine("Ready for multi-view: ${sparse.readyForMultiView}")
            appendLine("Warnings:")
            if (sparse.warnings.isEmpty()) appendLine("- None") else sparse.warnings.forEach { appendLine("- $it") }
            appendLine("Adjacent-pair geometry checks:")
            sparse.pairEvaluations.forEachIndexed { index, item ->
                appendLine("${index + 1}. ${item.firstPhoto} -> ${item.secondPhoto} | ratio ${item.ratioMatches} | RANSAC ${item.ransacInliers} | pose ${item.poseInliers}")
            }
        }
    }

    section("Stage 3 — Multi-View Reconstruction") {
        if (multi == null) appendLine("No saved Stage 3 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("multiview", project.id, multi)}")
            appendLine("Engine: ${multi.engine}")
            appendLine("Photos requested: ${multi.photosRequested}")
            appendLine("Connected cameras: ${multi.connectedCameras}")
            appendLine("Connected adjacent pairs: ${multi.connectedPairs}")
            appendLine("Raw triangulated points: ${multi.rawTriangulatedPoints}")
            appendLine("Combined/downsampled points: ${multi.combinedPoints}")
            appendLine("Average focal estimate: ${"%.1f".format(multi.focalPixels)} px")
            appendLine("Intrinsics source: ${multi.intrinsicsSource}")
            appendLine("Ready for bundle adjustment: ${multi.readyForBundleAdjustment}")
            appendLine("Warnings:")
            if (multi.warnings.isEmpty()) appendLine("- None") else multi.warnings.forEach { appendLine("- $it") }
            appendLine("Camera path:")
            multi.cameras.forEach { camera ->
                appendLine("${camera.index}. ${camera.photo} | connected=${camera.connected} | center=(${"%.4f".format(camera.x)}, ${"%.4f".format(camera.y)}, ${"%.4f".format(camera.z)})")
            }
            appendLine("Adjacent-pair pose diagnostics:")
            multi.pairEvaluations.forEachIndexed { index, item ->
                appendLine("${index + 1}. ${item.firstPhoto} -> ${item.secondPhoto} | ratio ${item.ratioMatches} | RANSAC ${item.ransacInliers} | pose ${item.poseInliers} | triangulated ${item.triangulatedPoints} | connected=${item.connected} | rotation=${"%.2f".format(item.relativeRotationDegrees)} deg")
            }
        }
    }

    section("Stage 4 — Bundle Refinement") {
        if (bundle == null) appendLine("No saved Stage 4 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("bundle", project.id, bundle)}")
            appendLine("Engine: ${bundle.engine}")
            appendLine("Connected cameras refined: ${bundle.connectedCameras}")
            appendLine("3+ view tracks built: ${bundle.tracksBuilt}")
            appendLine("Tracks selected for optimization: ${bundle.tracksUsed}")
            appendLine("Observations used after filtering: ${bundle.observationsUsed}")
            appendLine("Initial shared-track points: ${bundle.initialPoints}")
            appendLine("Refined points: ${bundle.refinedPoints}")
            appendLine("Initial RMS reprojection error: ${"%.4f".format(bundle.initialRmsPixels)} px")
            appendLine("Final RMS reprojection error: ${"%.4f".format(bundle.finalRmsPixels)} px")
            appendLine("Optimization iterations: ${bundle.iterations}")
            appendLine("Ready for dense reconstruction: ${bundle.readyForDenseReconstruction}")
            appendLine("Warnings / notes:")
            if (bundle.warnings.isEmpty()) appendLine("- None") else bundle.warnings.forEach { appendLine("- $it") }
            appendLine("Refined camera centers:")
            bundle.cameras.forEach { camera ->
                appendLine("${camera.index}. ${camera.photo} | center=(${"%.4f".format(camera.x)}, ${"%.4f".format(camera.y)}, ${"%.4f".format(camera.z)})")
            }
        }
    }

    section("Stage 5 — Dense Stereo") {
        if (dense == null) appendLine("No saved Stage 5 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("dense", project.id, dense)}")
            appendLine("Engine: ${dense.engine}")
            appendLine("Pair: ${dense.firstPhoto} -> ${dense.secondPhoto}")
            appendLine("Working image size: ${dense.width} x ${dense.height}")
            appendLine("Ratio-test matches: ${dense.ratioMatches}")
            appendLine("RANSAC inliers: ${dense.ransacInliers}")
            appendLine("Recovered-pose inliers: ${dense.poseInliers}")
            appendLine("Observed rectified inlier disparity: ${"%.2f".format(dense.observedDisparityLow)} .. ${"%.2f".format(dense.observedDisparityHigh)} px")
            appendLine("Observed median disparity: ${"%.2f".format(dense.observedDisparityMedian)} px")
            appendLine("Adaptive minimum disparity: ${dense.minDisparity}")
            appendLine("Stereo disparity search width: ${dense.numDisparities}")
            appendLine("SGBM block size: ${dense.blockSize}")
            appendLine("Valid disparity pixels: ${dense.validDisparityPixels}")
            appendLine("Sparse-depth-guided candidates: ${dense.geometryGuidedPoints}")
            appendLine("Filtered/exported dense points: ${dense.densePoints}")
            appendLine("Depth range (arbitrary scale): ${"%.4f".format(dense.minDepth)} .. ${"%.4f".format(dense.maxDepth)}")
            appendLine("Median depth: ${"%.4f".format(dense.medianDepth)}")
            appendLine("Ready for multi-pair dense fusion: ${dense.readyForDenseFusion}")
            appendLine("Warnings / notes:")
            if (dense.warnings.isEmpty()) appendLine("- None") else dense.warnings.forEach { appendLine("- $it") }
        }
    }

    section("Stage 6 — Dense Fusion") {
        if (fusion == null) appendLine("No saved Stage 6 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("dense-fusion", project.id, fusion)}")
            appendLine("Engine: ${fusion.engine}")
            appendLine("Photos requested: ${fusion.photosRequested}")
            appendLine("Connected cameras: ${fusion.connectedCameras}")
            appendLine("Eligible dense-pair candidates: ${fusion.candidatePairs}")
            appendLine("Dense pairs fused: ${fusion.pairsFused}")
            appendLine("Raw accepted pair points: ${fusion.rawDensePoints}")
            appendLine("Fused/downsampled points: ${fusion.fusedPoints}")
            appendLine("Ready for surface reconstruction: ${fusion.readyForSurfaceReconstruction}")
            appendLine("Warnings / notes:")
            if (fusion.warnings.isEmpty()) appendLine("- None") else fusion.warnings.forEach { appendLine("- $it") }
            appendLine("Selected pair diagnostics:")
            fusion.pairEvaluations.forEachIndexed { index, pair ->
                appendLine("${index + 1}. ${pair.firstPhoto} -> ${pair.secondPhoto} | pose ${pair.poseInliers} | median disparity ${"%.3f".format(pair.observedDisparityMedian)} px | valid disparity ${pair.validDisparityPixels} | local points ${pair.localDensePoints} | world points ${pair.fusedPoints} | accepted=${pair.accepted} | ${pair.reason}")
            }
        }
    }

    section("Stage 7 — Surface Mesh") {
        if (mesh == null) appendLine("No saved Stage 7 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("surface-mesh", project.id, mesh)}")
            appendLine("Engine: ${mesh.engine}")
            appendLine("Source fused points: ${mesh.sourcePoints}")
            appendLine("Mesh vertices: ${mesh.meshVertices}")
            appendLine("Triangles: ${mesh.triangles}")
            appendLine("Voxel size: ${"%.6f".format(mesh.voxelSize)}")
            appendLine("Maximum accepted local edge: ${"%.6f".format(mesh.maxAcceptedEdge)}")
            appendLine("Candidate triangles proposed: ${mesh.candidateTriangles}")
            appendLine("Cleanup-rejected faces: ${mesh.cleanupRejectedFaces}")
            appendLine("Unused vertices removed: ${mesh.unusedVerticesRemoved}")
            appendLine("Boundary edges: ${mesh.boundaryEdges}")
            appendLine("Closed loops before fill: ${mesh.closedLoopsBeforeFill}")
            appendLine("Closed loops filled: ${mesh.filledBoundaryLoops}")
            appendLine("Closed loops remaining: ${mesh.boundaryLoops}")
            appendLine("Hole-fill vertices added: ${mesh.holeFillAddedVertices}")
            appendLine("Hole-fill faces added: ${mesh.holeFillAddedFaces}")
            appendLine("Closed loops skipped by safety checks: ${mesh.skippedClosedLoops}")
            appendLine("Open/branched boundary components: ${mesh.openBoundaryChains}")
            appendLine("Boundary branch vertices: ${mesh.boundaryBranchVertices}")
            appendLine("Non-manifold edges: ${mesh.nonManifoldEdges}")
            appendLine("Retained surface components: ${mesh.surfaceComponents}")
            appendLine("Smoothing iterations: ${mesh.smoothingIterations}")
            appendLine("Smoothed interior vertices: ${mesh.smoothedVertices}")
            appendLine("Average smoothing displacement: ${"%.6f".format(mesh.averageSmoothingDisplacement)}")
            appendLine("Valid vertex normals: ${mesh.validVertexNormals}/${mesh.meshVertices}")
            appendLine("Ready for export: ${mesh.readyForExport}")
            appendLine("Warnings / notes:")
            if (mesh.warnings.isEmpty()) appendLine("- None") else mesh.warnings.forEach { appendLine("- $it") }
        }
    }

    section("Stage 8 — Photo Color Projection") {
        if (texture == null) appendLine("No saved Stage 8 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("texture-projection", project.id, texture)}")
            appendLine("Engine: ${texture.engine}")
            appendLine("Source mesh vertices: ${texture.sourceMeshVertices}")
            appendLine("Source mesh faces: ${texture.sourceMeshFaces}")
            appendLine("Photos requested: ${texture.photosRequested}")
            appendLine("Connected cameras: ${texture.connectedCameras}")
            appendLine("Recovered camera poses: ${texture.recoveredCameraPoses}")
            appendLine("Recovered orientation links: ${texture.recoveredOrientationLinks}")
            appendLine("Bridged orientation links: ${texture.bridgedOrientationLinks}")
            appendLine("Cameras used for best colors: ${texture.camerasUsed}")
            appendLine("Visibility-approved color candidates: ${texture.projectedCandidates}")
            appendLine("Visibility-rejected candidates: ${texture.visibilityRejectedCandidates}")
            appendLine("Colored vertices: ${texture.coloredVertices}")
            appendLine("Uncolored vertices: ${texture.uncoloredVertices}")
            appendLine("Color coverage: ${"%.2f".format(texture.coveragePercent)}%")
            appendLine("Average blended samples per colored vertex: ${"%.2f".format(texture.averageSamplesPerColoredVertex)}")
            appendLine("Ready for export: ${texture.readyForExport}")
            appendLine("Warnings / notes:")
            if (texture.warnings.isEmpty()) appendLine("- None") else texture.warnings.forEach { appendLine("- $it") }
            appendLine("Camera contributions:")
            texture.cameraContributions.forEachIndexed { index, item ->
                appendLine("${index + 1}. ${item.photo} | poseRecovered=${item.poseRecovered} | visibleProjected=${item.projectedVertices} | visibilityRejected=${item.visibilityRejectedVertices} | selectedBest=${item.selectedVertices}")
            }
        }
    }

    section("Stage 9 — Texture Source Assignment") {
        if (textureSources == null) appendLine("No saved Stage 9 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("texture-source", project.id, textureSources)}")
            appendLine("Engine: ${textureSources.engine}")
            appendLine("Source mesh vertices: ${textureSources.sourceMeshVertices}")
            appendLine("Source mesh faces: ${textureSources.sourceMeshFaces}")
            appendLine("Connected cameras: ${textureSources.connectedCameras}")
            appendLine("Recovered camera poses: ${textureSources.recoveredCameraPoses}")
            appendLine("Recovered orientation links: ${textureSources.recoveredOrientationLinks}")
            appendLine("Bridged orientation links: ${textureSources.bridgedOrientationLinks}")
            appendLine("Cameras used for triangle sources: ${textureSources.camerasUsed}")
            appendLine("Visible face candidates across cameras: ${textureSources.visibleFaceCandidates}")
            appendLine("Triangles assigned a source photo: ${textureSources.assignedFaces}")
            appendLine("Triangles without a source photo: ${textureSources.unassignedFaces}")
            appendLine("Triangle source coverage: ${"%.2f".format(textureSources.faceCoveragePercent)}%")
            appendLine("Ready for texture atlas: ${textureSources.readyForAtlas}")
            appendLine("Warnings / notes:")
            if (textureSources.warnings.isEmpty()) appendLine("- None") else textureSources.warnings.forEach { appendLine("- $it") }
            appendLine("Camera face contributions:")
            textureSources.cameraContributions.forEachIndexed { index, item ->
                appendLine("${index + 1}. ${item.photo} | poseRecovered=${item.poseRecovered} | visibleCandidates=${item.visibleCandidateFaces} | selectedFaces=${item.selectedFaces}")
            }
        }
    }

    section("Stage 10 — UV Texture Atlas") {
        if (textureAtlas == null) appendLine("No saved Stage 10 report.") else {
            appendLine("Report fingerprint: ${reportFingerprint("texture-atlas", project.id, textureAtlas)}")
            appendLine("Engine: ${textureAtlas.engine}")
            appendLine("Atlas size: ${textureAtlas.atlasWidth} x ${textureAtlas.atlasHeight}")
            appendLine("Packing mode: connected same-photo UV islands")
            appendLine("UV islands: ${textureAtlas.uvIslands}")
            appendLine("Largest UV island: ${textureAtlas.largestIslandFaces} face(s)")
            appendLine("Atlas occupancy: ${"%.2f".format(textureAtlas.atlasOccupancyPercent)}%")
            appendLine("Padding: ${textureAtlas.padding} px")
            appendLine("Source mesh vertices: ${textureAtlas.sourceMeshVertices}")
            appendLine("Source mesh faces: ${textureAtlas.sourceMeshFaces}")
            appendLine("Stage 9 assigned faces: ${textureAtlas.stage9AssignedFaces}")
            appendLine("Atlas-textured faces: ${textureAtlas.texturedFaces}")
            appendLine("Untextured faces preserved: ${textureAtlas.untexturedFaces}")
            appendLine("Texture-atlas face coverage: ${"%.2f".format(textureAtlas.textureCoveragePercent)}%")
            appendLine("Source photos used: ${textureAtlas.sourcePhotosUsed}")
            appendLine("Skipped missing-photo faces: ${textureAtlas.skippedMissingPhotos}")
            appendLine("Skipped rasterization faces: ${textureAtlas.skippedRasterizationFaces}")
            appendLine("Ready for export: ${textureAtlas.readyForExport}")
            appendLine("Warnings / notes:")
            if (textureAtlas.warnings.isEmpty()) appendLine("- None") else textureAtlas.warnings.forEach { appendLine("- $it") }
        }
    }
}

private inline fun StringBuilder.section(title: String, block: StringBuilder.() -> Unit) {
    appendLine("================================================================================")
    appendLine(title)
    appendLine("================================================================================")
    block()
    appendLine()
}
