package com.photogrammetrystudio.app

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.photogrammetrystudio.app.data.ProjectRepository
import com.photogrammetrystudio.app.engine.LocalNativeEngineStub
import com.photogrammetrystudio.app.engine.PhotogrammetryEngine
import com.photogrammetrystudio.app.model.PhotoProject
import com.photogrammetrystudio.app.model.FeatureMatchReport
import com.photogrammetrystudio.app.model.PhotoSetReport
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.CameraCalibrationProfile
import com.photogrammetrystudio.app.model.CameraCalibrationReport
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset
import com.photogrammetrystudio.app.model.LaserCalibrationTargetPreset
import com.photogrammetrystudio.app.model.LaserCalibrationPanelSide
import com.photogrammetrystudio.app.model.DenseReconstructionReport
import com.photogrammetrystudio.app.model.DenseFusionReport
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureProjectionReport
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import com.photogrammetrystudio.app.model.TextureAtlasReport
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import com.photogrammetrystudio.app.model.ReconstructionState
import com.photogrammetrystudio.app.model.ReconstructionStatus
import com.photogrammetrystudio.app.model.ScanMode
import com.photogrammetrystudio.app.model.LaserLineColor
import com.photogrammetrystudio.app.model.LaserLineReport
import com.photogrammetrystudio.app.model.LaserAnalysisRun
import com.photogrammetrystudio.app.model.LaserPlaneCalibrationReport
import com.photogrammetrystudio.app.util.PhotoSetAnalyzer
import com.photogrammetrystudio.app.util.OpenCvFeatureAnalyzer
import com.photogrammetrystudio.app.util.OpenCvSparseReconstructor
import com.photogrammetrystudio.app.util.OpenCvMultiViewReconstructor
import com.photogrammetrystudio.app.util.OpenCvBundleAdjuster
import com.photogrammetrystudio.app.util.OpenCvDenseStereoReconstructor
import com.photogrammetrystudio.app.util.OpenCvDenseFusionReconstructor
import com.photogrammetrystudio.app.util.LocalSurfaceMesher
import com.photogrammetrystudio.app.util.OpenCvTextureProjector
import com.photogrammetrystudio.app.util.TextureAtlasBuilder
import com.photogrammetrystudio.app.util.CameraCalibrationManager
import com.photogrammetrystudio.app.util.CalibrationTargetManager
import com.photogrammetrystudio.app.util.OpenCvCameraCalibrator
import com.photogrammetrystudio.app.util.LaserLineDetector
import com.photogrammetrystudio.app.util.LaserPlaneCalibrator
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ProjectRepository(application)
    private val engine: PhotogrammetryEngine = LocalNativeEngineStub()

    private val _projects = MutableStateFlow<List<PhotoProject>>(emptyList())
    val projects: StateFlow<List<PhotoProject>> = _projects.asStateFlow()

    private val _selectedProject = MutableStateFlow<PhotoProject?>(null)
    val selectedProject: StateFlow<PhotoProject?> = _selectedProject.asStateFlow()

    private val _report = MutableStateFlow<PhotoSetReport?>(null)
    val report: StateFlow<PhotoSetReport?> = _report.asStateFlow()

    private val _reconstruction = MutableStateFlow(ReconstructionStatus())
    val reconstruction: StateFlow<ReconstructionStatus> = _reconstruction.asStateFlow()

    private val _featureMatchReport = MutableStateFlow<FeatureMatchReport?>(null)
    val featureMatchReport: StateFlow<FeatureMatchReport?> = _featureMatchReport.asStateFlow()

    private val _sparseReport = MutableStateFlow<SparseReconstructionReport?>(null)
    val sparseReport: StateFlow<SparseReconstructionReport?> = _sparseReport.asStateFlow()

    private val _multiViewReport = MutableStateFlow<MultiViewReconstructionReport?>(null)
    val multiViewReport: StateFlow<MultiViewReconstructionReport?> = _multiViewReport.asStateFlow()

    private val _bundleReport = MutableStateFlow<BundleAdjustmentReport?>(null)
    val bundleReport: StateFlow<BundleAdjustmentReport?> = _bundleReport.asStateFlow()

    private val _denseReport = MutableStateFlow<DenseReconstructionReport?>(null)
    val denseReport: StateFlow<DenseReconstructionReport?> = _denseReport.asStateFlow()

    private val _denseFusionReport = MutableStateFlow<DenseFusionReport?>(null)
    val denseFusionReport: StateFlow<DenseFusionReport?> = _denseFusionReport.asStateFlow()

    private val _surfaceMeshReport = MutableStateFlow<SurfaceMeshReport?>(null)
    val surfaceMeshReport: StateFlow<SurfaceMeshReport?> = _surfaceMeshReport.asStateFlow()

    private val _textureProjectionReport = MutableStateFlow<TextureProjectionReport?>(null)
    val textureProjectionReport: StateFlow<TextureProjectionReport?> = _textureProjectionReport.asStateFlow()

    private val _textureSourceAssignmentReport = MutableStateFlow<TextureSourceAssignmentReport?>(null)
    val textureSourceAssignmentReport: StateFlow<TextureSourceAssignmentReport?> = _textureSourceAssignmentReport.asStateFlow()

    private val _textureAtlasReport = MutableStateFlow<TextureAtlasReport?>(null)
    val textureAtlasReport: StateFlow<TextureAtlasReport?> = _textureAtlasReport.asStateFlow()

    private val _calibrationProfile = MutableStateFlow<CameraCalibrationProfile?>(null)
    val calibrationProfile: StateFlow<CameraCalibrationProfile?> = _calibrationProfile.asStateFlow()

    private val _calibrationReport = MutableStateFlow<CameraCalibrationReport?>(null)
    val calibrationReport: StateFlow<CameraCalibrationReport?> = _calibrationReport.asStateFlow()

    private val _calibrationPhotos = MutableStateFlow<List<File>>(emptyList())
    val calibrationPhotos: StateFlow<List<File>> = _calibrationPhotos.asStateFlow()

    private val _calibrationStatus = MutableStateFlow("Camera calibration not started")
    val calibrationStatus: StateFlow<String> = _calibrationStatus.asStateFlow()

    private val _photoCalibrationTargetPreset = MutableStateFlow(PhotoCalibrationTargetPreset.US_LETTER)
    val photoCalibrationTargetPreset: StateFlow<PhotoCalibrationTargetPreset> = _photoCalibrationTargetPreset.asStateFlow()

    private val _laserCalibrationTargetPreset = MutableStateFlow(LaserCalibrationTargetPreset.US_LETTER)
    val laserCalibrationTargetPreset: StateFlow<LaserCalibrationTargetPreset> = _laserCalibrationTargetPreset.asStateFlow()

    private val _laserLineReport = MutableStateFlow<LaserLineReport?>(null)
    val laserLineReport: StateFlow<LaserLineReport?> = _laserLineReport.asStateFlow()

    private val _laserAnalysisHistory = MutableStateFlow<List<LaserAnalysisRun>>(emptyList())
    val laserAnalysisHistory: StateFlow<List<LaserAnalysisRun>> = _laserAnalysisHistory.asStateFlow()

    private val _laserPlaneReport = MutableStateFlow<LaserPlaneCalibrationReport?>(null)
    val laserPlaneReport: StateFlow<LaserPlaneCalibrationReport?> = _laserPlaneReport.asStateFlow()

    private val _laserOffFile = MutableStateFlow<File?>(null)
    val laserOffFile: StateFlow<File?> = _laserOffFile.asStateFlow()

    private val _laserOnFile = MutableStateFlow<File?>(null)
    val laserOnFile: StateFlow<File?> = _laserOnFile.asStateFlow()

    private val _laserStatus = MutableStateFlow("Laser line lab not started")
    val laserStatus: StateFlow<String> = _laserStatus.asStateFlow()

    private var captureRefreshJob: Job? = null

    // v0.10.0: one heavy reconstruction job may run in the background, but it always belongs
    // to the project that launched it. Live progress is only published when that owner project
    // is actually on screen. Project files were already isolated by ID; this adds UI isolation.
    private var activePipelineJob: Job? = null
    private var activePipelineProjectId: String? = null
    private var activePipelineProjectName: String? = null
    private var activePipelineStageLabel: String? = null
    private var activePipelineStatus: ReconstructionStatus = ReconstructionStatus()

    private fun selectedProjectIs(projectId: String): Boolean = _selectedProject.value?.id == projectId

    private fun publishPipelineStatus(projectId: String, status: ReconstructionStatus) {
        if (activePipelineProjectId == projectId) activePipelineStatus = status
        if (selectedProjectIs(projectId)) _reconstruction.value = status
    }

    private fun updateVisibleStatusForCurrentSelection() {
        val project = _selectedProject.value ?: run {
            _reconstruction.value = ReconstructionStatus()
            return
        }
        val active = activePipelineJob?.isActive == true
        if (active) {
            if (activePipelineProjectId == project.id) {
                _reconstruction.value = activePipelineStatus
            } else {
                _reconstruction.value = ReconstructionStatus(
                    ReconstructionState.READY,
                    0f,
                    "${activePipelineProjectName ?: "Another project"} is processing ${activePipelineStageLabel ?: "a reconstruction stage"} in the background. ${project.name} remains separate and is not processing."
                )
            }
            return
        }
        _reconstruction.value = when {
            _textureAtlasReport.value != null -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 10 UV texture atlas is saved for ${project.name}. Textured face coverage ${"%.1f".format(_textureAtlasReport.value?.textureCoveragePercent ?: 0.0)}%."
            )
            _textureSourceAssignmentReport.value != null -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 9 texture-source assignments are saved for ${project.name}. Face coverage ${"%.1f".format(_textureSourceAssignmentReport.value?.faceCoveragePercent ?: 0.0)}%."
            )
            _textureProjectionReport.value != null -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 8 photo colors are saved for ${project.name}. Coverage ${"%.1f".format(_textureProjectionReport.value?.coveragePercent ?: 0.0)}%. Next: Stage 9 — Assign triangle texture sources."
            )
            _surfaceMeshReport.value != null -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 7 is saved for ${project.name}. Next: Stage 8 — Project photo colors."
            )
            _denseFusionReport.value?.readyForSurfaceReconstruction == true -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 6 is ready. Next: Stage 7 — Build surface mesh."
            )
            _denseReport.value?.densePoints?.let { it > 0 } == true -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 5 is ready. Next: Stage 6 — Build dense fusion."
            )
            _bundleReport.value?.readyForDenseReconstruction == true -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 4 is ready. Next: Stage 5 — Build dense stereo."
            )
            _multiViewReport.value?.readyForBundleAdjustment == true -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 3 is ready. Next: Stage 4 — Refine bundle."
            )
            _sparseReport.value?.readyForMultiView == true -> ReconstructionStatus(
                ReconstructionState.COMPLETED, 1f,
                "Stage 2 is ready. Next: Stage 3 — Build multi-view."
            )
            _featureMatchReport.value?.readyForSparseReconstruction == true -> ReconstructionStatus(
                ReconstructionState.READY, 1f,
                "Stage 1 is ready. Next: Stage 2 — Build sparse reconstruction."
            )
            _report.value?.readyForReconstruction == true -> ReconstructionStatus(
                ReconstructionState.READY, 0f,
                if (project.scanMode == ScanMode.HYBRID) "Photo set is ready. Laser-pass integration is still pending." else "Photo set is ready. Start Stage 1 — Match photos."
            )
            else -> ReconstructionStatus(ReconstructionState.IDLE, 0f, "Add more overlapping photos before reconstruction.")
        }
    }

    private fun canStartPipeline(project: PhotoProject): Boolean {
        if (activePipelineJob?.isActive != true) return true
        _reconstruction.value = if (activePipelineProjectId == project.id) {
            activePipelineStatus
        } else {
            ReconstructionStatus(
                ReconstructionState.READY,
                0f,
                "${activePipelineProjectName ?: "Another project"} is already processing ${activePipelineStageLabel ?: "a reconstruction stage"}. Wait for it to finish before starting heavy processing on ${project.name}."
            )
        }
        return false
    }

    private fun launchOwnedPipeline(
        project: PhotoProject,
        stageLabel: String,
        dispatcher: CoroutineDispatcher,
        block: suspend () -> Unit
    ) {
        if (!canStartPipeline(project)) return
        activePipelineProjectId = project.id
        activePipelineProjectName = project.name
        activePipelineStageLabel = stageLabel
        activePipelineStatus = ReconstructionStatus(ReconstructionState.RUNNING, 0f, "$stageLabel starting…")
        recordPipelineDiagnostic(project.id, "JOB START | $stageLabel")
        val job = viewModelScope.launch(dispatcher, start = CoroutineStart.LAZY) {
            try {
                block()
            } finally {
                if (activePipelineProjectId == project.id) {
                    recordPipelineDiagnostic(project.id, "JOB END | $stageLabel")
                    activePipelineProjectId = null
                    activePipelineProjectName = null
                    activePipelineStageLabel = null
                    activePipelineJob = null
                    if (!selectedProjectIs(project.id)) updateVisibleStatusForCurrentSelection()
                }
            }
        }
        activePipelineJob = job
        job.start()
    }

    private val pipelineDiagnostics = application.getSharedPreferences("pipeline_stage_diagnostics", android.content.Context.MODE_PRIVATE)

    private fun recordPipelineDiagnostic(projectId: String, message: String) {
        val stamp = java.text.DateFormat.getDateTimeInstance().format(java.util.Date())
        val line = "$stamp | project=$projectId | $message"
        val existing = pipelineDiagnostics.getString("history", "").orEmpty()
            .lineSequence().filter { it.isNotBlank() }.toMutableList()
        existing += line
        while (existing.size > 40) existing.removeAt(0)
        pipelineDiagnostics.edit().putString("history", existing.joinToString("\n")).apply()
    }


    private enum class PipelineStage {
        FEATURE_MATCH,
        SPARSE,
        MULTI_VIEW,
        BUNDLE,
        DENSE,
        DENSE_FUSION,
        SURFACE_MESH,
        TEXTURE,
        TEXTURE_SOURCE,
        TEXTURE_ATLAS
    }

    private fun clearInMemoryFrom(stage: PipelineStage) {
        when (stage) {
            PipelineStage.FEATURE_MATCH -> {
                _featureMatchReport.value = null
                _sparseReport.value = null
                _multiViewReport.value = null
                _bundleReport.value = null
                _denseReport.value = null
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.SPARSE -> {
                _sparseReport.value = null
                _multiViewReport.value = null
                _bundleReport.value = null
                _denseReport.value = null
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.MULTI_VIEW -> {
                _multiViewReport.value = null
                _bundleReport.value = null
                _denseReport.value = null
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.BUNDLE -> {
                _bundleReport.value = null
                _denseReport.value = null
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.DENSE -> {
                _denseReport.value = null
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.DENSE_FUSION -> {
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.SURFACE_MESH -> {
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.TEXTURE -> {
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.TEXTURE_SOURCE -> {
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
            }
            PipelineStage.TEXTURE_ATLAS -> {
                _textureAtlasReport.value = null
            }
        }
    }

    private fun invalidateFrom(projectId: String, stage: PipelineStage) {
        if (selectedProjectIs(projectId)) clearInMemoryFrom(stage)
        when (stage) {
            PipelineStage.FEATURE_MATCH -> repository.clearFeatureMatchReport(projectId)
            PipelineStage.SPARSE -> repository.clearSparseReconstruction(projectId)
            PipelineStage.MULTI_VIEW -> repository.clearMultiViewReconstruction(projectId)
            PipelineStage.BUNDLE -> repository.clearBundleAdjustment(projectId)
            PipelineStage.DENSE -> repository.clearDenseReconstruction(projectId)
            PipelineStage.DENSE_FUSION -> repository.clearDenseFusion(projectId)
            PipelineStage.SURFACE_MESH -> repository.clearSurfaceMesh(projectId)
            PipelineStage.TEXTURE -> repository.clearTextureProjection(projectId)
            PipelineStage.TEXTURE_SOURCE -> repository.clearTextureSourceAssignment(projectId)
            PipelineStage.TEXTURE_ATLAS -> repository.clearTextureAtlas(projectId)
        }
    }

    init {
        CameraCalibrationManager.initialize(application)
        CalibrationTargetManager.initialize(application)
        _photoCalibrationTargetPreset.value = CalibrationTargetManager.selectedPhotoPreset()
        _laserCalibrationTargetPreset.value = CalibrationTargetManager.selectedLaserPreset()
        refreshCalibration()
        refreshProjects()
    }

    fun refreshCalibration() {
        _photoCalibrationTargetPreset.value = CalibrationTargetManager.selectedPhotoPreset()
        _laserCalibrationTargetPreset.value = CalibrationTargetManager.selectedLaserPreset()
        _calibrationProfile.value = CameraCalibrationManager.activeProfile()
        _calibrationReport.value = CameraCalibrationManager.loadLastReport()
        _calibrationPhotos.value = CameraCalibrationManager.listCalibrationPhotos()
        _calibrationStatus.value = _calibrationProfile.value?.let { p ->
            val target = PhotoCalibrationTargetPreset.fromId(p.targetPresetId)
            "Active calibration: ${p.label} • ${p.imageWidth}×${p.imageHeight} • RMS ${"%.3f".format(p.rmsReprojectionError)} px • target ${target.displayName}"
        } ?: "No active calibration profile. Selected target: ${_photoCalibrationTargetPreset.value.displayName}. Import calibration-board photos and run calibration."
    }

    fun setPhotoCalibrationTargetPreset(preset: PhotoCalibrationTargetPreset) {
        CalibrationTargetManager.setSelectedPhotoPreset(preset)
        _photoCalibrationTargetPreset.value = preset
        _calibrationStatus.value = "Photo calibration target selected: ${preset.displayName}. Geometry: ${preset.patternColumns}×${preset.patternRows} inner corners / ${preset.squareSizeMm} mm squares / ${preset.printSheetDescription}."
    }

    fun setLaserCalibrationTargetPreset(preset: LaserCalibrationTargetPreset) {
        CalibrationTargetManager.setSelectedLaserPreset(preset)
        _laserCalibrationTargetPreset.value = preset
        _laserStatus.value = "Laser background selected: ${preset.displayName}. Export matching LEFT and RIGHT panels and mount them at 90°."
    }

    fun importCalibrationPhotos(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val copied = CameraCalibrationManager.importCalibrationPhotos(uris)
            _calibrationPhotos.value = CameraCalibrationManager.listCalibrationPhotos()
            _calibrationStatus.value = "Imported $copied calibration photo(s). ${_calibrationPhotos.value.size} total ready."
        }
    }

    fun clearCalibrationPhotos() {
        viewModelScope.launch(Dispatchers.IO) {
            CameraCalibrationManager.clearCalibrationPhotos()
            _calibrationPhotos.value = emptyList()
            _calibrationStatus.value = "Calibration photos cleared. Saved active profile was kept."
        }
    }

    fun runCameraCalibration(label: String) {
        val files = _calibrationPhotos.value
        if (files.size < 10) {
            _calibrationStatus.value = "Import at least 10 calibration photos first; 15–25 is recommended."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _calibrationStatus.value = "Starting calibration from ${files.size} photo(s)…"
            val targetPreset = _photoCalibrationTargetPreset.value
            val result = OpenCvCameraCalibrator.calibrate(files, label, targetPreset) { progress, message ->
                _calibrationStatus.value = "${(progress * 100).toInt()}% • $message"
            }
            result.onSuccess { report ->
                CameraCalibrationManager.saveCalibration(report)
                _calibrationReport.value = report
                _calibrationProfile.value = CameraCalibrationManager.activeProfile()
                val p = report.profile
                _calibrationStatus.value = if (p?.readyForUse == true) {
                    "Calibration active: ${p.label} • ${PhotoCalibrationTargetPreset.fromId(p.targetPresetId).displayName} • RMS ${"%.3f".format(p.rmsReprojectionError)} px • ${report.acceptedImages}/${report.totalImages} views accepted"
                } else {
                    "Calibration solved but was not activated. Review the RMS/error warnings and capture a stronger set."
                }
            }.onFailure { error ->
                _calibrationStatus.value = "Calibration failed: ${error.message ?: error::class.java.simpleName}"
            }
        }
    }

    fun clearCameraCalibrationProfile() {
        CameraCalibrationManager.clearActiveProfile()
        _calibrationProfile.value = null
        _calibrationStatus.value = "Active calibration profile cleared. Existing calibration photos were kept."
    }

    fun calibrationTargetPdfBytes(preset: PhotoCalibrationTargetPreset): ByteArray =
        CalibrationTargetManager.photoTargetPdfBytes(preset)

    fun laserCalibrationTargetPdfBytes(
        preset: LaserCalibrationTargetPreset,
        side: LaserCalibrationPanelSide
    ): ByteArray = CalibrationTargetManager.laserTargetPdfBytes(preset, side)

    fun calibrationPrintInstructionsPdfBytes(): ByteArray = CalibrationTargetManager.printInstructionsPdfBytes()

    fun tiledCalibrationInstructionsPdfBytes(): ByteArray = CalibrationTargetManager.tiledCalibrationInstructionsPdfBytes()

    fun calibrationReportText(): String? {
        val report = _calibrationReport.value ?: return null
        return buildString {
            appendLine("3D Scan Studio - Camera Calibration Report")
            appendLine("App version: ${BuildConfig.VERSION_NAME}")
            appendLine("Total images: ${report.totalImages}")
            appendLine("Accepted images: ${report.acceptedImages}")
            appendLine("Rejected images: ${report.rejectedImages}")
            report.profile?.let { p ->
                appendLine("Profile: ${p.label}")
                appendLine("Device: ${p.deviceModel}")
                appendLine("Image size: ${p.imageWidth} x ${p.imageHeight}")
                val target = PhotoCalibrationTargetPreset.fromId(p.targetPresetId)
                appendLine("Target preset: ${target.displayName} (${p.targetPresetId})")
                appendLine("Target page: ${target.pageWidthIn} x ${target.pageHeightIn} in (${"%.1f".format(target.pageWidthMm)} x ${"%.1f".format(target.pageHeightMm)} mm)")
                appendLine("Pattern: ${p.patternColumns} x ${p.patternRows} inner corners, ${p.squareSizeMm} mm squares")
                appendLine("RMS reprojection error: ${p.rmsReprojectionError}")
                appendLine("fx=${p.fx} fy=${p.fy} cx=${p.cx} cy=${p.cy}")
                appendLine("k1=${p.k1} k2=${p.k2} p1=${p.p1} p2=${p.p2} k3=${p.k3}")
                appendLine("Ready for use: ${p.readyForUse}")
            }
            appendLine("Warnings:")
            if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
            appendLine("Frames:")
            report.frames.forEachIndexed { index, frame ->
                appendLine("${index + 1}. ${frame.fileName} | detected=${frame.detected} | ${frame.width}x${frame.height} | ${frame.reason}")
            }
        }
    }

    fun refreshProjects() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = repository.listProjects()
            _projects.value = list
            val id = _selectedProject.value?.id
            if (id != null) _selectedProject.value = repository.getProject(id)
        }
    }

    fun createProject(name: String, scanMode: ScanMode, onCreated: (PhotoProject) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val project = repository.createProject(name, scanMode)
            _projects.value = repository.listProjects()
            _selectedProject.value = project
            _featureMatchReport.value = null
            _sparseReport.value = null
            _multiViewReport.value = null
            _bundleReport.value = null
            _denseReport.value = null
            _denseFusionReport.value = null
            _surfaceMeshReport.value = null
            _textureProjectionReport.value = null
            _textureSourceAssignmentReport.value = null
            _textureAtlasReport.value = null
            _laserLineReport.value = null
            _laserPlaneReport.value = null
            _laserOffFile.value = null
            _laserOnFile.value = null
            _laserStatus.value = "Import a matched laser-OFF and laser-ON frame"
            setStatusForProject(project)
            withContext(Dispatchers.Main) { onCreated(project) }
        }
    }

    fun selectProject(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val project = repository.getProject(id) ?: return@launch
            _selectedProject.value = project
            _featureMatchReport.value = repository.loadFeatureMatchReport(id)
            _sparseReport.value = repository.loadSparseReconstruction(id)
            _multiViewReport.value = repository.loadMultiViewReconstruction(id)
            _bundleReport.value = repository.loadBundleAdjustment(id)
            _denseReport.value = repository.loadDenseReconstruction(id)
            _denseFusionReport.value = repository.loadDenseFusion(id)
            _surfaceMeshReport.value = repository.loadSurfaceMesh(id)
            _textureProjectionReport.value = repository.loadTextureProjection(id)
            _textureSourceAssignmentReport.value = repository.loadTextureSourceAssignment(id)
            _textureAtlasReport.value = repository.loadTextureAtlas(id)
            _laserOffFile.value = repository.laserFrame(id, false)
            _laserOnFile.value = repository.laserFrame(id, true)
            _laserLineReport.value = repository.loadLaserLineReport(id)
            _laserPlaneReport.value = repository.loadLaserPlaneReport(id)
            _laserAnalysisHistory.value = repository.loadLaserAnalysisHistory(id)
            _laserStatus.value = when {
                _laserPlaneReport.value != null -> "Saved laser-plane / single-frame 3D result loaded"
                _laserLineReport.value != null -> "Saved laser-line extraction loaded"
                _laserOffFile.value != null && _laserOnFile.value != null -> "Laser OFF/ON pair ready to analyze"
                else -> "Import a matched laser-OFF and laser-ON frame"
            }
            _report.value = if (project.scanMode == ScanMode.LASER) null else PhotoSetAnalyzer.analyze(project.photos)
            updateVisibleStatusForCurrentSelection()
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProject(id)
            if (_selectedProject.value?.id == id) {
                _selectedProject.value = null
                _featureMatchReport.value = null
                _sparseReport.value = null
                _multiViewReport.value = null
                _bundleReport.value = null
                _denseReport.value = null
                _denseFusionReport.value = null
                _surfaceMeshReport.value = null
                _textureProjectionReport.value = null
                _textureSourceAssignmentReport.value = null
                _textureAtlasReport.value = null
                _laserLineReport.value = null
                _laserPlaneReport.value = null
                _laserAnalysisHistory.value = emptyList()
                _laserOffFile.value = null
                _laserOnFile.value = null
                _laserStatus.value = "Laser line lab not started"
                _report.value = null
                _reconstruction.value = ReconstructionStatus()
            }
            _projects.value = repository.listProjects()
        }
    }

    fun newCaptureFile(projectId: String): File = repository.photoOutputFile(projectId)

    fun captureCompleted() {
        // Camera Rapid mode can save many stills in one sequence. Debounce project refresh so
        // a burst never launches a full photo-set analysis for every save callback.
        captureRefreshJob?.cancel()
        captureRefreshJob = viewModelScope.launch(Dispatchers.IO) {
            delay(350L)
            refreshSelectedAndAnalyze()
        }
    }

    fun importPhotos(uris: List<Uri>) {
        val project = _selectedProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.importPhotos(project.id, uris)
            refreshSelectedAndAnalyze()
        }
    }

    fun deletePhoto(file: File) {
        val project = _selectedProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.deletePhoto(project.id, file)
            refreshSelectedAndAnalyze()
        }
    }


    fun refreshLaserLineLab() {
        val project = _selectedProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _laserOffFile.value = repository.laserFrame(project.id, false)
            _laserOnFile.value = repository.laserFrame(project.id, true)
            _laserLineReport.value = repository.loadLaserLineReport(project.id)
            _laserPlaneReport.value = repository.loadLaserPlaneReport(project.id)
            _laserAnalysisHistory.value = repository.loadLaserAnalysisHistory(project.id)
            _laserStatus.value = when {
                _laserPlaneReport.value != null -> "Saved laser-plane / single-frame 3D result loaded"
                _laserLineReport.value != null -> "Saved laser-line extraction loaded"
                _laserOffFile.value != null && _laserOnFile.value != null -> "Laser OFF/ON pair ready to analyze"
                else -> "Import a matched laser-OFF and laser-ON frame"
            }
        }
    }

    fun importLaserFrame(uri: Uri, laserOn: Boolean) {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.PHOTOGRAMMETRY) return
        viewModelScope.launch(Dispatchers.IO) {
            _laserStatus.value = if (laserOn) "Importing laser-ON frame…" else "Importing laser-OFF frame…"
            val saved = repository.importLaserFrame(project.id, uri, laserOn)
            if (saved == null) {
                _laserStatus.value = "Could not import laser frame"
            } else {
                _laserOffFile.value = repository.laserFrame(project.id, false)
                _laserOnFile.value = repository.laserFrame(project.id, true)
                _laserLineReport.value = null
                _laserPlaneReport.value = null
                _laserAnalysisHistory.value = repository.loadLaserAnalysisHistory(project.id)
                _laserStatus.value = if (_laserOffFile.value != null && _laserOnFile.value != null) {
                    "Laser OFF/ON pair ready to analyze"
                } else {
                    "Imported ${if (laserOn) "laser-ON" else "laser-OFF"} frame; import the matching companion frame"
                }
            }
        }
    }

    fun runLaserLineDetection(color: LaserLineColor, threshold: Int) {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.PHOTOGRAMMETRY) return
        val off = repository.laserFrame(project.id, false)
        val on = repository.laserFrame(project.id, true)
        if (off == null || on == null) {
            _laserStatus.value = "Import both laser-OFF and laser-ON frames first"
            return
        }

        val runId = UUID.randomUUID().toString()
        val timestampEpochMs = System.currentTimeMillis()
        val startedElapsed = SystemClock.elapsedRealtime()
        val targetPresetId = _laserCalibrationTargetPreset.value.id
        recordPipelineDiagnostic(project.id, "USER_ACTION | LaserAnalyze pressed | run=${runId.take(8)} | color=${color.name} | threshold=$threshold | target=$targetPresetId")
        recordPipelineDiagnostic(project.id, "LaserAnalyze START | run=${runId.take(8)} | color=${color.name} | threshold=$threshold | target=$targetPresetId")

        viewModelScope.launch(Dispatchers.Default) {
            _laserStatus.value = "Extracting ${color.displayName.lowercase()} laser stripe…"
            LaserLineDetector.detect(off, on, color, threshold).fold(
                onSuccess = { result ->
                    val durationMs = (SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(0L)
                    repository.saveLaserLineResult(project.id, result.report, result.previewPng)
                    val run = LaserAnalysisRun(
                        runId = runId,
                        timestampEpochMs = timestampEpochMs,
                        projectId = project.id,
                        laserColor = color,
                        threshold = threshold,
                        success = true,
                        durationMs = durationMs,
                        engine = result.report.engine,
                        laserOffFileName = off.name,
                        laserOnFileName = on.name,
                        laserOffSizeBytes = off.length(),
                        laserOnSizeBytes = on.length(),
                        laserOffModifiedMs = off.lastModified(),
                        laserOnModifiedMs = on.lastModified(),
                        laserTargetPresetId = targetPresetId,
                        imageWidth = result.report.imageWidth,
                        imageHeight = result.report.imageHeight,
                        detectedRows = result.report.detectedRows,
                        coveragePercent = result.report.coveragePercent,
                        continuityPercent = result.report.continuityPercent,
                        meanSignal = result.report.meanSignal,
                        meanLineWidthPx = result.report.meanLineWidthPx,
                        minX = result.report.minX,
                        maxX = result.report.maxX,
                        readyForTriangulation = result.report.readyForTriangulation,
                        extractionOrientation = result.report.extractionOrientation,
                        sampleAxisLength = result.report.sampleAxisLength
                    )
                    repository.appendLaserAnalysisRun(project.id, run)
                    recordPipelineDiagnostic(
                        project.id,
                        "LaserAnalyze SUCCESS | run=${runId.take(8)} | threshold=$threshold | coverage=${"%.2f".format(result.report.coveragePercent)} | continuity=${"%.2f".format(result.report.continuityPercent)} | width=${"%.2f".format(result.report.meanLineWidthPx)} | ready=${result.report.readyForTriangulation} | durationMs=$durationMs"
                    )
                    if (_selectedProject.value?.id == project.id) {
                        _laserLineReport.value = result.report
                        _laserPlaneReport.value = null
                        repository.clearLaserPlaneResult(project.id)
                        _laserAnalysisHistory.value = repository.loadLaserAnalysisHistory(project.id)
                        _laserStatus.value = if (result.report.readyForTriangulation) {
                            "Laser stripe extracted. Run saved to history; use Stage 3 to solve the backdrop/laser plane and build a metric single-frame 3D stripe."
                        } else {
                            "Laser stripe extraction finished and run was saved; review coverage/continuity before triangulation."
                        }
                    }
                },
                onFailure = { error ->
                    val durationMs = (SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(0L)
                    val errorType = error.javaClass.simpleName.ifBlank { error::class.java.name }
                    val errorMessage = error.message ?: errorType
                    val run = LaserAnalysisRun(
                        runId = runId,
                        timestampEpochMs = timestampEpochMs,
                        projectId = project.id,
                        laserColor = color,
                        threshold = threshold,
                        success = false,
                        durationMs = durationMs,
                        laserOffFileName = off.name,
                        laserOnFileName = on.name,
                        laserOffSizeBytes = off.length(),
                        laserOnSizeBytes = on.length(),
                        laserOffModifiedMs = off.lastModified(),
                        laserOnModifiedMs = on.lastModified(),
                        laserTargetPresetId = targetPresetId,
                        errorType = errorType,
                        errorMessage = errorMessage,
                        errorStackTrace = error.stackTraceToString()
                    )
                    repository.appendLaserAnalysisRun(project.id, run)
                    recordPipelineDiagnostic(project.id, "LaserAnalyze FAILED | run=${runId.take(8)} | threshold=$threshold | $errorType: $errorMessage | durationMs=$durationMs")
                    if (_selectedProject.value?.id == project.id) {
                        _laserAnalysisHistory.value = repository.loadLaserAnalysisHistory(project.id)
                        _laserStatus.value = "Laser-line extraction failed and was saved to history: $errorMessage"
                    }
                }
            )
        }
    }

    fun runLaserPlaneCalibration() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.PHOTOGRAMMETRY) return
        val off = repository.laserFrame(project.id, false)
        val on = repository.laserFrame(project.id, true)
        val line = repository.loadLaserLineReport(project.id)
        if (off == null || on == null || line == null) {
            _laserStatus.value = "Analyze a matched laser-OFF/ON pair before solving the laser plane"
            return
        }
        if (!line.readyForTriangulation) {
            _laserStatus.value = "Current stripe run is not ready. Choose a cleaner threshold before laser-plane calibration."
            return
        }
        if (!line.engine.contains("v0.26")) {
            _laserStatus.value = "Re-run Analyze in v0.26 first so the dual-orientation stripe extractor produces geometry compatible with the laser-plane solve."
            return
        }
        if (CameraCalibrationManager.activeProfile()?.readyForUse != true) {
            _laserStatus.value = "Run Camera Calibration first; laser-plane calibration needs the active camera profile."
            return
        }
        val target = _laserCalibrationTargetPreset.value
        viewModelScope.launch(Dispatchers.Default) {
            _laserStatus.value = "Detecting calibration markers and fitting the instantaneous laser plane…"
            LaserPlaneCalibrator.calibrateAndTriangulate(off, on, line, target).fold(
                onSuccess = { result ->
                    repository.saveLaserPlaneResult(project.id, result.report, result.previewPng, result.plyBytes)
                    if (_selectedProject.value?.id == project.id) {
                        _laserPlaneReport.value = result.report
                        _laserStatus.value = if (result.report.readyForSingleFrame3d) {
                            "Laser backdrop solved. Single-frame metric 3D stripe is ready; export the PLY or test an object in front of the corner."
                        } else {
                            "Laser-plane solve finished; review panel angle, marker count, and residual before relying on 3D."
                        }
                    }
                },
                onFailure = { error ->
                    if (_selectedProject.value?.id == project.id) {
                        _laserPlaneReport.value = null
                        _laserStatus.value = "Laser-plane calibration failed: ${error.message ?: error.javaClass.simpleName}"
                    }
                }
            )
        }
    }

    fun laserPlanePreviewPngBytes(): ByteArray? {
        val project = _selectedProject.value ?: return null
        return repository.laserPlanePreviewBytes(project.id)
    }

    fun laserSingleFramePlyBytes(): ByteArray? {
        val project = _selectedProject.value ?: return null
        return repository.laserSingleFramePlyBytes(project.id)
    }

    fun laserPlaneReportText(): String? {
        val project = _selectedProject.value ?: return null
        val report = repository.loadLaserPlaneReport(project.id) ?: return null
        return buildString {
            appendLine("3D Scan Studio - v${BuildConfig.VERSION_NAME} Laser Plane / Single-Frame 3D Report")
            appendLine("Project: ${project.name}")
            appendLine("Project ID: ${project.id}")
            appendLine("Target preset: ${report.targetPresetId}")
            appendLine("Engine: ${report.engine}")
            appendLine("Image: ${report.imageWidth}x${report.imageHeight}")
            appendLine("Detected marker IDs: ${report.detectedMarkerIds.joinToString()}")
            appendLine("LEFT markers: ${report.leftMarkerIds.joinToString()}")
            appendLine("RIGHT markers: ${report.rightMarkerIds.joinToString()}")
            appendLine("Panel angle: ${"%.3f".format(report.panelAngleDegrees)} deg")
            appendLine("Backdrop stripe points: LEFT ${report.leftBackgroundStripePoints}, RIGHT ${report.rightBackgroundStripePoints}, total fit ${report.fittedLaserPoints}")
            appendLine("Mean laser-plane residual: ${"%.3f".format(report.meanLaserPlaneResidualMm)} mm")
            appendLine("Triangulated stripe points: ${report.triangulatedStripePoints.size}")
            appendLine("Non-backdrop stripe points: ${report.nonBackdropStripePoints.size}")
            appendLine("Ready for single-frame 3D: ${report.readyForSingleFrame3d}")
            report.laserPlane?.let { appendLine("Laser plane: n=(${"%.7f".format(it.nx)}, ${"%.7f".format(it.ny)}, ${"%.7f".format(it.nz)}), d=${"%.4f".format(it.d)} mm") }
            appendLine("Warnings / notes:")
            report.warnings.forEach { appendLine("- $it") }
        }
    }

    fun laserPreviewPngBytes(): ByteArray? {
        val project = _selectedProject.value ?: return null
        return repository.laserPreviewBytes(project.id)
    }

    fun laserAnalysisHistoryJsonlBytes(): ByteArray? {
        val project = _selectedProject.value ?: return null
        return repository.laserAnalysisHistoryBytes(project.id)
    }

    fun laserReportText(): String? {
        val project = _selectedProject.value ?: return null
        val report = repository.loadLaserLineReport(project.id) ?: return null
        return buildString {
            appendLine("3D Scan Studio - v${BuildConfig.VERSION_NAME} Laser Line Extraction Report")
            appendLine("Project: ${project.name}")
            appendLine("Project ID: ${project.id}")
            val laserTarget = _laserCalibrationTargetPreset.value
            appendLine("Selected laser background: ${laserTarget.displayName} (${laserTarget.id})")
            appendLine("Laser panel: ${laserTarget.pageWidthIn} x ${laserTarget.pageHeightIn} in (${"%.1f".format(laserTarget.pageWidthMm)} x ${"%.1f".format(laserTarget.pageHeightMm)} mm), marker=${laserTarget.markerSizeMm} mm")
            appendLine("Engine: ${report.engine}")
            appendLine("Laser color: ${report.laserColor.displayName}")
            appendLine("Threshold: ${report.threshold}")
            appendLine("Image: ${report.imageWidth}x${report.imageHeight}")
            appendLine("Extraction orientation: ${report.extractionOrientation}")
            appendLine("Detected samples: ${report.detectedRows}/${report.sampleAxisLength.coerceAtLeast(report.imageHeight)}")
            appendLine("Coverage: ${"%.2f".format(report.coveragePercent)}%")
            appendLine("Continuity: ${"%.2f".format(report.continuityPercent)}%")
            appendLine("Mean signal: ${"%.2f".format(report.meanSignal)}")
            appendLine("Mean line width: ${"%.2f".format(report.meanLineWidthPx)} px")
            appendLine("X range: ${"%.2f".format(report.minX)}..${"%.2f".format(report.maxX)}")
            appendLine("Ready for calibrated triangulation: ${report.readyForTriangulation}")
            appendLine("Warnings / notes:")
            report.warnings.forEach { appendLine("- $it") }
            val history = repository.loadLaserAnalysisHistory(project.id)
            appendLine()
            appendLine("Laser analysis run history: ${history.size} retained run(s), newest first")
            history.take(25).forEachIndexed { index, run ->
                if (run.success) {
                    appendLine(
                        "${index + 1}. run=${run.runId.take(8)} threshold=${run.threshold} color=${run.laserColor.displayName} " +
                            "coverage=${run.coveragePercent?.let { "%.2f".format(it) } ?: "n/a"}% " +
                            "continuity=${run.continuityPercent?.let { "%.2f".format(it) } ?: "n/a"}% " +
                            "width=${run.meanLineWidthPx?.let { "%.2f".format(it) } ?: "n/a"}px " +
                            "ready=${run.readyForTriangulation ?: false} durationMs=${run.durationMs}"
                    )
                } else {
                    appendLine("${index + 1}. run=${run.runId.take(8)} threshold=${run.threshold} color=${run.laserColor.displayName} FAILED ${run.errorType ?: "Error"}: ${run.errorMessage.orEmpty()} durationMs=${run.durationMs}")
                }
            }
            if (history.size > 25) appendLine("... ${history.size - 25} older run(s) remain in laser_analysis_history.jsonl")
        }
    }

    fun analyzeSelected() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) {
            _report.value = null
            if (activePipelineJob?.isActive != true) {
                _reconstruction.value = ReconstructionStatus(
                    ReconstructionState.IDLE, 0f,
                    "Laser Scan project ready. Open Laser Line Lab for dual-orientation stripe extraction and the v0.26 marker/backdrop single-frame 3D solve."
                )
            }
            return
        }
        viewModelScope.launch(Dispatchers.Default) {
            val analyzed = PhotoSetAnalyzer.analyze(project.photos)
            if (selectedProjectIs(project.id)) {
                _report.value = analyzed
                updateVisibleStatusForCurrentSelection()
            }
        }
    }

    fun matchSelectedPhotos() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) return
        if (!canStartPipeline(project)) return
        if (project.photos.size < 2) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Take or import at least 2 photos before matching.")
            return
        }
        launchOwnedPipeline(project, "Stage 1 — Match photos", Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.FEATURE_MATCH)
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.ANALYZING, 0f, "Starting local OpenCV feature matching for ${project.name}…"))
            val result = OpenCvFeatureAnalyzer.analyze(project.photos) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.ANALYZING, progress, message))
            }
            result.fold(
                onSuccess = { report ->
                    repository.saveFeatureMatchReport(project.id, report)
                    if (selectedProjectIs(project.id)) _featureMatchReport.value = report
                    _projects.value = repository.listProjects()
                    val message = if (report.readyForSparseReconstruction) {
                        "Photo matching looks usable. Next stage: estimate camera poses and build a sparse point cloud."
                    } else {
                        "Feature matching finished, but some photo pairs need better overlap before sparse reconstruction."
                    }
                    publishPipelineStatus(project.id, ReconstructionStatus(if (report.readyForSparseReconstruction) ReconstructionState.READY else ReconstructionState.IDLE, 1f, message))
                },
                onFailure = { error ->
                    publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, error.message ?: "Feature matching failed."))
                }
            )
        }
    }

    fun startReconstruction() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.ENGINE_UNAVAILABLE, 0f, "Laser triangulation is not connected yet. The project structure is ready for that integration.")
            return
        }
        if (!canStartPipeline(project)) return
        val matchReport = _featureMatchReport.value
        if (matchReport == null || !matchReport.readyForSparseReconstruction) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Run Match photos first and make sure the photo set is ready for sparse reconstruction.")
            return
        }
        launchOwnedPipeline(project, "Stage 2 — Sparse reconstruction", Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.SPARSE)
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0f, "Starting geometric verification and sparse triangulation…"))
            val result = OpenCvSparseReconstructor.reconstruct(project.photos) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.fold(
                onSuccess = { report ->
                    repository.saveSparseReconstruction(project.id, report)
                    if (selectedProjectIs(project.id)) {
                        _sparseReport.value = report
                        _selectedProject.value = repository.getProject(project.id)
                    }
                    _projects.value = repository.listProjects()
                    publishPipelineStatus(project.id, ReconstructionStatus(
                        if (report.readyForMultiView) ReconstructionState.COMPLETED else ReconstructionState.READY, 1f,
                        if (report.readyForMultiView) "Sparse 3D points created. Next stage: add more camera views and bundle adjustment." else "Sparse geometry was created, but it needs stronger geometry before multi-view expansion."
                    ))
                },
                onFailure = { error -> publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, error.message ?: "Sparse reconstruction failed.")) }
            )
        }
    }

    fun startMultiViewReconstruction() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) return
        if (!canStartPipeline(project)) return
        val sparse = _sparseReport.value
        if (sparse == null || !sparse.readyForMultiView) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Build a successful sparse 3D result first before multi-view reconstruction.")
            return
        }
        if (project.photos.size < 3) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "At least 3 photos are required for multi-view reconstruction.")
            return
        }
        launchOwnedPipeline(project, "Stage 3 — Multi-view reconstruction", Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.MULTI_VIEW)
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0f, "Connecting camera poses across the photo sequence…"))
            val result = OpenCvMultiViewReconstructor.reconstruct(project.photos) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.fold(
                onSuccess = { report ->
                    repository.saveMultiViewReconstruction(project.id, report)
                    if (selectedProjectIs(project.id)) {
                        _multiViewReport.value = report
                        _selectedProject.value = repository.getProject(project.id)
                    }
                    _projects.value = repository.listProjects()
                    publishPipelineStatus(project.id, ReconstructionStatus(
                        if (report.readyForBundleAdjustment) ReconstructionState.COMPLETED else ReconstructionState.READY, 1f,
                        if (report.readyForBundleAdjustment) "Connected ${report.connectedCameras}/${report.photosRequested} cameras with ${report.combinedPoints} combined sparse points. Next stage: bundle adjustment." else "Multi-view chaining finished, but the camera sequence needs stronger overlap before bundle adjustment."
                    ))
                },
                onFailure = { error -> publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, error.message ?: "Multi-view reconstruction failed.")) }
            )
        }
    }

    fun startBundleAdjustment() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) return
        if (!canStartPipeline(project)) return
        val multi = _multiViewReport.value
        if (multi == null || !multi.readyForBundleAdjustment) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Build a multi-view result that is ready for refinement first.")
            return
        }
        launchOwnedPipeline(project, "Stage 4 — Bundle refinement", Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.BUNDLE)
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0f, "Building shared feature tracks for bundle refinement…"))
            val result = OpenCvBundleAdjuster.refine(project.photos, multi) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.fold(
                onSuccess = { report ->
                    repository.saveBundleAdjustment(project.id, report)
                    if (selectedProjectIs(project.id)) {
                        _bundleReport.value = report
                        _selectedProject.value = repository.getProject(project.id)
                    }
                    _projects.value = repository.listProjects()
                    val improved = report.finalRmsPixels.isFinite() && report.initialRmsPixels.isFinite() && report.finalRmsPixels <= report.initialRmsPixels
                    publishPipelineStatus(project.id, ReconstructionStatus(
                        if (report.readyForDenseReconstruction) ReconstructionState.COMPLETED else ReconstructionState.READY, 1f,
                        if (report.readyForDenseReconstruction) {
                            "Bundle refinement used ${report.tracksUsed} tracks and reduced RMS reprojection error from ${"%.2f".format(report.initialRmsPixels)} px to ${"%.2f".format(report.finalRmsPixels)} px. Next stage: dense reconstruction."
                        } else if (improved) "Bundle refinement improved reprojection error, but more stable shared tracks are needed before dense reconstruction." else "Bundle refinement completed, but reprojection error did not improve enough. Review the report before dense reconstruction."
                    ))
                },
                onFailure = { error -> publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, error.message ?: "Bundle refinement failed.")) }
            )
        }
    }


    fun startDenseReconstruction() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) return
        if (!canStartPipeline(project)) return
        val sparse = _sparseReport.value
        val multi = _multiViewReport.value
        val bundle = _bundleReport.value
        if (sparse == null || multi == null || bundle == null || !bundle.readyForDenseReconstruction) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Run sparse reconstruction and a successful shared-track refinement before dense stereo.")
            return
        }
        launchOwnedPipeline(project, "Stage 5 — Dense stereo", Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.DENSE)
            recordPipelineDiagnostic(project.id, "Dense v0.8.4 START | photos=${project.photos.size} | sparsePair=${sparse.firstPhoto}->${sparse.secondPhoto} | connected=${multi.connectedCameras}/${multi.photosRequested}")
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0f, "Preparing connected-component dense stereo pair…"))
            var lastLoggedMessage = ""
            val result = OpenCvDenseStereoReconstructor.reconstruct(project.photos, sparse, multi, bundle) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
                if (message != lastLoggedMessage) {
                    lastLoggedMessage = message
                    recordPipelineDiagnostic(project.id, "Dense progress=${"%.0f".format(progress * 100f)}% | $message")
                }
            }
            result.fold(
                onSuccess = { report ->
                    repository.saveDenseReconstruction(project.id, report)
                    recordPipelineDiagnostic(project.id, "Dense SUCCESS | pair=${report.firstPhoto}->${report.secondPhoto} | disparity=${report.validDisparityPixels} | points=${report.densePoints}")
                    if (selectedProjectIs(project.id)) {
                        _denseReport.value = report
                        _selectedProject.value = repository.getProject(project.id)
                    }
                    _projects.value = repository.listProjects()
                    val hasSeedGeometry = report.densePoints > 0
                    publishPipelineStatus(project.id, ReconstructionStatus(
                        if (hasSeedGeometry) ReconstructionState.COMPLETED else ReconstructionState.READY, 1f,
                        if (hasSeedGeometry) "Dense stereo produced ${report.densePoints} filtered points from ${report.validDisparityPixels} valid disparity pixels. Next: Stage 6 — Dense Fusion." else "Dense stereo completed without a usable seed cloud. Review the dense report before fusion."
                    ))
                },
                onFailure = { error ->
                    val failureMessage = error.message ?: "Dense stereo reconstruction failed."
                    recordPipelineDiagnostic(project.id, "Dense FAILED | ${error::class.java.simpleName}: $failureMessage")
                    publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, failureMessage))
                }
            )
        }
    }

    fun startDenseFusion() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) return
        if (!canStartPipeline(project)) return
        val multi = _multiViewReport.value
        val bundle = _bundleReport.value
        val dense = _denseReport.value
        if (multi == null || bundle == null || dense == null || dense.densePoints <= 0) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Build a non-empty corrected dense stereo seed before multi-pair dense fusion.")
            return
        }
        launchOwnedPipeline(project, "Stage 6 — Dense fusion", Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.DENSE_FUSION)
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0f, "Preparing verified multi-pair dense fusion…"))
            val result = OpenCvDenseFusionReconstructor.fuse(project.photos, multi, bundle) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.fold(
                onSuccess = { report ->
                    repository.saveDenseFusion(project.id, report)
                    if (selectedProjectIs(project.id)) {
                        _denseFusionReport.value = report
                        _selectedProject.value = repository.getProject(project.id)
                    }
                    _projects.value = repository.listProjects()
                    publishPipelineStatus(project.id, ReconstructionStatus(
                        if (report.readyForSurfaceReconstruction) ReconstructionState.COMPLETED else ReconstructionState.READY, 1f,
                        if (report.readyForSurfaceReconstruction) "Dense fusion merged ${report.pairsFused} verified pair clouds into ${report.fusedPoints} points. Next: Stage 7 — Surface Mesh." else "Dense fusion completed with ${report.pairsFused} accepted pair(s) and ${report.fusedPoints} points. Review pair diagnostics before meshing."
                    ))
                },
                onFailure = { error -> publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, error.message ?: "Multi-pair dense fusion failed.")) }
            )
        }
    }

    private suspend fun refreshSelectedAndAnalyze() {
        _featureMatchReport.value = null
        _sparseReport.value = null
        _multiViewReport.value = null
        _bundleReport.value = null
        _denseReport.value = null
        _denseFusionReport.value = null
        _surfaceMeshReport.value = null
        _textureProjectionReport.value = null
        _textureSourceAssignmentReport.value = null
        val id = _selectedProject.value?.id ?: return
        repository.clearFeatureMatchReport(id)
        _selectedProject.value = repository.getProject(id)
        _projects.value = repository.listProjects()
        _selectedProject.value?.let { project ->
            when (project.scanMode) {
                ScanMode.LASER -> setStatusForProject(project)
                ScanMode.PHOTOGRAMMETRY,
                ScanMode.HYBRID -> {
                    _report.value = PhotoSetAnalyzer.analyze(project.photos)
                    val ready = _report.value?.readyForReconstruction == true
                    _reconstruction.value = if (ready) {
                        val message = if (project.scanMode == ScanMode.HYBRID) {
                            "Photo set is ready. Laser-pass integration is still pending."
                        } else {
                            "Photo set is ready for a reconstruction engine."
                        }
                        ReconstructionStatus(ReconstructionState.READY, 0f, message)
                    } else {
                        ReconstructionStatus(ReconstructionState.IDLE, 0f, "Add more overlapping photos before reconstruction.")
                    }
                }
            }
        }
    }

    fun resetReconstructionStages() {
        val project = _selectedProject.value ?: return
        if (project.scanMode == ScanMode.LASER) return
        if (!canStartPipeline(project)) return
        viewModelScope.launch(Dispatchers.Default) {
            invalidateFrom(project.id, PipelineStage.FEATURE_MATCH)
            recordPipelineDiagnostic(project.id, "Pipeline RESET | keptPhotos=${project.photos.size} | cleared=Stages1-9")
            val refreshed = repository.getProject(project.id) ?: project
            if (selectedProjectIs(project.id)) {
                _selectedProject.value = refreshed
                _report.value = PhotoSetAnalyzer.analyze(refreshed.photos)
                updateVisibleStatusForCurrentSelection()
            }
            _projects.value = repository.listProjects()
        }
    }

    private fun setStatusForProject(project: PhotoProject) {
        if (project.scanMode == ScanMode.LASER) {
            _report.value = null
            _reconstruction.value = ReconstructionStatus(
                ReconstructionState.IDLE,
                0f,
                "Laser Scan foundation is ready. Camera calibration and motion control come next."
            )
        } else {
            _reconstruction.value = ReconstructionStatus(
                ReconstructionState.IDLE,
                0f,
                "Add overlapping photos to begin."
            )
        }
    }
    fun startSurfaceMesh() {
        val project = _selectedProject.value ?: return
        if (!canStartPipeline(project)) return
        val fusion = _denseFusionReport.value ?: repository.loadDenseFusion(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 7 needs a saved Stage 6 dense-fusion cloud first.")
            return
        }
        if (!fusion.readyForSurfaceReconstruction || fusion.points.isEmpty()) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 6 dense fusion is not ready for Stage 7 surface meshing.")
            return
        }
        launchOwnedPipeline(project, "Stage 7 — Surface mesh", Dispatchers.IO) {
            invalidateFrom(project.id, PipelineStage.SURFACE_MESH)
            recordPipelineDiagnostic(project.id, "Mesh v0.11.0 START | fusedPoints=${fusion.points.size}")
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0.01f, "Stage 7 — preparing smoothed surface mesh…"))
            val result = LocalSurfaceMesher.reconstruct(fusion.points) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, "Stage 7 — $message"))
            }
            result.onSuccess { report ->
                repository.saveSurfaceMesh(project.id, report)
                if (selectedProjectIs(project.id)) _surfaceMeshReport.value = report
                _projects.value = repository.listProjects()
                recordPipelineDiagnostic(project.id, "Mesh SUCCESS | vertices=${report.meshVertices} | triangles=${report.triangles} | normals=${report.validVertexNormals} | loopsBefore=${report.closedLoopsBeforeFill} | filled=${report.filledBoundaryLoops} | loopsRemaining=${report.boundaryLoops} | open=${report.openBoundaryChains} | branches=${report.boundaryBranchVertices} | ready=${report.readyForExport}")
                publishPipelineStatus(project.id, ReconstructionStatus(
                    ReconstructionState.COMPLETED, 1f,
                    if (report.readyForExport) "Stage 7 built ${report.triangles} topology-clean triangles, filled ${report.filledBoundaryLoops}/${report.closedLoopsBeforeFill} safe closed loop(s), kept ${report.nonManifoldEdges} non-manifold edges, and calculated ${report.validVertexNormals} vertex normals. Next: Stage 8 — Project photo colors." else "Stage 7 produced only ${report.triangles} triangles. Review the mesh report before export."
                ))
            }.onFailure { error ->
                recordPipelineDiagnostic(project.id, "Mesh FAILED | ${error.message ?: error::class.java.simpleName}")
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 7 surface mesh failed: ${error.message ?: error::class.java.simpleName}"))
            }
        }
    }

    fun startTextureProjection() {
        val project = _selectedProject.value ?: return
        if (!canStartPipeline(project)) return
        val multi = _multiViewReport.value ?: repository.loadMultiViewReconstruction(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 8 needs the saved Stage 3 camera component.")
            return
        }
        val bundle = _bundleReport.value ?: repository.loadBundleAdjustment(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 8 needs the saved Stage 4 refined camera centers.")
            return
        }
        val mesh = _surfaceMeshReport.value ?: repository.loadSurfaceMesh(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 8 needs a saved Stage 7 surface mesh first.")
            return
        }
        if (!mesh.readyForExport || mesh.vertices.isEmpty()) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 7 is not ready for Stage 8 photo color projection.")
            return
        }
        launchOwnedPipeline(project, "Stage 8 — Photo color projection", Dispatchers.IO) {
            invalidateFrom(project.id, PipelineStage.TEXTURE)
            recordPipelineDiagnostic(project.id, "Texture v0.13.0 START | meshVertices=${mesh.vertices.size} | photos=${project.photos.size}")
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0.01f, "Stage 8 — preparing photo color projection…"))
            val result = OpenCvTextureProjector.project(project.photos, multi, bundle, mesh) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.onSuccess { report ->
                repository.saveTextureProjection(project.id, report, mesh)
                if (selectedProjectIs(project.id)) _textureProjectionReport.value = report
                _projects.value = repository.listProjects()
                recordPipelineDiagnostic(project.id, "Texture SUCCESS | colored=${report.coloredVertices}/${report.sourceMeshVertices} | coverage=${"%.1f".format(report.coveragePercent)} | recoveredCameras=${report.recoveredCameraPoses} | usedCameras=${report.camerasUsed} | ready=${report.readyForExport}")
                publishPipelineStatus(project.id, ReconstructionStatus(
                    if (report.readyForExport) ReconstructionState.COMPLETED else ReconstructionState.READY,
                    1f,
                    if (report.readyForExport) "Stage 8 projected visibility-refined photo color onto ${report.coloredVertices}/${report.sourceMeshVertices} vertices (${"%.1f".format(report.coveragePercent)}%) using ${report.camerasUsed} camera(s). Next: Stage 9 — Assign triangle texture sources." else "Stage 8 completed with ${"%.1f".format(report.coveragePercent)}% color coverage. Review the Stage 8 diagnostics before export."
                ))
            }.onFailure { error ->
                recordPipelineDiagnostic(project.id, "Texture FAILED | ${error.message ?: error::class.java.simpleName}")
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 8 photo color projection failed: ${error.message ?: error::class.java.simpleName}"))
            }
        }
    }


    fun startTextureSourceAssignment() {
        val project = _selectedProject.value ?: return
        if (!canStartPipeline(project)) return
        val multi = _multiViewReport.value ?: repository.loadMultiViewReconstruction(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 9 needs the saved Stage 3 camera component.")
            return
        }
        val bundle = _bundleReport.value ?: repository.loadBundleAdjustment(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 9 needs the saved Stage 4 refined camera centers.")
            return
        }
        val mesh = _surfaceMeshReport.value ?: repository.loadSurfaceMesh(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 9 needs a saved Stage 7 surface mesh first.")
            return
        }
        val texture = _textureProjectionReport.value ?: repository.loadTextureProjection(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Run Stage 8 photo color projection before Stage 9 texture-source assignment.")
            return
        }
        if (!texture.readyForExport || !mesh.readyForExport) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 8/Stage 7 results are not ready for Stage 9.")
            return
        }
        launchOwnedPipeline(project, "Stage 9 — Texture source assignment", Dispatchers.IO) {
            invalidateFrom(project.id, PipelineStage.TEXTURE_SOURCE)
            recordPipelineDiagnostic(project.id, "TextureSource v0.17.0 START | meshFaces=${mesh.faces.size} | photos=${project.photos.size}")
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0.01f, "Stage 9 — preparing triangle texture-source assignment…"))
            val result = OpenCvTextureProjector.assignTextureSources(project.photos, multi, bundle, mesh) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.onSuccess { report ->
                repository.saveTextureSourceAssignment(project.id, report)
                if (selectedProjectIs(project.id)) _textureSourceAssignmentReport.value = report
                _projects.value = repository.listProjects()
                recordPipelineDiagnostic(project.id, "TextureSource SUCCESS | assigned=${report.assignedFaces}/${report.sourceMeshFaces} | coverage=${"%.1f".format(report.faceCoveragePercent)} | recoveredCameras=${report.recoveredCameraPoses} | bridged=${report.bridgedOrientationLinks} | usedCameras=${report.camerasUsed} | ready=${report.readyForAtlas}")
                publishPipelineStatus(project.id, ReconstructionStatus(
                    if (report.readyForAtlas) ReconstructionState.COMPLETED else ReconstructionState.READY,
                    1f,
                    if (report.readyForAtlas) "Stage 9 assigned source photos to ${report.assignedFaces}/${report.sourceMeshFaces} triangles (${"%.1f".format(report.faceCoveragePercent)}%) using ${report.camerasUsed} camera(s). Next: Stage 10 — Build UV texture atlas." else "Stage 9 completed with ${"%.1f".format(report.faceCoveragePercent)}% triangle source coverage. Review Stage 9 diagnostics before atlas generation."
                ))
            }.onFailure { error ->
                recordPipelineDiagnostic(project.id, "TextureSource FAILED | ${error.message ?: error::class.java.simpleName}")
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 9 texture-source assignment failed: ${error.message ?: error::class.java.simpleName}"))
            }
        }
    }


    fun startTextureAtlas() {
        val project = _selectedProject.value ?: return
        if (!canStartPipeline(project)) return
        val mesh = _surfaceMeshReport.value ?: repository.loadSurfaceMesh(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 10 needs a saved Stage 7 surface mesh.")
            return
        }
        val sources = _textureSourceAssignmentReport.value ?: repository.loadTextureSourceAssignment(project.id) ?: run {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Run Stage 9 texture-source assignment before Stage 10.")
            return
        }
        if (sources.assignments.isEmpty()) {
            _reconstruction.value = ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 9 has no assigned triangles to place in a texture atlas.")
            return
        }
        launchOwnedPipeline(project, "Stage 10 — UV texture atlas", Dispatchers.IO) {
            invalidateFrom(project.id, PipelineStage.TEXTURE_ATLAS)
            recordPipelineDiagnostic(project.id, "TextureAtlas v0.17.0 START | assignedFaces=${sources.assignedFaces} | meshFaces=${mesh.faces.size}")
            publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, 0.01f, "Stage 10 — preparing connected UV-island texture atlas…"))
            val result = TextureAtlasBuilder.build(project.photos, mesh, sources) { progress, message ->
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.RUNNING, progress, message))
            }
            result.onSuccess { built ->
                repository.saveTextureAtlas(project.id, built.report, built.bitmap, mesh)
                built.bitmap.recycle()
                if (selectedProjectIs(project.id)) _textureAtlasReport.value = built.report
                _projects.value = repository.listProjects()
                recordPipelineDiagnostic(project.id, "TextureAtlas SUCCESS | textured=${built.report.texturedFaces}/${built.report.sourceMeshFaces} | coverage=${"%.1f".format(built.report.textureCoveragePercent)} | photos=${built.report.sourcePhotosUsed} | atlas=${built.report.atlasWidth}x${built.report.atlasHeight} | ready=${built.report.readyForExport}")
                publishPipelineStatus(project.id, ReconstructionStatus(
                    if (built.report.readyForExport) ReconstructionState.COMPLETED else ReconstructionState.READY,
                    1f,
                    if (built.report.readyForExport) "Stage 10 built a ${built.report.atlasWidth}×${built.report.atlasHeight} PNG atlas and UV-mapped model for ${built.report.texturedFaces}/${built.report.sourceMeshFaces} faces (${"%.1f".format(built.report.textureCoveragePercent)}%)." else "Stage 10 completed but produced no exportable textured faces."
                ))
            }.onFailure { error ->
                recordPipelineDiagnostic(project.id, "TextureAtlas FAILED | ${error.message ?: error::class.java.simpleName}")
                publishPipelineStatus(project.id, ReconstructionStatus(ReconstructionState.FAILED, 0f, "Stage 10 texture atlas failed: ${error.message ?: error::class.java.simpleName}"))
            }
        }
    }

    fun textureAtlasPackageBytes(): ByteArray? {
        val project = _selectedProject.value ?: return null
        return repository.textureAtlasPackageBytes(project.id)
    }

    fun textureAtlasPngBytes(): ByteArray? {
        val project = _selectedProject.value ?: return null
        return repository.textureAtlasPngBytes(project.id)
    }

}

