package com.photogrammetrystudio.app.util

import android.content.Context
import com.photogrammetrystudio.app.model.LaserCalibrationPanelSide
import com.photogrammetrystudio.app.model.LaserCalibrationTargetPreset
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset

/**
 * v0.24.0 calibration-target presets with standard copy sizes plus pin-align four-Letter photo and laser assemblies.
 *
 * Target selection is global because it describes the physical calibration material the user
 * currently has available, not a single reconstruction result. The selected photo target is also
 * copied into every newly solved camera-calibration profile for traceability.
 */
object CalibrationTargetManager {
    private const val PREFS = "calibration_target_presets"
    private const val KEY_PHOTO = "photo_target"
    private const val KEY_LASER = "laser_target"
    private const val PRINT_INSTRUCTIONS_ASSET = "calibration_targets/print_instructions.pdf"
    private const val TILED_INSTRUCTIONS_ASSET = "calibration_targets/tiled_calibration_instructions.pdf"

    @Volatile private var appContext: Context? = null

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }

    fun selectedPhotoPreset(): PhotoCalibrationTargetPreset {
        val context = appContext ?: return PhotoCalibrationTargetPreset.US_LETTER
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PHOTO, null)
        return PhotoCalibrationTargetPreset.fromId(id)
    }

    fun setSelectedPhotoPreset(preset: PhotoCalibrationTargetPreset) {
        val context = appContext ?: return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PHOTO, preset.id)
            .apply()
    }

    fun selectedLaserPreset(): LaserCalibrationTargetPreset {
        val context = appContext ?: return LaserCalibrationTargetPreset.US_LETTER
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LASER, null)
        return LaserCalibrationTargetPreset.fromId(id)
    }

    fun setSelectedLaserPreset(preset: LaserCalibrationTargetPreset) {
        val context = appContext ?: return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LASER, preset.id)
            .apply()
    }

    fun photoTargetPdfBytes(preset: PhotoCalibrationTargetPreset): ByteArray = readAsset(preset.assetPath)

    fun laserTargetPdfBytes(
        preset: LaserCalibrationTargetPreset,
        side: LaserCalibrationPanelSide
    ): ByteArray = readAsset(
        when (side) {
            LaserCalibrationPanelSide.LEFT -> preset.leftAssetPath
            LaserCalibrationPanelSide.RIGHT -> preset.rightAssetPath
        }
    )

    fun printInstructionsPdfBytes(): ByteArray = readAsset(PRINT_INSTRUCTIONS_ASSET)

    fun tiledCalibrationInstructionsPdfBytes(): ByteArray = readAsset(TILED_INSTRUCTIONS_ASSET)

    private fun readAsset(path: String): ByteArray {
        val context = checkNotNull(appContext) { "CalibrationTargetManager is not initialized" }
        return context.assets.open(path).use { it.readBytes() }
    }
}
