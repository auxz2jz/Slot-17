package com.photogrammetrystudio.app.ui.screens

import android.net.Uri
import com.photogrammetrystudio.app.BuildConfig
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.photogrammetrystudio.app.model.CameraCalibrationProfile
import com.photogrammetrystudio.app.model.CameraCalibrationReport
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalibrationScreen(
    photos: List<File>,
    profile: CameraCalibrationProfile?,
    report: CameraCalibrationReport?,
    status: String,
    targetPreset: PhotoCalibrationTargetPreset,
    onBack: () -> Unit,
    onImport: (List<Uri>) -> Unit,
    onClearPhotos: () -> Unit,
    onRunCalibration: (String) -> Unit,
    onClearProfile: () -> Unit,
    onTargetPresetChange: (PhotoCalibrationTargetPreset) -> Unit,
    onTargetPdf: (PhotoCalibrationTargetPreset) -> ByteArray,
    onPrintInstructionsPdf: () -> ByteArray,
    onTiledInstructionsPdf: () -> ByteArray,
    onReportText: () -> String?,
    onOpenTestGuide: () -> Unit
) {
    val context = LocalContext.current
    var label by remember(profile?.id) { mutableStateOf(profile?.label ?: "Main 1×") }
    var pendingTargetPreset by remember { mutableStateOf(targetPreset) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) onImport(uris)
    }
    val targetLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(onTargetPdf(pendingTargetPreset)) }
        }
    }
    val instructionsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(onPrintInstructionsPdf()) }
        }
    }
    val tiledInstructionsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(onTiledInstructionsPdf()) }
        }
    }
    val reportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching {
            val text = onReportText() ?: return@runCatching
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Camera Calibration") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = onOpenTestGuide) { Icon(Icons.Default.HelpOutline, contentDescription = "Test this version") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Tune, contentDescription = null)
                            Text("Why calibrate?", fontWeight = FontWeight.SemiBold)
                        }
                        Text("Calibration measures the real focal lengths, principal point, and lens distortion for one camera/lens/zoom/resolution setup. It is separate from scan markers: reflective dots and coded fiducials help tracking, while this board corrects the camera model itself.")
                        Text("Keep the same physical lens and zoom for calibration and scanning. Recalibrate after changing lens/zoom or when using a substantially different resolution.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("1. Choose and print the target", fontWeight = FontWeight.SemiBold)
                        Text("Choose the physical target you will actually print. Letter, Legal, Ledger, and Poster 12×18 keep the original 9×6 inner-corner / 25 mm checkerboard. The new Large 4-Letter target also uses 9×6 inner corners, but deliberately uses 38.1 mm (1.5 in) squares so four ordinary Letter sheets form a larger calibration board.")
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            PhotoCalibrationTargetPreset.entries.chunked(2).forEach { options ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    options.forEach { option ->
                                        FilterChip(
                                            modifier = Modifier.weight(1f),
                                            selected = targetPreset == option,
                                            onClick = { onTargetPresetChange(option) },
                                            label = { Text(option.displayName) }
                                        )
                                    }
                                    if (options.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                        Text("Selected: ${targetPreset.displayName} • ${targetPreset.printClassLabel}", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "Finished target: ${targetPreset.pageWidthIn} × ${targetPreset.pageHeightIn} in (${"%.1f".format(targetPreset.pageWidthMm)} × ${"%.1f".format(targetPreset.pageHeightMm)} mm). Checker pattern: ${"%.1f".format(targetPreset.patternWidthMm)} × ${"%.1f".format(targetPreset.patternHeightMm)} mm • ${targetPreset.printSheetDescription}.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Print at 100% / Actual Size — never Fit to Page. Measure one checker square: it must be exactly ${"%.1f".format(targetPreset.squareSizeMm)} mm. Keep the assembled print flat, rigid, and matte.", style = MaterialTheme.typography.bodySmall)
                        if (targetPreset.printSheetCount > 1) {
                            Text("Pin-align tiled target: match the labeled registration crosshairs, pierce their center dots with pins, then straight-cut the overlapped seam through the pin centers. The registration tabs are outside the final checkerboard and are discarded; no paper overlap should cover the finished target.", style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(
                            onClick = {
                                pendingTargetPreset = targetPreset
                                targetLauncher.launch(targetPreset.defaultFileName)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Export selected photo calibration PDF")
                        }
                        TextButton(
                            onClick = { instructionsLauncher.launch("3D_Scan_Studio_Calibration_Print_Instructions.pdf") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Export print-shop instructions PDF")
                        }
                        TextButton(
                            onClick = { tiledInstructionsLauncher.launch("3D_Scan_Studio_Tiled_Calibration_Instructions.pdf") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Export tiled / poster-board assembly instructions")
                        }
                    }
                }
            }

            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("2. Photograph the board", fontWeight = FontWeight.SemiBold)
                        Text("Take 15–25 sharp photos with the exact lens/zoom you plan to scan with. Keep phone orientation/resolution consistent. Include straight, tilted, near/far, center, and corner-of-frame views. Keep the whole checkerboard visible.")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = { importLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                Spacer(Modifier.padding(3.dp))
                                Text("Import photos")
                            }
                            OutlinedButton(onClick = onClearPhotos, modifier = Modifier.weight(1f), enabled = photos.isNotEmpty()) {
                                Text("Clear photos")
                            }
                        }
                        Text("Calibration photos stored: ${photos.size}", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }

            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("3. Solve calibration", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = label,
                            onValueChange = { label = it },
                            label = { Text("Lens/profile label") },
                            supportingText = { Text("Example: Main 1×") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = { onRunCalibration(label) }, modifier = Modifier.fillMaxWidth(), enabled = photos.size >= 10) {
                            Text("Run camera calibration")
                        }
                        Text(status, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Active calibration profile", fontWeight = FontWeight.SemiBold)
                        if (profile == null) {
                            Text("None. Reconstruction continues using EXIF/fallback intrinsics.")
                        } else {
                            Text("${profile.label} • ${profile.deviceModel}")
                            Text("${profile.imageWidth}×${profile.imageHeight} • ${profile.acceptedImages} accepted / ${profile.rejectedImages} rejected")
                            Text("Target used: ${PhotoCalibrationTargetPreset.fromId(profile.targetPresetId).displayName}")
                            Text("RMS reprojection: ${"%.3f".format(profile.rmsReprojectionError)} px")
                            Text("fx ${"%.2f".format(profile.fx)} • fy ${"%.2f".format(profile.fy)} • cx ${"%.2f".format(profile.cx)} • cy ${"%.2f".format(profile.cy)}")
                            Text("k1 ${"%.5f".format(profile.k1)} • k2 ${"%.5f".format(profile.k2)} • p1 ${"%.5f".format(profile.p1)} • p2 ${"%.5f".format(profile.p2)} • k3 ${"%.5f".format(profile.k3)}", style = MaterialTheme.typography.bodySmall)
                            Text("v0.21 keeps using the calibrated focal/principal-point values in reconstruction when image size/orientation matches. Distortion coefficients are saved now for the next distortion-correction pass.", style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = onClearProfile) { Text("Clear active calibration") }
                        }
                    }
                }
            }

            if (report != null) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Last calibration report", fontWeight = FontWeight.SemiBold)
                            Text("Accepted ${report.acceptedImages}/${report.totalImages}; rejected ${report.rejectedImages}")
                            report.warnings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            OutlinedButton(onClick = { reportLauncher.launch("3D_Scan_Studio_v${BuildConfig.VERSION_NAME}_camera_calibration_report.txt") }, modifier = Modifier.fillMaxWidth()) {
                                Text("Export calibration report")
                            }
                        }
                    }
                }
            }
        }
    }
}
