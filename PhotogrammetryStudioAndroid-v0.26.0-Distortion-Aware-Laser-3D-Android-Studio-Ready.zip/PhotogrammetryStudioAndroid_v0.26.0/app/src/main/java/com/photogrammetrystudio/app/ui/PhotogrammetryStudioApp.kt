package com.photogrammetrystudio.app.ui

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.photogrammetrystudio.app.BuildConfig
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.photogrammetrystudio.app.MainViewModel
import com.photogrammetrystudio.app.ui.screens.CameraCaptureScreen
import com.photogrammetrystudio.app.ui.screens.CalibrationScreen
import com.photogrammetrystudio.app.ui.screens.ProjectScreen
import com.photogrammetrystudio.app.ui.screens.LaserLineLabScreen
import com.photogrammetrystudio.app.ui.screens.ProjectsScreen
import com.photogrammetrystudio.app.ui.screens.VersionTestGuideDialog

private enum class AppScreen { Projects, Project, Camera, Calibration, LaserLine }

@Composable
fun PhotogrammetryStudioApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("test_guide", Context.MODE_PRIVATE) }
    val currentVersion = BuildConfig.VERSION_NAME
    var showTestGuide by rememberSaveable(currentVersion) {
        mutableStateOf(preferences.getString("last_seen_version", null) != currentVersion)
    }
    var screen by rememberSaveable { mutableStateOf(AppScreen.Projects) }
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val selected by viewModel.selectedProject.collectAsStateWithLifecycle()
    val report by viewModel.report.collectAsStateWithLifecycle()
    val reconstruction by viewModel.reconstruction.collectAsStateWithLifecycle()
    val featureMatchReport by viewModel.featureMatchReport.collectAsStateWithLifecycle()
    val sparseReport by viewModel.sparseReport.collectAsStateWithLifecycle()
    val multiViewReport by viewModel.multiViewReport.collectAsStateWithLifecycle()
    val bundleReport by viewModel.bundleReport.collectAsStateWithLifecycle()
    val denseReport by viewModel.denseReport.collectAsStateWithLifecycle()
    val denseFusionReport by viewModel.denseFusionReport.collectAsStateWithLifecycle()
    val surfaceMeshReport by viewModel.surfaceMeshReport.collectAsStateWithLifecycle()
    val textureProjectionReport by viewModel.textureProjectionReport.collectAsStateWithLifecycle()
    val textureSourceAssignmentReport by viewModel.textureSourceAssignmentReport.collectAsStateWithLifecycle()
    val textureAtlasReport by viewModel.textureAtlasReport.collectAsStateWithLifecycle()
    val calibrationProfile by viewModel.calibrationProfile.collectAsStateWithLifecycle()
    val calibrationReport by viewModel.calibrationReport.collectAsStateWithLifecycle()
    val calibrationPhotos by viewModel.calibrationPhotos.collectAsStateWithLifecycle()
    val calibrationStatus by viewModel.calibrationStatus.collectAsStateWithLifecycle()
    val photoCalibrationTargetPreset by viewModel.photoCalibrationTargetPreset.collectAsStateWithLifecycle()
    val laserCalibrationTargetPreset by viewModel.laserCalibrationTargetPreset.collectAsStateWithLifecycle()
    val laserLineReport by viewModel.laserLineReport.collectAsStateWithLifecycle()
    val laserPlaneReport by viewModel.laserPlaneReport.collectAsStateWithLifecycle()
    val laserAnalysisHistory by viewModel.laserAnalysisHistory.collectAsStateWithLifecycle()
    val laserOffFile by viewModel.laserOffFile.collectAsStateWithLifecycle()
    val laserOnFile by viewModel.laserOnFile.collectAsStateWithLifecycle()
    val laserStatus by viewModel.laserStatus.collectAsStateWithLifecycle()

    when (screen) {
        AppScreen.Projects -> ProjectsScreen(
            projects = projects,
            onProjectClick = {
                viewModel.selectProject(it.id)
                screen = AppScreen.Project
            },
            onCreateProject = { name, mode ->
                viewModel.createProject(name, mode) { screen = AppScreen.Project }
            },
            onDeleteProject = { viewModel.deleteProject(it.id) },
            onOpenCalibration = {
                viewModel.refreshCalibration()
                screen = AppScreen.Calibration
            },
            onOpenTestGuide = { showTestGuide = true }
        )

        AppScreen.Project -> ProjectScreen(
            project = selected,
            report = report,
            reconstruction = reconstruction,
            featureMatchReport = featureMatchReport,
            sparseReport = sparseReport,
            multiViewReport = multiViewReport,
            bundleReport = bundleReport,
            denseReport = denseReport,
            denseFusionReport = denseFusionReport,
            surfaceMeshReport = surfaceMeshReport,
            textureProjectionReport = textureProjectionReport,
            textureSourceAssignmentReport = textureSourceAssignmentReport,
            textureAtlasReport = textureAtlasReport,
            onBack = { screen = AppScreen.Projects },
            onCapture = { screen = AppScreen.Camera },
            onImport = viewModel::importPhotos,
            onDeletePhoto = viewModel::deletePhoto,
            onAnalyze = viewModel::analyzeSelected,
            onMatchPhotos = viewModel::matchSelectedPhotos,
            onBuild = viewModel::startReconstruction,
            onBuildMultiView = viewModel::startMultiViewReconstruction,
            onBundleAdjust = viewModel::startBundleAdjustment,
            onBuildDense = viewModel::startDenseReconstruction,
            onBuildDenseFusion = viewModel::startDenseFusion,
            onBuildSurfaceMesh = viewModel::startSurfaceMesh,
            onBuildTextureProjection = viewModel::startTextureProjection,
            onBuildTextureSourceAssignment = viewModel::startTextureSourceAssignment,
            onBuildTextureAtlas = viewModel::startTextureAtlas,
            onLoadTextureAtlasPackage = viewModel::textureAtlasPackageBytes,
            onLoadTextureAtlasPng = viewModel::textureAtlasPngBytes,
            onResetReconstruction = viewModel::resetReconstructionStages,
            onOpenLaserLab = {
                viewModel.refreshLaserLineLab()
                screen = AppScreen.LaserLine
            },
            onOpenTestGuide = { showTestGuide = true }
        )

        AppScreen.Calibration -> CalibrationScreen(
            photos = calibrationPhotos,
            profile = calibrationProfile,
            report = calibrationReport,
            status = calibrationStatus,
            targetPreset = photoCalibrationTargetPreset,
            onBack = { screen = AppScreen.Projects },
            onImport = viewModel::importCalibrationPhotos,
            onClearPhotos = viewModel::clearCalibrationPhotos,
            onRunCalibration = viewModel::runCameraCalibration,
            onClearProfile = viewModel::clearCameraCalibrationProfile,
            onTargetPresetChange = viewModel::setPhotoCalibrationTargetPreset,
            onTargetPdf = viewModel::calibrationTargetPdfBytes,
            onPrintInstructionsPdf = viewModel::calibrationPrintInstructionsPdfBytes,
            onTiledInstructionsPdf = viewModel::tiledCalibrationInstructionsPdfBytes,
            onReportText = viewModel::calibrationReportText,
            onOpenTestGuide = { showTestGuide = true }
        )

        AppScreen.LaserLine -> LaserLineLabScreen(
            project = selected,
            laserOffFile = laserOffFile,
            laserOnFile = laserOnFile,
            report = laserLineReport,
            planeReport = laserPlaneReport,
            analysisHistory = laserAnalysisHistory,
            status = laserStatus,
            targetPreset = laserCalibrationTargetPreset,
            onBack = { screen = AppScreen.Project },
            onImportLaserOff = { viewModel.importLaserFrame(it, false) },
            onImportLaserOn = { viewModel.importLaserFrame(it, true) },
            onAnalyze = viewModel::runLaserLineDetection,
            onCalibrateLaserPlane = viewModel::runLaserPlaneCalibration,
            onTargetPresetChange = viewModel::setLaserCalibrationTargetPreset,
            onTargetPdf = viewModel::laserCalibrationTargetPdfBytes,
            onPrintInstructionsPdf = viewModel::calibrationPrintInstructionsPdfBytes,
            onTiledInstructionsPdf = viewModel::tiledCalibrationInstructionsPdfBytes,
            onPreviewPng = viewModel::laserPreviewPngBytes,
            onHistoryJsonl = viewModel::laserAnalysisHistoryJsonlBytes,
            onReportText = viewModel::laserReportText,
            onPlanePreviewPng = viewModel::laserPlanePreviewPngBytes,
            onPlanePly = viewModel::laserSingleFramePlyBytes,
            onPlaneReportText = viewModel::laserPlaneReportText,
            onOpenTestGuide = { showTestGuide = true }
        )

        AppScreen.Camera -> {
            val project = selected
            if (project == null) {
                screen = AppScreen.Projects
            } else {
                CameraCaptureScreen(
                    projectName = project.name,
                    outputFileProvider = { viewModel.newCaptureFile(project.id) },
                    onPhotoSaved = viewModel::captureCompleted,
                    onBack = { screen = AppScreen.Project },
                    onOpenTestGuide = { showTestGuide = true }
                )
            }
        }
    }

    if (showTestGuide) {
        VersionTestGuideDialog(
            versionName = currentVersion,
            selectedProject = selected,
            featureMatchReport = featureMatchReport,
            sparseReport = sparseReport,
            multiViewReport = multiViewReport,
            bundleReport = bundleReport,
            denseReport = denseReport,
            denseFusionReport = denseFusionReport,
            surfaceMeshReport = surfaceMeshReport,
            textureProjectionReport = textureProjectionReport,
            textureSourceAssignmentReport = textureSourceAssignmentReport,
            textureAtlasReport = textureAtlasReport,
            calibrationProfile = calibrationProfile,
            calibrationReport = calibrationReport,
            photoCalibrationTargetPreset = photoCalibrationTargetPreset,
            laserCalibrationTargetPreset = laserCalibrationTargetPreset,
            laserAnalysisHistory = laserAnalysisHistory,
            laserPlaneReport = laserPlaneReport,
            reconstructionStatus = reconstruction,
            onPause = { showTestGuide = false },
            onFinish = {
                preferences.edit().putString("last_seen_version", currentVersion).apply()
                showTestGuide = false
            }
        )
    }
}
