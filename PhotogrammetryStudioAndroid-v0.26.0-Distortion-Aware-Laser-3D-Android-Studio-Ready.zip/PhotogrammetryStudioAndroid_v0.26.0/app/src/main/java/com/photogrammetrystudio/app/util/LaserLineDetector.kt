package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.photogrammetrystudio.app.model.LaserLineColor
import com.photogrammetrystudio.app.model.LaserLinePoint
import com.photogrammetrystudio.app.model.LaserLineReport
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * v0.26 laser-line extraction.
 *
 * Earlier builds sampled one X coordinate per image row, which is excellent for a mostly vertical
 * stripe but can underperform badly when a hand-swept laser appears nearly horizontal. v0.26 runs
 * both row-wise (X per row) and column-wise (Y per column) extraction, scores both results, and
 * keeps the orientation that best matches the current stripe. OFF/ON color-difference suppression,
 * channel dominance, local weighted centroids, and broad-highlight rejection are retained.
 */
object LaserLineDetector {
    data class Result(
        val report: LaserLineReport,
        val previewPng: ByteArray
    )

    private data class Candidate(
        val orientation: String,
        val points: List<LaserLinePoint>,
        val axisLength: Int,
        val coverage: Double,
        val continuity: Double,
        val meanSignal: Double,
        val meanWidth: Double,
        val qualityScore: Double
    )

    fun detect(
        laserOff: File,
        laserOn: File,
        color: LaserLineColor,
        threshold: Int = 28,
        maxImageSide: Int = 1280
    ): kotlin.Result<Result> = runCatching {
        require(threshold in 1..255) { "Threshold must be 1..255" }
        val off0 = ExifBitmapLoader.decodeScaledRaw(laserOff, maxImageSide)
            ?: error("Could not decode laser-OFF image")
        val on0 = ExifBitmapLoader.decodeScaledRaw(laserOn, maxImageSide)
            ?: error("Could not decode laser-ON image")

        val on = on0
        val off = if (off0.width == on.width && off0.height == on.height) {
            off0
        } else {
            Bitmap.createScaledBitmap(off0, on.width, on.height, true).also {
                if (it !== off0) off0.recycle()
            }
        }

        val width = on.width
        val height = on.height
        val offPixels = IntArray(width * height)
        val onPixels = IntArray(width * height)
        off.getPixels(offPixels, 0, width, 0, 0, width, height)
        on.getPixels(onPixels, 0, width, 0, 0, width, height)
        val responses = IntArray(width * height)
        for (i in responses.indices) {
            val a = offPixels[i]
            val b = onPixels[i]
            val dr = Color.red(b) - Color.red(a)
            val dg = Color.green(b) - Color.green(a)
            val db = Color.blue(b) - Color.blue(a)
            val primary: Int
            val other1: Int
            val other2: Int
            when (color) {
                LaserLineColor.RED -> { primary = dr; other1 = dg; other2 = db }
                LaserLineColor.GREEN -> { primary = dg; other1 = dr; other2 = db }
                LaserLineColor.BLUE -> { primary = db; other1 = dr; other2 = dg }
            }
            responses[i] = max(0, primary - max(0, (other1 + other2) / 2))
        }

        val rowWise = extractRows(responses, width, height, threshold)
        val columnWise = extractColumns(responses, width, height, threshold)
        val chosen = if (columnWise.qualityScore > rowWise.qualityScore * 1.04) columnWise else rowWise

        val minX = chosen.points.minOfOrNull { it.x } ?: 0.0
        val maxX = chosen.points.maxOfOrNull { it.x } ?: 0.0
        val warnings = mutableListOf<String>()
        if (chosen.coverage < 25.0) warnings += "Laser stripe was detected on less than 25% of the selected sampling axis. Improve laser visibility, reduce reflections, or adjust threshold."
        if (chosen.continuity < 70.0 && chosen.points.size > 20) warnings += "Detected stripe is fragmented/jumpy. A darker background, steadier camera, or cleaner laser-OFF reference may help."
        if (rowWise.orientation != chosen.orientation) warnings += "v0.26 automatically selected column-wise extraction because the stripe is more horizontal than vertical in this frame."
        else warnings += "v0.26 selected row-wise extraction for this stripe orientation."
        warnings += "v0.26 can hand the extracted 2D stripe to marker-based backdrop/laser-plane calibration for metric single-frame 3D."
        val ready = chosen.points.size >= max(40, chosen.axisLength / 4) && chosen.continuity >= 55.0

        val report = LaserLineReport(
            engine = "Laser OFF/ON dual-orientation weighted-centroid extractor v0.26.0",
            laserColor = color,
            threshold = threshold,
            imageWidth = width,
            imageHeight = height,
            detectedRows = chosen.points.size,
            coveragePercent = chosen.coverage,
            meanSignal = chosen.meanSignal,
            meanLineWidthPx = chosen.meanWidth,
            continuityPercent = chosen.continuity,
            minX = minX,
            maxX = maxX,
            points = chosen.points,
            warnings = warnings,
            readyForTriangulation = ready,
            extractionOrientation = chosen.orientation,
            sampleAxisLength = chosen.axisLength
        )

        val preview = on.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(preview)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = Color.CYAN
            strokeWidth = max(2f, width / 500f)
            style = Paint.Style.STROKE
        }
        var previous: LaserLinePoint? = null
        for (p in chosen.points) {
            previous?.let { q ->
                val adjacent = if (chosen.orientation == "COLUMN_WISE") {
                    abs(p.x - q.x) <= 1.25
                } else {
                    p.row == q.row + 1
                }
                val crossDelta = if (chosen.orientation == "COLUMN_WISE") abs(p.row - q.row).toDouble() else abs(p.x - q.x)
                val crossLimit = if (chosen.orientation == "COLUMN_WISE") max(10.0, height * 0.08) else max(10.0, width * 0.08)
                if (adjacent && crossDelta < crossLimit) {
                    canvas.drawLine(q.x.toFloat(), q.row.toFloat(), p.x.toFloat(), p.row.toFloat(), paint)
                }
            }
            previous = p
        }
        val bytes = ByteArrayOutputStream().use { stream ->
            preview.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.toByteArray()
        }

        if (preview !== on) preview.recycle()
        on.recycle()
        if (off !== off0) off.recycle() else off0.recycle()

        Result(report, bytes)
    }

    private fun extractRows(responses: IntArray, width: Int, height: Int, threshold: Int): Candidate {
        val points = ArrayList<LaserLinePoint>(height)
        var totalSignal = 0.0
        var totalWidth = 0.0
        for (y in 0 until height) {
            var maxSignal = 0
            var maxIndex = -1
            val base = y * width
            for (x in 0 until width) {
                val response = responses[base + x]
                if (response > maxSignal) { maxSignal = response; maxIndex = x }
            }
            if (maxIndex < 0 || maxSignal < threshold) continue
            val localThreshold = max(threshold, (maxSignal * 0.45).toInt())
            var start = maxIndex
            while (start > 0 && responses[base + start - 1] >= localThreshold) start--
            var end = maxIndex
            while (end + 1 < width && responses[base + end + 1] >= localThreshold) end++
            val lineWidth = end - start + 1
            if (lineWidth > max(24, width / 20)) continue
            var weighted = 0.0; var weight = 0.0
            for (x in start..end) {
                val w = responses[base + x].toDouble()
                weighted += x * w; weight += w
            }
            if (weight <= 0.0) continue
            points += LaserLinePoint(y, weighted / weight, maxSignal.toDouble())
            totalSignal += maxSignal; totalWidth += lineWidth
        }
        return candidate("ROW_WISE", points, height, width, totalSignal, totalWidth)
    }

    private fun extractColumns(responses: IntArray, width: Int, height: Int, threshold: Int): Candidate {
        val points = ArrayList<LaserLinePoint>(width)
        var totalSignal = 0.0
        var totalWidth = 0.0
        for (x in 0 until width) {
            var maxSignal = 0
            var maxIndex = -1
            for (y in 0 until height) {
                val response = responses[y * width + x]
                if (response > maxSignal) { maxSignal = response; maxIndex = y }
            }
            if (maxIndex < 0 || maxSignal < threshold) continue
            val localThreshold = max(threshold, (maxSignal * 0.45).toInt())
            var start = maxIndex
            while (start > 0 && responses[(start - 1) * width + x] >= localThreshold) start--
            var end = maxIndex
            while (end + 1 < height && responses[(end + 1) * width + x] >= localThreshold) end++
            val lineWidth = end - start + 1
            if (lineWidth > max(24, height / 20)) continue
            var weighted = 0.0; var weight = 0.0
            for (y in start..end) {
                val w = responses[y * width + x].toDouble()
                weighted += y * w; weight += w
            }
            if (weight <= 0.0) continue
            val yCenter = (weighted / weight).roundToInt().coerceIn(0, height - 1)
            points += LaserLinePoint(yCenter, x.toDouble(), maxSignal.toDouble())
            totalSignal += maxSignal; totalWidth += lineWidth
        }
        return candidate("COLUMN_WISE", points, width, height, totalSignal, totalWidth)
    }

    private fun candidate(
        orientation: String,
        points: List<LaserLinePoint>,
        axisLength: Int,
        crossLength: Int,
        totalSignal: Double,
        totalWidth: Double
    ): Candidate {
        val coverage = if (axisLength > 0) points.size * 100.0 / axisLength else 0.0
        var links = 0
        var possible = 0
        for (i in 1 until points.size) {
            val a = points[i - 1]; val b = points[i]
            val adjacent = if (orientation == "COLUMN_WISE") abs(b.x - a.x) <= 1.25 else b.row == a.row + 1
            if (!adjacent) continue
            possible++
            val delta = if (orientation == "COLUMN_WISE") abs(b.row - a.row).toDouble() else abs(b.x - a.x)
            if (delta <= max(10.0, crossLength * 0.035)) links++
        }
        val continuity = if (possible > 0) links * 100.0 / possible else 0.0
        val meanSignal = if (points.isNotEmpty()) totalSignal / points.size else 0.0
        val meanWidth = if (points.isNotEmpty()) totalWidth / points.size else 0.0
        val widthPenalty = max(0.0, meanWidth - 18.0) * 0.35
        val score = coverage * 0.58 + continuity * 0.34 + min(8.0, meanSignal / 32.0) - widthPenalty
        return Candidate(orientation, points, axisLength, coverage, continuity, meanSignal, meanWidth, score)
    }
}
