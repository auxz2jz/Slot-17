package com.photogrammetrystudio.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.photogrammetrystudio.app.model.FeatureMatchPair
import com.photogrammetrystudio.app.model.FeatureMatchReport
import com.photogrammetrystudio.app.model.PhotoProject
import com.photogrammetrystudio.app.model.CameraPoseSummary
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.DenseReconstructionReport
import com.photogrammetrystudio.app.model.DenseFusionPairEvaluation
import com.photogrammetrystudio.app.model.DenseFusionReport
import com.photogrammetrystudio.app.model.MeshTriangle
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureProjectionReport
import com.photogrammetrystudio.app.model.TextureCameraContribution
import com.photogrammetrystudio.app.model.FaceTextureAssignment
import com.photogrammetrystudio.app.model.FaceTextureCameraContribution
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import com.photogrammetrystudio.app.model.TextureAtlasReport
import com.photogrammetrystudio.app.model.FaceAtlasUv
import com.photogrammetrystudio.app.model.VertexColor
import com.photogrammetrystudio.app.model.MultiViewPairEvaluation
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.ScanMode
import com.photogrammetrystudio.app.model.LaserLineColor
import com.photogrammetrystudio.app.model.LaserLinePoint
import com.photogrammetrystudio.app.model.LaserLineReport
import com.photogrammetrystudio.app.model.LaserAnalysisRun
import com.photogrammetrystudio.app.model.LaserPlane3D
import com.photogrammetrystudio.app.model.LaserPlaneCalibrationReport
import com.photogrammetrystudio.app.model.SparsePairEvaluation
import com.photogrammetrystudio.app.model.SparsePoint
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.UUID

class ProjectRepository(private val context: Context) {
    private val root = File(context.filesDir, "projects").apply { mkdirs() }

    fun listProjects(): List<PhotoProject> = root.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull(::readProject)
        ?.sortedByDescending { it.createdAt }
        .orEmpty()

    fun createProject(name: String, scanMode: ScanMode): PhotoProject {
        val id = UUID.randomUUID().toString()
        val dir = File(root, id).apply { mkdirs() }
        File(dir, "photos").mkdirs()
        File(dir, "laser").mkdirs()
        File(dir, "depth").mkdirs()
        File(dir, "models").mkdirs()
        File(dir, "reports").mkdirs()
        val project = PhotoProject(
            id = id,
            name = name.trim().ifBlank { "Untitled project" },
            createdAt = System.currentTimeMillis(),
            directory = dir,
            scanMode = scanMode
        )
        writeMetadata(project)
        return readProject(dir) ?: project
    }

    fun getProject(id: String): PhotoProject? = readProject(File(root, id))

    fun deleteProject(id: String): Boolean {
        val dir = File(root, id)
        if (!dir.exists()) return true
        val rootCanonical = root.canonicalFile
        val dirCanonical = dir.canonicalFile
        if (dirCanonical.parentFile != rootCanonical) return false
        return dirCanonical.deleteRecursively()
    }

    fun photoOutputFile(projectId: String): File {
        val dir = File(File(root, projectId), "photos").apply { mkdirs() }
        return File(dir, "IMG_${System.currentTimeMillis()}.jpg")
    }

    fun importPhotos(projectId: String, uris: List<Uri>): Int {
        val photoDir = File(File(root, projectId), "photos").apply { mkdirs() }
        var copied = 0
        uris.forEachIndexed { index, uri ->
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val extension = when (context.contentResolver.getType(uri)?.lowercase()) {
                        "image/png" -> "png"
                        "image/webp" -> "webp"
                        "image/heic", "image/heif" -> "heic"
                        else -> "jpg"
                    }
                    val out = File(photoDir, "IMPORT_${System.currentTimeMillis()}_${index}.$extension")
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                    copied++
                }
            }
        }
        if (copied > 0) clearFeatureMatchReport(projectId)
        return copied
    }


    fun importLaserFrame(projectId: String, uri: Uri, laserOn: Boolean): File? {
        val dir = File(File(root, projectId), "laser").apply { mkdirs() }
        val prefix = if (laserOn) "laser_on" else "laser_off"
        dir.listFiles()?.filter { it.name.startsWith("${prefix}.") }?.forEach { it.delete() }
        val extension = when (context.contentResolver.getType(uri)?.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/heic", "image/heif" -> "heic"
            else -> "jpg"
        }
        val out = File(dir, "$prefix.$extension")
        val copied = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(out).use { output -> input.copyTo(output) }
            } ?: error("Could not open imported laser frame")
            true
        }.getOrDefault(false)
        if (!copied) {
            out.delete()
            return null
        }
        clearLaserLineResult(projectId)
        return out
    }

    fun laserFrame(projectId: String, laserOn: Boolean): File? {
        val dir = File(File(root, projectId), "laser")
        val prefix = if (laserOn) "laser_on." else "laser_off."
        return dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith(prefix) }
    }

    fun saveLaserLineResult(projectId: String, report: LaserLineReport, previewPng: ByteArray) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val laserDir = File(projectDir, "laser").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("laserColor", report.laserColor.name)
            .put("threshold", report.threshold)
            .put("imageWidth", report.imageWidth)
            .put("imageHeight", report.imageHeight)
            .put("detectedRows", report.detectedRows)
            .put("coveragePercent", report.coveragePercent)
            .put("meanSignal", report.meanSignal)
            .put("meanLineWidthPx", report.meanLineWidthPx)
            .put("continuityPercent", report.continuityPercent)
            .put("minX", report.minX)
            .put("maxX", report.maxX)
            .put("readyForTriangulation", report.readyForTriangulation)
            .put("extractionOrientation", report.extractionOrientation)
            .put("sampleAxisLength", report.sampleAxisLength)
            .put("warnings", JSONArray().apply { report.warnings.forEach(::put) })
            .put("points", JSONArray().apply {
                report.points.forEach { point ->
                    put(JSONObject().put("row", point.row).put("x", point.x).put("strength", point.strength))
                }
            })
        File(reportsDir, "laser_line_report.json").writeText(json.toString(2))
        File(laserDir, "laser_line_preview.png").writeBytes(previewPng)
    }

    fun loadLaserLineReport(projectId: String): LaserLineReport? {
        val file = File(File(File(root, projectId), "reports"), "laser_line_report.json")
        if (!file.exists()) return null
        return runCatching {
            val json = JSONObject(file.readText())
            val warningsJson = json.optJSONArray("warnings") ?: JSONArray()
            val warnings = buildList {
                for (i in 0 until warningsJson.length()) add(warningsJson.optString(i))
            }
            val pointsJson = json.optJSONArray("points") ?: JSONArray()
            val points = buildList {
                for (i in 0 until pointsJson.length()) {
                    val obj = pointsJson.getJSONObject(i)
                    add(LaserLinePoint(obj.getInt("row"), obj.getDouble("x"), obj.optDouble("strength", 0.0)))
                }
            }
            LaserLineReport(
                engine = json.getString("engine"),
                laserColor = runCatching { LaserLineColor.valueOf(json.getString("laserColor")) }.getOrDefault(LaserLineColor.RED),
                threshold = json.getInt("threshold"),
                imageWidth = json.getInt("imageWidth"),
                imageHeight = json.getInt("imageHeight"),
                detectedRows = json.getInt("detectedRows"),
                coveragePercent = json.getDouble("coveragePercent"),
                meanSignal = json.getDouble("meanSignal"),
                meanLineWidthPx = json.getDouble("meanLineWidthPx"),
                continuityPercent = json.getDouble("continuityPercent"),
                minX = json.getDouble("minX"),
                maxX = json.getDouble("maxX"),
                points = points,
                warnings = warnings,
                readyForTriangulation = json.optBoolean("readyForTriangulation", false),
                extractionOrientation = json.optString("extractionOrientation", "ROW_WISE"),
                sampleAxisLength = json.optInt("sampleAxisLength", json.optInt("imageHeight", 0))
            )
        }.getOrNull()
    }

    fun laserPreviewBytes(projectId: String): ByteArray? {
        val file = File(File(File(root, projectId), "laser"), "laser_line_preview.png")
        return if (file.exists()) runCatching { file.readBytes() }.getOrNull() else null
    }

    fun saveLaserPlaneResult(
        projectId: String,
        report: LaserPlaneCalibrationReport,
        previewPng: ByteArray,
        plyBytes: ByteArray
    ) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val laserDir = File(projectDir, "laser").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("targetPresetId", report.targetPresetId)
            .put("imageWidth", report.imageWidth)
            .put("imageHeight", report.imageHeight)
            .put("detectedMarkerIds", JSONArray().apply { report.detectedMarkerIds.forEach(::put) })
            .put("leftMarkerIds", JSONArray().apply { report.leftMarkerIds.forEach(::put) })
            .put("rightMarkerIds", JSONArray().apply { report.rightMarkerIds.forEach(::put) })
            .put("leftPlane", report.leftPlane?.let(::laserPlaneToJson))
            .put("rightPlane", report.rightPlane?.let(::laserPlaneToJson))
            .put("panelAngleDegrees", report.panelAngleDegrees)
            .put("leftBackgroundStripePoints", report.leftBackgroundStripePoints)
            .put("rightBackgroundStripePoints", report.rightBackgroundStripePoints)
            .put("fittedLaserPoints", report.fittedLaserPoints)
            .put("laserPlane", report.laserPlane?.let(::laserPlaneToJson))
            .put("meanLaserPlaneResidualMm", report.meanLaserPlaneResidualMm)
            .put("readyForSingleFrame3d", report.readyForSingleFrame3d)
            .put("warnings", JSONArray().apply { report.warnings.forEach(::put) })
            .put("triangulatedStripePoints", sparsePointsToJson(report.triangulatedStripePoints))
            .put("nonBackdropStripePoints", sparsePointsToJson(report.nonBackdropStripePoints))
        File(reportsDir, "laser_plane_report.json").writeText(json.toString(2))
        File(laserDir, "laser_plane_preview.png").writeBytes(previewPng)
        File(laserDir, "laser_single_frame.ply").writeBytes(plyBytes)
    }

    fun loadLaserPlaneReport(projectId: String): LaserPlaneCalibrationReport? {
        val file = File(File(File(root, projectId), "reports"), "laser_plane_report.json")
        if (!file.exists()) return null
        return runCatching {
            val json = JSONObject(file.readText())
            fun ints(name: String): List<Int> {
                val arr = json.optJSONArray(name) ?: JSONArray()
                return buildList { for (i in 0 until arr.length()) add(arr.optInt(i)) }
            }
            val warningsArr = json.optJSONArray("warnings") ?: JSONArray()
            val warnings = buildList { for (i in 0 until warningsArr.length()) add(warningsArr.optString(i)) }
            LaserPlaneCalibrationReport(
                engine = json.optString("engine"),
                targetPresetId = json.optString("targetPresetId"),
                imageWidth = json.optInt("imageWidth"),
                imageHeight = json.optInt("imageHeight"),
                detectedMarkerIds = ints("detectedMarkerIds"),
                leftMarkerIds = ints("leftMarkerIds"),
                rightMarkerIds = ints("rightMarkerIds"),
                leftPlane = json.optJSONObject("leftPlane")?.let(::laserPlaneFromJson),
                rightPlane = json.optJSONObject("rightPlane")?.let(::laserPlaneFromJson),
                panelAngleDegrees = json.optDouble("panelAngleDegrees"),
                leftBackgroundStripePoints = json.optInt("leftBackgroundStripePoints"),
                rightBackgroundStripePoints = json.optInt("rightBackgroundStripePoints"),
                fittedLaserPoints = json.optInt("fittedLaserPoints"),
                laserPlane = json.optJSONObject("laserPlane")?.let(::laserPlaneFromJson),
                meanLaserPlaneResidualMm = json.optDouble("meanLaserPlaneResidualMm"),
                triangulatedStripePoints = sparsePointsFromJson(json.optJSONArray("triangulatedStripePoints") ?: JSONArray()),
                nonBackdropStripePoints = sparsePointsFromJson(json.optJSONArray("nonBackdropStripePoints") ?: JSONArray()),
                warnings = warnings,
                readyForSingleFrame3d = json.optBoolean("readyForSingleFrame3d", false)
            )
        }.getOrNull()
    }

    fun laserPlanePreviewBytes(projectId: String): ByteArray? {
        val file = File(File(File(root, projectId), "laser"), "laser_plane_preview.png")
        return if (file.exists()) runCatching { file.readBytes() }.getOrNull() else null
    }

    fun laserSingleFramePlyBytes(projectId: String): ByteArray? {
        val file = File(File(File(root, projectId), "laser"), "laser_single_frame.ply")
        return if (file.exists()) runCatching { file.readBytes() }.getOrNull() else null
    }

    fun clearLaserPlaneResult(projectId: String) {
        File(File(File(root, projectId), "reports"), "laser_plane_report.json").delete()
        File(File(File(root, projectId), "laser"), "laser_plane_preview.png").delete()
        File(File(File(root, projectId), "laser"), "laser_single_frame.ply").delete()
    }

    private fun laserPlaneToJson(p: LaserPlane3D): JSONObject = JSONObject()
        .put("nx", p.nx).put("ny", p.ny).put("nz", p.nz).put("d", p.d)

    private fun laserPlaneFromJson(json: JSONObject): LaserPlane3D = LaserPlane3D(
        json.optDouble("nx"), json.optDouble("ny"), json.optDouble("nz"), json.optDouble("d")
    )

    private fun sparsePointsToJson(points: List<SparsePoint>): JSONArray = JSONArray().apply {
        points.forEach { put(JSONArray().put(it.x).put(it.y).put(it.z)) }
    }

    private fun sparsePointsFromJson(arr: JSONArray): List<SparsePoint> = buildList {
        for (i in 0 until arr.length()) {
            val p = arr.optJSONArray(i) ?: continue
            add(SparsePoint(p.optDouble(0), p.optDouble(1), p.optDouble(2)))
        }
    }

    /**
     * Append one laser Analyze attempt using the shared cross-platform JSONL schema.
     * The file is bounded to the newest 200 runs so repeated tuning cannot grow forever.
     */
    fun appendLaserAnalysisRun(projectId: String, run: LaserAnalysisRun) {
        val reportsDir = File(File(root, projectId), "reports").apply { mkdirs() }
        val file = File(reportsDir, "laser_analysis_history.jsonl")
        val json = laserAnalysisRunToJson(run).toString()
        val lines = if (file.exists()) {
            runCatching { file.readLines().filter { it.isNotBlank() }.toMutableList() }.getOrDefault(mutableListOf())
        } else mutableListOf()
        lines += json
        val bounded = lines.takeLast(200)
        file.writeText(bounded.joinToString(separator = "\n", postfix = if (bounded.isEmpty()) "" else "\n"))
    }

    fun loadLaserAnalysisHistory(projectId: String): List<LaserAnalysisRun> {
        val file = File(File(File(root, projectId), "reports"), "laser_analysis_history.jsonl")
        if (!file.exists()) return emptyList()
        return runCatching {
            file.readLines()
                .asSequence()
                .filter { it.isNotBlank() }
                .mapNotNull { line -> runCatching { laserAnalysisRunFromJson(JSONObject(line)) }.getOrNull() }
                .toList()
                .asReversed() // newest first for UI; the file itself stays chronological
        }.getOrDefault(emptyList())
    }

    fun laserAnalysisHistoryBytes(projectId: String): ByteArray? {
        val file = File(File(File(root, projectId), "reports"), "laser_analysis_history.jsonl")
        return if (file.exists()) runCatching { file.readBytes() }.getOrNull() else null
    }

    private fun laserAnalysisRunToJson(run: LaserAnalysisRun): JSONObject {
        val json = JSONObject()
            .put("schemaVersion", run.schemaVersion)
            .put("runId", run.runId)
            .put("timestampEpochMs", run.timestampEpochMs)
            .put("timestampUtc", java.time.Instant.ofEpochMilli(run.timestampEpochMs).toString())
            .put("projectId", run.projectId)
            .put("laserColor", run.laserColor.name)
            .put("threshold", run.threshold)
            .put("success", run.success)
            .put("durationMs", run.durationMs)
        run.engine?.let { json.put("engine", it) }
        run.laserOffFileName?.let { json.put("laserOffFileName", it) }
        run.laserOnFileName?.let { json.put("laserOnFileName", it) }
        run.laserOffSizeBytes?.let { json.put("laserOffSizeBytes", it) }
        run.laserOnSizeBytes?.let { json.put("laserOnSizeBytes", it) }
        run.laserOffModifiedMs?.let { json.put("laserOffModifiedMs", it) }
        run.laserOnModifiedMs?.let { json.put("laserOnModifiedMs", it) }
        run.laserTargetPresetId?.let { json.put("laserTargetPresetId", it) }
        run.imageWidth?.let { json.put("imageWidth", it) }
        run.imageHeight?.let { json.put("imageHeight", it) }
        run.detectedRows?.let { json.put("detectedRows", it) }
        run.coveragePercent?.let { json.put("coveragePercent", it) }
        run.continuityPercent?.let { json.put("continuityPercent", it) }
        run.meanSignal?.let { json.put("meanSignal", it) }
        run.meanLineWidthPx?.let { json.put("meanLineWidthPx", it) }
        run.minX?.let { json.put("minX", it) }
        run.maxX?.let { json.put("maxX", it) }
        run.readyForTriangulation?.let { json.put("readyForTriangulation", it) }
        run.extractionOrientation?.let { json.put("extractionOrientation", it) }
        run.sampleAxisLength?.let { json.put("sampleAxisLength", it) }
        run.errorType?.let { json.put("errorType", it) }
        run.errorMessage?.let { json.put("errorMessage", it) }
        run.errorStackTrace?.let { json.put("errorStackTrace", it) }
        return json
    }

    private fun laserAnalysisRunFromJson(json: JSONObject): LaserAnalysisRun = LaserAnalysisRun(
        schemaVersion = json.optInt("schemaVersion", 1),
        runId = json.getString("runId"),
        timestampEpochMs = json.getLong("timestampEpochMs"),
        projectId = json.optString("projectId", ""),
        laserColor = runCatching { LaserLineColor.valueOf(json.getString("laserColor")) }.getOrDefault(LaserLineColor.RED),
        threshold = json.getInt("threshold"),
        success = json.optBoolean("success", false),
        durationMs = json.optLong("durationMs", 0L),
        engine = json.optString("engine").takeIf { it.isNotBlank() },
        laserOffFileName = json.optString("laserOffFileName").takeIf { it.isNotBlank() },
        laserOnFileName = json.optString("laserOnFileName").takeIf { it.isNotBlank() },
        laserOffSizeBytes = json.optLong("laserOffSizeBytes").takeIf { json.has("laserOffSizeBytes") },
        laserOnSizeBytes = json.optLong("laserOnSizeBytes").takeIf { json.has("laserOnSizeBytes") },
        laserOffModifiedMs = json.optLong("laserOffModifiedMs").takeIf { json.has("laserOffModifiedMs") },
        laserOnModifiedMs = json.optLong("laserOnModifiedMs").takeIf { json.has("laserOnModifiedMs") },
        laserTargetPresetId = json.optString("laserTargetPresetId").takeIf { it.isNotBlank() },
        imageWidth = json.optInt("imageWidth").takeIf { json.has("imageWidth") },
        imageHeight = json.optInt("imageHeight").takeIf { json.has("imageHeight") },
        detectedRows = json.optInt("detectedRows").takeIf { json.has("detectedRows") },
        coveragePercent = json.optDouble("coveragePercent").takeIf { json.has("coveragePercent") },
        continuityPercent = json.optDouble("continuityPercent").takeIf { json.has("continuityPercent") },
        meanSignal = json.optDouble("meanSignal").takeIf { json.has("meanSignal") },
        meanLineWidthPx = json.optDouble("meanLineWidthPx").takeIf { json.has("meanLineWidthPx") },
        minX = json.optDouble("minX").takeIf { json.has("minX") },
        maxX = json.optDouble("maxX").takeIf { json.has("maxX") },
        readyForTriangulation = json.optBoolean("readyForTriangulation").takeIf { json.has("readyForTriangulation") },
        extractionOrientation = json.optString("extractionOrientation").takeIf { it.isNotBlank() },
        sampleAxisLength = json.optInt("sampleAxisLength").takeIf { json.has("sampleAxisLength") },
        errorType = json.optString("errorType").takeIf { it.isNotBlank() },
        errorMessage = json.optString("errorMessage").takeIf { it.isNotBlank() },
        errorStackTrace = json.optString("errorStackTrace").takeIf { it.isNotBlank() }
    )

    fun clearLaserLineResult(projectId: String) {
        File(File(File(root, projectId), "reports"), "laser_line_report.json").delete()
        File(File(File(root, projectId), "laser"), "laser_line_preview.png").delete()
        clearLaserPlaneResult(projectId)
    }

    fun deletePhoto(projectId: String, file: File): Boolean {
        val expectedParent = File(File(root, projectId), "photos").canonicalFile
        val actualParent = file.parentFile?.canonicalFile
        if (expectedParent != actualParent) return false
        val deleted = file.delete()
        if (deleted) clearFeatureMatchReport(projectId)
        return deleted
    }

    fun saveFeatureMatchReport(projectId: String, report: FeatureMatchReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("analyzedPhotos", report.analyzedPhotos)
            .put("totalKeypoints", report.totalKeypoints)
            .put("strongOrUsablePairs", report.strongOrUsablePairs)
            .put("readyForSparseReconstruction", report.readyForSparseReconstruction)
            .put("savedAt", System.currentTimeMillis())

        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)

        val pairs = JSONArray()
        report.adjacentPairs.forEach { pair ->
            pairs.put(
                JSONObject()
                    .put("firstPhoto", pair.firstPhoto)
                    .put("secondPhoto", pair.secondPhoto)
                    .put("firstKeypoints", pair.firstKeypoints)
                    .put("secondKeypoints", pair.secondKeypoints)
                    .put("goodMatches", pair.goodMatches)
                    .put("quality", pair.quality)
            )
        }
        json.put("adjacentPairs", pairs)
        File(reportsDir, "feature_match.json").writeText(json.toString(2))
    }

    fun loadFeatureMatchReport(projectId: String): FeatureMatchReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "feature_match.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList {
            for (i in 0 until warningArray.length()) add(warningArray.getString(i))
        }
        val pairArray = json.optJSONArray("adjacentPairs") ?: JSONArray()
        val pairs = buildList {
            for (i in 0 until pairArray.length()) {
                val pair = pairArray.getJSONObject(i)
                add(
                    FeatureMatchPair(
                        firstPhoto = pair.getString("firstPhoto"),
                        secondPhoto = pair.getString("secondPhoto"),
                        firstKeypoints = pair.getInt("firstKeypoints"),
                        secondKeypoints = pair.getInt("secondKeypoints"),
                        goodMatches = pair.getInt("goodMatches"),
                        quality = pair.getString("quality")
                    )
                )
            }
        }
        FeatureMatchReport(
            engine = json.getString("engine"),
            analyzedPhotos = json.getInt("analyzedPhotos"),
            totalKeypoints = json.getInt("totalKeypoints"),
            adjacentPairs = pairs,
            strongOrUsablePairs = json.getInt("strongOrUsablePairs"),
            warnings = warnings,
            readyForSparseReconstruction = json.getBoolean("readyForSparseReconstruction")
        )
    }.getOrNull()

    fun clearFeatureMatchReport(projectId: String) {
        File(File(File(root, projectId), "reports"), "feature_match.json").delete()
        clearSparseReconstruction(projectId)
    }

    fun saveSparseReconstruction(projectId: String, report: SparseReconstructionReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }

        val json = JSONObject()
            .put("engine", report.engine)
            .put("firstPhoto", report.firstPhoto)
            .put("secondPhoto", report.secondPhoto)
            .put("ratioMatches", report.ratioMatches)
            .put("ransacInliers", report.ransacInliers)
            .put("poseInliers", report.poseInliers)
            .put("triangulatedPoints", report.triangulatedPoints)
            .put("focalPixels", report.focalPixels)
            .put("intrinsicsSource", report.intrinsicsSource)
            .put("relativeRotationDegrees", report.relativeRotationDegrees)
            .put("readyForMultiView", report.readyForMultiView)
            .put("savedAt", System.currentTimeMillis())

        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)

        val evals = JSONArray()
        report.pairEvaluations.forEach { item ->
            evals.put(
                JSONObject()
                    .put("firstPhoto", item.firstPhoto)
                    .put("secondPhoto", item.secondPhoto)
                    .put("ratioMatches", item.ratioMatches)
                    .put("ransacInliers", item.ransacInliers)
                    .put("poseInliers", item.poseInliers)
            )
        }
        json.put("pairEvaluations", evals)

        val points = JSONArray()
        report.points.forEach { point ->
            points.put(JSONArray().put(point.x).put(point.y).put(point.z))
        }
        json.put("points", points)
        File(reportsDir, "sparse_reconstruction.json").writeText(json.toString(2))
        File(modelsDir, "sparse_best_pair.ply").writeText(sparsePly(report.points))
    }

    fun loadSparseReconstruction(projectId: String): SparseReconstructionReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "sparse_reconstruction.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList {
            for (i in 0 until warningArray.length()) add(warningArray.getString(i))
        }
        val evalArray = json.optJSONArray("pairEvaluations") ?: JSONArray()
        val evaluations = buildList {
            for (i in 0 until evalArray.length()) {
                val item = evalArray.getJSONObject(i)
                add(
                    SparsePairEvaluation(
                        firstPhoto = item.getString("firstPhoto"),
                        secondPhoto = item.getString("secondPhoto"),
                        ratioMatches = item.getInt("ratioMatches"),
                        ransacInliers = item.getInt("ransacInliers"),
                        poseInliers = item.getInt("poseInliers")
                    )
                )
            }
        }
        val pointArray = json.optJSONArray("points") ?: JSONArray()
        val points = buildList {
            for (i in 0 until pointArray.length()) {
                val item = pointArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }
        SparseReconstructionReport(
            engine = json.getString("engine"),
            firstPhoto = json.getString("firstPhoto"),
            secondPhoto = json.getString("secondPhoto"),
            ratioMatches = json.getInt("ratioMatches"),
            ransacInliers = json.getInt("ransacInliers"),
            poseInliers = json.getInt("poseInliers"),
            triangulatedPoints = json.getInt("triangulatedPoints"),
            focalPixels = json.getDouble("focalPixels"),
            intrinsicsSource = json.getString("intrinsicsSource"),
            relativeRotationDegrees = json.getDouble("relativeRotationDegrees"),
            pairEvaluations = evaluations,
            points = points,
            warnings = warnings,
            readyForMultiView = json.getBoolean("readyForMultiView")
        )
    }.getOrNull()

    fun sparsePlyFile(projectId: String): File =
        File(File(File(root, projectId), "models"), "sparse_best_pair.ply")

    fun clearSparseReconstruction(projectId: String) {
        File(File(File(root, projectId), "reports"), "sparse_reconstruction.json").delete()
        sparsePlyFile(projectId).delete()
        clearMultiViewReconstruction(projectId)
    }


    fun saveMultiViewReconstruction(projectId: String, report: MultiViewReconstructionReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }

        val json = JSONObject()
            .put("engine", report.engine)
            .put("photosRequested", report.photosRequested)
            .put("connectedCameras", report.connectedCameras)
            .put("connectedPairs", report.connectedPairs)
            .put("rawTriangulatedPoints", report.rawTriangulatedPoints)
            .put("combinedPoints", report.combinedPoints)
            .put("focalPixels", report.focalPixels)
            .put("intrinsicsSource", report.intrinsicsSource)
            .put("readyForBundleAdjustment", report.readyForBundleAdjustment)
            .put("savedAt", System.currentTimeMillis())

        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)

        val evals = JSONArray()
        report.pairEvaluations.forEach { item ->
            evals.put(
                JSONObject()
                    .put("firstPhoto", item.firstPhoto)
                    .put("secondPhoto", item.secondPhoto)
                    .put("ratioMatches", item.ratioMatches)
                    .put("ransacInliers", item.ransacInliers)
                    .put("poseInliers", item.poseInliers)
                    .put("triangulatedPoints", item.triangulatedPoints)
                    .put("connected", item.connected)
                    .put("relativeRotationDegrees", item.relativeRotationDegrees)
            )
        }
        json.put("pairEvaluations", evals)

        val cameras = JSONArray()
        report.cameras.forEach { camera ->
            cameras.put(
                JSONObject()
                    .put("photo", camera.photo)
                    .put("index", camera.index)
                    .put("connected", camera.connected)
                    .put("x", camera.x)
                    .put("y", camera.y)
                    .put("z", camera.z)
            )
        }
        json.put("cameras", cameras)

        val points = JSONArray()
        report.points.forEach { point ->
            points.put(JSONArray().put(point.x).put(point.y).put(point.z))
        }
        json.put("points", points)

        File(reportsDir, "multiview_reconstruction.json").writeText(json.toString(2))
        File(modelsDir, "multiview_sparse.ply").writeText(multiViewPly(report.points))
    }

    fun loadMultiViewReconstruction(projectId: String): MultiViewReconstructionReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "multiview_reconstruction.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())

        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList {
            for (i in 0 until warningArray.length()) add(warningArray.getString(i))
        }

        val evalArray = json.optJSONArray("pairEvaluations") ?: JSONArray()
        val evaluations = buildList {
            for (i in 0 until evalArray.length()) {
                val item = evalArray.getJSONObject(i)
                add(
                    MultiViewPairEvaluation(
                        firstPhoto = item.getString("firstPhoto"),
                        secondPhoto = item.getString("secondPhoto"),
                        ratioMatches = item.getInt("ratioMatches"),
                        ransacInliers = item.getInt("ransacInliers"),
                        poseInliers = item.getInt("poseInliers"),
                        triangulatedPoints = item.getInt("triangulatedPoints"),
                        connected = item.getBoolean("connected"),
                        relativeRotationDegrees = item.getDouble("relativeRotationDegrees")
                    )
                )
            }
        }

        val cameraArray = json.optJSONArray("cameras") ?: JSONArray()
        val cameras = buildList {
            for (i in 0 until cameraArray.length()) {
                val item = cameraArray.getJSONObject(i)
                add(
                    CameraPoseSummary(
                        photo = item.getString("photo"),
                        index = item.getInt("index"),
                        connected = item.getBoolean("connected"),
                        x = item.getDouble("x"),
                        y = item.getDouble("y"),
                        z = item.getDouble("z")
                    )
                )
            }
        }

        val pointArray = json.optJSONArray("points") ?: JSONArray()
        val points = buildList {
            for (i in 0 until pointArray.length()) {
                val item = pointArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }

        MultiViewReconstructionReport(
            engine = json.getString("engine"),
            photosRequested = json.getInt("photosRequested"),
            connectedCameras = json.getInt("connectedCameras"),
            connectedPairs = json.getInt("connectedPairs"),
            rawTriangulatedPoints = json.getInt("rawTriangulatedPoints"),
            combinedPoints = json.getInt("combinedPoints"),
            focalPixels = json.getDouble("focalPixels"),
            intrinsicsSource = json.getString("intrinsicsSource"),
            pairEvaluations = evaluations,
            cameras = cameras,
            points = points,
            warnings = warnings,
            readyForBundleAdjustment = json.getBoolean("readyForBundleAdjustment")
        )
    }.getOrNull()

    fun multiViewPlyFile(projectId: String): File =
        File(File(File(root, projectId), "models"), "multiview_sparse.ply")

    fun clearMultiViewReconstruction(projectId: String) {
        File(File(File(root, projectId), "reports"), "multiview_reconstruction.json").delete()
        multiViewPlyFile(projectId).delete()
        clearBundleAdjustment(projectId)
    }


    fun saveBundleAdjustment(projectId: String, report: BundleAdjustmentReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("connectedCameras", report.connectedCameras)
            .put("tracksBuilt", report.tracksBuilt)
            .put("tracksUsed", report.tracksUsed)
            .put("observationsUsed", report.observationsUsed)
            .put("initialPoints", report.initialPoints)
            .put("refinedPoints", report.refinedPoints)
            .put("initialRmsPixels", report.initialRmsPixels)
            .put("finalRmsPixels", report.finalRmsPixels)
            .put("iterations", report.iterations)
            .put("readyForDenseReconstruction", report.readyForDenseReconstruction)
            .put("savedAt", System.currentTimeMillis())

        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)

        val cameras = JSONArray()
        report.cameras.forEach { camera ->
            cameras.put(JSONObject()
                .put("photo", camera.photo).put("index", camera.index).put("connected", camera.connected)
                .put("x", camera.x).put("y", camera.y).put("z", camera.z))
        }
        json.put("cameras", cameras)

        val points = JSONArray()
        report.points.forEach { p -> points.put(JSONArray().put(p.x).put(p.y).put(p.z)) }
        json.put("points", points)

        File(reportsDir, "bundle_adjustment.json").writeText(json.toString(2))
        File(modelsDir, "bundle_refined_sparse.ply").writeText(bundlePly(report.points))
    }

    fun loadBundleAdjustment(projectId: String): BundleAdjustmentReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "bundle_adjustment.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        val cameraArray = json.optJSONArray("cameras") ?: JSONArray()
        val cameras = buildList {
            for (i in 0 until cameraArray.length()) {
                val item = cameraArray.getJSONObject(i)
                add(CameraPoseSummary(item.getString("photo"), item.getInt("index"), item.getBoolean("connected"), item.getDouble("x"), item.getDouble("y"), item.getDouble("z")))
            }
        }
        val pointArray = json.optJSONArray("points") ?: JSONArray()
        val points = buildList {
            for (i in 0 until pointArray.length()) {
                val item = pointArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }
        BundleAdjustmentReport(
            engine = json.getString("engine"), connectedCameras = json.getInt("connectedCameras"),
            tracksBuilt = json.getInt("tracksBuilt"), tracksUsed = json.getInt("tracksUsed"),
            observationsUsed = json.getInt("observationsUsed"), initialPoints = json.getInt("initialPoints"),
            refinedPoints = json.getInt("refinedPoints"), initialRmsPixels = json.getDouble("initialRmsPixels"),
            finalRmsPixels = json.getDouble("finalRmsPixels"), iterations = json.getInt("iterations"),
            cameras = cameras, points = points, warnings = warnings,
            readyForDenseReconstruction = json.getBoolean("readyForDenseReconstruction")
        )
    }.getOrNull()

    fun bundlePlyFile(projectId: String): File = File(File(File(root, projectId), "models"), "bundle_refined_sparse.ply")

    fun clearBundleAdjustment(projectId: String) {
        File(File(File(root, projectId), "reports"), "bundle_adjustment.json").delete()
        bundlePlyFile(projectId).delete()
        clearDenseReconstruction(projectId)
    }

    fun saveDenseReconstruction(projectId: String, report: DenseReconstructionReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("firstPhoto", report.firstPhoto)
            .put("secondPhoto", report.secondPhoto)
            .put("width", report.width)
            .put("height", report.height)
            .put("ratioMatches", report.ratioMatches)
            .put("ransacInliers", report.ransacInliers)
            .put("poseInliers", report.poseInliers)
            .put("minDisparity", report.minDisparity)
            .put("numDisparities", report.numDisparities)
            .put("blockSize", report.blockSize)
            .put("observedDisparityLow", report.observedDisparityLow)
            .put("observedDisparityMedian", report.observedDisparityMedian)
            .put("observedDisparityHigh", report.observedDisparityHigh)
            .put("validDisparityPixels", report.validDisparityPixels)
            .put("geometryGuidedPoints", report.geometryGuidedPoints)
            .put("densePoints", report.densePoints)
            .put("minDepth", report.minDepth)
            .put("medianDepth", report.medianDepth)
            .put("maxDepth", report.maxDepth)
            .put("readyForDenseFusion", report.readyForDenseFusion)
            .put("savedAt", System.currentTimeMillis())
        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)
        val points = JSONArray()
        report.points.forEach { p -> points.put(JSONArray().put(p.x).put(p.y).put(p.z)) }
        json.put("points", points)
        File(reportsDir, "dense_pair_reconstruction.json").writeText(json.toString(2))
        File(modelsDir, "dense_pair_cloud.ply").writeText(densePly(report.points))
    }

    fun loadDenseReconstruction(projectId: String): DenseReconstructionReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "dense_pair_reconstruction.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        val pointArray = json.optJSONArray("points") ?: JSONArray()
        val points = buildList {
            for (i in 0 until pointArray.length()) {
                val item = pointArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }
        DenseReconstructionReport(
            engine = json.getString("engine"),
            firstPhoto = json.getString("firstPhoto"), secondPhoto = json.getString("secondPhoto"),
            width = json.getInt("width"), height = json.getInt("height"),
            ratioMatches = json.getInt("ratioMatches"), ransacInliers = json.getInt("ransacInliers"), poseInliers = json.getInt("poseInliers"),
            minDisparity = json.optInt("minDisparity", 0), numDisparities = json.getInt("numDisparities"), blockSize = json.getInt("blockSize"),
            observedDisparityLow = json.optDouble("observedDisparityLow", 0.0),
            observedDisparityMedian = json.optDouble("observedDisparityMedian", 0.0),
            observedDisparityHigh = json.optDouble("observedDisparityHigh", 0.0),
            validDisparityPixels = json.getInt("validDisparityPixels"),
            geometryGuidedPoints = json.optInt("geometryGuidedPoints", 0),
            densePoints = json.getInt("densePoints"),
            minDepth = json.getDouble("minDepth"), medianDepth = json.getDouble("medianDepth"), maxDepth = json.getDouble("maxDepth"),
            points = points, warnings = warnings, readyForDenseFusion = json.getBoolean("readyForDenseFusion")
        )
    }.getOrNull()

    fun densePlyFile(projectId: String): File = File(File(File(root, projectId), "models"), "dense_pair_cloud.ply")

    fun clearDenseReconstruction(projectId: String) {
        File(File(File(root, projectId), "reports"), "dense_pair_reconstruction.json").delete()
        densePlyFile(projectId).delete()
        clearDenseFusion(projectId)
    }

    fun saveDenseFusion(projectId: String, report: DenseFusionReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("photosRequested", report.photosRequested)
            .put("connectedCameras", report.connectedCameras)
            .put("candidatePairs", report.candidatePairs)
            .put("pairsFused", report.pairsFused)
            .put("rawDensePoints", report.rawDensePoints)
            .put("fusedPoints", report.fusedPoints)
            .put("readyForSurfaceReconstruction", report.readyForSurfaceReconstruction)
            .put("savedAt", System.currentTimeMillis())
        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)
        val pairArray = JSONArray()
        report.pairEvaluations.forEach { pair ->
            pairArray.put(JSONObject()
                .put("firstPhoto", pair.firstPhoto)
                .put("secondPhoto", pair.secondPhoto)
                .put("poseInliers", pair.poseInliers)
                .put("observedDisparityMedian", pair.observedDisparityMedian)
                .put("validDisparityPixels", pair.validDisparityPixels)
                .put("localDensePoints", pair.localDensePoints)
                .put("fusedPoints", pair.fusedPoints)
                .put("accepted", pair.accepted)
                .put("reason", pair.reason))
        }
        json.put("pairEvaluations", pairArray)
        val points = JSONArray()
        report.points.forEach { p -> points.put(JSONArray().put(p.x).put(p.y).put(p.z)) }
        json.put("points", points)
        File(reportsDir, "dense_fusion.json").writeText(json.toString(2))
        File(modelsDir, "dense_fused_cloud.ply").writeText(denseFusionPly(report.points))
    }

    fun loadDenseFusion(projectId: String): DenseFusionReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "dense_fusion.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        val pairArray = json.optJSONArray("pairEvaluations") ?: JSONArray()
        val pairs = buildList {
            for (i in 0 until pairArray.length()) {
                val item = pairArray.getJSONObject(i)
                add(DenseFusionPairEvaluation(
                    firstPhoto = item.getString("firstPhoto"),
                    secondPhoto = item.getString("secondPhoto"),
                    poseInliers = item.getInt("poseInliers"),
                    observedDisparityMedian = item.getDouble("observedDisparityMedian"),
                    validDisparityPixels = item.getInt("validDisparityPixels"),
                    localDensePoints = item.getInt("localDensePoints"),
                    fusedPoints = item.getInt("fusedPoints"),
                    accepted = item.getBoolean("accepted"),
                    reason = item.getString("reason")
                ))
            }
        }
        val pointArray = json.optJSONArray("points") ?: JSONArray()
        val points = buildList {
            for (i in 0 until pointArray.length()) {
                val item = pointArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }
        DenseFusionReport(
            engine = json.getString("engine"),
            photosRequested = json.getInt("photosRequested"),
            connectedCameras = json.getInt("connectedCameras"),
            candidatePairs = json.getInt("candidatePairs"),
            pairsFused = json.getInt("pairsFused"),
            rawDensePoints = json.getInt("rawDensePoints"),
            fusedPoints = json.getInt("fusedPoints"),
            pairEvaluations = pairs,
            points = points,
            warnings = warnings,
            readyForSurfaceReconstruction = json.getBoolean("readyForSurfaceReconstruction")
        )
    }.getOrNull()

    fun denseFusionPlyFile(projectId: String): File = File(File(File(root, projectId), "models"), "dense_fused_cloud.ply")

    fun clearDenseFusion(projectId: String) {
        File(File(File(root, projectId), "reports"), "dense_fusion.json").delete()
        denseFusionPlyFile(projectId).delete()
        clearSurfaceMesh(projectId)
    }

    fun saveSurfaceMesh(projectId: String, report: SurfaceMeshReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("sourcePoints", report.sourcePoints)
            .put("meshVertices", report.meshVertices)
            .put("triangles", report.triangles)
            .put("voxelSize", report.voxelSize)
            .put("maxAcceptedEdge", report.maxAcceptedEdge)
            .put("boundaryEdges", report.boundaryEdges)
            .put("nonManifoldEdges", report.nonManifoldEdges)
            .put("surfaceComponents", report.surfaceComponents)
            .put("candidateTriangles", report.candidateTriangles)
            .put("cleanupRejectedFaces", report.cleanupRejectedFaces)
            .put("unusedVerticesRemoved", report.unusedVerticesRemoved)
            .put("boundaryLoops", report.boundaryLoops)
            .put("closedLoopsBeforeFill", report.closedLoopsBeforeFill)
            .put("filledBoundaryLoops", report.filledBoundaryLoops)
            .put("holeFillAddedVertices", report.holeFillAddedVertices)
            .put("holeFillAddedFaces", report.holeFillAddedFaces)
            .put("skippedClosedLoops", report.skippedClosedLoops)
            .put("openBoundaryChains", report.openBoundaryChains)
            .put("boundaryBranchVertices", report.boundaryBranchVertices)
            .put("smoothingIterations", report.smoothingIterations)
            .put("smoothedVertices", report.smoothedVertices)
            .put("averageSmoothingDisplacement", report.averageSmoothingDisplacement)
            .put("validVertexNormals", report.validVertexNormals)
            .put("readyForExport", report.readyForExport)
            .put("savedAt", System.currentTimeMillis())
        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)
        val vertices = JSONArray()
        report.vertices.forEach { p -> vertices.put(JSONArray().put(p.x).put(p.y).put(p.z)) }
        json.put("vertices", vertices)
        val faces = JSONArray()
        report.faces.forEach { f -> faces.put(JSONArray().put(f.a).put(f.b).put(f.c)) }
        json.put("faces", faces)
        val normals = JSONArray()
        report.vertexNormals.forEach { n -> normals.put(JSONArray().put(n.x).put(n.y).put(n.z)) }
        json.put("vertexNormals", normals)
        File(reportsDir, "surface_mesh.json").writeText(json.toString(2))
        File(modelsDir, "surface_mesh.obj").writeText(surfaceMeshObj(report))
        File(modelsDir, "surface_mesh.ply").writeText(surfaceMeshPly(report))
    }

    fun loadSurfaceMesh(projectId: String): SurfaceMeshReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "surface_mesh.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        val vertexArray = json.optJSONArray("vertices") ?: JSONArray()
        val vertices = buildList {
            for (i in 0 until vertexArray.length()) {
                val item = vertexArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }
        val faceArray = json.optJSONArray("faces") ?: JSONArray()
        val faces = buildList {
            for (i in 0 until faceArray.length()) {
                val item = faceArray.getJSONArray(i)
                add(MeshTriangle(item.getInt(0), item.getInt(1), item.getInt(2)))
            }
        }
        val normalArray = json.optJSONArray("vertexNormals") ?: JSONArray()
        val normals = buildList {
            for (i in 0 until normalArray.length()) {
                val item = normalArray.getJSONArray(i)
                add(SparsePoint(item.getDouble(0), item.getDouble(1), item.getDouble(2)))
            }
        }
        SurfaceMeshReport(
            engine = json.getString("engine"),
            sourcePoints = json.getInt("sourcePoints"),
            meshVertices = json.getInt("meshVertices"),
            triangles = json.getInt("triangles"),
            voxelSize = json.getDouble("voxelSize"),
            maxAcceptedEdge = json.getDouble("maxAcceptedEdge"),
            vertices = vertices, faces = faces, warnings = warnings,
            readyForExport = json.getBoolean("readyForExport"),
            boundaryEdges = json.optInt("boundaryEdges", 0),
            nonManifoldEdges = json.optInt("nonManifoldEdges", 0),
            surfaceComponents = json.optInt("surfaceComponents", 0),
            candidateTriangles = json.optInt("candidateTriangles", json.getInt("triangles")),
            cleanupRejectedFaces = json.optInt("cleanupRejectedFaces", 0),
            unusedVerticesRemoved = json.optInt("unusedVerticesRemoved", 0),
            boundaryLoops = json.optInt("boundaryLoops", 0),
            closedLoopsBeforeFill = json.optInt("closedLoopsBeforeFill", json.optInt("boundaryLoops", 0)),
            filledBoundaryLoops = json.optInt("filledBoundaryLoops", 0),
            holeFillAddedVertices = json.optInt("holeFillAddedVertices", 0),
            holeFillAddedFaces = json.optInt("holeFillAddedFaces", 0),
            skippedClosedLoops = json.optInt("skippedClosedLoops", 0),
            openBoundaryChains = json.optInt("openBoundaryChains", 0),
            boundaryBranchVertices = json.optInt("boundaryBranchVertices", 0),
            smoothingIterations = json.optInt("smoothingIterations", 0),
            smoothedVertices = json.optInt("smoothedVertices", 0),
            averageSmoothingDisplacement = json.optDouble("averageSmoothingDisplacement", 0.0),
            vertexNormals = normals,
            validVertexNormals = json.optInt("validVertexNormals", normals.size)
        )
    }.getOrNull()

    fun surfaceMeshObjFile(projectId: String): File = File(File(File(root, projectId), "models"), "surface_mesh.obj")
    fun surfaceMeshPlyFile(projectId: String): File = File(File(File(root, projectId), "models"), "surface_mesh.ply")

    fun clearSurfaceMesh(projectId: String) {
        File(File(File(root, projectId), "reports"), "surface_mesh.json").delete()
        surfaceMeshObjFile(projectId).delete()
        surfaceMeshPlyFile(projectId).delete()
        clearTextureProjection(projectId)
    }

    private fun surfaceMeshObj(report: SurfaceMeshReport): String = buildString {
        appendLine("# 3D Scan Studio v0.11.0 safe closed-loop-filled surface mesh")
        appendLine("# arbitrary scale")
        report.vertices.forEach { appendLine("v ${it.x} ${it.y} ${it.z}") }
        val hasNormals = report.vertexNormals.size == report.vertices.size
        if (hasNormals) report.vertexNormals.forEach { appendLine("vn ${it.x} ${it.y} ${it.z}") }
        report.faces.forEach { face ->
            if (hasNormals) appendLine("f ${face.a + 1}//${face.a + 1} ${face.b + 1}//${face.b + 1} ${face.c + 1}//${face.c + 1}")
            else appendLine("f ${face.a + 1} ${face.b + 1} ${face.c + 1}")
        }
    }

    private fun surfaceMeshPly(report: SurfaceMeshReport): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.11.0 safe closed-loop-filled local-fan surface; arbitrary scale")
        appendLine("element vertex ${report.vertices.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        val hasNormals = report.vertexNormals.size == report.vertices.size
        if (hasNormals) {
            appendLine("property float nx")
            appendLine("property float ny")
            appendLine("property float nz")
        }
        appendLine("element face ${report.faces.size}")
        appendLine("property list uchar int vertex_indices")
        appendLine("end_header")
        report.vertices.forEachIndexed { index, p ->
            if (hasNormals) {
                val n = report.vertexNormals[index]
                appendLine("${p.x} ${p.y} ${p.z} ${n.x} ${n.y} ${n.z}")
            } else appendLine("${p.x} ${p.y} ${p.z}")
        }
        report.faces.forEach { appendLine("3 ${it.a} ${it.b} ${it.c}") }
    }

    fun saveTextureProjection(projectId: String, report: TextureProjectionReport, mesh: SurfaceMeshReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("sourceMeshVertices", report.sourceMeshVertices)
            .put("sourceMeshFaces", report.sourceMeshFaces)
            .put("photosRequested", report.photosRequested)
            .put("connectedCameras", report.connectedCameras)
            .put("recoveredCameraPoses", report.recoveredCameraPoses)
            .put("camerasUsed", report.camerasUsed)
            .put("projectedCandidates", report.projectedCandidates)
            .put("coloredVertices", report.coloredVertices)
            .put("uncoloredVertices", report.uncoloredVertices)
            .put("coveragePercent", report.coveragePercent)
            .put("averageSamplesPerColoredVertex", report.averageSamplesPerColoredVertex)
            .put("recoveredOrientationLinks", report.recoveredOrientationLinks)
            .put("bridgedOrientationLinks", report.bridgedOrientationLinks)
            .put("visibilityRejectedCandidates", report.visibilityRejectedCandidates)
            .put("readyForExport", report.readyForExport)
            .put("savedAt", System.currentTimeMillis())
        val colors = JSONArray()
        report.vertexColors.forEach { colors.put(JSONArray().put(it.red).put(it.green).put(it.blue)) }
        json.put("vertexColors", colors)
        val contributions = JSONArray()
        report.cameraContributions.forEach { item ->
            contributions.put(JSONObject()
                .put("photo", item.photo)
                .put("projectedVertices", item.projectedVertices)
                .put("selectedVertices", item.selectedVertices)
                .put("poseRecovered", item.poseRecovered)
                .put("visibilityRejectedVertices", item.visibilityRejectedVertices))
        }
        json.put("cameraContributions", contributions)
        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)
        File(reportsDir, "texture_projection.json").writeText(json.toString(2))
        File(modelsDir, "surface_mesh_colored.ply").writeText(textureColoredPly(report, mesh))
        File(modelsDir, "surface_mesh_colored.obj").writeText(textureColoredObj(report, mesh))
    }

    fun loadTextureProjection(projectId: String): TextureProjectionReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "texture_projection.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val colorArray = json.optJSONArray("vertexColors") ?: JSONArray()
        val colors = buildList {
            for (i in 0 until colorArray.length()) {
                val item = colorArray.getJSONArray(i)
                add(VertexColor(item.getInt(0), item.getInt(1), item.getInt(2)))
            }
        }
        val contributionArray = json.optJSONArray("cameraContributions") ?: JSONArray()
        val contributions = buildList {
            for (i in 0 until contributionArray.length()) {
                val item = contributionArray.getJSONObject(i)
                add(TextureCameraContribution(
                    photo = item.getString("photo"),
                    projectedVertices = item.optInt("projectedVertices", 0),
                    selectedVertices = item.optInt("selectedVertices", 0),
                    poseRecovered = item.optBoolean("poseRecovered", false),
                    visibilityRejectedVertices = item.optInt("visibilityRejectedVertices", 0)
                ))
            }
        }
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        TextureProjectionReport(
            engine = json.getString("engine"),
            sourceMeshVertices = json.getInt("sourceMeshVertices"),
            sourceMeshFaces = json.getInt("sourceMeshFaces"),
            photosRequested = json.getInt("photosRequested"),
            connectedCameras = json.getInt("connectedCameras"),
            recoveredCameraPoses = json.getInt("recoveredCameraPoses"),
            camerasUsed = json.getInt("camerasUsed"),
            projectedCandidates = json.getInt("projectedCandidates"),
            coloredVertices = json.getInt("coloredVertices"),
            uncoloredVertices = json.getInt("uncoloredVertices"),
            coveragePercent = json.getDouble("coveragePercent"),
            averageSamplesPerColoredVertex = json.getDouble("averageSamplesPerColoredVertex"),
            vertexColors = colors,
            cameraContributions = contributions,
            warnings = warnings,
            readyForExport = json.getBoolean("readyForExport"),
            recoveredOrientationLinks = json.optInt("recoveredOrientationLinks", 0),
            bridgedOrientationLinks = json.optInt("bridgedOrientationLinks", 0),
            visibilityRejectedCandidates = json.optInt("visibilityRejectedCandidates", 0)
        )
    }.getOrNull()

    fun textureColoredPlyFile(projectId: String): File = File(File(File(root, projectId), "models"), "surface_mesh_colored.ply")
    fun textureColoredObjFile(projectId: String): File = File(File(File(root, projectId), "models"), "surface_mesh_colored.obj")

    fun clearTextureProjection(projectId: String) {
        File(File(File(root, projectId), "reports"), "texture_projection.json").delete()
        textureColoredPlyFile(projectId).delete()
        textureColoredObjFile(projectId).delete()
        clearTextureSourceAssignment(projectId)
    }

    fun saveTextureSourceAssignment(projectId: String, report: TextureSourceAssignmentReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("sourceMeshVertices", report.sourceMeshVertices)
            .put("sourceMeshFaces", report.sourceMeshFaces)
            .put("connectedCameras", report.connectedCameras)
            .put("recoveredCameraPoses", report.recoveredCameraPoses)
            .put("recoveredOrientationLinks", report.recoveredOrientationLinks)
            .put("bridgedOrientationLinks", report.bridgedOrientationLinks)
            .put("camerasUsed", report.camerasUsed)
            .put("visibleFaceCandidates", report.visibleFaceCandidates)
            .put("assignedFaces", report.assignedFaces)
            .put("unassignedFaces", report.unassignedFaces)
            .put("faceCoveragePercent", report.faceCoveragePercent)
            .put("readyForAtlas", report.readyForAtlas)
            .put("savedAt", System.currentTimeMillis())
        val assignmentArray = JSONArray()
        report.assignments.forEach { item ->
            assignmentArray.put(JSONObject()
                .put("faceIndex", item.faceIndex)
                .put("photo", item.photo)
                .put("u0", item.u0).put("v0", item.v0)
                .put("u1", item.u1).put("v1", item.v1)
                .put("u2", item.u2).put("v2", item.v2)
                .put("score", item.score))
        }
        json.put("assignments", assignmentArray)
        val contributionArray = JSONArray()
        report.cameraContributions.forEach { item ->
            contributionArray.put(JSONObject()
                .put("photo", item.photo)
                .put("visibleCandidateFaces", item.visibleCandidateFaces)
                .put("selectedFaces", item.selectedFaces)
                .put("poseRecovered", item.poseRecovered))
        }
        json.put("cameraContributions", contributionArray)
        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)
        File(reportsDir, "texture_source_assignment.json").writeText(json.toString(2))
    }

    fun loadTextureSourceAssignment(projectId: String): TextureSourceAssignmentReport? = runCatching {
        val file = File(File(File(root, projectId), "reports"), "texture_source_assignment.json")
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val assignmentArray = json.optJSONArray("assignments") ?: JSONArray()
        val assignments = buildList {
            for (i in 0 until assignmentArray.length()) {
                val item = assignmentArray.getJSONObject(i)
                add(FaceTextureAssignment(
                    faceIndex = item.getInt("faceIndex"),
                    photo = item.getString("photo"),
                    u0 = item.getDouble("u0"), v0 = item.getDouble("v0"),
                    u1 = item.getDouble("u1"), v1 = item.getDouble("v1"),
                    u2 = item.getDouble("u2"), v2 = item.getDouble("v2"),
                    score = item.getDouble("score")
                ))
            }
        }
        val contributionArray = json.optJSONArray("cameraContributions") ?: JSONArray()
        val contributions = buildList {
            for (i in 0 until contributionArray.length()) {
                val item = contributionArray.getJSONObject(i)
                add(FaceTextureCameraContribution(
                    photo = item.getString("photo"),
                    visibleCandidateFaces = item.optInt("visibleCandidateFaces", 0),
                    selectedFaces = item.optInt("selectedFaces", 0),
                    poseRecovered = item.optBoolean("poseRecovered", false)
                ))
            }
        }
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        TextureSourceAssignmentReport(
            engine = json.getString("engine"),
            sourceMeshVertices = json.getInt("sourceMeshVertices"),
            sourceMeshFaces = json.getInt("sourceMeshFaces"),
            connectedCameras = json.getInt("connectedCameras"),
            recoveredCameraPoses = json.getInt("recoveredCameraPoses"),
            recoveredOrientationLinks = json.optInt("recoveredOrientationLinks", 0),
            bridgedOrientationLinks = json.optInt("bridgedOrientationLinks", 0),
            camerasUsed = json.getInt("camerasUsed"),
            visibleFaceCandidates = json.getInt("visibleFaceCandidates"),
            assignedFaces = json.getInt("assignedFaces"),
            unassignedFaces = json.getInt("unassignedFaces"),
            faceCoveragePercent = json.getDouble("faceCoveragePercent"),
            assignments = assignments,
            cameraContributions = contributions,
            warnings = warnings,
            readyForAtlas = json.getBoolean("readyForAtlas")
        )
    }.getOrNull()

    fun textureSourceAssignmentFile(projectId: String): File = File(File(File(root, projectId), "reports"), "texture_source_assignment.json")

    fun clearTextureSourceAssignment(projectId: String) {
        textureSourceAssignmentFile(projectId).delete()
        clearTextureAtlas(projectId)
    }

    fun saveTextureAtlas(projectId: String, report: TextureAtlasReport, atlas: Bitmap, mesh: SurfaceMeshReport) {
        val projectDir = File(root, projectId)
        val reportsDir = File(projectDir, "reports").apply { mkdirs() }
        val modelsDir = File(projectDir, "models").apply { mkdirs() }
        val json = JSONObject()
            .put("engine", report.engine)
            .put("atlasWidth", report.atlasWidth)
            .put("atlasHeight", report.atlasHeight)
            .put("tileSize", report.tileSize)
            .put("padding", report.padding)
            .put("sourceMeshVertices", report.sourceMeshVertices)
            .put("sourceMeshFaces", report.sourceMeshFaces)
            .put("stage9AssignedFaces", report.stage9AssignedFaces)
            .put("texturedFaces", report.texturedFaces)
            .put("untexturedFaces", report.untexturedFaces)
            .put("textureCoveragePercent", report.textureCoveragePercent)
            .put("sourcePhotosUsed", report.sourcePhotosUsed)
            .put("skippedMissingPhotos", report.skippedMissingPhotos)
            .put("skippedRasterizationFaces", report.skippedRasterizationFaces)
            .put("uvIslands", report.uvIslands)
            .put("largestIslandFaces", report.largestIslandFaces)
            .put("atlasOccupancyPercent", report.atlasOccupancyPercent)
            .put("readyForExport", report.readyForExport)
            .put("savedAt", System.currentTimeMillis())
        val uvArray = JSONArray()
        report.faceUvs.forEach { uv ->
            uvArray.put(JSONObject()
                .put("faceIndex", uv.faceIndex)
                .put("u0", uv.u0).put("v0", uv.v0)
                .put("u1", uv.u1).put("v1", uv.v1)
                .put("u2", uv.u2).put("v2", uv.v2))
        }
        json.put("faceUvs", uvArray)
        val warnings = JSONArray()
        report.warnings.forEach { warnings.put(it) }
        json.put("warnings", warnings)
        textureAtlasReportFile(projectId).writeText(json.toString(2))

        FileOutputStream(textureAtlasPngFile(projectId)).use { out -> atlas.compress(Bitmap.CompressFormat.PNG, 100, out) }
        textureAtlasMtlFile(projectId).writeText(textureAtlasMtl())
        textureAtlasObjFile(projectId).writeText(textureAtlasObj(report, mesh))
    }

    fun loadTextureAtlas(projectId: String): TextureAtlasReport? = runCatching {
        val file = textureAtlasReportFile(projectId)
        if (!file.exists()) return@runCatching null
        val json = JSONObject(file.readText())
        val uvArray = json.optJSONArray("faceUvs") ?: JSONArray()
        val uvs = buildList {
            for (i in 0 until uvArray.length()) {
                val item = uvArray.getJSONObject(i)
                add(FaceAtlasUv(
                    faceIndex = item.getInt("faceIndex"),
                    u0 = item.getDouble("u0"), v0 = item.getDouble("v0"),
                    u1 = item.getDouble("u1"), v1 = item.getDouble("v1"),
                    u2 = item.getDouble("u2"), v2 = item.getDouble("v2")
                ))
            }
        }
        val warningArray = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningArray.length()) add(warningArray.getString(i)) }
        TextureAtlasReport(
            engine = json.getString("engine"),
            atlasWidth = json.getInt("atlasWidth"),
            atlasHeight = json.getInt("atlasHeight"),
            tileSize = json.getInt("tileSize"),
            padding = json.getInt("padding"),
            sourceMeshVertices = json.getInt("sourceMeshVertices"),
            sourceMeshFaces = json.getInt("sourceMeshFaces"),
            stage9AssignedFaces = json.getInt("stage9AssignedFaces"),
            texturedFaces = json.getInt("texturedFaces"),
            untexturedFaces = json.getInt("untexturedFaces"),
            textureCoveragePercent = json.getDouble("textureCoveragePercent"),
            sourcePhotosUsed = json.getInt("sourcePhotosUsed"),
            skippedMissingPhotos = json.optInt("skippedMissingPhotos", 0),
            skippedRasterizationFaces = json.optInt("skippedRasterizationFaces", 0),
            faceUvs = uvs, warnings = warnings,
            readyForExport = json.getBoolean("readyForExport"),
            uvIslands = json.optInt("uvIslands", 0),
            largestIslandFaces = json.optInt("largestIslandFaces", 0),
            atlasOccupancyPercent = json.optDouble("atlasOccupancyPercent", 0.0)
        )
    }.getOrNull()

    fun textureAtlasReportFile(projectId: String): File = File(File(File(root, projectId), "reports"), "texture_atlas.json")
    fun textureAtlasPngFile(projectId: String): File = File(File(File(root, projectId), "models"), "texture_atlas.png")
    fun textureAtlasObjFile(projectId: String): File = File(File(File(root, projectId), "models"), "textured_model.obj")
    fun textureAtlasMtlFile(projectId: String): File = File(File(File(root, projectId), "models"), "texture_atlas.mtl")

    fun clearTextureAtlas(projectId: String) {
        textureAtlasReportFile(projectId).delete()
        textureAtlasPngFile(projectId).delete()
        textureAtlasObjFile(projectId).delete()
        textureAtlasMtlFile(projectId).delete()
    }

    fun textureAtlasPackageBytes(projectId: String): ByteArray? = runCatching {
        val report = loadTextureAtlas(projectId) ?: return@runCatching null
        if (!report.readyForExport) return@runCatching null
        val files = listOf(textureAtlasObjFile(projectId), textureAtlasMtlFile(projectId), textureAtlasPngFile(projectId))
        if (files.any { !it.exists() }) return@runCatching null
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use { zip ->
            files.forEach { file ->
                zip.putNextEntry(ZipEntry(file.name))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        bytes.toByteArray()
    }.getOrNull()

    fun textureAtlasPngBytes(projectId: String): ByteArray? = textureAtlasPngFile(projectId).takeIf { it.exists() }?.readBytes()

    private fun textureAtlasMtl(): String = buildString {
        appendLine("# 3D Scan Studio v0.17.0 Stage 10 texture materials")
        appendLine("newmtl photo_atlas")
        appendLine("Ka 0.000 0.000 0.000")
        appendLine("Kd 1.000 1.000 1.000")
        appendLine("Ks 0.000 0.000 0.000")
        appendLine("map_Kd texture_atlas.png")
        appendLine()
        appendLine("newmtl untextured")
        appendLine("Ka 0.200 0.200 0.200")
        appendLine("Kd 0.500 0.500 0.500")
        appendLine("Ks 0.000 0.000 0.000")
    }

    private fun textureAtlasObj(report: TextureAtlasReport, mesh: SurfaceMeshReport): String = buildString {
        appendLine("# 3D Scan Studio v0.17.0 Stage 10 UV-island model")
        appendLine("# assigned/textured faces ${report.texturedFaces}/${report.sourceMeshFaces}")
        appendLine("mtllib texture_atlas.mtl")
        mesh.vertices.forEach { appendLine("v ${it.x} ${it.y} ${it.z}") }
        val hasNormals = mesh.vertexNormals.size == mesh.vertices.size
        if (hasNormals) mesh.vertexNormals.forEach { appendLine("vn ${it.x} ${it.y} ${it.z}") }

        val uvStartByFace = HashMap<Int, Int>()
        var nextVt = 1
        report.faceUvs.sortedBy { it.faceIndex }.forEach { uv ->
            uvStartByFace[uv.faceIndex] = nextVt
            appendLine("vt ${uv.u0} ${uv.v0}")
            appendLine("vt ${uv.u1} ${uv.v1}")
            appendLine("vt ${uv.u2} ${uv.v2}")
            nextVt += 3
        }

        var currentMaterial = ""
        mesh.faces.forEachIndexed { faceIndex, face ->
            val vt = uvStartByFace[faceIndex]
            val material = if (vt != null) "photo_atlas" else "untextured"
            if (material != currentMaterial) { appendLine("usemtl $material"); currentMaterial = material }
            val a = face.a + 1; val b = face.b + 1; val c = face.c + 1
            if (vt != null) {
                if (hasNormals) appendLine("f $a/${vt}/$a $b/${vt + 1}/$b $c/${vt + 2}/$c")
                else appendLine("f $a/$vt $b/${vt + 1} $c/${vt + 2}")
            } else {
                if (hasNormals) appendLine("f $a//$a $b//$b $c//$c") else appendLine("f $a $b $c")
            }
        }
    }

    private fun textureColoredPly(report: TextureProjectionReport, mesh: SurfaceMeshReport): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio Stage 8 v0.13.0 visibility-refined photo-projected vertex colors; arbitrary scale")
        appendLine("element vertex ${mesh.vertices.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        val hasNormals = mesh.vertexNormals.size == mesh.vertices.size
        if (hasNormals) {
            appendLine("property float nx")
            appendLine("property float ny")
            appendLine("property float nz")
        }
        appendLine("property uchar red")
        appendLine("property uchar green")
        appendLine("property uchar blue")
        appendLine("element face ${mesh.faces.size}")
        appendLine("property list uchar int vertex_indices")
        appendLine("end_header")
        mesh.vertices.forEachIndexed { index, p ->
            val color = report.vertexColors.getOrNull(index) ?: VertexColor(128, 128, 128)
            if (hasNormals) {
                val n = mesh.vertexNormals[index]
                appendLine("${p.x} ${p.y} ${p.z} ${n.x} ${n.y} ${n.z} ${color.red} ${color.green} ${color.blue}")
            } else {
                appendLine("${p.x} ${p.y} ${p.z} ${color.red} ${color.green} ${color.blue}")
            }
        }
        mesh.faces.forEach { appendLine("3 ${it.a} ${it.b} ${it.c}") }
    }

    private fun textureColoredObj(report: TextureProjectionReport, mesh: SurfaceMeshReport): String = buildString {
        appendLine("# 3D Scan Studio Stage 8 v0.13.0 visibility-refined vertex-colored OBJ")
        appendLine("# Vertex RGB uses the widely supported non-standard 'v x y z r g b' extension; PLY is the primary color export.")
        mesh.vertices.forEachIndexed { index, p ->
            val c = report.vertexColors.getOrNull(index) ?: VertexColor(128, 128, 128)
            appendLine("v ${p.x} ${p.y} ${p.z} ${c.red / 255.0} ${c.green / 255.0} ${c.blue / 255.0}")
        }
        val hasNormals = mesh.vertexNormals.size == mesh.vertices.size
        if (hasNormals) mesh.vertexNormals.forEach { appendLine("vn ${it.x} ${it.y} ${it.z}") }
        mesh.faces.forEach { face ->
            if (hasNormals) appendLine("f ${face.a + 1}//${face.a + 1} ${face.b + 1}//${face.b + 1} ${face.c + 1}//${face.c + 1}")
            else appendLine("f ${face.a + 1} ${face.b + 1} ${face.c + 1}")
        }
    }

    private fun denseFusionPly(points: List<SparsePoint>): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.8 multi-pair dense fusion; arbitrary scale")
        appendLine("element vertex ${points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    private fun densePly(points: List<SparsePoint>): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.7.1 adaptive dense stereo pair; arbitrary scale")
        appendLine("element vertex ${points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    private fun bundlePly(points: List<SparsePoint>): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.6 shared-track limited bundle adjustment; arbitrary scale")
        appendLine("element vertex ${points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    private fun multiViewPly(points: List<SparsePoint>): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.5 multi-view sparse cloud; arbitrary scale; pre-bundle-adjustment")
        appendLine("element vertex ${points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    private fun sparsePly(points: List<SparsePoint>): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.4 sparse two-view cloud; arbitrary scale")
        appendLine("element vertex ${points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    private fun readProject(dir: File): PhotoProject? = runCatching {
        val meta = File(dir, "project.json")
        if (!meta.exists()) return@runCatching null
        val json = JSONObject(meta.readText())
        val photos = File(dir, "photos").listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in setOf("jpg", "jpeg", "png", "heic", "webp") }
            ?.sortedBy { it.lastModified() }
            .orEmpty()
        val models = File(dir, "models").listFiles()?.filter { it.isFile }.orEmpty()
        val modeName = json.optString("scanMode", ScanMode.PHOTOGRAMMETRY.name)
        val mode = runCatching { ScanMode.valueOf(modeName) }.getOrDefault(ScanMode.PHOTOGRAMMETRY)
        PhotoProject(
            id = json.getString("id"),
            name = json.getString("name"),
            createdAt = json.getLong("createdAt"),
            directory = dir,
            scanMode = mode,
            photos = photos,
            modelFiles = models
        )
    }.getOrNull()

    private fun writeMetadata(project: PhotoProject) {
        val json = JSONObject()
            .put("id", project.id)
            .put("name", project.name)
            .put("createdAt", project.createdAt)
            .put("scanMode", project.scanMode.name)
        File(project.directory, "project.json").writeText(json.toString(2))
    }
}
