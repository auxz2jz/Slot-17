package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.max

/**
 * Shared image loader for every computer-vision stage.
 *
 * Android's BitmapFactory decodes the stored pixel matrix but does not apply EXIF orientation.
 * For photogrammetry, every stage must see the same upright/mirrored pixel geometry, so this
 * helper decodes a sampled bitmap and normalizes all eight EXIF orientation values.
 */
object ExifBitmapLoader {
    data class OrientationInfo(
        val exifValue: Int,
        val label: String,
        val rotationDegrees: Int,
        val mirrored: Boolean
    )

    fun decodeScaled(file: File, maxImageSide: Int): Bitmap? = decodeScaledRaw(file, maxImageSide)

    /** Raw EXIF-normalized decode used by camera calibration before any calibration profile is applied. */
    fun decodeScaledRaw(file: File, maxImageSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        val maxSide = max(bounds.outWidth, bounds.outHeight)
        while (maxSide / sample > maxImageSide) sample *= 2

        val decoded = BitmapFactory.decodeFile(
            file.absolutePath,
            BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
        ) ?: return null

        return applyOrientation(decoded, orientationInfo(file).exifValue)
    }

    fun orientationInfo(file: File): OrientationInfo {
        val value = runCatching {
            ExifInterface(file).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        return when (value) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> OrientationInfo(value, "flip-horizontal", 0, true)
            ExifInterface.ORIENTATION_ROTATE_180 -> OrientationInfo(value, "rotate-180", 180, false)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> OrientationInfo(value, "flip-vertical", 180, true)
            ExifInterface.ORIENTATION_TRANSPOSE -> OrientationInfo(value, "transpose", 90, true)
            ExifInterface.ORIENTATION_ROTATE_90 -> OrientationInfo(value, "rotate-90", 90, false)
            ExifInterface.ORIENTATION_TRANSVERSE -> OrientationInfo(value, "transverse", 270, true)
            ExifInterface.ORIENTATION_ROTATE_270 -> OrientationInfo(value, "rotate-270", 270, false)
            else -> OrientationInfo(ExifInterface.ORIENTATION_NORMAL, "normal", 0, false)
        }
    }

    fun auditLines(files: List<File>): List<String> = files.mapIndexed { index, file ->
        val info = orientationInfo(file)
        "${index + 1}. ${file.name} | EXIF=${info.exifValue} | ${info.label} | normalized rotation=${info.rotationDegrees}° | mirrored=${info.mirrored}"
    }

    private fun applyOrientation(source: Bitmap, orientation: Int): Bitmap {
        if (orientation == ExifInterface.ORIENTATION_NORMAL || orientation == ExifInterface.ORIENTATION_UNDEFINED) {
            return source
        }

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> {
                matrix.setRotate(180f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.setRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.setRotate(-90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            else -> return source
        }

        return try {
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true).also { normalized ->
                if (normalized !== source) source.recycle()
            }
        } catch (_: Throwable) {
            source
        }
    }
}
