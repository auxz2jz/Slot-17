package com.photogrammetrystudio.app.ui.screens

import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.photogrammetrystudio.app.BuildConfig
import com.photogrammetrystudio.app.model.PhotoProject
import com.photogrammetrystudio.app.model.FeatureMatchReport
import com.photogrammetrystudio.app.model.PhotoSetReport
import com.photogrammetrystudio.app.model.ReconstructionState
import com.photogrammetrystudio.app.model.ReconstructionStatus
import com.photogrammetrystudio.app.model.ScanMode
import com.photogrammetrystudio.app.model.SparsePoint
import com.photogrammetrystudio.app.model.SparseReconstructionReport
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.BundleAdjustmentReport
import com.photogrammetrystudio.app.model.DenseReconstructionReport
import com.photogrammetrystudio.app.model.DenseFusionReport
import com.photogrammetrystudio.app.model.MeshTriangle
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureProjectionReport
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import com.photogrammetrystudio.app.model.TextureAtlasReport
import com.photogrammetrystudio.app.model.VertexColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import com.photogrammetrystudio.app.util.ExifBitmapLoader
import com.photogrammetrystudio.app.util.buildCombinedProjectDiagnostics
import com.photogrammetrystudio.app.util.reportFingerprint
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectScreen(
    project: PhotoProject?,
    report: PhotoSetReport?,
    reconstruction: ReconstructionStatus,
    featureMatchReport: FeatureMatchReport?,
    sparseReport: SparseReconstructionReport?,
    multiViewReport: MultiViewReconstructionReport?,
    bundleReport: BundleAdjustmentReport?,
    denseReport: DenseReconstructionReport?,
    denseFusionReport: DenseFusionReport?,
    surfaceMeshReport: SurfaceMeshReport?,
    textureProjectionReport: TextureProjectionReport?,
    textureSourceAssignmentReport: TextureSourceAssignmentReport?,
    textureAtlasReport: TextureAtlasReport?,
    onBack: () -> Unit,
    onCapture: () -> Unit,
    onImport: (List<Uri>) -> Unit,
    onDeletePhoto: (File) -> Unit,
    onAnalyze: () -> Unit,
    onMatchPhotos: () -> Unit,
    onBuild: () -> Unit,
    onBuildMultiView: () -> Unit,
    onBundleAdjust: () -> Unit,
    onBuildDense: () -> Unit,
    onBuildDenseFusion: () -> Unit,
    onBuildSurfaceMesh: () -> Unit,
    onBuildTextureProjection: () -> Unit,
    onBuildTextureSourceAssignment: () -> Unit,
    onBuildTextureAtlas: () -> Unit,
    onLoadTextureAtlasPackage: () -> ByteArray?,
    onLoadTextureAtlasPng: () -> ByteArray?,
    onResetReconstruction: () -> Unit,
    onOpenLaserLab: () -> Unit,
    onOpenTestGuide: () -> Unit
) {
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) onImport(uris)
    }
    var showResetReconstructionDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project?.name ?: "Project") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onOpenTestGuide) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "Test this version")
                    }
                }
            )
        }
    ) { padding ->
        if (project == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Loading project…")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 4.dp, 16.dp, 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ScanModeCard(project.scanMode)
                }

                if (project.scanMode != ScanMode.LASER) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(onClick = onCapture, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                Spacer(Modifier.size(8.dp))
                                Text("Camera")
                            }
                            FilledTonalButton(
                                onClick = { importLauncher.launch("image/*") },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                Spacer(Modifier.size(8.dp))
                                Text("Import")
                            }
                        }
                    }

                    item { GuidanceCard(project.photos.size, report) }
                    item { ReconstructionCard(reconstruction, onAnalyze, onMatchPhotos, onBuild, project.scanMode, project.photos.size) }
                    item {
                        OutlinedButton(
                            onClick = { showResetReconstructionDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = reconstruction.state != ReconstructionState.RUNNING &&
                                reconstruction.state != ReconstructionState.ANALYZING
                        ) {
                            Text("Reset reconstruction stages")
                        }
                    }
                    item {
                        CombinedDiagnosticsCard(
                            project = project,
                            report = report,
                            reconstruction = reconstruction,
                            featureMatchReport = featureMatchReport,
                            sparseReport = sparseReport,
                            multiViewReport = multiViewReport,
                            bundleReport = bundleReport,
                            denseReport = denseReport,
                            denseFusionReport = denseFusionReport,
                            surfaceMeshReport = surfaceMeshReport,
                            textureProjectionReport = textureProjectionReport,
                            textureSourceAssignmentReport = textureSourceAssignmentReport,
                            textureAtlasReport = textureAtlasReport
                        )
                    }
                    if (featureMatchReport != null) {
                        item { FeatureMatchCard(project.id, project.name, featureMatchReport) }
                    }
                    if (sparseReport != null) {
                        item { SparseReconstructionCard(project.id, project.name, sparseReport, onBuildMultiView) }
                    }
                    if (multiViewReport != null) {
                        item { MultiViewReconstructionCard(project.id, project.name, multiViewReport, onBundleAdjust) }
                    }
                    if (bundleReport != null) {
                        item { BundleAdjustmentCard(project.id, project.name, bundleReport, onBuildDense) }
                    }
                    if (denseReport != null) {
                        item { DenseReconstructionCard(project.id, project.name, denseReport, onBuildDenseFusion) }
                    }
                    if (denseFusionReport != null) {
                        item { DenseFusionCard(project.id, project.name, denseFusionReport, onBuildSurfaceMesh) }
                    }
                    if (surfaceMeshReport != null) {
                        item { SurfaceMeshCard(project.id, project.name, surfaceMeshReport, onBuildTextureProjection) }
                    }
                    if (surfaceMeshReport != null && textureProjectionReport != null) {
                        item { TextureProjectionCard(project.id, project.name, surfaceMeshReport, textureProjectionReport, onBuildTextureSourceAssignment) }
                    }
                    if (textureSourceAssignmentReport != null) {
                        item { TextureSourceAssignmentCard(project.id, project.name, textureSourceAssignmentReport, onBuildTextureAtlas) }
                    }
                    if (textureAtlasReport != null && surfaceMeshReport != null) {
                        item { TextureAtlasCard(project.id, project.name, surfaceMeshReport, textureAtlasReport, onLoadTextureAtlasPackage, onLoadTextureAtlasPng) }
                    }
                } else {
                    item { LaserFoundationCard(onOpenLaserLab) }
                }

                if (project.scanMode == ScanMode.HYBRID) {
                    item { HybridFoundationCard(onOpenLaserLab) }
                }

                if (project.scanMode != ScanMode.LASER) {
                    item {
                        Column {
                            Text(
                                "Photos (${project.photos.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                if (project.photos.isEmpty()) "No photos yet." else "Swipe left or right to review captured photos.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    if (project.photos.isEmpty()) {
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                    Text("Capture or import an overlapping photo set.")
                                }
                            }
                        }
                    } else {
                        item {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(project.photos, key = { it.absolutePath }) { file ->
                                    PhotoTile(file = file, onDelete = { onDeletePhoto(file) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResetReconstructionDialog && project != null) {
        AlertDialog(
            onDismissRequest = { showResetReconstructionDialog = false },
            title = { Text("Reset reconstruction stages?") },
            text = {
                Text(
                    "Keep all ${project.photos.size} photos and project settings, but delete the generated results for Stages 1–9. " +
                        "You will restart with Stage 1 — Match photos."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetReconstructionDialog = false
                        onResetReconstruction()
                    }
                ) {
                    Text("Reset stages")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetReconstructionDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ScanModeCard(scanMode: ScanMode) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(scanMode.displayName, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(scanMode.description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun LaserFoundationCard(onOpenLaserLab: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Laser Scan — v0.26 dual-orientation extraction + metric single-frame 3D", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Import a matched laser-OFF / laser-ON image pair and extract the visible stripe before calibrated triangulation is added.")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onOpenLaserLab, modifier = Modifier.fillMaxWidth()) { Text("Open Laser Line Lab") }
            Spacer(Modifier.height(6.dp))
            Text("v0.26 manual mode can solve the 90° marker backdrop and build a metric single-frame laser stripe. Multi-frame hand-sweep accumulation and motion-controller commands remain later milestones.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun HybridFoundationCard(onOpenLaserLab: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Hybrid laser pass", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Photo reconstruction stays active. v0.26 keeps laser Analyze history, supports vertical or horizontal stripe extraction automatically, and can solve the LEFT/RIGHT marker backdrop plus instantaneous laser plane for metric single-frame 3D.")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenLaserLab, modifier = Modifier.fillMaxWidth()) { Text("Open Laser Line Lab") }
        }
    }
}

@Composable
private fun GuidanceCard(photoCount: Int, report: PhotoSetReport?) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Capture guidance", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("For best accuracy: keep about 70–80% overlap, use the same lens/zoom for the whole scan, move in small steps, and shoot low/middle/high rings around the object.")
            Spacer(Modifier.height(4.dp))
            Text("Keep the object sharp with steady, even lighting. Avoid blur, strong reflections, and changing exposure. Plain objects benefit from temporary visual markers or texture.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Text("Current set: $photoCount photos", style = MaterialTheme.typography.labelLarge)
            report?.warnings?.take(3)?.forEach { warning ->
                Spacer(Modifier.height(4.dp))
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ReconstructionCard(
    status: ReconstructionStatus,
    onAnalyze: () -> Unit,
    onMatchPhotos: () -> Unit,
    onBuild: () -> Unit,
    scanMode: ScanMode,
    photoCount: Int
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(
                if (scanMode == ScanMode.HYBRID) "Photo reconstruction" else "3D reconstruction",
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(5.dp))
            Text(status.message, style = MaterialTheme.typography.bodyMedium)
            if (status.state == ReconstructionState.RUNNING || status.state == ReconstructionState.ANALYZING) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { status.progress },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onAnalyze) {
                    Icon(Icons.Default.Analytics, contentDescription = null)
                    Spacer(Modifier.size(6.dp))
                    Text("Quick check")
                }
                Button(onClick = onMatchPhotos, enabled = photoCount >= 2) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.size(6.dp))
                    Text("Stage 1 — Match photos")
                }
            }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = onBuild, modifier = Modifier.fillMaxWidth()) {
                Text("Next: Stage 2 — Build sparse reconstruction")
            }
            if (status.state == ReconstructionState.ENGINE_UNAVAILABLE) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "This scan mode is not connected to its geometry engine yet. Photos stay local on your device.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}


@Composable
private fun CombinedDiagnosticsCard(
    project: PhotoProject,
    report: PhotoSetReport?,
    reconstruction: ReconstructionStatus,
    featureMatchReport: FeatureMatchReport?,
    sparseReport: SparseReconstructionReport?,
    multiViewReport: MultiViewReconstructionReport?,
    bundleReport: BundleAdjustmentReport?,
    denseReport: DenseReconstructionReport?,
    denseFusionReport: DenseFusionReport?,
    surfaceMeshReport: SurfaceMeshReport?,
    textureProjectionReport: TextureProjectionReport?,
    textureSourceAssignmentReport: TextureSourceAssignmentReport?,
    textureAtlasReport: TextureAtlasReport?
) {
    val context = LocalContext.current
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }
    val availableStages = listOf(
        featureMatchReport,
        sparseReport,
        multiViewReport,
        bundleReport,
        denseReport,
        denseFusionReport,
        surfaceMeshReport,
        textureProjectionReport,
        textureSourceAssignmentReport,
        textureAtlasReport
    ).count { it != null }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Combined Project Diagnostics", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text(
                "One text export with Quick Check plus every currently saved Stage 1–10 diagnostic report. New or rebuilt stages are automatically included the next time you export it.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(6.dp))
            Text("Saved stage reports currently included: $availableStages / 10")
            Text("PLY/OBJ geometry stays separate and only needs to be exported when geometry inspection is requested.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = buildCombinedProjectDiagnostics(
                        appVersion = BuildConfig.VERSION_NAME,
                        project = project,
                        photoSetReport = report,
                        reconstruction = reconstruction,
                        feature = featureMatchReport,
                        sparse = sparseReport,
                        multi = multiViewReport,
                        bundle = bundleReport,
                        dense = denseReport,
                        fusion = denseFusionReport,
                        mesh = surfaceMeshReport,
                        texture = textureProjectionReport,
                        textureSources = textureSourceAssignmentReport,
                        textureAtlas = textureAtlasReport
                    )
                    val safe = project.name.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_combined_project_diagnostics.txt")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export combined project diagnostics")
            }
        }
    }
}

@Composable
private fun FeatureMatchCard(projectId: String, projectName: String, report: FeatureMatchReport) {
    val context = LocalContext.current
    var showAllPairs by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    fun exportText(): String = buildString {
        appendLine("3D Scan Studio - Feature Match Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("feature-match", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Photos analyzed: ${report.analyzedPhotos}")
        appendLine("Detected keypoints: ${report.totalKeypoints}")
        appendLine("Usable/strong adjacent pairs: ${report.strongOrUsablePairs} / ${report.adjacentPairs.size}")
        appendLine("Ready for sparse reconstruction: ${report.readyForSparseReconstruction}")
        appendLine()
        appendLine("Warnings:")
        if (report.warnings.isEmpty()) appendLine("- None")
        else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Adjacent pair results:")
        report.adjacentPairs.forEachIndexed { index, pair ->
            appendLine(
                "${index + 1}. ${pair.firstPhoto} -> ${pair.secondPhoto} | " +
                    "keypoints ${pair.firstKeypoints}/${pair.secondKeypoints} | " +
                    "good matches ${pair.goodMatches} | ${pair.quality}"
            )
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 1 — Feature Matching", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text("Photos analyzed: ${report.analyzedPhotos}")
            Text("Detected keypoints: ${report.totalKeypoints}")
            Text("Usable/strong adjacent pairs: ${report.strongOrUsablePairs} / ${report.adjacentPairs.size}")
            Spacer(Modifier.height(8.dp))
            Text(
                if (report.readyForSparseReconstruction)
                    "Overlap looks good enough to move toward camera-pose estimation."
                else
                    "Some neighboring photos do not overlap strongly enough yet.",
                fontWeight = FontWeight.SemiBold
            )
            report.warnings.take(3).forEach { warning ->
                Spacer(Modifier.height(4.dp))
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
            }
            if (report.adjacentPairs.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("Adjacent pair results", fontWeight = FontWeight.SemiBold)
                report.adjacentPairs.take(8).forEachIndexed { index, pair ->
                    Text(
                        "${index + 1}. ${pair.goodMatches} good matches — ${pair.quality}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (report.adjacentPairs.size > 8) {
                    Text("…and ${report.adjacentPairs.size - 8} more pair(s)", style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showAllPairs = true }) {
                        Text("View all ${report.adjacentPairs.size}")
                    }
                    FilledTonalButton(onClick = {
                        pendingExportText = exportText()
                        val safeName = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_')
                            .ifBlank { "scan_project" }
                        exportLauncher.launch("${safeName}_feature_matches.txt")
                    }) {
                        Text("Export results")
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "These results are saved with the project and will still be here after you leave and reopen it. Adding or deleting a photo clears them because the old report would be stale.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showAllPairs) {
        AlertDialog(
            onDismissRequest = { showAllPairs = false },
            title = { Text("All adjacent photo matches") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 520.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    report.adjacentPairs.forEachIndexed { index, pair ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text("Pair ${index + 1}: ${pair.quality}", fontWeight = FontWeight.SemiBold)
                                Text("${pair.goodMatches} good matches", style = MaterialTheme.typography.bodyMedium)
                                Text("${pair.firstPhoto} → ${pair.secondPhoto}", style = MaterialTheme.typography.bodySmall)
                                Text("Keypoints: ${pair.firstKeypoints} / ${pair.secondKeypoints}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAllPairs = false }) { Text("Close") }
            }
        )
    }
}


@Composable
private fun SparseReconstructionCard(
    projectId: String,
    projectName: String,
    report: SparseReconstructionReport,
    onBuildMultiView: () -> Unit
) {
    val context = LocalContext.current
    var showCloud by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    var exportType by remember { mutableStateOf("txt") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - Sparse Reconstruction Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("sparse", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Best pair: ${report.firstPhoto} -> ${report.secondPhoto}")
        appendLine("Ratio-test matches: ${report.ratioMatches}")
        appendLine("RANSAC inliers: ${report.ransacInliers}")
        appendLine("Recovered-pose inliers: ${report.poseInliers}")
        appendLine("Triangulated 3D points: ${report.triangulatedPoints}")
        appendLine("Estimated focal length: ${"%.1f".format(report.focalPixels)} px")
        appendLine("Intrinsics source: ${report.intrinsicsSource}")
        appendLine("Relative rotation: ${"%.2f".format(report.relativeRotationDegrees)} degrees")
        appendLine("Ready for multi-view: ${report.readyForMultiView}")
        appendLine()
        appendLine("Warnings:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Adjacent-pair geometry checks:")
        report.pairEvaluations.forEachIndexed { index, item ->
            appendLine("${index + 1}. ${item.firstPhoto} -> ${item.secondPhoto} | ratio ${item.ratioMatches} | RANSAC ${item.ransacInliers} | pose ${item.poseInliers}")
        }
    }

    fun plyText(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio sparse two-view point cloud; arbitrary scale")
        appendLine("comment app_version ${BuildConfig.VERSION_NAME}")
        appendLine("comment project_id $projectId")
        appendLine("comment report_fingerprint ${reportFingerprint("sparse-ply", projectId, report)}")
        appendLine("element vertex ${report.points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        report.points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 2 — Sparse Reconstruction", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text("Best pair: ${report.firstPhoto} → ${report.secondPhoto}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Text("Ratio matches: ${report.ratioMatches}")
            Text("RANSAC inliers: ${report.ransacInliers}")
            Text("Pose inliers: ${report.poseInliers}")
            Text("3D points: ${report.triangulatedPoints}", fontWeight = FontWeight.Bold)
            Text("Relative camera rotation: ${"%.2f".format(report.relativeRotationDegrees)}°")
            Spacer(Modifier.height(6.dp))
            Text("Camera estimate: ${report.intrinsicsSource}", style = MaterialTheme.typography.bodySmall)
            report.warnings.forEach { warning ->
                Spacer(Modifier.height(3.dp))
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showCloud = true }) { Text("View cloud") }
                OutlinedButton(onClick = {
                    exportType = "txt"
                    pendingExportText = reportText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_sparse_report.txt")
                }) { Text("Export report") }
            }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    exportType = "ply"
                    pendingExportText = plyText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_sparse_cloud.ply")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export PLY point cloud") }
            if (report.readyForMultiView) {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onBuildMultiView,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Next: Stage 3 — Build multi-view reconstruction")
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("History: this stage began in v0.4. Current pipeline labels stay fixed by stage so test instructions match the screen.", style = MaterialTheme.typography.bodySmall)
        }
    }

    if (showCloud) {
        SparsePointCloudDialog(report.points, onDismiss = { showCloud = false })
    }
}


@Composable
private fun MultiViewReconstructionCard(projectId: String, projectName: String, report: MultiViewReconstructionReport, onBundleAdjust: () -> Unit) {
    val context = LocalContext.current
    var showCloud by remember { mutableStateOf(false) }
    var showPairs by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - Multi-View Sparse Reconstruction Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("multiview", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Photos requested: ${report.photosRequested}")
        appendLine("Connected cameras: ${report.connectedCameras}")
        appendLine("Connected adjacent pairs: ${report.connectedPairs}")
        appendLine("Raw triangulated points: ${report.rawTriangulatedPoints}")
        appendLine("Combined/downsampled points: ${report.combinedPoints}")
        appendLine("Average focal estimate: ${"%.1f".format(report.focalPixels)} px")
        appendLine("Intrinsics source: ${report.intrinsicsSource}")
        appendLine("Ready for bundle adjustment: ${report.readyForBundleAdjustment}")
        appendLine()
        appendLine("Warnings:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Camera path:")
        report.cameras.forEach { camera ->
            appendLine(
                "${camera.index + 1}. ${camera.photo} | connected=${camera.connected} | " +
                    "center=(${"%.4f".format(camera.x)}, ${"%.4f".format(camera.y)}, ${"%.4f".format(camera.z)})"
            )
        }
        appendLine()
        appendLine("Adjacent-pair multi-view checks:")
        report.pairEvaluations.forEachIndexed { index, item ->
            appendLine(
                "${index + 1}. ${item.firstPhoto} -> ${item.secondPhoto} | ratio ${item.ratioMatches} | " +
                    "RANSAC ${item.ransacInliers} | pose ${item.poseInliers} | " +
                    "points ${item.triangulatedPoints} | connected=${item.connected} | " +
                    "rotation ${"%.2f".format(item.relativeRotationDegrees)} deg"
            )
        }
    }

    fun plyText(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio largest-component multi-view sparse cloud; arbitrary scale; pre-bundle-adjustment")
        appendLine("comment app_version ${BuildConfig.VERSION_NAME}")
        appendLine("comment project_id $projectId")
        appendLine("comment report_fingerprint ${reportFingerprint("multiview-ply", projectId, report)}")
        appendLine("element vertex ${report.points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        report.points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 3 — Multi-View Reconstruction", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text(
                "Connected cameras: ${report.connectedCameras} / ${report.photosRequested}",
                fontWeight = FontWeight.Bold
            )
            Text("Connected adjacent pairs: ${report.connectedPairs} / ${(report.photosRequested - 1).coerceAtLeast(0)}")
            Text("Raw triangulated points: ${report.rawTriangulatedPoints}")
            Text("Combined sparse points: ${report.combinedPoints}", fontWeight = FontWeight.Bold)
            Text("Ready for bundle adjustment: ${report.readyForBundleAdjustment}")
            Spacer(Modifier.height(6.dp))
            report.warnings.take(4).forEach { warning ->
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(3.dp))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showCloud = true }) {
                    Text("View combined cloud")
                }
                OutlinedButton(onClick = { showPairs = true }) {
                    Text("View path")
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    pendingExportText = reportText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_multiview_report.txt")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export multi-view report")
            }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = plyText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_multiview_cloud.ply")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export multi-view PLY")
            }
            if (report.readyForBundleAdjustment) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onBundleAdjust, modifier = Modifier.fillMaxWidth()) {
                    Text("Next: Stage 4 — Refine bundle")
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "History: multi-view recovery began in v0.5.1. The next visible action is always named by pipeline stage rather than old release number.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showCloud) {
        SparsePointCloudDialog(report.points, onDismiss = { showCloud = false })
    }

    if (showPairs) {
        AlertDialog(
            onDismissRequest = { showPairs = false },
            title = { Text("Multi-view camera path") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 520.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    report.pairEvaluations.forEachIndexed { index, item ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                val pairStatus = when {
                                    item.connected -> "CONNECTED"
                                    item.poseInliers >= 20 && item.triangulatedPoints > 0 -> "VERIFIED / OUTSIDE MAIN SEGMENT"
                                    else -> "WEAK / DISCONNECTED"
                                }
                                Text(
                                    "Pair ${index + 1}: $pairStatus",
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text("${item.firstPhoto} → ${item.secondPhoto}", style = MaterialTheme.typography.bodySmall)
                                Text("Ratio ${item.ratioMatches} • RANSAC ${item.ransacInliers} • Pose ${item.poseInliers}")
                                Text("Triangulated ${item.triangulatedPoints} points • Rotation ${"%.2f".format(item.relativeRotationDegrees)}°")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPairs = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun BundleAdjustmentCard(projectId: String, projectName: String, report: BundleAdjustmentReport, onBuildDense: () -> Unit) {
    val context = LocalContext.current
    var showCloud by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - v0.6 Track Bundle Refinement Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("bundle", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Connected cameras refined: ${report.connectedCameras}")
        appendLine("3+ view tracks built: ${report.tracksBuilt}")
        appendLine("Tracks selected for optimization: ${report.tracksUsed}")
        appendLine("Observations used after filtering: ${report.observationsUsed}")
        appendLine("Initial shared-track points: ${report.initialPoints}")
        appendLine("Refined points: ${report.refinedPoints}")
        appendLine("Initial RMS reprojection error: ${"%.4f".format(report.initialRmsPixels)} px")
        appendLine("Final RMS reprojection error: ${"%.4f".format(report.finalRmsPixels)} px")
        appendLine("Optimization iterations: ${report.iterations}")
        appendLine("Ready for dense reconstruction: ${report.readyForDenseReconstruction}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Refined camera centers:")
        report.cameras.forEach { camera ->
            appendLine("${camera.index + 1}. ${camera.photo} | center=(${"%.4f".format(camera.x)}, ${"%.4f".format(camera.y)}, ${"%.4f".format(camera.z)})")
        }
    }

    fun plyText(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio shared-track limited bundle adjustment; arbitrary scale")
        appendLine("comment app_version ${BuildConfig.VERSION_NAME}")
        appendLine("comment project_id $projectId")
        appendLine("comment report_fingerprint ${reportFingerprint("bundle-ply", projectId, report)}")
        appendLine("element vertex ${report.points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        report.points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 4 — Bundle Refinement", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text("Connected cameras: ${report.connectedCameras}")
            Text("3+ view tracks: ${report.tracksBuilt} built • ${report.tracksUsed} optimized")
            Text("Observations used: ${report.observationsUsed}")
            Text("Refined sparse points: ${report.refinedPoints}", fontWeight = FontWeight.Bold)
            val rmsImprovementPercent = if (report.initialRmsPixels > 0.0) {
                ((report.initialRmsPixels - report.finalRmsPixels) / report.initialRmsPixels) * 100.0
            } else 0.0
            val rmsImproved = report.finalRmsPixels < report.initialRmsPixels
            Text(
                "RMS reprojection: ${"%.2f".format(report.initialRmsPixels)} px → ${"%.2f".format(report.finalRmsPixels)} px",
                fontWeight = FontWeight.Bold
            )
            Text(
                if (rmsImproved) "Improved by ${"%.1f".format(rmsImprovementPercent)}% — lower is better."
                else "Did not improve — lower is better.",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold
            )
            Text("Ready for dense reconstruction: ${report.readyForDenseReconstruction}")
            Spacer(Modifier.height(6.dp))
            report.warnings.take(4).forEach { warning ->
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(3.dp))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { showCloud = true }, modifier = Modifier.fillMaxWidth()) {
                Text("View refined cloud")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    pendingExportText = reportText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_bundle_report.txt")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export bundle refinement report") }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = plyText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_bundle_refined_cloud.ply")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export refined PLY") }
            if (report.readyForDenseReconstruction) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onBuildDense, modifier = Modifier.fillMaxWidth()) {
                    Text("Next: Stage 5 — Build dense stereo")
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "History: bundle refinement was introduced in v0.6. Current app ${BuildConfig.VERSION_NAME} keeps the tested connected-component dense recovery and uses stable stage labels for navigation.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showCloud) SparsePointCloudDialog(report.points, onDismiss = { showCloud = false })
}

@Composable
private fun DenseReconstructionCard(projectId: String, projectName: String, report: DenseReconstructionReport, onBuildDenseFusion: () -> Unit) {
    val context = LocalContext.current
    var showCloud by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - v0.8.4 Connected Dense Stereo Pair Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("dense-pair", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Pair: ${report.firstPhoto} -> ${report.secondPhoto}")
        appendLine("Working image size: ${report.width} x ${report.height}")
        appendLine("Ratio-test matches: ${report.ratioMatches}")
        appendLine("RANSAC inliers: ${report.ransacInliers}")
        appendLine("Recovered-pose inliers: ${report.poseInliers}")
        appendLine("Observed rectified inlier disparity: ${"%.2f".format(report.observedDisparityLow)} .. ${"%.2f".format(report.observedDisparityHigh)} px")
        appendLine("Observed median disparity: ${"%.2f".format(report.observedDisparityMedian)} px")
        appendLine("Adaptive minimum disparity: ${report.minDisparity}")
        appendLine("Stereo disparity search width: ${report.numDisparities}")
        appendLine("SGBM block size: ${report.blockSize}")
        appendLine("Valid disparity pixels: ${report.validDisparityPixels}")
        appendLine("Sparse-depth-guided candidates: ${report.geometryGuidedPoints}")
        appendLine("Filtered/exported dense points: ${report.densePoints}")
        appendLine("Depth range (arbitrary scale): ${"%.4f".format(report.minDepth)} .. ${"%.4f".format(report.maxDepth)}")
        appendLine("Median depth: ${"%.4f".format(report.medianDepth)}")
        appendLine("Ready for multi-pair dense fusion: ${report.readyForDenseFusion}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
    }

    fun plyText(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.7.1 adaptive dense stereo pair; arbitrary scale")
        appendLine("comment app_version ${BuildConfig.VERSION_NAME}")
        appendLine("comment project_id $projectId")
        appendLine("comment report_fingerprint ${reportFingerprint("dense-pair-ply", projectId, report)}")
        appendLine("element vertex ${report.points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        report.points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 5 — Dense Stereo", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text("Pair: ${report.firstPhoto} → ${report.secondPhoto}", style = MaterialTheme.typography.bodySmall)
            Text("Pose inliers: ${report.poseInliers} • Valid disparity pixels: ${report.validDisparityPixels}")
            if (report.observedDisparityMedian != 0.0) {
                Text(
                    "Verified disparity: ${"%.1f".format(report.observedDisparityLow)}–${"%.1f".format(report.observedDisparityHigh)} px • median ${"%.1f".format(report.observedDisparityMedian)}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "SGBM search: ${report.minDisparity} .. ${report.minDisparity + report.numDisparities - 1} px",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text("Sparse-depth-guided candidates: ${report.geometryGuidedPoints}")
            Text("Dense 3D points: ${report.densePoints}", fontWeight = FontWeight.Bold)
            Text("Median depth: ${"%.2f".format(report.medianDepth)} (arbitrary scale)")
            Text("Ready for multi-pair dense fusion: ${report.readyForDenseFusion}")
            Spacer(Modifier.height(6.dp))
            report.warnings.take(4).forEach { warning ->
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(3.dp))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { showCloud = true }, modifier = Modifier.fillMaxWidth()) {
                Text("View dense cloud")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    pendingExportText = reportText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_dense_pair_report.txt")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export dense report") }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = plyText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_dense_pair_cloud.ply")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export dense PLY") }
            Spacer(Modifier.height(6.dp))
            if (report.densePoints > 0) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onBuildDenseFusion, modifier = Modifier.fillMaxWidth()) {
                    Text("Next: Stage 6 — Fuse dense pairs")
                }
                if (!report.readyForDenseFusion) {
                    Text(
                        "Seed pair is below the older 1,000-point gate, but v0.8.1 lets the fusion engine evaluate connected pairs independently.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Stage 5 validates one dense stereo pair. Stage 6 evaluates several connected pairs and transforms accepted dense points into the shared refined camera frame.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showCloud) SparsePointCloudDialog(report.points, onDismiss = { showCloud = false })
}

@Composable
private fun DenseFusionCard(projectId: String, projectName: String, report: DenseFusionReport, onBuildSurfaceMesh: () -> Unit) {
    val context = LocalContext.current
    var showCloud by remember { mutableStateOf(false) }
    var showPairs by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(pendingExportText)
                }
            }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - v0.8.4 Multi-Pair Dense Fusion Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("dense-fusion", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Photos requested: ${report.photosRequested}")
        appendLine("Connected cameras: ${report.connectedCameras}")
        appendLine("Eligible dense-pair candidates: ${report.candidatePairs}")
        appendLine("Dense pairs fused: ${report.pairsFused}")
        appendLine("Raw accepted pair points: ${report.rawDensePoints}")
        appendLine("Fused/downsampled points: ${report.fusedPoints}")
        appendLine("Ready for surface reconstruction: ${report.readyForSurfaceReconstruction}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Selected pair diagnostics:")
        report.pairEvaluations.forEachIndexed { index, pair ->
            appendLine("${index + 1}. ${pair.firstPhoto} -> ${pair.secondPhoto} | pose ${pair.poseInliers} | median disparity ${"%.3f".format(pair.observedDisparityMedian)} px | valid disparity ${pair.validDisparityPixels} | local points ${pair.localDensePoints} | world points ${pair.fusedPoints} | accepted=${pair.accepted} | ${pair.reason}")
        }
    }

    fun plyText(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio v0.8.4 preflight-filtered multi-pair dense fusion; arbitrary scale")
        appendLine("comment app_version ${BuildConfig.VERSION_NAME}")
        appendLine("comment project_id $projectId")
        appendLine("comment report_fingerprint ${reportFingerprint("dense-fusion-ply", projectId, report)}")
        appendLine("element vertex ${report.points.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        appendLine("end_header")
        report.points.forEach { appendLine("${it.x} ${it.y} ${it.z}") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 6 — Dense Fusion", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text("Connected cameras: ${report.connectedCameras}")
            Text("Dense pairs: ${report.pairsFused} fused / ${report.candidatePairs} eligible candidates")
            Text("Raw accepted pair points: ${report.rawDensePoints}")
            Text("Fused 3D points: ${report.fusedPoints}", fontWeight = FontWeight.Bold)
            Text("Ready for surface reconstruction: ${report.readyForSurfaceReconstruction}")
            Spacer(Modifier.height(6.dp))
            report.warnings.take(4).forEach { warning ->
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(3.dp))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { showCloud = true }, modifier = Modifier.fillMaxWidth()) { Text("View fused dense cloud") }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = { showPairs = true }, modifier = Modifier.fillMaxWidth()) { Text("View pair diagnostics") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    pendingExportText = reportText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_dense_fusion_report.txt")
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("Export dense fusion report") }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = plyText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_dense_fused_cloud.ply")
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("Export fused dense PLY") }
            Spacer(Modifier.height(6.dp))
            if (report.readyForSurfaceReconstruction) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onBuildSurfaceMesh, modifier = Modifier.fillMaxWidth()) {
                    Text("Next: Stage 7 — Build surface mesh")
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Stage 6 is the shared-frame dense cloud. It rejects unstable stereo pairs instead of merging every result. Stage 7 converts the validated cloud into an experimental triangle surface.", style = MaterialTheme.typography.bodySmall)
        }
    }

    if (showCloud) SparsePointCloudDialog(report.points, onDismiss = { showCloud = false })
    if (showPairs) {
        AlertDialog(
            onDismissRequest = { showPairs = false },
            title = { Text("Dense fusion pair diagnostics") },
            text = {
                Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    report.pairEvaluations.forEachIndexed { index, pair ->
                        Text("${index + 1}. ${pair.firstPhoto} → ${pair.secondPhoto}", fontWeight = FontWeight.SemiBold)
                        Text("Pose ${pair.poseInliers} • median disparity ${"%.2f".format(pair.observedDisparityMedian)} px • valid ${pair.validDisparityPixels}")
                        Text("Local ${pair.localDensePoints} • world ${pair.fusedPoints} • ${if (pair.accepted) "FUSED" else "SKIPPED"}")
                        Text(pair.reason, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPairs = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun SurfaceMeshCard(projectId: String, projectName: String, report: SurfaceMeshReport, onBuildTexture: () -> Unit) {
    val context = LocalContext.current
    var showMesh by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer -> writer.write(pendingExportText) }
            }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - Stage 7 Surface Mesh Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("surface-mesh", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Source fused points: ${report.sourcePoints}")
        appendLine("Mesh vertices: ${report.meshVertices}")
        appendLine("Triangles: ${report.triangles}")
        appendLine("Voxel size: ${"%.6f".format(report.voxelSize)}")
        appendLine("Maximum accepted local edge: ${"%.6f".format(report.maxAcceptedEdge)}")
        appendLine("Candidate triangles proposed: ${report.candidateTriangles}")
        appendLine("Cleanup-rejected faces: ${report.cleanupRejectedFaces}")
        appendLine("Unused vertices removed: ${report.unusedVerticesRemoved}")
        appendLine("Boundary edges: ${report.boundaryEdges}")
        appendLine("Closed loops before fill: ${report.closedLoopsBeforeFill}")
        appendLine("Closed loops filled: ${report.filledBoundaryLoops}")
        appendLine("Closed loops remaining: ${report.boundaryLoops}")
        appendLine("Hole-fill vertices added: ${report.holeFillAddedVertices}")
        appendLine("Hole-fill faces added: ${report.holeFillAddedFaces}")
        appendLine("Closed loops skipped by safety checks: ${report.skippedClosedLoops}")
        appendLine("Open/branched boundary components: ${report.openBoundaryChains}")
        appendLine("Boundary branch vertices: ${report.boundaryBranchVertices}")
        appendLine("Non-manifold edges: ${report.nonManifoldEdges}")
        appendLine("Retained surface components: ${report.surfaceComponents}")
        appendLine("Smoothing iterations: ${report.smoothingIterations}")
        appendLine("Smoothed interior vertices: ${report.smoothedVertices}")
        appendLine("Average smoothing displacement: ${"%.6f".format(report.averageSmoothingDisplacement)}")
        appendLine("Valid vertex normals: ${report.validVertexNormals}/${report.meshVertices}")
        appendLine("Ready for export: ${report.readyForExport}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
    }

    fun objText(): String = buildString {
        appendLine("# 3D Scan Studio Stage 7 surface mesh")
        appendLine("# app_version ${BuildConfig.VERSION_NAME}")
        appendLine("# project_id $projectId")
        appendLine("# report_fingerprint ${reportFingerprint("surface-mesh-obj", projectId, report)}")
        appendLine("# arbitrary scale")
        report.vertices.forEach { appendLine("v ${it.x} ${it.y} ${it.z}") }
        val hasNormals = report.vertexNormals.size == report.vertices.size
        if (hasNormals) report.vertexNormals.forEach { appendLine("vn ${it.x} ${it.y} ${it.z}") }
        report.faces.forEach { face ->
            if (hasNormals) appendLine("f ${face.a + 1}//${face.a + 1} ${face.b + 1}//${face.b + 1} ${face.c + 1}//${face.c + 1}")
            else appendLine("f ${face.a + 1} ${face.b + 1} ${face.c + 1}")
        }
    }

    fun plyText(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio Stage 7 v0.11.0 safe closed-loop-filled surface mesh; arbitrary scale")
        appendLine("comment app_version ${BuildConfig.VERSION_NAME}")
        appendLine("comment project_id $projectId")
        appendLine("comment report_fingerprint ${reportFingerprint("surface-mesh-ply", projectId, report)}")
        appendLine("element vertex ${report.vertices.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        val hasNormals = report.vertexNormals.size == report.vertices.size
        if (hasNormals) {
            appendLine("property float nx")
            appendLine("property float ny")
            appendLine("property float nz")
        }
        appendLine("element face ${report.faces.size}")
        appendLine("property list uchar int vertex_indices")
        appendLine("end_header")
        report.vertices.forEachIndexed { index, vertex ->
            if (hasNormals) {
                val n = report.vertexNormals[index]
                appendLine("${vertex.x} ${vertex.y} ${vertex.z} ${n.x} ${n.y} ${n.z}")
            } else appendLine("${vertex.x} ${vertex.y} ${vertex.z}")
        }
        report.faces.forEach { appendLine("3 ${it.a} ${it.b} ${it.c}") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 7 — Surface Mesh", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Engine: ${report.engine}", style = MaterialTheme.typography.bodySmall)
            Text("Source fused points: ${report.sourcePoints}")
            Text("Mesh vertices: ${report.meshVertices}")
            Text("Triangles: ${report.triangles}", fontWeight = FontWeight.Bold)
            Text("Boundary edges: ${report.boundaryEdges}")
            Text("Closed loops: ${report.closedLoopsBeforeFill} before / ${report.filledBoundaryLoops} filled / ${report.boundaryLoops} remaining")
            Text("Hole-fill geometry: +${report.holeFillAddedVertices} vertex/vertices, +${report.holeFillAddedFaces} faces")
            Text("Open/branched boundary components: ${report.openBoundaryChains}")
            Text("Boundary branch vertices: ${report.boundaryBranchVertices}")
            Text("Non-manifold edges: ${report.nonManifoldEdges}", fontWeight = FontWeight.Bold)
            Text("Surface components: ${report.surfaceComponents}")
            Text("Smoothed interior vertices: ${report.smoothedVertices} (${report.smoothingIterations} passes)")
            Text("Vertex normals: ${report.validVertexNormals}/${report.meshVertices}")
            Text("Unused vertices removed: ${report.unusedVerticesRemoved}")
            Text("Ready for export: ${report.readyForExport}")
            Spacer(Modifier.height(6.dp))
            report.warnings.take(4).forEach { warning ->
                Text("• $warning", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(3.dp))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { showMesh = true }, modifier = Modifier.fillMaxWidth()) {
                Text("View Stage 7 mesh")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    pendingExportText = reportText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_surface_mesh_report.txt")
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("Export Stage 7 mesh report") }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = objText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_surface_mesh.obj")
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("Export mesh OBJ") }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = {
                    pendingExportText = plyText()
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    exportLauncher.launch("${safe}_surface_mesh.ply")
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("Export triangle PLY") }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onBuildTexture, modifier = Modifier.fillMaxWidth(), enabled = report.readyForExport) {
                Text("Next: Stage 8 — Project photo colors")
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "v0.11.0 preserves the topology-clean local fan mesh and normals, then fills only small/simple closed loops that pass conservative shape, edge-length, and planarity checks. Open or branched borders are left untouched.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showMesh) MeshWireframeDialog(report.vertices, report.faces, onDismiss = { showMesh = false })
}

@Composable
private fun TextureProjectionCard(
    projectId: String,
    projectName: String,
    mesh: SurfaceMeshReport,
    report: TextureProjectionReport,
    onBuildTextureSources: () -> Unit
) {
    val context = LocalContext.current
    var showColors by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExportText) } }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - Stage 8 Photo Color Projection Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("texture-projection", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Source mesh vertices: ${report.sourceMeshVertices}")
        appendLine("Source mesh faces: ${report.sourceMeshFaces}")
        appendLine("Photos requested: ${report.photosRequested}")
        appendLine("Connected cameras: ${report.connectedCameras}")
        appendLine("Recovered camera poses: ${report.recoveredCameraPoses}")
        appendLine("Recovered orientation links: ${report.recoveredOrientationLinks}")
        appendLine("Bridged orientation links: ${report.bridgedOrientationLinks}")
        appendLine("Cameras used for best colors: ${report.camerasUsed}")
        appendLine("Visibility-approved color candidates: ${report.projectedCandidates}")
        appendLine("Visibility-rejected candidates: ${report.visibilityRejectedCandidates}")
        appendLine("Colored vertices: ${report.coloredVertices}")
        appendLine("Uncolored vertices: ${report.uncoloredVertices}")
        appendLine("Color coverage: ${"%.2f".format(report.coveragePercent)}%")
        appendLine("Average blended samples per colored vertex: ${"%.2f".format(report.averageSamplesPerColoredVertex)}")
        appendLine("Ready for export: ${report.readyForExport}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Camera contributions:")
        report.cameraContributions.forEachIndexed { index, item ->
            appendLine("${index + 1}. ${item.photo} | poseRecovered=${item.poseRecovered} | visibleProjected=${item.projectedVertices} | visibilityRejected=${item.visibilityRejectedVertices} | selectedBest=${item.selectedVertices}")
        }
    }

    fun coloredPly(): String = buildString {
        appendLine("ply")
        appendLine("format ascii 1.0")
        appendLine("comment 3D Scan Studio Stage 8 v0.13.0 visibility-refined photo-projected vertex colors; arbitrary scale")
        appendLine("element vertex ${mesh.vertices.size}")
        appendLine("property float x")
        appendLine("property float y")
        appendLine("property float z")
        val hasNormals = mesh.vertexNormals.size == mesh.vertices.size
        if (hasNormals) {
            appendLine("property float nx"); appendLine("property float ny"); appendLine("property float nz")
        }
        appendLine("property uchar red"); appendLine("property uchar green"); appendLine("property uchar blue")
        appendLine("element face ${mesh.faces.size}")
        appendLine("property list uchar int vertex_indices")
        appendLine("end_header")
        mesh.vertices.forEachIndexed { index, p ->
            val c = report.vertexColors.getOrNull(index) ?: VertexColor(128, 128, 128)
            if (hasNormals) {
                val n = mesh.vertexNormals[index]
                appendLine("${p.x} ${p.y} ${p.z} ${n.x} ${n.y} ${n.z} ${c.red} ${c.green} ${c.blue}")
            } else appendLine("${p.x} ${p.y} ${p.z} ${c.red} ${c.green} ${c.blue}")
        }
        mesh.faces.forEach { appendLine("3 ${it.a} ${it.b} ${it.c}") }
    }

    fun coloredObj(): String = buildString {
        appendLine("# 3D Scan Studio Stage 8 v0.13.0 visibility-refined vertex-colored OBJ")
        appendLine("# PLY is the primary color export; this OBJ uses the common v x y z r g b extension.")
        mesh.vertices.forEachIndexed { index, p ->
            val c = report.vertexColors.getOrNull(index) ?: VertexColor(128, 128, 128)
            appendLine("v ${p.x} ${p.y} ${p.z} ${c.red / 255.0} ${c.green / 255.0} ${c.blue / 255.0}")
        }
        val hasNormals = mesh.vertexNormals.size == mesh.vertices.size
        if (hasNormals) mesh.vertexNormals.forEach { appendLine("vn ${it.x} ${it.y} ${it.z}") }
        mesh.faces.forEach { f ->
            if (hasNormals) appendLine("f ${f.a + 1}//${f.a + 1} ${f.b + 1}//${f.b + 1} ${f.c + 1}//${f.c + 1}")
            else appendLine("f ${f.a + 1} ${f.b + 1} ${f.c + 1}")
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 8 — Photo Color Projection", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Colored vertices: ${report.coloredVertices} / ${report.sourceMeshVertices}")
            Text("Coverage: ${"%.1f".format(report.coveragePercent)}%")
            Text("Recovered camera poses: ${report.recoveredCameraPoses} / ${report.connectedCameras}")
            Text("Recovered orientation links: ${report.recoveredOrientationLinks} (bridged: ${report.bridgedOrientationLinks})")
            Text("Visibility-rejected candidates: ${report.visibilityRejectedCandidates}")
            Text("Cameras supplying best colors: ${report.camerasUsed}")
            Text("Average photo samples per colored vertex: ${"%.2f".format(report.averageSamplesPerColoredVertex)}")
            Text("Ready for export: ${report.readyForExport}")
            report.warnings.take(3).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = { showColors = true }, modifier = Modifier.fillMaxWidth()) { Text("View Stage 8 photo colors") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = {
                pendingExportText = reportText()
                val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                exportLauncher.launch("${safe}_stage8_photo_color_report.txt")
            }, modifier = Modifier.fillMaxWidth()) { Text("Export Stage 8 color report") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = {
                pendingExportText = coloredPly()
                val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                exportLauncher.launch("${safe}_surface_mesh_colored.ply")
            }, modifier = Modifier.fillMaxWidth()) { Text("Export colored PLY") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = {
                pendingExportText = coloredObj()
                val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                exportLauncher.launch("${safe}_surface_mesh_colored.obj")
            }, modifier = Modifier.fillMaxWidth()) { Text("Export vertex-colored OBJ") }
            Spacer(Modifier.height(6.dp))
            Button(onClick = onBuildTextureSources, modifier = Modifier.fillMaxWidth(), enabled = report.readyForExport) {
                Text("Next: Stage 9 — Assign triangle texture sources")
            }
            Spacer(Modifier.height(6.dp))
            Text("Stage 8 now uses short-gap pose bridging plus coarse depth visibility. Stage 9 assigns one real source photo and normalized photo coordinates to each usable triangle before a later texture atlas is packed.", style = MaterialTheme.typography.bodySmall)
        }
    }

    if (showColors) {
        MeshWireframeDialog(
            vertices = mesh.vertices,
            faces = mesh.faces,
            vertexColors = report.vertexColors,
            title = "Stage 8 photo color preview",
            onDismiss = { showColors = false }
        )
    }
}

@Composable
private fun TextureSourceAssignmentCard(
    projectId: String,
    projectName: String,
    report: TextureSourceAssignmentReport,
    onBuildTextureAtlas: () -> Unit
) {
    val context = LocalContext.current
    var pendingExportText by remember { mutableStateOf("") }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null && pendingExportText.isNotBlank()) {
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExportText) } }
        }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - Stage 9 Texture Source Assignment Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("texture-source", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Source mesh vertices: ${report.sourceMeshVertices}")
        appendLine("Source mesh faces: ${report.sourceMeshFaces}")
        appendLine("Connected cameras: ${report.connectedCameras}")
        appendLine("Recovered camera poses: ${report.recoveredCameraPoses}")
        appendLine("Recovered orientation links: ${report.recoveredOrientationLinks}")
        appendLine("Bridged orientation links: ${report.bridgedOrientationLinks}")
        appendLine("Cameras used for triangle sources: ${report.camerasUsed}")
        appendLine("Visible face candidates across cameras: ${report.visibleFaceCandidates}")
        appendLine("Triangles assigned a source photo: ${report.assignedFaces}")
        appendLine("Triangles without a source photo: ${report.unassignedFaces}")
        appendLine("Triangle source coverage: ${"%.2f".format(report.faceCoveragePercent)}%")
        appendLine("Ready for texture atlas: ${report.readyForAtlas}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
        appendLine()
        appendLine("Camera face contributions:")
        report.cameraContributions.forEachIndexed { index, item ->
            appendLine("${index + 1}. ${item.photo} | poseRecovered=${item.poseRecovered} | visibleCandidates=${item.visibleCandidateFaces} | selectedFaces=${item.selectedFaces}")
        }
    }

    fun faceMapText(): String = buildString {
        appendLine("# 3D Scan Studio Stage 9 v0.17.0 triangle texture-source map")
        appendLine("# faceIndex\tphoto\tu0\tv0\tu1\tv1\tu2\tv2\tscore")
        report.assignments.forEach { item ->
            appendLine("${item.faceIndex}\t${item.photo}\t${item.u0}\t${item.v0}\t${item.u1}\t${item.v1}\t${item.u2}\t${item.v2}\t${item.score}")
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 9 — Texture Source Assignment", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Triangles assigned: ${report.assignedFaces} / ${report.sourceMeshFaces}")
            Text("Triangle source coverage: ${"%.1f".format(report.faceCoveragePercent)}%")
            Text("Recovered camera poses: ${report.recoveredCameraPoses} / ${report.connectedCameras}")
            Text("Bridged orientation links: ${report.bridgedOrientationLinks}")
            Text("Cameras supplying triangle sources: ${report.camerasUsed}")
            Text("Ready for texture atlas: ${report.readyForAtlas}")
            report.warnings.take(3).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                pendingExportText = reportText()
                val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                exportLauncher.launch("${safe}_stage9_texture_source_report.txt")
            }, modifier = Modifier.fillMaxWidth()) { Text("Export Stage 9 source report") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = {
                pendingExportText = faceMapText()
                val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                exportLauncher.launch("${safe}_stage9_triangle_source_map.tsv")
            }, modifier = Modifier.fillMaxWidth()) { Text("Export triangle source map") }
            Spacer(Modifier.height(6.dp))
            Button(onClick = onBuildTextureAtlas, modifier = Modifier.fillMaxWidth(), enabled = report.assignments.isNotEmpty()) {
                Text("Next: Stage 10 — Build UV texture atlas")
            }
            Spacer(Modifier.height(6.dp))
            Text("Stage 9 stores which original photo should texture each usable triangle and its normalized photo coordinates. Stage 10 packs those real photo patches into a PNG atlas and UV-mapped OBJ.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TextureAtlasCard(
    projectId: String,
    projectName: String,
    mesh: SurfaceMeshReport,
    report: TextureAtlasReport,
    onLoadPackage: () -> ByteArray?,
    onLoadPng: () -> ByteArray?
) {
    val context = LocalContext.current
    var pendingBytes by remember { mutableStateOf<ByteArray?>(null) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showTexturedPreview by remember { mutableStateOf(false) }
    val zipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val bytes = pendingBytes
        if (uri != null && bytes != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
        pendingBytes = null
    }
    val pngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        val bytes = pendingBytes
        if (uri != null && bytes != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
        pendingBytes = null
    }
    var pendingText by remember { mutableStateOf("") }
    val textLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null && pendingText.isNotBlank()) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingText) } }
    }

    fun reportText(): String = buildString {
        appendLine("3D Scan Studio - Stage 10 UV Texture Atlas Report")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Project: $projectName")
        appendLine("Project ID: $projectId")
        appendLine("Report fingerprint: ${reportFingerprint("texture-atlas", projectId, report)}")
        appendLine("Exported: ${DateFormat.getDateTimeInstance().format(Date())}")
        appendLine("Engine: ${report.engine}")
        appendLine("Atlas size: ${report.atlasWidth} x ${report.atlasHeight}")
        appendLine("Packing mode: connected same-photo UV islands")
        appendLine("UV islands: ${report.uvIslands}")
        appendLine("Largest UV island: ${report.largestIslandFaces} face(s)")
        appendLine("Atlas occupancy: ${"%.2f".format(report.atlasOccupancyPercent)}%")
        appendLine("Padding: ${report.padding} px")
        appendLine("Source mesh vertices: ${report.sourceMeshVertices}")
        appendLine("Source mesh faces: ${report.sourceMeshFaces}")
        appendLine("Stage 9 assigned faces: ${report.stage9AssignedFaces}")
        appendLine("Atlas-textured faces: ${report.texturedFaces}")
        appendLine("Untextured faces preserved: ${report.untexturedFaces}")
        appendLine("Texture coverage: ${"%.2f".format(report.textureCoveragePercent)}%")
        appendLine("Source photos used: ${report.sourcePhotosUsed}")
        appendLine("Skipped missing-photo faces: ${report.skippedMissingPhotos}")
        appendLine("Skipped rasterization/mapping faces: ${report.skippedRasterizationFaces}")
        appendLine("Ready for export: ${report.readyForExport}")
        appendLine()
        appendLine("Warnings / notes:")
        if (report.warnings.isEmpty()) appendLine("- None") else report.warnings.forEach { appendLine("- $it") }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Stage 10 — UV Texture Atlas", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("Atlas: ${report.atlasWidth} × ${report.atlasHeight}")
            Text("UV islands: ${report.uvIslands} (largest ${report.largestIslandFaces} faces)")
            Text("Atlas occupancy: ${"%.1f".format(report.atlasOccupancyPercent)}%")
            Text("Textured faces: ${report.texturedFaces} / ${report.sourceMeshFaces}")
            Text("Texture coverage: ${"%.1f".format(report.textureCoveragePercent)}%")
            Text("Source photos used: ${report.sourcePhotosUsed}")
            Text("Untextured faces preserved: ${report.untexturedFaces}")
            Text("Ready for export: ${report.readyForExport}")
            report.warnings.take(3).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = {
                val bytes = onLoadPng()
                val decoded = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                if (decoded != null) { previewBitmap = decoded; showTexturedPreview = true }
            }, modifier = Modifier.fillMaxWidth(), enabled = report.readyForExport) { Text("View textured model in app") }
            Spacer(Modifier.height(6.dp))
            FilledTonalButton(onClick = {
                pendingBytes = onLoadPackage()
                if (pendingBytes != null) {
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    zipLauncher.launch("${safe}_textured_model_package.zip")
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = report.readyForExport) { Text("Export textured model package (.zip)") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = {
                pendingBytes = onLoadPng()
                if (pendingBytes != null) {
                    val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                    pngLauncher.launch("${safe}_texture_atlas.png")
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = report.readyForExport) { Text("Export texture atlas PNG") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = {
                pendingText = reportText()
                val safe = projectName.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "scan_project" }
                textLauncher.launch("${safe}_stage10_texture_atlas_report.txt")
            }, modifier = Modifier.fillMaxWidth()) { Text("Export Stage 10 atlas report") }
            Spacer(Modifier.height(6.dp))
            Text("v0.17.0 keeps the UV islands/exposure normalization and adds neighbor-consistent Stage 9 recovery for still-unassigned faces. The atlas itself still is not meant to resemble the assembled object; use the in-app textured preview or exported OBJ package.", style = MaterialTheme.typography.bodySmall)
        }
    }

    val atlas = previewBitmap
    if (showTexturedPreview && atlas != null) {
        TexturedMeshDialog(mesh.vertices, mesh.faces, report.faceUvs, atlas, onDismiss = { showTexturedPreview = false })
    }
}

private data class TexturedPreviewPoint(val point: Offset, val depth: Double)

@Composable
private fun TexturedMeshDialog(
    vertices: List<SparsePoint>,
    faces: List<MeshTriangle>,
    faceUvs: List<com.photogrammetrystudio.app.model.FaceAtlasUv>,
    atlas: Bitmap,
    onDismiss: () -> Unit
) {
    var yaw by remember { mutableFloatStateOf(0f) }
    var pitch by remember { mutableFloatStateOf(0f) }
    var roll by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    fun wrapAngle(value: Float): Float { var w = (value + 180f) % 360f; if (w < 0f) w += 360f; return w - 180f }
    val centerX = remember(vertices) { vertices.map { it.x }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val centerY = remember(vertices) { vertices.map { it.y }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val centerZ = remember(vertices) { vertices.map { it.z }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val radius = remember(vertices) {
        val d = vertices.map { p -> max(max(kotlin.math.abs(p.x-centerX), kotlin.math.abs(p.y-centerY)), kotlin.math.abs(p.z-centerZ)) }.sorted()
        if (d.isEmpty()) 1.0 else d[((d.size-1)*0.95).toInt().coerceIn(0,d.lastIndex)].coerceAtLeast(1e-6)
    }
    val uvByFace = remember(faceUvs) { faceUvs.associateBy { it.faceIndex } }
    val previewIndices = remember(faces, faceUvs) {
        val textured = faceUvs.map { it.faceIndex }.filter { it in faces.indices }.toSet()
        val result = ArrayList<Int>()
        result.addAll(textured.sorted())
        val remainingBudget = (7000 - result.size).coerceAtLeast(0)
        val untextured = faces.indices.filter { it !in textured }
        if (remainingBudget > 0 && untextured.isNotEmpty()) {
            val step = max(1, untextured.size / remainingBudget.coerceAtLeast(1))
            untextured.filterIndexed { idx, _ -> idx % step == 0 }.take(remainingBudget).forEach { result += it }
        }
        result
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Textured model preview (${faceUvs.size}/${faces.size} textured faces)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { yaw=0f; pitch=0f; roll=0f; zoom=1f }) { Text("Reset") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
                Text("Drag = yaw/pitch • pinch = zoom • two-finger twist = roll", style = MaterialTheme.typography.bodySmall)
                Canvas(Modifier.fillMaxWidth().weight(1f).background(Color.Black).pointerInput(vertices, faceUvs) {
                    detectTransformGestures { _, pan, gestureZoom, gestureRotation ->
                        yaw=wrapAngle(yaw+pan.x*0.35f); pitch=wrapAngle(pitch-pan.y*0.35f); roll=wrapAngle(roll+gestureRotation); zoom=(zoom*gestureZoom).coerceIn(0.25f,6f)
                    }
                }) {
                    val yr=Math.toRadians(yaw.toDouble()); val pr=Math.toRadians(pitch.toDouble()); val rr=Math.toRadians(roll.toDouble())
                    val cy=cos(yr); val sy=sin(yr); val cp=cos(pr); val sp=sin(pr); val cr=cos(rr); val sr=sin(rr)
                    val scale=(minOf(size.width,size.height)*0.44f/radius*zoom).toFloat()
                    val projected=ArrayList<TexturedPreviewPoint>(vertices.size)
                    vertices.forEach { p ->
                        val x0=p.x-centerX; val y0=p.y-centerY; val z0=p.z-centerZ
                        val x1=x0*cy+z0*sy; val y1=y0; val z1=-x0*sy+z0*cy
                        val x2=x1; val y2=y1*cp-z1*sp; val z2=y1*sp+z1*cp
                        val x3=x2*cr-y2*sr; val y3=x2*sr+y2*cr; val z3=z2
                        val persp=(1.0/(1.0+z3/(radius*6.0))).coerceIn(0.55,1.6)
                        projected += TexturedPreviewPoint(Offset(size.width/2f+(x3*scale*persp).toFloat(), size.height/2f-(y3*scale*persp).toFloat()), z3)
                    }
                    val ordered = previewIndices.sortedByDescending { fi ->
                        val f=faces[fi]; (projected[f.a].depth+projected[f.b].depth+projected[f.c].depth)/3.0
                    }
                    drawIntoCanvas { canvas ->
                        val nc=canvas.nativeCanvas
                        val imagePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap=true }
                        val grayPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.FILL; color=android.graphics.Color.rgb(92,92,92) }
                        val edgePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE; strokeWidth=0.7f; color=android.graphics.Color.argb(70,255,255,255) }
                        val matrix=Matrix(); val path=AndroidPath(); val src=FloatArray(6); val dst=FloatArray(6)
                        ordered.forEach { fi ->
                            val f=faces[fi]
                            if (f.a !in projected.indices || f.b !in projected.indices || f.c !in projected.indices) return@forEach
                            val a=projected[f.a].point; val b=projected[f.b].point; val c=projected[f.c].point
                            if (!(a.x.isFinite()&&a.y.isFinite()&&b.x.isFinite()&&b.y.isFinite()&&c.x.isFinite()&&c.y.isFinite())) return@forEach
                            path.reset(); path.moveTo(a.x,a.y); path.lineTo(b.x,b.y); path.lineTo(c.x,c.y); path.close()
                            val uv=uvByFace[fi]
                            if (uv != null) {
                                src[0]=(uv.u0*(atlas.width-1)).toFloat(); src[1]=((1.0-uv.v0)*(atlas.height-1)).toFloat()
                                src[2]=(uv.u1*(atlas.width-1)).toFloat(); src[3]=((1.0-uv.v1)*(atlas.height-1)).toFloat()
                                src[4]=(uv.u2*(atlas.width-1)).toFloat(); src[5]=((1.0-uv.v2)*(atlas.height-1)).toFloat()
                                dst[0]=a.x; dst[1]=a.y; dst[2]=b.x; dst[3]=b.y; dst[4]=c.x; dst[5]=c.y
                                matrix.reset()
                                if (matrix.setPolyToPoly(src,0,dst,0,3)) {
                                    val save=nc.save(); nc.clipPath(path); nc.drawBitmap(atlas,matrix,imagePaint); nc.restoreToCount(save)
                                } else nc.drawPath(path,grayPaint)
                            } else nc.drawPath(path,grayPaint)
                            nc.drawPath(path,edgePaint)
                        }
                    }
                }
                Text("Yaw ${yaw.toInt()}° • Pitch ${pitch.toInt()}° • Roll ${roll.toInt()}° • ${"%.1f".format(zoom)}×", style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton({yaw=0f;pitch=0f;roll=0f},Modifier.weight(1f)){Text("Front")}; OutlinedButton({yaw=180f;pitch=0f;roll=0f},Modifier.weight(1f)){Text("Back")}; OutlinedButton({yaw=-90f;pitch=0f;roll=0f},Modifier.weight(1f)){Text("Left")}; OutlinedButton({yaw=90f;pitch=0f;roll=0f},Modifier.weight(1f)){Text("Right")}
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton({yaw=0f;pitch=-90f;roll=0f},Modifier.weight(1f)){Text("Top")}; OutlinedButton({yaw=0f;pitch=90f;roll=0f},Modifier.weight(1f)){Text("Bottom")}
                }
            }
        }
    }
}

@Composable
private fun MeshWireframeDialog(
    vertices: List<SparsePoint>,
    faces: List<MeshTriangle>,
    vertexColors: List<VertexColor>? = null,
    title: String = "Surface mesh",
    onDismiss: () -> Unit
) {
    var yaw by remember { mutableFloatStateOf(0f) }
    var pitch by remember { mutableFloatStateOf(0f) }
    var roll by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }

    fun wrapAngle(value: Float): Float {
        var wrapped = (value + 180f) % 360f
        if (wrapped < 0f) wrapped += 360f
        return wrapped - 180f
    }

    val centerX = remember(vertices) { vertices.map { it.x }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val centerY = remember(vertices) { vertices.map { it.y }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val centerZ = remember(vertices) { vertices.map { it.z }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val radius = remember(vertices) {
        val d = vertices.map { p -> max(max(kotlin.math.abs(p.x - centerX), kotlin.math.abs(p.y - centerY)), kotlin.math.abs(p.z - centerZ)) }.sorted()
        if (d.isEmpty()) 1.0 else d[((d.size - 1) * 0.95).toInt().coerceIn(0, d.lastIndex)].coerceAtLeast(1e-6)
    }
    val previewFaces = remember(faces) {
        if (faces.size <= 14000) faces else faces.filterIndexed { index, _ -> index % (faces.size / 14000 + 1) == 0 }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "$title (${vertices.size} vertices • ${faces.size} triangles)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { yaw = 0f; pitch = 0f; roll = 0f; zoom = 1f }) { Text("Reset") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
                Text("Drag = yaw/pitch • pinch = zoom • two-finger twist = roll", style = MaterialTheme.typography.bodySmall)

                Canvas(
                    modifier = Modifier.fillMaxWidth().weight(1f).background(Color.Black).pointerInput(vertices, faces) {
                        detectTransformGestures { _, pan, gestureZoom, gestureRotation ->
                            yaw = wrapAngle(yaw + pan.x * 0.35f)
                            pitch = wrapAngle(pitch - pan.y * 0.35f)
                            roll = wrapAngle(roll + gestureRotation)
                            zoom = (zoom * gestureZoom).coerceIn(0.25f, 6f)
                        }
                    }
                ) {
                    val yawRad = Math.toRadians(yaw.toDouble()); val pitchRad = Math.toRadians(pitch.toDouble()); val rollRad = Math.toRadians(roll.toDouble())
                    val cy = cos(yawRad); val sy = sin(yawRad); val cp = cos(pitchRad); val sp = sin(pitchRad); val cr = cos(rollRad); val sr = sin(rollRad)
                    val scale = (minOf(size.width, size.height) * 0.44f / radius * zoom).toFloat()
                    val projected = ArrayList<Offset>(vertices.size)
                    vertices.forEach { p ->
                        val x0 = p.x - centerX; val y0 = p.y - centerY; val z0 = p.z - centerZ
                        val x1 = x0 * cy + z0 * sy; val y1 = y0; val z1 = -x0 * sy + z0 * cy
                        val x2 = x1; val y2 = y1 * cp - z1 * sp; val z2 = y1 * sp + z1 * cp
                        val x3 = x2 * cr - y2 * sr; val y3 = x2 * sr + y2 * cr; val z3 = z2
                        val perspective = (1.0 / (1.0 + z3 / (radius * 6.0))).coerceIn(0.55, 1.6)
                        projected += Offset(size.width / 2f + (x3 * scale * perspective).toFloat(), size.height / 2f - (y3 * scale * perspective).toFloat())
                    }
                    if (vertexColors?.size == vertices.size) {
                        projected.forEachIndexed { index, point ->
                            val c = vertexColors[index]
                            drawCircle(
                                Color(c.red / 255f, c.green / 255f, c.blue / 255f, 0.88f),
                                2.2f,
                                point
                            )
                        }
                    }
                    previewFaces.forEach { f ->
                        if (f.a in projected.indices && f.b in projected.indices && f.c in projected.indices) {
                            val a = projected[f.a]; val b = projected[f.b]; val c = projected[f.c]
                            if (a.x.isFinite() && a.y.isFinite() && b.x.isFinite() && b.y.isFinite() && c.x.isFinite() && c.y.isFinite()) {
                                drawLine(Color.White.copy(alpha = if (vertexColors != null) 0.18f else 0.40f), a, b, strokeWidth = 1f)
                                drawLine(Color.White.copy(alpha = if (vertexColors != null) 0.18f else 0.40f), b, c, strokeWidth = 1f)
                                drawLine(Color.White.copy(alpha = if (vertexColors != null) 0.18f else 0.40f), c, a, strokeWidth = 1f)
                            }
                        }
                    }
                }
                Text("Yaw ${yaw.toInt()}° • Pitch ${pitch.toInt()}° • Roll ${roll.toInt()}° • ${"%.1f".format(zoom)}×", style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton({ yaw = 0f; pitch = 0f; roll = 0f }, Modifier.weight(1f)) { Text("Front") }
                    OutlinedButton({ yaw = 180f; pitch = 0f; roll = 0f }, Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton({ yaw = -90f; pitch = 0f; roll = 0f }, Modifier.weight(1f)) { Text("Left") }
                    OutlinedButton({ yaw = 90f; pitch = 0f; roll = 0f }, Modifier.weight(1f)) { Text("Right") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton({ yaw = 0f; pitch = -90f; roll = 0f }, Modifier.weight(1f)) { Text("Top") }
                    OutlinedButton({ yaw = 0f; pitch = 90f; roll = 0f }, Modifier.weight(1f)) { Text("Bottom") }
                }
            }
        }
    }
}

@Composable
private fun SparsePointCloudDialog(points: List<SparsePoint>, onDismiss: () -> Unit) {
    var yaw by remember { mutableFloatStateOf(0f) }
    var pitch by remember { mutableFloatStateOf(0f) }
    var roll by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var showFineControls by remember { mutableStateOf(false) }

    fun wrapAngle(value: Float): Float {
        var wrapped = (value + 180f) % 360f
        if (wrapped < 0f) wrapped += 360f
        return wrapped - 180f
    }

    val usable = remember(points) {
        if (points.size <= 3200) points else points.filterIndexed { index, _ -> index % (points.size / 3200 + 1) == 0 }
    }
    val centerX = remember(points) { points.map { it.x }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val centerY = remember(points) { points.map { it.y }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val centerZ = remember(points) { points.map { it.z }.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] } }
    val radius = remember(points) {
        val distances = points.map { p ->
            max(
                max(kotlin.math.abs(p.x - centerX), kotlin.math.abs(p.y - centerY)),
                kotlin.math.abs(p.z - centerZ)
            )
        }.sorted()
        if (distances.isEmpty()) 1.0 else {
            val robustIndex = ((distances.size - 1) * 0.95).toInt().coerceIn(0, distances.lastIndex)
            distances[robustIndex].coerceAtLeast(1e-6)
        }
    }
    val previewPoints = remember(usable, radius, centerX, centerY, centerZ) {
        usable.filter { p ->
            val d = max(
                max(kotlin.math.abs(p.x - centerX), kotlin.math.abs(p.y - centerY)),
                kotlin.math.abs(p.z - centerZ)
            )
            d <= radius * 1.35
        }
    }

    fun setView(newYaw: Float, newPitch: Float, newRoll: Float = 0f) {
        yaw = newYaw; pitch = newPitch; roll = newRoll
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Point cloud (${points.size} points)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { yaw = 0f; pitch = 0f; roll = 0f; zoom = 1f }) { Text("Reset") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }

                Text(
                    "Drag = yaw/pitch • pinch = zoom • two-finger twist = roll",
                    style = MaterialTheme.typography.bodySmall
                )

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color.Black)
                        .pointerInput(points) {
                            detectTransformGestures { _, pan, gestureZoom, gestureRotation ->
                                yaw = wrapAngle(yaw + pan.x * 0.35f)
                                pitch = wrapAngle(pitch - pan.y * 0.35f)
                                roll = wrapAngle(roll + gestureRotation)
                                zoom = (zoom * gestureZoom).coerceIn(0.25f, 6.0f)
                            }
                        }
                ) {
                    val yawRad = Math.toRadians(yaw.toDouble())
                    val pitchRad = Math.toRadians(pitch.toDouble())
                    val rollRad = Math.toRadians(roll.toDouble())
                    val cy = cos(yawRad); val sy = sin(yawRad)
                    val cp = cos(pitchRad); val sp = sin(pitchRad)
                    val cr = cos(rollRad); val sr = sin(rollRad)
                    val scale = (minOf(size.width, size.height) * 0.44f / radius * zoom).toFloat()

                    previewPoints.forEach { p ->
                        val x0 = p.x - centerX
                        val y0 = p.y - centerY
                        val z0 = p.z - centerZ

                        val x1 = x0 * cy + z0 * sy
                        val y1 = y0
                        val z1 = -x0 * sy + z0 * cy

                        val x2 = x1
                        val y2 = y1 * cp - z1 * sp
                        val z2 = y1 * sp + z1 * cp

                        val x3 = x2 * cr - y2 * sr
                        val y3 = x2 * sr + y2 * cr
                        val z3 = z2

                        val perspective = (1.0 / (1.0 + (z3 / (radius * 6.0)))).coerceIn(0.55, 1.6)
                        val px = size.width / 2f + (x3 * scale * perspective).toFloat()
                        val py = size.height / 2f - (y3 * scale * perspective).toFloat()
                        if (px.isFinite() && py.isFinite()) {
                            drawCircle(Color.White.copy(alpha = 0.82f), 1.8f, Offset(px, py))
                        }
                    }
                }

                Text(
                    "Yaw ${yaw.toInt()}° • Pitch ${pitch.toInt()}° • Roll ${roll.toInt()}° • ${"%.1f".format(zoom)}×",
                    style = MaterialTheme.typography.bodySmall
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton({ setView(0f, 0f) }, Modifier.weight(1f)) { Text("Front") }
                    OutlinedButton({ setView(180f, 0f) }, Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton({ setView(-90f, 0f) }, Modifier.weight(1f)) { Text("Left") }
                    OutlinedButton({ setView(90f, 0f) }, Modifier.weight(1f)) { Text("Right") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton({ setView(0f, -90f) }, Modifier.weight(1f)) { Text("Top") }
                    OutlinedButton({ setView(0f, 90f) }, Modifier.weight(1f)) { Text("Bottom") }
                    OutlinedButton({ showFineControls = !showFineControls }, Modifier.weight(1f)) {
                        Text(if (showFineControls) "Hide sliders" else "Sliders")
                    }
                }

                if (showFineControls) {
                    Text("Yaw", style = MaterialTheme.typography.bodySmall)
                    Slider(yaw, { yaw = it }, valueRange = -180f..180f)
                    Text("Pitch", style = MaterialTheme.typography.bodySmall)
                    Slider(pitch, { pitch = it }, valueRange = -180f..180f)
                    Text("Roll", style = MaterialTheme.typography.bodySmall)
                    Slider(roll, { roll = it }, valueRange = -180f..180f)
                    Text("Zoom", style = MaterialTheme.typography.bodySmall)
                    Slider(zoom, { zoom = it }, valueRange = 0.25f..6f)
                }
            }
        }
    }
}

@Composable
private fun PhotoTile(file: File, onDelete: () -> Unit) {
    var bitmap by remember(file.absolutePath, file.lastModified()) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(file.absolutePath, file.lastModified()) {
        bitmap = withContext(Dispatchers.IO) {
            ExifBitmapLoader.decodeScaled(file, 500)
        }
    }

    Box(
        modifier = Modifier
            .width(126.dp)
            .aspectRatio(1f)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
    ) {
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = file.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        IconButton(
            onClick = onDelete,
            modifier = Modifier.align(Alignment.TopEnd).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.72f))
        ) {
            Icon(Icons.Default.Delete, contentDescription = "Delete ${file.name}")
        }
    }
}
