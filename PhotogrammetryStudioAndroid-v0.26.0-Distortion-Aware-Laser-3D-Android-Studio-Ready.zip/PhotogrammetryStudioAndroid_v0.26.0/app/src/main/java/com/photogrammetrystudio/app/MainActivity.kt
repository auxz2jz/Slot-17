package com.photogrammetrystudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.photogrammetrystudio.app.ui.PhotogrammetryStudioApp
import com.photogrammetrystudio.app.ui.theme.PhotogrammetryStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PhotogrammetryStudioTheme {
                val viewModel: MainViewModel = viewModel()
                PhotogrammetryStudioApp(viewModel)
            }
        }
    }
}
