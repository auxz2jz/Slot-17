package com.photogrammetrystudio.app.util

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.photogrammetrystudio.app.model.CameraCalibrationFrameResult
import com.photogrammetrystudio.app.model.CameraCalibrationProfile
import com.photogrammetrystudio.app.model.CameraCalibrationReport
import com.photogrammetrystudio.app.model.PhotoCalibrationTargetPreset
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/**
 * v0.18.0 camera-calibration persistence and active-intrinsics provider.
 *
 * The calibration is global because it describes a physical phone camera/lens configuration,
 * not one scan project. Scan projects may therefore reuse the same validated profile.
 */
object CameraCalibrationManager {
    const val PATTERN_COLUMNS = 9
    const val PATTERN_ROWS = 6
    const val SQUARE_SIZE_MM = 25.0

    data class ScaledIntrinsics(
        val fx: Double,
        val fy: Double,
        val cx: Double,
        val cy: Double,
        val rotatedProfile: Boolean,
        val sourceLabel: String
    )

    data class ScaledDistortion(
        val k1: Double,
        val k2: Double,
        val p1: Double,
        val p2: Double,
        val k3: Double,
        val rotatedProfile: Boolean,
        val tangentialSuppressedForRotation: Boolean
    )

    @Volatile private var appContext: Context? = null
    @Volatile private var cachedProfile: CameraCalibrationProfile? = null

    private fun root(context: Context): File = File(context.filesDir, "camera_calibration").apply { mkdirs() }
    private fun photoDir(context: Context): File = File(root(context), "photos").apply { mkdirs() }
    private fun profileFile(context: Context): File = File(root(context), "active_profile.json")
    private fun reportFile(context: Context): File = File(root(context), "last_report.json")

    fun initialize(context: Context) {
        appContext = context.applicationContext
        cachedProfile = loadProfileInternal(context.applicationContext)
    }

    fun activeProfile(): CameraCalibrationProfile? = cachedProfile

    fun listCalibrationPhotos(): List<File> {
        val context = appContext ?: return emptyList()
        return photoDir(context).listFiles()?.filter { it.isFile }?.sortedBy { it.name }.orEmpty()
    }

    fun importCalibrationPhotos(uris: List<Uri>): Int {
        val context = appContext ?: return 0
        val dir = photoDir(context)
        var copied = 0
        uris.forEachIndexed { index, uri ->
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val ext = when (context.contentResolver.getType(uri)?.lowercase()) {
                        "image/png" -> "png"
                        "image/webp" -> "webp"
                        "image/heic", "image/heif" -> "heic"
                        else -> "jpg"
                    }
                    val out = File(dir, "CAL_${System.currentTimeMillis()}_${index}.$ext")
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                    copied++
                }
            }
        }
        return copied
    }

    fun clearCalibrationPhotos() {
        val context = appContext ?: return
        photoDir(context).listFiles()?.forEach { it.delete() }
    }

    fun saveCalibration(report: CameraCalibrationReport) {
        val context = appContext ?: return
        saveReportInternal(context, report)
        report.profile?.takeIf { it.readyForUse }?.let { profile ->
            profileFile(context).writeText(profileToJson(profile).toString(2))
            cachedProfile = profile
        }
    }

    fun loadLastReport(): CameraCalibrationReport? {
        val context = appContext ?: return null
        val file = reportFile(context)
        if (!file.exists()) return null
        return runCatching { reportFromJson(JSONObject(file.readText())) }.getOrNull()
    }

    fun clearActiveProfile() {
        val context = appContext ?: return
        profileFile(context).delete()
        cachedProfile = null
    }

    /**
     * Returns calibrated intrinsics scaled to the working bitmap size. If the bitmap orientation is
     * swapped relative to the calibration profile, fx/fy are swapped and the principal point is
     * conservatively centered; v0.18 reports this as a rotated-profile approximation.
     */
    fun intrinsicsFor(width: Int, height: Int): ScaledIntrinsics? {
        val p = cachedProfile?.takeIf { it.readyForUse } ?: return null
        if (width <= 0 || height <= 0 || p.imageWidth <= 0 || p.imageHeight <= 0) return null
        val sourceAspect = p.imageWidth.toDouble() / p.imageHeight.toDouble()
        val targetAspect = width.toDouble() / height.toDouble()
        val same = abs(sourceAspect - targetAspect) / sourceAspect < 0.035
        val swappedAspect = 1.0 / sourceAspect
        val swapped = abs(swappedAspect - targetAspect) / swappedAspect < 0.035
        return when {
            same -> {
                val sx = width.toDouble() / p.imageWidth
                val sy = height.toDouble() / p.imageHeight
                ScaledIntrinsics(
                    fx = p.fx * sx,
                    fy = p.fy * sy,
                    cx = p.cx * sx,
                    cy = p.cy * sy,
                    rotatedProfile = false,
                    sourceLabel = "Calibrated ${p.label} (RMS ${"%.3f".format(p.rmsReprojectionError)} px)"
                )
            }
            swapped -> {
                val sx = width.toDouble() / p.imageHeight
                val sy = height.toDouble() / p.imageWidth
                ScaledIntrinsics(
                    fx = p.fy * sx,
                    fy = p.fx * sy,
                    cx = width / 2.0,
                    cy = height / 2.0,
                    rotatedProfile = true,
                    sourceLabel = "Calibrated ${p.label} rotated (RMS ${"%.3f".format(p.rmsReprojectionError)} px)"
                )
            }
            else -> null
        }
    }

    fun focalEstimate(width: Int, height: Int): Pair<Double, String>? = intrinsicsFor(width, height)?.let {
        ((it.fx + it.fy) / 2.0) to it.sourceLabel
    }

    /**
     * Returns the saved Brown-Conrady distortion coefficients for a compatible working image.
     * Radial coefficients are invariant to a 90-degree image rotation. For the rotated-profile
     * compatibility path we intentionally suppress p1/p2 because width/height alone cannot tell
     * whether the normalized image arrived through a clockwise or counter-clockwise EXIF rotation.
     * A same-orientation calibration therefore gets the full measured model; a rotated use still
     * gains the measured radial correction without applying a potentially wrong tangential sign.
     */
    fun distortionFor(width: Int, height: Int): ScaledDistortion? {
        val p = cachedProfile?.takeIf { it.readyForUse } ?: return null
        val intr = intrinsicsFor(width, height) ?: return null
        return if (!intr.rotatedProfile) {
            ScaledDistortion(p.k1, p.k2, p.p1, p.p2, p.k3, false, false)
        } else {
            ScaledDistortion(p.k1, p.k2, 0.0, 0.0, p.k3, true, true)
        }
    }

    fun hasUsableDistortion(width: Int, height: Int): Boolean = distortionFor(width, height) != null

    fun printableTargetPdfBytes(): ByteArray {
        // US Letter landscape: 11 x 8.5 in at 72 points/inch.
        val pageWidth = 792
        val pageHeight = 612
        val mmToPoints = 72.0 / 25.4
        val square = (SQUARE_SIZE_MM * mmToPoints).toFloat()
        val squaresAcross = PATTERN_COLUMNS + 1
        val squaresDown = PATTERN_ROWS + 1
        val boardWidth = square * squaresAcross
        val boardHeight = square * squaresDown
        val left = (pageWidth - boardWidth) / 2f
        val top = 34f

        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create())
        val canvas = page.canvas
        canvas.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.style = Paint.Style.FILL
        for (row in 0 until squaresDown) {
            for (col in 0 until squaresAcross) {
                if ((row + col) % 2 == 0) {
                    paint.color = Color.BLACK
                    val x0 = left + col * square
                    val y0 = top + row * square
                    canvas.drawRect(RectF(x0, y0, x0 + square, y0 + square), paint)
                }
            }
        }
        paint.color = Color.BLACK
        paint.textSize = 12f
        canvas.drawText("3D Scan Studio camera calibration target — 9 × 6 inner corners, 25 mm squares", 42f, pageHeight - 52f, paint)
        paint.textSize = 10f
        canvas.drawText("Print at 100% / Actual Size. Do not Fit to Page. Mount flat on rigid board.", 42f, pageHeight - 34f, paint)
        pdf.finishPage(page)
        return ByteArrayOutputStream().use { out ->
            pdf.writeTo(out)
            pdf.close()
            out.toByteArray()
        }
    }

    private fun loadProfileInternal(context: Context): CameraCalibrationProfile? {
        val file = profileFile(context)
        if (!file.exists()) return null
        return runCatching { profileFromJson(JSONObject(file.readText())) }.getOrNull()
    }

    private fun saveReportInternal(context: Context, report: CameraCalibrationReport) {
        val json = JSONObject()
            .put("totalImages", report.totalImages)
            .put("acceptedImages", report.acceptedImages)
            .put("rejectedImages", report.rejectedImages)
            .put("warnings", JSONArray(report.warnings))
            .put("profile", report.profile?.let(::profileToJson))
        val frames = JSONArray()
        report.frames.forEach { frame ->
            frames.put(JSONObject()
                .put("fileName", frame.fileName)
                .put("detected", frame.detected)
                .put("width", frame.width)
                .put("height", frame.height)
                .put("reason", frame.reason))
        }
        json.put("frames", frames)
        reportFile(context).writeText(json.toString(2))
    }

    private fun reportFromJson(json: JSONObject): CameraCalibrationReport {
        val framesJson = json.optJSONArray("frames") ?: JSONArray()
        val frames = buildList {
            for (i in 0 until framesJson.length()) {
                val f = framesJson.getJSONObject(i)
                add(CameraCalibrationFrameResult(
                    fileName = f.optString("fileName"),
                    detected = f.optBoolean("detected"),
                    width = f.optInt("width"),
                    height = f.optInt("height"),
                    reason = f.optString("reason")
                ))
            }
        }
        val warningsJson = json.optJSONArray("warnings") ?: JSONArray()
        val warnings = buildList { for (i in 0 until warningsJson.length()) add(warningsJson.getString(i)) }
        val profileJson = json.optJSONObject("profile")
        return CameraCalibrationReport(
            totalImages = json.optInt("totalImages"),
            acceptedImages = json.optInt("acceptedImages"),
            rejectedImages = json.optInt("rejectedImages"),
            frames = frames,
            profile = profileJson?.let(::profileFromJson),
            warnings = warnings
        )
    }

    private fun profileToJson(p: CameraCalibrationProfile): JSONObject = JSONObject()
        .put("id", p.id)
        .put("label", p.label)
        .put("deviceModel", p.deviceModel)
        .put("imageWidth", p.imageWidth)
        .put("imageHeight", p.imageHeight)
        .put("patternColumns", p.patternColumns)
        .put("patternRows", p.patternRows)
        .put("squareSizeMm", p.squareSizeMm)
        .put("acceptedImages", p.acceptedImages)
        .put("rejectedImages", p.rejectedImages)
        .put("rmsReprojectionError", p.rmsReprojectionError)
        .put("fx", p.fx).put("fy", p.fy).put("cx", p.cx).put("cy", p.cy)
        .put("k1", p.k1).put("k2", p.k2).put("p1", p.p1).put("p2", p.p2).put("k3", p.k3)
        .put("targetPresetId", p.targetPresetId)
        .put("createdAt", p.createdAt)
        .put("readyForUse", p.readyForUse)

    private fun profileFromJson(json: JSONObject): CameraCalibrationProfile = CameraCalibrationProfile(
        id = json.optString("id"),
        label = json.optString("label", "Main 1×"),
        deviceModel = json.optString("deviceModel"),
        imageWidth = json.optInt("imageWidth"),
        imageHeight = json.optInt("imageHeight"),
        patternColumns = json.optInt("patternColumns", PATTERN_COLUMNS),
        patternRows = json.optInt("patternRows", PATTERN_ROWS),
        squareSizeMm = json.optDouble("squareSizeMm", SQUARE_SIZE_MM),
        acceptedImages = json.optInt("acceptedImages"),
        rejectedImages = json.optInt("rejectedImages"),
        rmsReprojectionError = json.optDouble("rmsReprojectionError"),
        fx = json.optDouble("fx"), fy = json.optDouble("fy"),
        cx = json.optDouble("cx"), cy = json.optDouble("cy"),
        k1 = json.optDouble("k1"), k2 = json.optDouble("k2"),
        p1 = json.optDouble("p1"), p2 = json.optDouble("p2"), k3 = json.optDouble("k3"),
        targetPresetId = json.optString("targetPresetId", PhotoCalibrationTargetPreset.US_LETTER.id),
        createdAt = json.optLong("createdAt"),
        readyForUse = json.optBoolean("readyForUse")
    )
}
