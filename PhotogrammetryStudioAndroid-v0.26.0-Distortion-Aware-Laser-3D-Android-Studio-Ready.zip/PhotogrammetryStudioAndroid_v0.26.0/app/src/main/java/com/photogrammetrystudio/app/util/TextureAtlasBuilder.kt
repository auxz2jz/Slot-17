package com.photogrammetrystudio.app.util

import android.graphics.Bitmap
import android.graphics.Color
import com.photogrammetrystudio.app.model.FaceAtlasUv
import com.photogrammetrystudio.app.model.FaceTextureAssignment
import com.photogrammetrystudio.app.model.MeshTriangle
import com.photogrammetrystudio.app.model.SurfaceMeshReport
import com.photogrammetrystudio.app.model.TextureAtlasReport
import com.photogrammetrystudio.app.model.TextureSourceAssignmentReport
import java.io.File
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * v0.17.0 Stage 10 — connected UV-island texture atlas with exposure normalization.
 *
 * v0.14 proved that OBJ/MTL/PNG UV mapping works by giving every assigned triangle its own tile.
 * v0.15 groups edge-connected triangles that use the same Stage 9 source photo into a shared UV
 * island. v0.16 keeps that layout and adds a conservative per-photo luminance gain before atlas
 * copying so exposure changes between source photos create less visible brightness stepping.
 */
object TextureAtlasBuilder {

    data class BuildResult(
        val report: TextureAtlasReport,
        val bitmap: Bitmap
    )

    private data class Island(
        val photo: String,
        val assignments: List<FaceTextureAssignment>,
        val minU: Double,
        val minV: Double,
        val maxU: Double,
        val maxV: Double,
        val desiredWidth: Int,
        val desiredHeight: Int
    )

    private data class PackedIsland(
        val island: Island,
        val left: Int,
        val top: Int,
        val width: Int,
        val height: Int,
        val padding: Int
    ) {
        val innerLeft: Int get() = left + padding
        val innerTop: Int get() = top + padding
        val innerWidth: Int get() = (width - padding * 2).coerceAtLeast(2)
        val innerHeight: Int get() = (height - padding * 2).coerceAtLeast(2)
    }

    private data class Packing(val atlasSize: Int, val islands: List<PackedIsland>)

    fun build(
        photos: List<File>,
        mesh: SurfaceMeshReport,
        sources: TextureSourceAssignmentReport,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<BuildResult> = runCatching {
        require(mesh.readyForExport && mesh.vertices.isNotEmpty() && mesh.faces.isNotEmpty()) {
            "Stage 10 needs a valid saved Stage 7 surface mesh."
        }
        require(sources.assignments.isNotEmpty()) {
            "Stage 10 needs at least one Stage 9 triangle source assignment."
        }

        val validAssignments = sources.assignments
            .filter { it.faceIndex in mesh.faces.indices && assignmentUvsFinite(it) }
            .sortedBy { it.faceIndex }
        require(validAssignments.isNotEmpty()) { "No valid Stage 9 face assignments match the saved Stage 7 mesh." }

        onProgress(0.03f, "Stage 10 — grouping adjacent textured triangles into UV islands…")
        val islands = buildIslands(mesh.faces, validAssignments)
        require(islands.isNotEmpty()) { "No UV islands could be built from the Stage 9 assignments." }

        onProgress(0.08f, "Stage 10 — packing ${islands.size} UV island(s)…")
        val packing = packIslands(islands)
        val atlasSize = packing.atlasSize
        val atlasPixels = IntArray(atlasSize * atlasSize) { Color.rgb(96, 96, 96) }
        val photoByName = photos.associateBy { it.name }
        val faceUvs = ArrayList<FaceAtlasUv>(validAssignments.size)
        val renderedFaceIndices = linkedSetOf<Int>()
        val usedPhotos = linkedSetOf<String>()

        var missingPhotoFaces = 0
        var rasterSkipped = 0
        var renderedIslands = 0
        var usedPixelArea = 0L

        val groupedByPhoto = packing.islands.groupBy { it.island.photo }
        onProgress(0.10f, "Stage 10 — estimating source-photo exposure for seam normalization…")
        val photoLuma = groupedByPhoto.keys.mapNotNull { name ->
            val file = photoByName[name] ?: return@mapNotNull null
            estimateMeanLuma(file)?.let { name to it }
        }.toMap()
        val sortedLuma = photoLuma.values.sorted()
        val targetLuma = if (sortedLuma.isEmpty()) 128.0 else sortedLuma[sortedLuma.size / 2]
        val gainByPhoto = photoLuma.mapValues { (_, value) ->
            (targetLuma / value.coerceAtLeast(1.0)).coerceIn(0.82, 1.22)
        }
        val normalizedPhotos = gainByPhoto.values.count { kotlin.math.abs(it - 1.0) >= 0.03 }
        var photoOrdinal = 0
        groupedByPhoto.forEach photoLoop@{ (photoName, photoIslands) ->
            photoOrdinal++
            val fraction = photoOrdinal.toFloat() / groupedByPhoto.size.coerceAtLeast(1).toFloat()
            onProgress(0.12f + 0.78f * fraction, "Stage 10 — copying photo island $photoOrdinal/${groupedByPhoto.size}: $photoName")
            val file = photoByName[photoName]
            val bitmap = file?.let { ExifBitmapLoader.decodeScaled(it, 2200) }
            if (bitmap == null) {
                missingPhotoFaces += photoIslands.sumOf { it.island.assignments.size }
                return@photoLoop
            }
            val sourcePixels = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(sourcePixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

            photoIslands.forEach islandLoop@{ packed ->
                val island = packed.island
                if (!copySourceRectToIsland(
                        packed, sourcePixels, bitmap.width, bitmap.height, atlasPixels, atlasSize,
                        gainByPhoto[photoName] ?: 1.0
                    )) {
                    rasterSkipped += island.assignments.size
                    return@islandLoop
                }
                renderedIslands++
                usedPixelArea += packed.innerWidth.toLong() * packed.innerHeight.toLong()
                island.assignments.forEach { a ->
                    val mapped = mapAssignmentToAtlas(a, packed, atlasSize)
                    if (mapped != null) {
                        faceUvs += mapped
                        renderedFaceIndices += a.faceIndex
                    } else rasterSkipped++
                }
                usedPhotos += photoName
            }
            bitmap.recycle()
        }

        val finalUvs = faceUvs.distinctBy { it.faceIndex }.sortedBy { it.faceIndex }
        val effectiveTextured = finalUvs.size
        val atlas = Bitmap.createBitmap(atlasSize, atlasSize, Bitmap.Config.ARGB_8888)
        atlas.setPixels(atlasPixels, 0, atlasSize, 0, 0, atlasSize, atlasSize)

        val coverage = effectiveTextured * 100.0 / mesh.faces.size.toDouble()
        val occupancy = usedPixelArea * 100.0 / (atlasSize.toLong() * atlasSize.toLong()).toDouble()
        val largestIslandFaces = packing.islands.maxOfOrNull { it.island.assignments.size } ?: 0
        val warnings = mutableListOf<String>()
        warnings += "v0.17.0 keeps connected same-photo UV islands and applies conservative per-photo luminance normalization before atlas copying."
        warnings += "Exposure normalization adjusted $normalizedPhotos/${groupedByPhoto.size} source photo(s) by at least 3%, with gain clamped to 0.82..1.22 to avoid large color/exposure distortions."
        warnings += "The atlas is not supposed to look like the assembled object; the OBJ UV coordinates place each island on the 3D surface. The in-app textured preview is the preferred visual check."
        warnings += "Only Stage 9-assigned faces receive photo texture; unassigned faces stay gray rather than receiving invented image content."
        if (missingPhotoFaces > 0) warnings += "$missingPhotoFaces assigned triangle(s) were skipped because their source photo could not be decoded."
        if (rasterSkipped > 0) warnings += "$rasterSkipped assigned triangle mapping(s) were skipped because the source/atlas coordinates were unsafe."
        if (coverage < 25.0) warnings += "Only ${"%.1f".format(coverage)}% of mesh faces are textured. The model remains valid, but large gray/untextured regions are expected."

        val report = TextureAtlasReport(
            engine = "Connected UV-island atlas + exposure normalization v0.17.0",
            atlasWidth = atlasSize,
            atlasHeight = atlasSize,
            tileSize = 0,
            padding = 4,
            sourceMeshVertices = mesh.vertices.size,
            sourceMeshFaces = mesh.faces.size,
            stage9AssignedFaces = sources.assignedFaces,
            texturedFaces = effectiveTextured,
            untexturedFaces = (mesh.faces.size - effectiveTextured).coerceAtLeast(0),
            textureCoveragePercent = coverage,
            sourcePhotosUsed = usedPhotos.size,
            skippedMissingPhotos = missingPhotoFaces,
            skippedRasterizationFaces = rasterSkipped,
            faceUvs = finalUvs,
            warnings = warnings,
            readyForExport = effectiveTextured > 0,
            uvIslands = renderedIslands,
            largestIslandFaces = largestIslandFaces,
            atlasOccupancyPercent = occupancy
        )
        onProgress(1f, "Stage 10 connected UV-island atlas complete")
        BuildResult(report, atlas)
    }

    private fun buildIslands(faces: List<MeshTriangle>, assignments: List<FaceTextureAssignment>): List<Island> {
        val byFace = assignments.associateBy { it.faceIndex }
        val neighbors = HashMap<Int, MutableSet<Int>>()
        assignments.forEach { neighbors[it.faceIndex] = linkedSetOf() }
        val edges = HashMap<Long, MutableList<Int>>()
        assignments.forEach { a ->
            val f = faces[a.faceIndex]
            listOf(f.a to f.b, f.b to f.c, f.c to f.a).forEach { (x, y) ->
                edges.getOrPut(edgeKey(x, y)) { arrayListOf() }.add(a.faceIndex)
            }
        }
        edges.values.forEach { owners ->
            if (owners.size < 2) return@forEach
            for (i in 0 until owners.lastIndex) for (j in i + 1 until owners.size) {
                val a = byFace[owners[i]] ?: continue
                val b = byFace[owners[j]] ?: continue
                if (a.photo == b.photo) {
                    neighbors.getValue(a.faceIndex).add(b.faceIndex)
                    neighbors.getValue(b.faceIndex).add(a.faceIndex)
                }
            }
        }

        val visited = hashSetOf<Int>()
        val result = arrayListOf<Island>()
        assignments.forEach { seed ->
            if (!visited.add(seed.faceIndex)) return@forEach
            val queue = ArrayDeque<Int>()
            queue.add(seed.faceIndex)
            val component = arrayListOf<FaceTextureAssignment>()
            while (queue.isNotEmpty()) {
                val faceIndex = queue.removeFirst()
                val item = byFace[faceIndex] ?: continue
                component += item
                neighbors[faceIndex].orEmpty().forEach { n ->
                    if (visited.add(n)) queue.add(n)
                }
            }
            val allU = component.flatMap { listOf(it.u0, it.u1, it.u2) }
            val allV = component.flatMap { listOf(it.v0, it.v1, it.v2) }
            var minU = allU.minOrNull() ?: 0.0
            var maxU = allU.maxOrNull() ?: 1.0
            var minV = allV.minOrNull() ?: 0.0
            var maxV = allV.maxOrNull() ?: 1.0
            val padU = max(0.002, (maxU - minU) * 0.03)
            val padV = max(0.002, (maxV - minV) * 0.03)
            minU = (minU - padU).coerceIn(0.0, 1.0); maxU = (maxU + padU).coerceIn(0.0, 1.0)
            minV = (minV - padV).coerceIn(0.0, 1.0); maxV = (maxV + padV).coerceIn(0.0, 1.0)
            val bw = (maxU - minU).coerceAtLeast(1e-4)
            val bh = (maxV - minV).coerceAtLeast(1e-4)
            val aspect = (bw / bh).coerceIn(0.20, 5.0)
            val targetArea = (component.size * 500.0).coerceIn(28.0 * 28.0, 620.0 * 620.0)
            val innerW = sqrt(targetArea * aspect).roundToInt().coerceIn(24, 720)
            val innerH = sqrt(targetArea / aspect).roundToInt().coerceIn(24, 720)
            result += Island(seed.photo, component.sortedBy { it.faceIndex }, minU, minV, maxU, maxV, innerW + 8, innerH + 8)
        }
        return result.sortedWith(compareByDescending<Island> { it.desiredHeight }.thenByDescending { it.desiredWidth })
    }

    private fun packIslands(islands: List<Island>): Packing {
        val preferred = if (islands.sumOf { it.desiredWidth.toLong() * it.desiredHeight.toLong() } < 2_300_000L) 2048 else 4096
        val sizes = if (preferred == 2048) listOf(2048, 4096) else listOf(4096)
        for (atlas in sizes) {
            var scale = 1.0
            while (scale >= 0.28) {
                val packed = tryPack(islands, atlas, scale)
                if (packed != null) return Packing(atlas, packed)
                scale *= 0.90
            }
        }
        error("UV islands could not fit in a 4096×4096 atlas safely.")
    }

    private fun tryPack(islands: List<Island>, atlasSize: Int, scale: Double): List<PackedIsland>? {
        val gap = 4
        var x = gap
        var y = gap
        var rowHeight = 0
        val packed = arrayListOf<PackedIsland>()
        islands.forEach { island ->
            val w = (island.desiredWidth * scale).roundToInt().coerceAtLeast(14).coerceAtMost(atlasSize - gap * 2)
            val h = (island.desiredHeight * scale).roundToInt().coerceAtLeast(14).coerceAtMost(atlasSize - gap * 2)
            if (x + w + gap > atlasSize) {
                x = gap
                y += rowHeight + gap
                rowHeight = 0
            }
            if (y + h + gap > atlasSize) return null
            val pad = min(4, min(w, h) / 5).coerceAtLeast(1)
            packed += PackedIsland(island, x, y, w, h, pad)
            x += w + gap
            rowHeight = max(rowHeight, h)
        }
        return packed
    }

    private fun copySourceRectToIsland(
        packed: PackedIsland,
        source: IntArray,
        sourceWidth: Int,
        sourceHeight: Int,
        atlas: IntArray,
        atlasWidth: Int,
        exposureGain: Double
    ): Boolean {
        val island = packed.island
        val du = island.maxU - island.minU
        val dv = island.maxV - island.minV
        if (!du.isFinite() || !dv.isFinite() || du <= 1e-8 || dv <= 1e-8) return false
        for (dy in 0 until packed.innerHeight) {
            val v = island.minV + dv * dy.toDouble() / (packed.innerHeight - 1).coerceAtLeast(1).toDouble()
            val ay = packed.innerTop + dy
            for (dx in 0 until packed.innerWidth) {
                val u = island.minU + du * dx.toDouble() / (packed.innerWidth - 1).coerceAtLeast(1).toDouble()
                atlas[ay * atlasWidth + packed.innerLeft + dx] = applyExposureGain(
                    sample(source, sourceWidth, sourceHeight, u, v), exposureGain
                )
            }
        }
        // Extend the island edge colors into the padding to reduce bilinear seam bleed.
        for (p in 1..packed.padding) {
            val topY = packed.innerTop - p
            val bottomY = packed.innerTop + packed.innerHeight - 1 + p
            for (dx in 0 until packed.innerWidth) {
                val x = packed.innerLeft + dx
                if (topY >= 0) atlas[topY * atlasWidth + x] = atlas[packed.innerTop * atlasWidth + x]
                if (bottomY < atlasWidth) atlas[bottomY * atlasWidth + x] = atlas[(packed.innerTop + packed.innerHeight - 1) * atlasWidth + x]
            }
            val leftX = packed.innerLeft - p
            val rightX = packed.innerLeft + packed.innerWidth - 1 + p
            for (dy in -packed.padding until packed.innerHeight + packed.padding) {
                val y = (packed.innerTop + dy).coerceIn(0, atlasWidth - 1)
                if (leftX >= 0) atlas[y * atlasWidth + leftX] = atlas[y * atlasWidth + packed.innerLeft]
                if (rightX < atlasWidth) atlas[y * atlasWidth + rightX] = atlas[y * atlasWidth + packed.innerLeft + packed.innerWidth - 1]
            }
        }
        return true
    }

    private fun mapAssignmentToAtlas(a: FaceTextureAssignment, packed: PackedIsland, atlasSize: Int): FaceAtlasUv? {
        val island = packed.island
        val du = island.maxU - island.minU
        val dv = island.maxV - island.minV
        if (du <= 1e-8 || dv <= 1e-8) return null
        fun map(u: Double, v: Double): Pair<Double, Double>? {
            if (!u.isFinite() || !v.isFinite()) return null
            val nx = ((u - island.minU) / du).coerceIn(0.0, 1.0)
            val ny = ((v - island.minV) / dv).coerceIn(0.0, 1.0)
            val x = packed.innerLeft + nx * (packed.innerWidth - 1)
            val y = packed.innerTop + ny * (packed.innerHeight - 1)
            return x / (atlasSize - 1).toDouble() to (1.0 - y / (atlasSize - 1).toDouble())
        }
        val p0 = map(a.u0, a.v0) ?: return null
        val p1 = map(a.u1, a.v1) ?: return null
        val p2 = map(a.u2, a.v2) ?: return null
        return FaceAtlasUv(a.faceIndex, p0.first, p0.second, p1.first, p1.second, p2.first, p2.second)
    }


    private fun estimateMeanLuma(file: File): Double? {
        val bitmap = ExifBitmapLoader.decodeScaled(file, 320) ?: return null
        return try {
            val step = max(1, min(bitmap.width, bitmap.height) / 80)
            var sum = 0.0
            var count = 0
            var y = 0
            while (y < bitmap.height) {
                var x = 0
                while (x < bitmap.width) {
                    val c = bitmap.getPixel(x, y)
                    val luma = 0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)
                    // Skip nearly clipped pixels so white/black background regions do not dominate.
                    if (luma in 8.0..247.0) {
                        sum += luma
                        count++
                    }
                    x += step
                }
                y += step
            }
            if (count >= 16) sum / count else null
        } finally {
            bitmap.recycle()
        }
    }

    private fun applyExposureGain(color: Int, gain: Double): Int = Color.rgb(
        (Color.red(color) * gain).roundToInt().coerceIn(0, 255),
        (Color.green(color) * gain).roundToInt().coerceIn(0, 255),
        (Color.blue(color) * gain).roundToInt().coerceIn(0, 255)
    )

    private fun assignmentUvsFinite(a: FaceTextureAssignment): Boolean =
        listOf(a.u0, a.v0, a.u1, a.v1, a.u2, a.v2).all { it.isFinite() && it in 0.0..1.0 }

    private fun edgeKey(a: Int, b: Int): Long {
        val lo = min(a, b)
        val hi = max(a, b)
        return (lo.toLong() shl 32) xor (hi.toLong() and 0xffffffffL)
    }

    private fun sample(pixels: IntArray, width: Int, height: Int, u: Double, v: Double): Int {
        val x = (u.coerceIn(0.0, 1.0) * (width - 1)).roundToInt().coerceIn(0, width - 1)
        val y = (v.coerceIn(0.0, 1.0) * (height - 1)).roundToInt().coerceIn(0, height - 1)
        return pixels[y * width + x]
    }
}
