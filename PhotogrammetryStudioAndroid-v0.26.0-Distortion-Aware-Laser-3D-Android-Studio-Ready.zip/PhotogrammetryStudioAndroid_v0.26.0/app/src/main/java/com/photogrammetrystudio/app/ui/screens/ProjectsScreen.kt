package com.photogrammetrystudio.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.photogrammetrystudio.app.model.PhotoProject
import com.photogrammetrystudio.app.model.ScanMode
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    projects: List<PhotoProject>,
    onProjectClick: (PhotoProject) -> Unit,
    onCreateProject: (String, ScanMode) -> Unit,
    onDeleteProject: (PhotoProject) -> Unit,
    onOpenCalibration: () -> Unit,
    onOpenTestGuide: () -> Unit
) {
    var showNewProject by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    var scanMode by remember { mutableStateOf(ScanMode.PHOTOGRAMMETRY) }
    var projectPendingDelete by remember { mutableStateOf<PhotoProject?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("3D Scan Studio") },
                actions = {
                    IconButton(onClick = onOpenCalibration) {
                        Icon(Icons.Default.Tune, contentDescription = "Camera calibration")
                    }
                    IconButton(onClick = onOpenTestGuide) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "Test this version")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewProject = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New scan") }
            )
        }
    ) { padding ->
        if (projects.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding).padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Create a scan project and choose Photo Scan, Laser Scan, or Hybrid Scan.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Photo Scan is working now. Laser and Hybrid projects establish the structure for the next hardware and reconstruction stages.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(projects, key = { it.id }) { project ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onProjectClick(project) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text(project.scanMode.displayName, style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(8.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${project.photos.size} photos")
                                    Text(DateFormat.getDateInstance().format(Date(project.createdAt)))
                                }
                            }
                            IconButton(onClick = { projectPendingDelete = project }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete ${project.name}")
                            }
                        }
                    }
                }
            }
        }
    }

    projectPendingDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { projectPendingDelete = null },
            title = { Text("Delete project?") },
            text = {
                Text("Delete '${project.name}' and all photos, reports, and future model files stored inside it? This cannot be undone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteProject(project)
                    projectPendingDelete = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { projectPendingDelete = null }) { Text("Cancel") }
            }
        )
    }

    if (showNewProject) {
        AlertDialog(
            onDismissRequest = { showNewProject = false },
            title = { Text("New 3D scan project") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Project name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Scan mode", fontWeight = FontWeight.SemiBold)
                    ScanMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { scanMode = mode }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = scanMode == mode,
                                onClick = { scanMode = mode }
                            )
                            Column(Modifier.padding(start = 6.dp)) {
                                Text(mode.displayName, fontWeight = FontWeight.SemiBold)
                                Text(mode.description, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onCreateProject(projectName, scanMode)
                    projectName = ""
                    scanMode = ScanMode.PHOTOGRAMMETRY
                    showNewProject = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewProject = false }) { Text("Cancel") } }
        )
    }
}
