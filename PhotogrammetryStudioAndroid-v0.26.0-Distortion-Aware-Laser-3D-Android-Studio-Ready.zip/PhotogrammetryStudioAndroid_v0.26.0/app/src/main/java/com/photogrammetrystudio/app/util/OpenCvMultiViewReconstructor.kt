package com.photogrammetrystudio.app.util

import androidx.exifinterface.media.ExifInterface
import com.photogrammetrystudio.app.model.CameraPoseSummary
import com.photogrammetrystudio.app.model.MultiViewPairEvaluation
import com.photogrammetrystudio.app.model.MultiViewReconstructionReport
import com.photogrammetrystudio.app.model.SparsePoint
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * v0.5 milestone:
 * - chain adjacent relative camera poses into one arbitrary-scale coordinate system
 * - triangulate every successfully connected adjacent pair
 * - merge/downsample the resulting sparse points
 *
 * This is intentionally pre-bundle-adjustment. Each adjacent translation recovered by
 * recoverPose has unit length, so the path has arbitrary scale and can drift.
 */
object OpenCvMultiViewReconstructor {
    private const val MAX_IMAGE_SIDE = 1600
    private const val MAX_FEATURES = 2500
    private const val RATIO_TEST = 0.75f
    private const val RANSAC_THRESHOLD_PX = 1.5
    private const val MIN_RATIO_MATCHES = 12
    private const val MIN_POSE_INLIERS = 20
    private const val VOXEL_SIZE = 0.025

    @Volatile
    private var initialized: Boolean? = null

    private fun ensureOpenCv(): Boolean {
        initialized?.let { return it }
        return synchronized(this) {
            initialized ?: OpenCVLoader.initLocal().also { initialized = it }
        }
    }

    private data class Features(
        val file: File,
        val keypoints: Array<org.opencv.core.KeyPoint>,
        val descriptors: Mat,
        val width: Int,
        val height: Int,
        val focalPixels: Double,
        val intrinsicsSource: String
    )

    private data class Pose(
        val r: DoubleArray,
        val t: DoubleArray
    )

    private data class PairGeometry(
        val firstIndex: Int,
        val secondIndex: Int,
        val ratioMatches: Int,
        val ransacInliers: Int,
        val poseInliers: Int,
        val localPoints: List<SparsePoint>,
        val relR: DoubleArray?,
        val relT: DoubleArray?,
        val relativeRotationDegrees: Double
    ) {
        val usable: Boolean
            get() = poseInliers >= MIN_POSE_INLIERS && localPoints.isNotEmpty() && relR != null && relT != null
    }

    fun reconstruct(
        files: List<File>,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<MultiViewReconstructionReport> = runCatching {
        require(files.size >= 3) { "Take or import at least 3 photos before multi-view reconstruction." }
        check(ensureOpenCv()) { "OpenCV could not initialize on this device." }

        val orb = ORB.create(MAX_FEATURES)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        val featureSets = mutableListOf<Features>()
        val warnings = mutableListOf<String>()

        try {
            files.forEachIndexed { index, file ->
                onProgress(
                    (index.toFloat() / files.size.coerceAtLeast(1)) * 0.30f,
                    "Preparing multi-view features ${index + 1}/${files.size}"
                )
                val bitmap = decodeScaled(file)
                if (bitmap == null) {
                    warnings += "Could not decode ${file.name}."
                    return@forEachIndexed
                }

                val rgba = Mat()
                val gray = Mat()
                val keypointMat = MatOfKeyPoint()
                val descriptors = Mat()
                try {
                    Utils.bitmapToMat(bitmap, rgba)
                    Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                    orb.detectAndCompute(gray, Mat(), keypointMat, descriptors)
                    val focal = estimateFocalPixels(file, bitmap.width, bitmap.height)
                    featureSets += Features(
                        file = file,
                        keypoints = keypointMat.toArray(),
                        descriptors = descriptors,
                        width = bitmap.width,
                        height = bitmap.height,
                        focalPixels = focal.first,
                        intrinsicsSource = focal.second
                    )
                } finally {
                    bitmap.recycle()
                    rgba.release()
                    gray.release()
                    keypointMat.release()
                }
            }

            require(featureSets.size >= 3) { "Fewer than 3 photos could be decoded for multi-view reconstruction." }

            // First evaluate EVERY adjacent pair. v0.5.0 stopped permanently at the first weak pair,
            // which meant one early gap could hide a long strong sequence later in the project.
            val geometries = mutableListOf<PairGeometry>()
            val pairCount = featureSets.size - 1

            for (i in 0 until pairCount) {
                val a = featureSets[i]
                val b = featureSets[i + 1]
                onProgress(
                    0.30f + (i.toFloat() / pairCount.coerceAtLeast(1)) * 0.45f,
                    "Checking camera link ${i + 1} → ${i + 2}"
                )

                val ratioMatches = mutableListOf<org.opencv.core.DMatch>()
                if (!a.descriptors.empty() && !b.descriptors.empty()) {
                    val knn = mutableListOf<MatOfDMatch>()
                    matcher.knnMatch(a.descriptors, b.descriptors, knn, 2)
                    knn.forEach { set ->
                        val matches = set.toArray()
                        if (matches.size >= 2 && matches[0].distance < RATIO_TEST * matches[1].distance) {
                            ratioMatches += matches[0]
                        }
                        set.release()
                    }
                }

                if (ratioMatches.size < MIN_RATIO_MATCHES) {
                    geometries += PairGeometry(i, i + 1, ratioMatches.size, 0, 0, emptyList(), null, null, 0.0)
                    continue
                }

                val p1Array = ratioMatches.mapNotNull { match ->
                    a.keypoints.getOrNull(match.queryIdx)?.pt
                }.toTypedArray()
                val p2Array = ratioMatches.mapNotNull { match ->
                    b.keypoints.getOrNull(match.trainIdx)?.pt
                }.toTypedArray()
                val n = min(p1Array.size, p2Array.size)

                if (n < MIN_RATIO_MATCHES) {
                    geometries += PairGeometry(i, i + 1, n, 0, 0, emptyList(), null, null, 0.0)
                    continue
                }

                val points1 = MatOfPoint2f(*p1Array.copyOf(n))
                val points2 = MatOfPoint2f(*p2Array.copyOf(n))
                val mask = Mat()
                val relRMat = Mat()
                val relTMat = Mat()
                val triangulated = Mat()
                val focal = (a.focalPixels + b.focalPixels) / 2.0
                val workingWidth = (a.width + b.width) / 2
                val workingHeight = (a.height + b.height) / 2
                val geometryModel = OpenCvCalibrationGeometry.model(workingWidth, workingHeight, focal)
                val geometryPoints1 = OpenCvCalibrationGeometry.undistortPixelPoints(points1, geometryModel)
                val geometryPoints2 = OpenCvCalibrationGeometry.undistortPixelPoints(points2, geometryModel)

                try {
                    val essential = Calib3d.findEssentialMat(
                        geometryPoints1,
                        geometryPoints2,
                        geometryModel.k,
                        Calib3d.RANSAC,
                        0.999,
                        RANSAC_THRESHOLD_PX,
                        1000,
                        mask
                    )

                    if (essential.empty()) {
                        geometries += PairGeometry(i, i + 1, n, 0, 0, emptyList(), null, null, 0.0)
                        essential.release()
                        continue
                    }

                    val ransacInliers = countMask(mask)
                    val poseInliers = if (ransacInliers >= 5) {
                        Calib3d.recoverPose(
                            essential,
                            geometryPoints1,
                            geometryPoints2,
                            geometryModel.k,
                            relRMat,
                            relTMat,
                            50.0,
                            mask,
                            triangulated
                        )
                    } else 0

                    val relativeRotation = if (!relRMat.empty()) rotationAngleDegrees(relRMat) else 0.0
                    val localPoints = if (poseInliers >= MIN_POSE_INLIERS && !triangulated.empty()) {
                        extractPoints(triangulated, mask)
                    } else emptyList()
                    val relR = if (poseInliers >= MIN_POSE_INLIERS && !relRMat.empty()) mat3(relRMat) else null
                    val relT = if (poseInliers >= MIN_POSE_INLIERS && !relTMat.empty()) vec3(relTMat) else null

                    geometries += PairGeometry(
                        firstIndex = i,
                        secondIndex = i + 1,
                        ratioMatches = n,
                        ransacInliers = ransacInliers,
                        poseInliers = poseInliers,
                        localPoints = localPoints,
                        relR = relR,
                        relT = relT,
                        relativeRotationDegrees = relativeRotation
                    )
                    essential.release()
                } finally {
                    points1.release()
                    points2.release()
                    geometryPoints1.release()
                    geometryPoints2.release()
                    mask.release()
                    relRMat.release()
                    relTMat.release()
                    triangulated.release()
                    geometryModel.close()
                }
            }

            // Select the largest contiguous usable component. This is robust to one weak pair near
            // the beginning/end and is a much better pre-bundle-adjustment behavior than aborting.
            var bestStart = -1
            var bestLength = 0
            var runStart = -1
            var runLength = 0
            geometries.forEachIndexed { index, geometry ->
                if (geometry.usable) {
                    if (runLength == 0) runStart = index
                    runLength++
                    if (runLength > bestLength) {
                        bestLength = runLength
                        bestStart = runStart
                    }
                } else {
                    runStart = -1
                    runLength = 0
                }
            }

            val selectedPairIndices = if (bestStart >= 0 && bestLength > 0) {
                (bestStart until (bestStart + bestLength)).toSet()
            } else emptySet()

            val cameraPoses = arrayOfNulls<Pose>(featureSets.size)
            val allWorldPoints = mutableListOf<SparsePoint>()
            var rawPointCount = 0

            if (selectedPairIndices.isNotEmpty()) {
                val firstCamera = bestStart
                var currentPose = Pose(identity3(), doubleArrayOf(0.0, 0.0, 0.0))
                cameraPoses[firstCamera] = currentPose

                for (pairIndex in bestStart until (bestStart + bestLength)) {
                    val geometry = geometries[pairIndex]
                    onProgress(
                        0.75f + ((pairIndex - bestStart).toFloat() / bestLength.coerceAtLeast(1)) * 0.20f,
                        "Building main camera segment ${pairIndex - bestStart + 1}/$bestLength"
                    )
                    val worldPoints = geometry.localPoints.mapNotNull { point ->
                        cameraToWorld(point, currentPose)
                    }
                    rawPointCount += worldPoints.size
                    allWorldPoints += worldPoints

                    currentPose = composePose(currentPose, geometry.relR!!, geometry.relT!!)
                    cameraPoses[geometry.secondIndex] = currentPose
                }
            }

            val pairEvaluations = geometries.mapIndexed { index, geometry ->
                MultiViewPairEvaluation(
                    firstPhoto = featureSets[geometry.firstIndex].file.name,
                    secondPhoto = featureSets[geometry.secondIndex].file.name,
                    ratioMatches = geometry.ratioMatches,
                    ransacInliers = geometry.ransacInliers,
                    poseInliers = geometry.poseInliers,
                    triangulatedPoints = geometry.localPoints.size,
                    connected = index in selectedPairIndices,
                    relativeRotationDegrees = geometry.relativeRotationDegrees
                )
            }

            val cameraSummaries = featureSets.mapIndexed { index, features ->
                val pose = cameraPoses[index]
                if (pose != null) {
                    cameraSummary(index, features.file.name, pose, connected = true)
                } else {
                    CameraPoseSummary(features.file.name, index, false, 0.0, 0.0, 0.0)
                }
            }

            val connectedCameras = cameraSummaries.count { it.connected }
            val connectedPairs = selectedPairIndices.size
            val combined = voxelDownsample(allWorldPoints, VOXEL_SIZE)

            if (bestStart < 0) {
                warnings += "No adjacent camera pair had enough recovered-pose inliers to form a multi-view component."
            } else {
                val startCamera = bestStart + 1
                val endCamera = bestStart + bestLength + 1
                warnings += "v0.5.1 selected the largest connected camera segment: cameras $startCamera through $endCamera ($connectedCameras cameras)."
            }

            val weakPairs = geometries.mapIndexedNotNull { index, geometry -> if (!geometry.usable) index else null }
            if (weakPairs.isNotEmpty()) {
                weakPairs.take(4).forEach { index ->
                    val geometry = geometries[index]
                    warnings += "Weak geometry between ${featureSets[index].file.name} and ${featureSets[index + 1].file.name}: ${geometry.poseInliers} recovered-pose inliers. Other strong segments are still evaluated."
                }
                if (weakPairs.size > 4) warnings += "${weakPairs.size - 4} additional weak adjacent pair(s) were found."
            }

            if (connectedCameras < featureSets.size) {
                warnings += "$connectedCameras of ${featureSets.size} cameras belong to the largest connected segment. Disconnected cameras can be recovered later with bridge photos or graph-based matching."
            }
            if (combined.size < 300) {
                warnings += "Only ${combined.size} combined sparse points survived filtering. This remains a sparse pre-bundle-adjustment cloud."
            }
            if (featureSets.map { it.intrinsicsSource }.distinct().size > 1) {
                warnings += "Mixed camera-intrinsic estimates were detected across the photo set."
            }
            warnings += if (CameraCalibrationManager.activeProfile() != null) "v0.26 Stage 3 removes calibrated lens distortion from matched feature coordinates before every adjacent essential-matrix/pose solve." else "No compatible active camera calibration; Stage 3 uses fallback pinhole geometry."
            warnings += "Stage 3 still uses unit-length adjacent translations and largest contiguous-component selection; Stage 4 refines translations, while graph/loop recovery remains a later upgrade."

            val averageFocal = featureSets.map { it.focalPixels }.average()
            val intrinsicsSource = featureSets.map { it.intrinsicsSource }.distinct().let { sources ->
                if (sources.size == 1) sources.first() else "Mixed estimates"
            }

            onProgress(1f, "Multi-view sparse reconstruction complete")
            MultiViewReconstructionReport(
                engine = "OpenCV distortion-aware largest-component sequential pose chaining 4.14 / v0.26",
                photosRequested = featureSets.size,
                connectedCameras = connectedCameras,
                connectedPairs = connectedPairs,
                rawTriangulatedPoints = rawPointCount,
                combinedPoints = combined.size,
                focalPixels = averageFocal,
                intrinsicsSource = intrinsicsSource,
                pairEvaluations = pairEvaluations,
                cameras = cameraSummaries,
                points = combined,
                warnings = warnings,
                readyForBundleAdjustment = connectedCameras >= 4 && connectedPairs >= 3 && combined.size >= 200
            )
        } finally {
            featureSets.forEach { it.descriptors.release() }
            orb.clear()
            matcher.clear()
        }
    }

    private fun decodeScaled(file: File): android.graphics.Bitmap? =
        ExifBitmapLoader.decodeScaled(file, MAX_IMAGE_SIDE)

    private fun estimateFocalPixels(file: File, width: Int, height: Int): Pair<Double, String> {
        CameraCalibrationManager.focalEstimate(width, height)?.let { return it }
        val focal35 = runCatching {
            ExifInterface(file).getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
        }.getOrDefault(0)
        if (focal35 > 0) {
            val imageDiagonal = sqrt(width.toDouble() * width + height.toDouble() * height)
            val focalPixels = focal35.toDouble() * imageDiagonal / 43.2666153
            return focalPixels to "EXIF 35mm-equivalent focal length"
        }
        return (0.9 * max(width, height)) to "Fallback 0.9× max image dimension"
    }

    private fun cameraMatrix(width: Int, height: Int, focal: Double): Mat {
        CameraCalibrationManager.intrinsicsFor(width, height)?.let { intr ->
            val calibrated = Mat.eye(3, 3, CvType.CV_64F)
            calibrated.put(0, 0, intr.fx); calibrated.put(1, 1, intr.fy)
            calibrated.put(0, 2, intr.cx); calibrated.put(1, 2, intr.cy)
            return calibrated
        }
        val k = Mat.eye(3, 3, CvType.CV_64F)
        k.put(0, 0, focal)
        k.put(1, 1, focal)
        k.put(0, 2, width / 2.0)
        k.put(1, 2, height / 2.0)
        return k
    }

    private fun countMask(mask: Mat): Int {
        if (mask.empty()) return 0
        var count = 0
        val total = mask.rows() * mask.cols()
        for (i in 0 until total) {
            val value = if (mask.rows() == 1) mask.get(0, i) else mask.get(i, 0)
            if ((value?.getOrNull(0) ?: 0.0) != 0.0) count++
        }
        return count
    }

    private fun maskValue(mask: Mat, index: Int): Boolean {
        if (mask.empty()) return true
        val value = if (mask.rows() == 1) mask.get(0, index) else mask.get(index, 0)
        return (value?.getOrNull(0) ?: 0.0) != 0.0
    }

    private fun extractPoints(homogeneous: Mat, mask: Mat): List<SparsePoint> {
        if (homogeneous.rows() != 4) return emptyList()
        val points = ArrayList<SparsePoint>(homogeneous.cols())
        for (i in 0 until homogeneous.cols()) {
            if (!maskValue(mask, i)) continue
            val xh = homogeneous.get(0, i)?.getOrNull(0) ?: continue
            val yh = homogeneous.get(1, i)?.getOrNull(0) ?: continue
            val zh = homogeneous.get(2, i)?.getOrNull(0) ?: continue
            val wh = homogeneous.get(3, i)?.getOrNull(0) ?: continue
            if (!xh.isFinite() || !yh.isFinite() || !zh.isFinite() || !wh.isFinite() || abs(wh) < 1e-9) continue
            val x = xh / wh
            val y = yh / wh
            val z = zh / wh
            if (!x.isFinite() || !y.isFinite() || !z.isFinite() || z <= 0.0) continue
            val norm = sqrt(x * x + y * y + z * z)
            if (norm > 0.0 && norm < 1000.0) points += SparsePoint(x, y, z)
        }
        return trimExtremeDepth(points)
    }

    private fun trimExtremeDepth(points: List<SparsePoint>): List<SparsePoint> {
        if (points.size < 20) return points
        val sorted = points.map { it.z }.sorted()
        val low = sorted[(sorted.size * 0.02).toInt().coerceIn(0, sorted.lastIndex)]
        val high = sorted[(sorted.size * 0.98).toInt().coerceIn(0, sorted.lastIndex)]
        return points.filter { it.z in low..high }
    }

    private fun mat3(mat: Mat): DoubleArray {
        val out = DoubleArray(9)
        for (r in 0..2) for (c in 0..2) {
            out[r * 3 + c] = mat.get(r, c)?.getOrNull(0) ?: if (r == c) 1.0 else 0.0
        }
        return out
    }

    private fun vec3(mat: Mat): DoubleArray = doubleArrayOf(
        mat.get(0, 0)?.getOrNull(0) ?: 0.0,
        mat.get(1, 0)?.getOrNull(0) ?: 0.0,
        mat.get(2, 0)?.getOrNull(0) ?: 0.0
    )

    private fun identity3(): DoubleArray = doubleArrayOf(
        1.0, 0.0, 0.0,
        0.0, 1.0, 0.0,
        0.0, 0.0, 1.0
    )

    private fun multiply3(a: DoubleArray, b: DoubleArray): DoubleArray {
        val out = DoubleArray(9)
        for (r in 0..2) {
            for (c in 0..2) {
                out[r * 3 + c] =
                    a[r * 3] * b[c] +
                    a[r * 3 + 1] * b[3 + c] +
                    a[r * 3 + 2] * b[6 + c]
            }
        }
        return out
    }

    private fun multiply3Vec(a: DoubleArray, v: DoubleArray): DoubleArray = doubleArrayOf(
        a[0] * v[0] + a[1] * v[1] + a[2] * v[2],
        a[3] * v[0] + a[4] * v[1] + a[5] * v[2],
        a[6] * v[0] + a[7] * v[1] + a[8] * v[2]
    )

    private fun transpose3(a: DoubleArray): DoubleArray = doubleArrayOf(
        a[0], a[3], a[6],
        a[1], a[4], a[7],
        a[2], a[5], a[8]
    )

    private fun composePose(current: Pose, relR: DoubleArray, relT: DoubleArray): Pose {
        val nextR = multiply3(relR, current.r)
        val rotatedT = multiply3Vec(relR, current.t)
        val nextT = doubleArrayOf(
            rotatedT[0] + relT[0],
            rotatedT[1] + relT[1],
            rotatedT[2] + relT[2]
        )
        return Pose(nextR, nextT)
    }

    private fun cameraToWorld(point: SparsePoint, pose: Pose): SparsePoint? {
        val camera = doubleArrayOf(point.x, point.y, point.z)
        val shifted = doubleArrayOf(
            camera[0] - pose.t[0],
            camera[1] - pose.t[1],
            camera[2] - pose.t[2]
        )
        val world = multiply3Vec(transpose3(pose.r), shifted)
        if (!world.all { it.isFinite() }) return null
        val norm = sqrt(world[0] * world[0] + world[1] * world[1] + world[2] * world[2])
        if (norm <= 0.0 || norm > 5000.0) return null
        return SparsePoint(world[0], world[1], world[2])
    }

    private fun cameraSummary(index: Int, photo: String, pose: Pose, connected: Boolean): CameraPoseSummary {
        val rt = transpose3(pose.r)
        val negT = doubleArrayOf(-pose.t[0], -pose.t[1], -pose.t[2])
        val center = multiply3Vec(rt, negT)
        return CameraPoseSummary(
            photo = photo,
            index = index,
            connected = connected,
            x = center[0],
            y = center[1],
            z = center[2]
        )
    }

    private fun voxelDownsample(points: List<SparsePoint>, voxel: Double): List<SparsePoint> {
        if (points.isEmpty()) return emptyList()
        val cells = LinkedHashMap<String, DoubleArray>()
        points.forEach { point ->
            val ix = (point.x / voxel).roundToInt()
            val iy = (point.y / voxel).roundToInt()
            val iz = (point.z / voxel).roundToInt()
            val key = "$ix:$iy:$iz"
            val acc = cells[key]
            if (acc == null) {
                cells[key] = doubleArrayOf(point.x, point.y, point.z, 1.0)
            } else {
                acc[0] += point.x
                acc[1] += point.y
                acc[2] += point.z
                acc[3] += 1.0
            }
        }
        return cells.values.map { acc ->
            val count = acc[3].coerceAtLeast(1.0)
            SparsePoint(acc[0] / count, acc[1] / count, acc[2] / count)
        }
    }

    private fun rotationAngleDegrees(r: Mat): Double {
        if (r.rows() != 3 || r.cols() != 3) return 0.0
        val trace = (r.get(0, 0)?.getOrNull(0) ?: 1.0) +
            (r.get(1, 1)?.getOrNull(0) ?: 1.0) +
            (r.get(2, 2)?.getOrNull(0) ?: 1.0)
        val cosAngle = ((trace - 1.0) / 2.0).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(cosAngle))
    }
}
