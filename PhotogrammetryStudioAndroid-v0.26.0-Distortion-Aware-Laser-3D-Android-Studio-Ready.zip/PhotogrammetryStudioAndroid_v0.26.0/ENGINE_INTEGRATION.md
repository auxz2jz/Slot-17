# Engine Integration

## v0.3 milestone: OpenCV on Android
The app now begins real on-device computer vision using the official OpenCV Android AAR (`org.opencv:opencv:4.14.0`). It is downloaded by Gradle at build time and bundled in the app; the installed scanner does not contact GitHub for this processing.

Current implemented stage:
1. Decode reduced in-memory working images (original photos remain unchanged).
2. Detect ORB visual keypoints/descriptors.
3. Match adjacent images with Hamming k-NN matching.
4. Apply Lowe-style ratio filtering.
5. Report good-match counts and overlap quality.

Next reconstruction stage:
1. Geometrically verify descriptor matches with RANSAC.
2. Estimate relative camera motion.
3. Triangulate initial 3D points.
4. Expand to additional views.
5. Bundle-adjust camera poses/points.
6. Display a sparse point cloud.

The existing COLMAP/OpenMVG/OpenMVS/AliceVision/Meshroom/ODM/MicMac source collection remains available for later engine/library reuse where practical on Android.


## v0.4 sparse geometry milestone

After ORB feature matching, the app now tests adjacent image pairs with an essential matrix and RANSAC, recovers a relative two-camera pose, and triangulates 3D points from the best verified pair. The cloud is saved locally and exportable as ASCII PLY.

This is intentionally not presented as a finished photogrammetry model: translation scale is arbitrary and the current cloud uses one image pair. The next engine milestone is multi-view track building, camera-pose expansion, and bundle adjustment before dense reconstruction.


## v0.5 multi-view milestone

The app now chains relative camera poses from adjacent images into one arbitrary-scale coordinate system and transforms each adjacent pair's triangulated sparse points into that shared frame. A simple voxel merge reduces duplicate points. The result is a combined sparse cloud and approximate camera path.

This is intentionally pre-bundle-adjustment. `recoverPose` provides translation direction up to scale, so v0.5 uses unit-length adjacent baselines. Scale is arbitrary and drift accumulates. The next geometry milestone is shared multi-image tracks plus bundle adjustment/loop consistency before any dense reconstruction work.


- v0.5.1: multi-view no longer aborts at the first weak adjacent link; it evaluates all pairs and reconstructs the largest connected camera segment.


## v0.6.0 shared-track bundle milestone

The v0.5.1 cloud is a merge of independently triangulated adjacent-pair points. Full bundle adjustment requires shared observations of the same feature across multiple photos, so v0.6 first builds explicit 3+ view ORB tracks within the largest connected camera component.

v0.6 then runs a bounded on-device nonlinear refinement:
1. Hold camera rotations and intrinsics fixed from the sequential pose solution.
2. Triangulate shared feature tracks.
3. Alternate 3D-point optimization and camera-translation optimization using reprojection error.
4. Keep the first two cameras fixed to remove gauge/scale freedom.
5. Use Huber weighting for outliers and remove high-error tracks after refinement.
6. Report initial/final RMS reprojection error and export the refined sparse cloud.

This is intentionally a limited bundle-adjustment milestone. The next optimization stage can add rotation/intrinsic refinement and graph/loop-closure constraints before dense reconstruction.

## v0.7.0 first dense stereo pair

The first dense stage deliberately uses one already verified sparse pair before full multi-pair fusion.

1. Recompute ORB matches and RANSAC essential geometry for the saved best pair.
2. Recover relative pose and stereo-rectify both working images.
3. Run OpenCV StereoSGBM at a mobile-friendly working resolution.
4. Convert disparity to floating point and reproject through the stereo Q matrix.
5. Reject non-finite/negative/extreme-depth samples and trim depth outliers.
6. Cap the exported point set for practical Android persistence/export.
7. Persist/export a dense-pair report and PLY with report identity metadata.

The recoverPose translation baseline remains unit/arbitrary scale and lens distortion is assumed zero in this milestone. Multi-pair dense fusion, calibrated distortion, full rotation/intrinsic bundle adjustment, meshing, and texturing remain future stages.


## v0.7.1 adaptive disparity correction

The v0.7 device run passed functionally but exposed a quality artifact: the dense preview appeared stretched/cone-like. The exported report showed a generic SGBM search interval that did not necessarily cover the verified object's actual rectified disparity.

v0.7.1 keeps the same stereo pipeline but derives a robust 5th/50th/95th percentile disparity distribution from the recovered-pose inliers after stereo rectification. The SGBM minimum disparity and search width are then padded around that observed band.

Because the sparse pair and dense pair use the same arbitrary unit baseline, Euclidean point radius is comparable between the sparse and rectified dense frames. A broad sparse-radius band is therefore used as an optional object-depth prior to reject far-background dense samples. If too few guided points survive, the implementation falls back to the dense candidates rather than failing.

The preview also uses a robust 95th-percentile cloud extent so isolated extreme points do not shrink the visible target geometry.

After this corrected one-pair result is validated, continue to multi-pair dense fusion rather than adding another separate reconstruction branch.

## v0.8.0 multi-pair dense fusion
v0.8 stays on the dense-reconstruction path established in v0.7/v0.7.1 but no longer trusts one stereo pair as the final geometry source.

Pipeline:
1. Read the largest connected multi-view component and refined camera centers.
2. Recompute adjacent relative rotations for the connected component.
3. Select a distributed subset of verified connected pairs for the first mobile fusion milestone.
4. Run adaptive StereoSGBM per selected pair.
5. Reject pairs with extremely low parallax or insufficient verified-band dense samples.
6. Rotate points out of the rectified-left-camera frame, scale them to the refined adjacent baseline, and transform them into the shared world frame.
7. Robustly trim extreme global outliers, voxel-downsample, and cap the exported fused cloud.
8. Persist/export pair-by-pair diagnostics and the fused PLY.

This remains arbitrary-scale and assumes zero lens distortion. Camera calibration, more complete dense-pair selection, and surface/mesh reconstruction remain later work.

## v0.8.1 capture/orientation integration

v0.8.1 adds a capture-quality layer without changing the established photogrammetry engine sequence.

Camera capture now supports:
- Single still capture.
- Rapid Hold: capture continuously while the shutter control is held.
- Rapid Start/Stop: tap once to start a timed sequence and tap again to stop.
- Selectable target intervals from 5 captures/sec through one capture every 5 seconds.
- Optional 3-second delayed start for mounted/rotating-camera workflows.

Rapid capture waits for each ImageCapture save callback before issuing the next still. If the phone cannot sustain the requested rate, the actual rate falls back naturally to the fastest safe serialized rate instead of piling up capture requests.

All OpenCV stages now decode image pixels through a shared EXIF-aware bitmap loader. EXIF orientation/mirror transforms are applied before ORB detection, geometric verification, bundle refinement, dense stereo, and dense fusion. Portrait/landscape file orientation should therefore be an engine concern, not a user concern.

The v0.8 fusion prerequisite was also loosened: a non-empty corrected dense seed is enough to expose/run multi-pair fusion. The fusion engine already performs its own per-pair quality rejection, so the old single-pair 1,000-point gate could incorrectly block otherwise useful connected pairs (as happened on test3 with a 713-point seed cloud).


## v0.8.2 viewer/capture stabilization

The reconstruction algorithms are intentionally unchanged in this maintenance build because two independent v0.8.1 data sets successfully reached multi-pair dense fusion. The changes improve capture reliability and observability before surface reconstruction:

1. Hold Rapid no longer keys its pointer-input coroutine on rapidActive, preventing recomposition from cancelling the active press immediately after Rapid starts.
2. Every Rapid run records the requested interval and measured sustained full-resolution throughput. A 5/sec request is a target, not a promise that the camera/JPEG/storage pipeline can sustain five full-resolution saves per second.
3. App navigation and test-guide visibility are saveable across configuration recreation; camera capture-style settings are saveable as well.
4. Point-cloud preview now applies yaw (Y), pitch (X), and roll (Z) rotations before perspective projection and supports pinch zoom plus preset orthogonal views.
5. Test reports carry recent Rapid-run diagnostics and optional notes for successful steps.

The next geometry milestone remains surface/mesh reconstruction from the multi-pair dense fused cloud.

## v0.8.3 connected-component dense recovery

The v0.8.2 test4 project contained 175 photos and successfully completed feature matching, two-view sparse reconstruction, a 100-camera largest connected component, and limited bundle refinement. Its global best sparse pair was immediately before the chosen largest connected component, so the one-pair dense stage was not anchored to geometry included in the refined camera solution.

v0.8.3 changes dense-seed selection:
1. If the saved best sparse pair belongs to the largest connected multi-view component, keep it unchanged.
2. Otherwise choose the connected adjacent pair with the strongest recovered-pose support (triangulated-point count as tie-breaker).
3. Skip the old sparse-radius guidance when a different pair is selected, because that saved sparse cloud belongs to another baseline.
4. Preserve adaptive rectified-disparity selection and all previous dense filtering.
5. Persist start/progress/success/failure events for the dense attempt so a future no-output event has an exact stage and exception in the exported test report.

This is a recovery/stability change; multi-pair fusion mathematics is unchanged.

## v0.8.4 fusion candidate preflight

The v0.8.3 recovery build fixed the 175-photo test4 dense-seed failure and produced a valid 30,000-point connected-component dense seed plus a 14,191-point fused cloud. Review of the pair diagnostics found a smaller fusion-selection issue: two selected later pairs were inside the refined 100-camera component but failed with `Missing refined pose or image file.`

The cause is the fusion engine's separately rebuilt global rotation chain. A pair can recover a valid local relative pose even when an earlier chain link failed, leaving that later pair's first camera without a shared-world rotation. v0.8.3 selected candidates from connected/pose-valid pairs before checking that shared transform availability.

v0.8.4 adds a preflight stage before distributed pair selection:
1. Keep the existing connected-pair, pose-inlier, and relative-pose checks.
2. Require both image files.
3. Require both refined camera centers from the bundle report.
4. Require a completed shared-world pose for the pair's first camera.
5. Select up to six distributed pairs only from this eligible set.
6. Record how many geometric candidates were filtered before selection.
7. If a defensive check still fails later, report the exact missing prerequisite instead of a combined generic message.

The dense-stereo math, world transform math, robust global trimming, voxel downsampling, and readiness thresholds remain unchanged. This is a candidate-selection/diagnostic robustness maintenance release before surface meshing.


## v0.9.0 Stage 7 local-neighbor surface milestone

The validated Stage 6 fused dense cloud is now used as the input to the first on-device surface stage. This is intentionally a conservative mobile validation algorithm rather than a claim of full Poisson/ball-pivoting quality.

Pipeline:
1. Reject non-finite fused points.
2. Compute robust 1st/99th percentile coordinate bounds and trim isolated extremes with padding so outliers do not dominate scale.
3. Voxel-average the cloud, increasing voxel size only as needed to remain below the mobile vertex cap.
4. Build a 3D spatial hash for local-neighbor queries.
5. Estimate local point spacing from nearest neighbors.
6. Form candidate local triangles only when all edges fit adaptive local/global limits.
7. Reject highly stretched and nearly degenerate triangles.
8. Orient each accepted face approximately outward relative to the cloud centroid.
9. Cap the first mobile mesh at 30,000 faces.
10. Persist the mesh and export OBJ plus triangle PLY.

The first viewer is wireframe so triangle connectivity can be inspected without requiring normals/materials. Later mesh stages can replace or augment this algorithm with stronger surface reconstruction, normal estimation/orientation, smoothing, hole filling, component filtering, and texture projection.


## v0.9.1 topology cleanup

v0.9.0 proved that the device can build and export triangle surfaces, but combinatorial local neighbor pairs create overlapping faces. v0.9.1 changes Stage 7 to an angularly ordered local-fan strategy and applies explicit topology cleanup.

Pipeline additions:
1. Estimate a local tangent frame from non-collinear neighbors.
2. Sort nearby points by angle around that local frame.
3. Propose adjacent fan triangles rather than every neighbor-pair combination.
4. Rank candidate quality and enforce no more than two faces per undirected edge.
5. Remove only tiny disconnected face fragments.
6. Remove unused vertices and compact indices.
7. Report boundary/non-manifold/component statistics.

The algorithm is still an open-surface mobile reconstruction, not a watertight Poisson implementation. Boundary edges remain a measured input for the next cleanup milestone.


## v0.9.2 state-management maintenance

No geometry algorithm changes are made in v0.9.2.

The reconstruction pipeline now treats each stage as an explicit invalidation boundary. Rebuilding a stage clears that stage and all later stages from both in-memory UI state and persisted reports/models before processing begins. This fixes the stale Stage 7 card observed during v0.9.1 retesting.

A full pipeline reset is also exposed to the user. It preserves the photo set and project metadata while deleting generated Stage 1–7 results. This gives repeatable from-scratch testing without deleting and re-importing hundreds of photos.

## v0.10.0 project-scoped execution and surface-quality pass

Project storage has always been organized by project ID, but v0.10.0 also scopes live execution state. A heavy job owns the project that launched it; navigation does not retarget its input/output and its callbacks cannot overwrite another project's visible live state or selected-project pointer. One heavy job is scheduled at a time until explicit multi-job scheduling is designed.

Stage 7 retains the v0.9.1 manifold local-fan connectivity and adds a conservative quality pass:
1. build adjacency from the topology-clean face list;
2. identify boundary vertices;
3. run two light Laplacian-style smoothing passes on interior vertices only;
4. calculate area-weighted vertex normals from the smoothed geometry;
5. classify boundary graph components as simple closed loops or open/branched groups;
6. count branched boundary vertices;
7. export normals with OBJ and PLY.

No hole is filled automatically in v0.10.0. The real test clouds contain many branched boundary vertices, so automatic broad filling would risk inventing geometry. The next hole stage should begin with small/simple closed loops and validate every added face for manifoldness and local shape.


## v0.11.0 conservative closed-loop capping

After v0.10.0 identifies boundary graph components, v0.11.0 extracts only components whose boundary vertices all have degree two (simple closed loops). It does not treat open or branched borders as holes.

For each simple loop, a fill is accepted only when local geometry is small, sufficiently planar, and can be triangulated to one centroid without creating excessively long, thin, or degenerate triangles. Accepted caps add one center vertex and a triangle fan. Rejected loops remain open and report the reason.

This deliberately prefers an incomplete mesh over invented geometry. Validation on the real project clouds demonstrates both branches: test4's small loop is capped; test3's stretched loop is rejected because its centroid fan would contain a poor triangle. Both remain manifold by the current edge-count test.

## Combined diagnostic contract

The app now has one upload-oriented project diagnostic text format. It serializes the same detailed information users previously exported from individual Stage 1–7 cards, plus Quick Check and the current pipeline state. Point-cloud/mesh coordinates remain in their native PLY/OBJ artifacts.

## v0.12.0 Stage 8 photo color projection

Stage 8 is the first photographic appearance pass after topology validation. It intentionally starts with per-vertex color because this gives a measurable camera-registration and coverage test before introducing UV seams and atlas generation.

Pipeline:
1. Load saved Stage 3 connected-camera graph, Stage 4 refined camera centers and Stage 7 topology-clean mesh.
2. Recompute adjacent relative camera rotations using ORB + essential matrix + recoverPose, following the same world-orientation convention used by dense fusion.
3. Decode source photos through the EXIF-normalizing bitmap loader.
4. Project each Stage 7 vertex into recovered cameras with approximate intrinsics.
5. Reject negative depth, out-of-image and strongly back-facing candidates.
6. Rank candidate views by normal facing, image-center position and camera distance.
7. Blend up to three strongest source-photo samples into one RGB value per mesh vertex.
8. Persist camera contributions, coverage statistics and vertex colors.
9. Export colored PLY/OBJ without changing Stage 7 geometry.

Known limitations at this milestone:
- camera intrinsics remain approximate;
- lens distortion is still treated as zero;
- no full triangle rasterized z-buffer/occlusion test yet;
- no UV coordinates or texture atlas yet.

These limitations are explicit so Stage 8 device diagnostics can tell us whether camera recovery and color registration are good enough to justify the UV-atlas step.


## v0.13.0 visibility refinement and texture-source preparation

Stage 8 now treats camera-pose chain breaks as recoverable when possible. If the immediately previous connected camera cannot produce a valid relative orientation, the engine tries older recovered cameras within a small four-camera window and composes the recovered relative rotation into the existing world chain. These bridge recoveries are reported separately so they can be validated rather than hidden.

For appearance visibility, each recovered camera receives a coarse image-space depth grid built from projected Stage 7 vertices. A projected vertex is usable for color/source assignment only when it is close to the nearest projected surface depth in its image cell. This is not yet full triangle rasterization, but it rejects obvious behind-surface samples that v0.12.0 could blend incorrectly.

### Stage 9 triangle source assignment

For each Stage 7 face, Stage 9 searches recovered cameras and requires all three vertices to have valid, visibility-approved image projections. It rejects effectively sub-pixel projected triangles, scores the remaining views, and persists the best source photo plus normalized source-photo coordinates for all three corners.

This deliberately separates **source-view correctness** from **atlas layout**. A later atlas stage can pack triangle islands and copy pixels using already-validated source-photo coordinates rather than deciding visibility and UV packing simultaneously.

Known limitations remain approximate intrinsics, zero lens-distortion assumption and coarse vertex-based visibility rather than a full triangle z-buffer.

## v0.14.0 Stage 10 UV texture atlas

Stage 10 consumes the exact Stage 9 triangle source assignments. Each assigned face receives its own padded atlas tile. The three source-photo coordinates from Stage 9 are rasterized barycentrically into a right-triangle tile in a PNG atlas, and a matching three-corner UV mapping is written to the OBJ.

The first atlas deliberately favors correctness over packing efficiency:
1. one tile per assigned triangle avoids accidental UV overlap;
2. tile padding plus same-face centroid color around the triangle reduces filtering bleed;
3. assigned faces use the `photo_atlas` material;
4. unassigned faces stay in the OBJ under an `untextured` gray material;
5. no Stage 7 vertices/faces are changed;
6. OBJ, MTL and PNG are packaged together in one ZIP.

This establishes a conventional textured-model export. Later work can merge neighboring triangles into UV islands, improve atlas utilization, blend seams/exposure differences, and increase source assignment coverage.


## v0.15.0 UV-island packing and textured preview

Stage 10 no longer allocates one independent atlas tile for every textured triangle. It builds face adjacency from shared mesh edges, then groups neighboring Stage 9 assignments when they use the same source photograph. Each connected group becomes one UV island whose source-photo bounding rectangle is copied into the atlas; the member triangles map into that rectangle with their original relative source coordinates preserved.

This is still conservative: islands never cross source-photo boundaries and unassigned faces remain untextured. The new in-app preview uses the generated atlas plus the persisted per-face UVs and applies them back to the Stage 7 mesh with an approximate depth-sorted renderer. Desktop OBJ/MTL/PNG export remains the authoritative standards-based model package.


## v0.16.0 appearance-quality refinement

Stage 9 remains conservative by default. The original v0.13 strict path requires all three face vertices to pass the coarse depth-visibility test. v0.16 adds a second candidate pool only for faces with no strict assignment: all three vertices must still be geometrically valid (positive depth, in image, front-facing), at least two vertices must pass visibility, projected area must remain non-trivial, and mean view score must remain above a minimum. Strict assignments always win.

Stage 10 retains v0.15 connected same-photo UV islands. Before copying source-photo regions into the atlas it samples each used source photo, estimates mean luminance while ignoring nearly clipped pixels, chooses the median used-photo luminance as the target, and applies a clamped gain of 0.82..1.22. This is an exposure normalization pass only; it intentionally avoids aggressive per-channel color correction.


## v0.17.0 neighbor-consistent Stage 9 recovery

v0.16 proved that a generic two-of-three visibility relaxation is safe but only recovers a small number of additional faces. v0.17 therefore uses mesh topology instead of relaxing the same visibility threshold again.

After strict and v0.16 fallback assignments are frozen, v0.17 builds face adjacency from shared mesh edges. A still-unassigned face may use a source photo only when at least two already-assigned neighboring faces agree on that same photo. The target face must independently pass geometric projection checks in that camera and retain at least one coarse visibility-approved vertex.

The recovery uses only the frozen strict/v0.16 assignments as voting anchors. Newly recovered faces do not vote, preventing propagation across uncertain areas. Stage 10 atlas packing and exposure normalization are unchanged.

## v0.18.0 camera calibration

A physical-camera profile is now stored independently of scan projects. The first implementation uses a planar checkerboard with 9×6 inner corners and 25 mm squares. OpenCV finds/refines the corners across multiple views and calibrateCamera solves the intrinsic matrix plus standard radial/tangential distortion coefficients.

The active profile stores fx, fy, cx, cy, k1, k2, p1, p2 and k3 together with the image dimensions, lens/profile label, device model, accepted/rejected frame counts and overall RMS reprojection error. Profiles with at least ten accepted frames and RMS <= 1.5 px become active.

v0.18 begins pipeline integration by replacing EXIF/fallback focal/principal-point values in the existing camera-matrix helpers when the working image size/orientation is compatible. Saved distortion coefficients are reported and persisted but are not yet globally applied to raster/feature undistortion; that is intentionally the next calibration pass after the profile solve is validated on-device.

Marker assistance remains separate: repeated reflective dots are useful as additional trackable visual features, while coded fiducials can provide identifiable anchors for camera pose/tracking. A known-size marker or rig dimension can later provide metric scale.

## v0.20.0 calibration-target preset integration

Physical print size is now modeled explicitly rather than assumed. `PhotoCalibrationTargetPreset` and `LaserCalibrationTargetPreset` describe the selectable target assets and geometry/layout metadata, while `CalibrationTargetManager` persists the user's current physical-target choices and provides the bundled PDF bytes for Android document export.

The two photo presets deliberately share the same mathematical checkerboard geometry (9×6 inner corners, 25.0 mm square pitch). This means changing Letter versus 12×18 changes the printable page/working margin rather than changing the object-point coordinates supplied to OpenCV. The selected preset is nevertheless embedded in new calibration profiles/reports so later diagnostics know exactly which physical print was used.

Laser presets differ in marker layout/marker size and therefore remain distinct identifiers. v0.20 stores/exports them but the v0.19 OFF/ON line detector is unchanged. Future laser-background calibration must resolve the selected preset ID before marker decoding, laser-plane recovery and triangulation.


## v0.21.0 standard print-size target integration

Photo calibration continues to solve against the same 9×6 inner-corner pattern with 25.0 mm squares regardless of page size. The page-size preset is traceability/printing metadata; it does not change the camera-calibration object-point geometry.

Laser presets are physically distinct. Letter, Legal, Ledger and 12×18 each have known panel dimensions and marker sizes/layouts. The selected preset ID must remain the future lookup key when marker decoding and laser-plane reconstruction are implemented.


## v0.22 laser diagnostic interchange
Laser Analyze attempts are now recorded independently of the detailed latest laser-line result. `reports/laser_analysis_history.jsonl` uses the shared schema v1 and is intended to be readable by the future Windows implementation. This build does not change stripe extraction or triangulation math.
